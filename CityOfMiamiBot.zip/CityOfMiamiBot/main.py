import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import getpass
import os
import re
import sys
import threading
import time
import traceback
import webbrowser

# Always run from the bot's own folder so config.json and commands/ are found,
# no matter how the bot is started (double-click, VS Code, terminal...)
BOT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BOT_DIR)
print(f"Running from: {BOT_DIR}")

from dashboard.envfile import load_env, save_env_value, upgrade_env  # noqa: E402

if upgrade_env():
    print("[Dashboard] Updated .env: DASHBOARD_HOST is now auto, so the dashboard works on your PC and on a VPS.")
load_env()

# Imported after os.chdir so config.json is read from the bot folder
from commands.Staff.wl_embed import config, simple_view, use_guild, guild_context, migrate_legacy  # noqa: E402
from commands.Staff.figs import COMMAND_FEATURES, feature_on, figs_with  # noqa: E402
from dashboard import start_dashboard, headless  # noqa: E402
from dashboard.setup import TOKEN_SHAPE, TokenError, check_token, clean_token  # noqa: E402


class BotTree(app_commands.CommandTree):
    """Runs before every slash command: picks the server's settings, and blocks commands that
    were turned off on the dashboard or belong to a fig the server hasn't turned on."""

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.guild is None:
            if interaction.type == discord.InteractionType.application_command:
                await interaction.response.send_message("Use my commands inside a server.", ephemeral=True)
            return False
        use_guild(interaction.guild)
        name = (interaction.data or {}).get("name")
        blocked = None
        if name and name in config.get("disabled_commands", []):
            blocked = ("## Command Turned Off", f"`/{name}` is turned off on the dashboard.")
        elif name in COMMAND_FEATURES and not feature_on(config, COMMAND_FEATURES[name]):
            figs = " or ".join(f"**{n}**" for n in figs_with(COMMAND_FEATURES[name]))
            blocked = ("## Fig Not Turned On", f"`/{name}` comes with the {figs} fig. Turn it on in the dashboard.")
        if blocked:
            if interaction.type == discord.InteractionType.application_command:
                await interaction.response.send_message(view=simple_view(*blocked), ephemeral=True)
            return False
        return True


def _guild_of(args):
    """The server an event came from (a message, member, reaction, interaction...)."""
    for a in args:
        if isinstance(a, discord.Guild):
            return a
        g = getattr(a, "guild", None)
        if g is not None and getattr(g, "id", None):
            return g
        gid = getattr(a, "guild_id", None)
        if gid:
            return gid
    return None


class CityBot(commands.Bot):
    async def process_commands(self, message):
        """discord.py's own text commands aren't used: prefix commands (,ban ...) run the slash commands' code (commands/Staff/prefix.py)."""
        return

    def dispatch(self, event_name, /, *args, **kwargs):
        # Every event handler starts with the settings of the server the event came from
        with guild_context(_guild_of(args)):
            super().dispatch(event_name, *args, **kwargs)


def make_bot(runner: "BotRunner") -> commands.Bot:
    intents = discord.Intents.default()
    intents.message_content = True
    intents.guilds = True
    intents.members = True

    bot = CityBot(command_prefix="!", intents=intents, tree_cls=BotTree)
    bot.start_time = time.time()

    @bot.event
    async def on_ready():
        migrate_legacy(bot)  # old single-server config.json → that server's settings (once)
        runner.state = "online"
        runner.error = None
        print(f"Bot is online as {bot.user} in {len(bot.guilds)} server(s)")
        try:
            synced = await bot.tree.sync()
            print(f"Synced {len(synced)} slash command(s): {', '.join('/' + c.name for c in synced)}")
        except Exception as e:
            print(f"Failed to sync commands: {e}")

    return bot


async def load_cogs(bot: commands.Bot):
    staff_path = './commands/Staff'

    if not os.path.exists(staff_path):
        print(f"Folder not found: {staff_path}")
        return

    for filename in sorted(os.listdir(staff_path)):
        if filename.endswith('.py') and not filename.startswith('__'):
            module_name = filename[:-3]
            if module_name in ['wl_embed', 'figs', 'kit']:  # shared helpers, not features
                continue

            try:
                await bot.load_extension(f'commands.Staff.{module_name}')
                print(f"Loaded: commands/Staff/{filename}")
            except Exception as e:
                print(f"Failed to load {filename}: {e}")
                traceback.print_exc()


# ── asking in the console (the bot token is never typed into the website) ──

def can_ask() -> bool:
    """True when the bot runs in a window someone can type in (not as a background service)."""
    try:
        return sys.stdin is not None and sys.stdin.isatty()
    except (ValueError, OSError):
        return False


def dashboard_on() -> bool:
    return os.getenv("DASHBOARD_ENABLED", "true").strip().lower() not in ("0", "false", "no", "off")


def _read(prompt: str, hidden: bool) -> str | None:
    try:
        return getpass.getpass(prompt) if hidden else input(prompt)
    except (EOFError, KeyboardInterrupt, OSError):
        return None


async def ask(prompt: str, hidden: bool = False) -> str | None:
    """Read a line without blocking the bot. None if the window can't be typed in."""
    loop = asyncio.get_running_loop()
    answer = loop.create_future()

    def work():
        text = _read(prompt, hidden)
        try:
            loop.call_soon_threadsafe(lambda: answer.done() or answer.set_result(text))
        except RuntimeError:
            pass  # the bot already stopped

    # a daemon thread, so Ctrl+C still closes the bot while it waits for an answer
    threading.Thread(target=work, daemon=True).start()
    return await answer


def banner(*lines: str):
    print()
    print("=" * 70)
    for line in lines:
        print(line)
    print("=" * 70)


async def ask_token(runner: "BotRunner", reason: str) -> bool:
    """Ask for the bot token until Discord accepts one, then save it to .env."""
    banner(reason,
           "  1. Open discord.com/developers/applications and pick your bot.",
           "  2. Go to Bot, click Reset Token and copy it.",
           "  3. On the same page, turn on Server Members Intent and Message Content Intent.",
           "Paste the token here and press Enter. It stays hidden while you paste.")
    while True:
        raw = await ask("Bot token: ", hidden=True)
        if raw is None:
            return False
        token = clean_token(raw)
        if not token:
            print("Nothing was pasted. Right-click (or Ctrl+V) to paste, then press Enter.")
            continue
        if not TOKEN_SHAPE.match(token):
            print("That doesn't look like a bot token. It's a long code with two dots in it, from the Bot page.")
            continue
        try:
            info = await check_token(token)
        except TokenError as e:
            print(e)
            if e.wrong_token:
                continue
            info = None  # couldn't reach Discord to check: save it and let the bot try
        runner.save_token(token)
        print(f"Token saved in the .env file. Starting {info['name'] if info else 'the bot'}...")
        return True


async def ask_client_secret():
    """The website's only login is Login with Discord, which needs the bot's Client Secret."""
    banner("The website logs people in with Discord. For that it needs your bot's Client Secret.",
           "  1. discord.com/developers/applications → your bot → OAuth2.",
           "  2. Copy the Client Secret (click Reset Secret if you can't see it).",
           "Paste it here and press Enter (it stays hidden). Press Enter on its own to skip:",
           "nobody can log in to the website until it's added.")
    while True:
        raw = await ask("Client secret: ", hidden=True)
        secret = (raw or "").strip()
        if not secret:
            print("Skipped. Put it in the .env file as DISCORD_CLIENT_SECRET=... when you're ready.")
            return
        if not re.match(r"^[A-Za-z0-9_-]{20,64}$", secret):
            print("That doesn't look like a client secret. Copy it again from OAuth2 (not the token, not the public key).")
            continue
        save_env_value("DISCORD_CLIENT_SECRET", secret)
        print("Client secret saved in the .env file. Next, add the redirects listed below on that OAuth2 page.")
        return


def offer_netlify() -> bool:
    """Not set up yet, not skipped before, and the website doesn't already have its own address (a domain, a proxy)."""
    from dashboard import netlify
    own = os.getenv("DASHBOARD_URL", "").strip()
    behind_proxy = os.getenv("DASHBOARD_BEHIND_PROXY", "").strip().lower() in ("1", "true", "yes", "on")
    return netlify.needs_setup() and not behind_proxy and (not own or ".netlify.app" in own)


async def ask_netlify():
    """One time: put the website on Netlify at a free yourname.netlify.app address (see dashboard/netlify.py)."""
    from dashboard import netlify
    banner("Put the website online at a free yourname.netlify.app address? (optional)",
           "Each time the bot starts, it uploads the website to Netlify and connects it to this PC by itself.",
           "Nothing to install. You only need a Netlify access token, once:",
           "  1. Log in (or sign up for free) at app.netlify.com.",
           f"  2. Open {netlify.TOKEN_PAGE}",
           "     and click New access token.",
           "  3. Type any description, pick when it expires, click Generate token and copy it.",
           "Paste it here and press Enter (it stays hidden). Press Enter on its own to skip.")
    while True:
        raw = await ask("Netlify token: ", hidden=True)
        if raw is None:
            return
        token = raw.strip()
        if not token:
            save_env_value("NETLIFY_SITE", "off")
            print("Skipped. To set it up later, remove the NETLIFY_SITE=off line from the .env file and restart the bot.")
            return
        try:
            user, _, _ = await netlify.check_setup(token)
            print(f"Token works{' (' + user['full_name'] + ')' if user.get('full_name') else ''}.")
        except netlify.NetlifyError as e:
            if e.status == 401:
                print("Netlify didn't accept that token. Copy it again (Netlify only shows it once, so make a new one if you need to).")
                continue
            print(f"{e} Keeping the token anyway: the bot tries again when it starts.")
        break

    old = os.getenv("DASHBOARD_URL", "")
    suggested = netlify.site_name(old) if ".netlify.app" in old else None
    print()
    print("Now the website's name: it becomes NAME.netlify.app. Type the name of a site you already have")
    print("on Netlify to use that one, or a new name (letters, numbers and dashes).")
    while True:
        raw = await ask(f"Site name{f' (press Enter for {suggested})' if suggested else ''}: ")
        if raw is None:
            return
        name = netlify.site_name(raw) if raw.strip() else suggested
        if not name:
            print("Use only letters, numbers and dashes, like zyrix-bot.")
            continue
        made = None
        try:
            _, _, made = await netlify.check_setup(token, name)
        except netlify.NetlifyError as e:
            print(e)
            if e.status in (403, 422):
                continue
            if e.status == 401:
                return
            print("Keeping the name anyway: the bot tries again when it starts.")
        save_env_value("NETLIFY_TOKEN", token)
        save_env_value("NETLIFY_SITE", name)
        url = netlify.site_url(name)
        print(("Made your new site " if made else "Using your site ") + url + ". Saved in the .env file.")
        if suggested:
            # the old by-hand Netlify setup: the bot handles the address now
            save_env_value("DASHBOARD_URL", "")
            print("Cleared the old DASHBOARD_URL in .env: the bot uses the Netlify address by itself now.")
        print(f"One last thing, once: add {url}/callback in the Developer Portal (your bot → OAuth2 → Redirects).")
        return


NO_TOKEN = ("No bot token. Put it in the .env file as DISCORD_TOKEN=your-token, "
            "or start the bot in a window (py main.py) and paste it when asked.")
INTENTS_HELP = ("Discord blocked the bot because Server Members Intent and Message Content Intent are turned off. "
                "Turn both on at discord.com/developers/applications → your bot → Bot.")
BAD_TOKEN = "Discord didn't accept the bot token. It may have been reset."


class BotRunner:
    """Runs the bot, and starts it again after the console fixes a problem (a new token, intents turned on)."""

    def __init__(self):
        self.token = os.getenv("DISCORD_TOKEN", "").strip()
        self.bot: commands.Bot | None = None
        self.state = "offline"   # offline → starting → online
        self.error: str | None = None
        self._task: asyncio.Task | None = None
        self._asking = False

    def save_token(self, token: str):
        self.token = token
        save_env_value("DISCORD_TOKEN", token)

    async def start(self, token: str | None = None):
        if token:
            self.token = token
        await self.stop()
        bot = make_bot(self)
        await load_cogs(bot)
        self.bot = bot
        self.state, self.error = "starting", None
        self._task = asyncio.create_task(self._run(bot))

    async def _run(self, bot: commands.Bot):
        try:
            await bot.start(self.token)
        except discord.LoginFailure:
            self._failed(bot, BAD_TOKEN, "token")
        except discord.PrivilegedIntentsRequired:
            self._failed(bot, INTENTS_HELP, "intents")
        except discord.ConnectionClosed as e:
            if e.code == 4004:
                self._failed(bot, BAD_TOKEN, "token")
            else:
                self._failed(bot, f"Lost the connection to Discord (code {e.code}).", "retry")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            traceback.print_exc()
            self._failed(bot, f"The bot stopped: {e}", "retry")

    def _failed(self, bot: commands.Bot, message: str, fix: str):
        if bot is not self.bot:
            return  # an old bot we already replaced
        self.state, self.error = "offline", message
        print(f"[Bot] {message}")
        if can_ask() and not self._asking:
            asyncio.get_running_loop().create_task(self._console_fix(fix, message))
        elif fix == "token":
            print("[Bot] Put the new token in the .env file as DISCORD_TOKEN=..., then restart the bot.")
        else:
            print("[Bot] Fix it, then restart the bot.")

    async def _console_fix(self, fix: str, message: str):
        """Fix the problem right here in the console, then start the bot again."""
        self._asking = True
        try:
            if fix == "token":
                ok = await ask_token(self, message + " Paste the current one.")
            else:
                ok = await ask("Fix it, then press Enter here to start the bot again: ") is not None
            if ok:
                await self.start()
        finally:
            self._asking = False

    async def stop(self):
        bot, self.bot = self.bot, None
        if bot is None:
            return
        for name in list(bot.extensions):
            try:
                await bot.unload_extension(name)
            except Exception:
                pass
        if not bot.is_closed():
            await bot.close()


async def main():
    runner = BotRunner()
    first_time = False

    if not runner.token:
        if not can_ask() or not await ask_token(runner, "The bot needs its token to start (only the first time)."):
            print(NO_TOKEN)
            return
        first_time = True
    if dashboard_on() and not os.getenv("DISCORD_CLIENT_SECRET", "").strip() and can_ask():
        await ask_client_secret()
    if dashboard_on() and can_ask() and offer_netlify():
        await ask_netlify()

    url = await start_dashboard(runner)  # the website (see dashboard/ and the .env file)
    await runner.start()

    # First setup on a computer with a screen: open the website (never on a VPS)
    if first_time and url and not headless() and os.getenv("DASHBOARD_OPEN_BROWSER", "true").lower() not in ("0", "false", "no", "off"):
        try:
            webbrowser.open(url)
        except Exception:
            pass

    await asyncio.Event().wait()  # keep running until the window is closed / Ctrl+C


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Bot stopped.")
