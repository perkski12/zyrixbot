/* The public pages: the home page, your servers, and bot settings (bot owner only). */
'use strict';

function figCode(f) {
  return f.name.replace(/ Server$/, '').toUpperCase();
}

function figName(id) {
  const f = (S.public?.figs || S.data?.figs?.figs || []).find(x => x.id === id);
  return f ? f.name.replace(/ Server$/, '') : id;
}

function serverIcon(g, cls = '') {
  const el = h('span', { class: `server-icon ${cls}` });
  if (g.icon) el.style.backgroundImage = `url("${g.icon}")`;
  else el.textContent = (g.name || '?').slice(0, 1).toUpperCase();
  return el;
}

/** Where Servers goes. Logged out, it logs you in with Discord first, then shows your servers. */
function serversHref() {
  if (S.session?.user || !S.session?.methods?.discord) return '#/servers';
  // Opened a server's link while logged out: go back to that page after logging in
  const next = /^#\/(s\/\d+|bot)/.test(location.hash) ? location.hash.split('?')[0] : '#/servers';
  return '/login/discord?next=' + encodeURIComponent(next);
}

function serversButton(cls = '') {
  return h('a', { class: `btn ${cls}`, href: serversHref() }, icon('servers'), 'Servers');
}

const Site = {
  /** The header and footer around the public pages. */
  frame(content) {
    App.leaveServer();
    const me = S.session?.user;
    const head = h('header', { class: 'site-head' },
      h('a', { class: 'site-brand', href: '#/', 'aria-label': `${BRAND.name} home page` }, brandMark('head')),
      h('nav', { class: 'site-actions', 'aria-label': 'Account' },
        me ? [
          me.bot_owner ? h('a', { class: 'btn small ghost', href: '#/bot', title: 'Bot settings', 'aria-label': 'Bot settings' }, icon('cog'), h('span', { class: 'wide-only' }, 'Bot settings')) : null,
          serversButton('small'),
          themeButton(),
          h('span', { class: 'site-me', title: `${me.name} (${howLoggedIn(me)})` },
            me.avatar ? h('img', { src: me.avatar, alt: '' }) : h('span', { class: 'avatar-blank' })),
          h('button', { class: 'btn icon small ghost', 'aria-label': 'Log out', title: 'Log out', onclick: () => App.logout() }, icon('logout')),
        ] : [themeButton(), serversButton('small')],
      ),
    );
    const foot = h('footer', { class: 'site-foot' },
      h('span', null, S.public?.name || S.session?.bot?.name || 'Discord bot'),
      h('a', { href: serversHref() }, 'Servers'),
    );
    App.root().replaceChildren(h('div', { class: 'site' }, head, h('main', { class: 'site-main', id: 'main' }, content), foot));
    window.scrollTo(0, 0);
  },

  loading(text = 'Loading') {
    return h('div', { class: 'site-wait' }, h('div', { class: 'spinner', role: 'status', 'aria-label': text }));
  },

  /* ═════════════ Home ═════════════ */

  async home({ needLogin = false } = {}) {
    const visit = App.visit;
    if (!S.public) Site.frame(Site.loading());
    if (!S.offline) {
      try {
        S.public = await api('GET', '/api/public');
      } catch { /* show what we have */ }
    }
    if (visit !== App.visit) return;

    const pub = S.public || { name: S.session?.bot?.name || 'Bot', online: false, servers: 0, members: 0, figs: [], invite: null };
    const me = S.session?.user;
    const notice = S.notice;
    S.notice = null;
    document.title = `${pub.name} · Discord bot`;

    const face = pub.avatar ? h('img', { class: 'hero-face', src: pub.avatar, alt: '' }) : h('span', { class: 'hero-face blank' });
    const inviteButton = () => pub.invite
      ? h('a', { class: 'btn primary big', href: pub.invite, target: '_blank', rel: 'noopener' }, icon('plus'), 'Add to Discord')
      : h('span', { class: 'btn primary big', 'aria-disabled': 'true' }, 'The bot is offline');
    const reach = pub.online && pub.servers
      ? `In ${pub.servers.toLocaleString()} ${pub.servers === 1 ? 'server' : 'servers'} with ${pub.members.toLocaleString()} members.`
      : null;

    const hero = h('section', { class: 'hero' },
      notice ? h('div', { class: 'note', role: 'alert' }, icon('alert'), h('div', null, notice)) : null,
      S.offline ? note(`${pub.name} is offline right now, so logging in and the dashboard are paused. This page checks back by itself.`, 'info') : null,
      needLogin && !S.offline ? note(S.session?.methods?.discord ? 'Press Servers to log in with Discord and see your servers.' : LOGIN_ERRORS.off, 'info') : null,
      h('div', { class: 'hero-bot' }, face, h('b', null, pub.name),
        h('span', { class: pub.online ? 'online' : 'offline' }, pub.online ? 'Online' : 'Offline')),
      h('h1', null, 'Zyrix All in one bot'),
      h('p', { class: 'hero-lead' },
        `Add ${BRAND.name} to your Discord, turn on the figs that fit your server, and the dashboard opens the tabs you need. Every command works here, as a slash command, or typed with a prefix.`),
      h('div', { class: 'hero-actions' }, inviteButton(), serversButton('big')),
      reach ? h('p', { class: 'hero-reach' }, reach) : null,
    );

    const width = Math.max(6, ...pub.figs.map(f => figCode(f).length));
    const board = h('div', { class: 'board fig-board', role: 'table', 'aria-label': 'Figs' },
      h('div', { class: 'board-row board-cols', role: 'row' },
        h('span', { role: 'columnheader' }, 'Fig'), h('span', { role: 'columnheader' }, 'What it sets up'),
        h('span', { role: 'columnheader', class: 'wide-only' }, 'Features')),
      pub.figs.map((f, i) => h('div', { class: 'board-row', role: 'row' },
        h('span', { role: 'cell' }, flapWord(figCode(f), width, i)),
        h('span', { role: 'cell', class: 'fig-what' }, h('b', null, f.name), h('span', null, f.blurb),
          h('span', { class: 'fig-list' }, f.features.map(x => x.name).join(', '))),
        h('span', { role: 'cell', class: 'fig-count wide-only' }, String(f.features.length)),
      )),
    );

    const steps = [
      ['Add the bot', 'Invite it to your server with Add to Discord. It asks for the permissions its features use.'],
      ['Open your server', 'Log in with Discord. Servers where you have Administrator or Manage Server show up, plus any where the owner gave you access.'],
      ['Turn on figs', 'Pick FiveM, Roblox, Community, Support or any mix. Their tabs open in the menu, ready to set up.'],
    ];

    Site.frame([
      hero,
      // what it does, with previews, the dashboard, commands and a last Add to Discord (showcase.js)
      ...Show.sections(pub, {
        invite: inviteButton(),
        figs: h('section', { class: 'site-section' },
          h('div', { class: 'section-head' },
            h('h2', null, 'Figs'),
            h('p', null, "A fig is a server type. Turn on any mix in your server's dashboard and each one opens its own tabs. Features two figs share only show up once.")),
          board,
        ),
        steps: h('section', { class: 'site-section' },
          h('div', { class: 'section-head' }, h('h2', null, 'How it works')),
          h('ol', { class: 'steps' }, steps.map(([title, text]) => h('li', null, h('b', null, title), h('span', null, text)))),
        ),
      }).filter(Boolean),
    ]);
  },

  /* ═════════════ Your servers ═════════════ */

  async servers(quiet = false) {
    const visit = App.visit;
    document.title = 'Your servers';
    if (!quiet || !document.querySelector('.server-page')) Site.frame(Site.loading('Loading your servers'));

    let data;
    try {
      [data] = await Promise.all([
        api('GET', '/api/guilds'),
        S.public ? null : api('GET', '/api/public').then(p => { S.public = p; }).catch(() => null),
      ]);
    } catch (e) {
      if (visit !== App.visit || e.status === 401) return;
      return Site.frame(h('div', { class: 'site-page' },
        pageHead('Your servers'),
        note(e.message),
        h('div', { style: { marginTop: '16px' } }, h('button', { class: 'btn', onclick: () => Site.servers() }, icon('refresh'), 'Try again'))));
    }
    if (visit !== App.visit) return;
    S.guilds = data;

    if (!data.ready) {
      const bot = (await api('GET', '/api/session').catch(() => null))?.bot || {};
      if (visit !== App.visit) return;
      const offline = bot.state === 'offline';
      Site.frame(h('div', { class: 'site-page server-page' },
        pageHead('Your servers', offline ? 'The bot is offline right now.' : 'The bot is connecting to Discord. This takes a few seconds.'),
        offline
          ? note(S.session.user?.bot_owner && bot.error
            ? `${bot.error} Fix it in the bot's console (the window where it runs). This page opens your servers once the bot is back.`
            : 'Try again in a few minutes.', 'info')
          : Site.loading()));
      App.timer = setTimeout(() => { if (visit === App.visit) Site.servers(true); }, offline ? 5000 : 2000);
      return;
    }

    const me = S.session.user;
    const invite = S.public?.invite;
    const card = g => h('a', { class: 'server-card', href: `#/s/${g.id}/overview` },
      serverIcon(g, 'big'),
      h('div', { class: 'sc-body' },
        h('div', { class: 'sc-name' }, g.name),
        h('div', { class: 'sc-meta' }, `${(g.members || 0).toLocaleString()} ${g.members === 1 ? 'member' : 'members'}`,
          g.owner_view ? h('span', null, 'Bot owner access') : null),
        h('div', { class: 'sc-figs' }, g.figs.length
          ? g.figs.map(id => h('span', { class: 'tag' }, figName(id)))
          : h('span', { class: 'tag warn' }, 'No figs yet')),
      ),
      h('span', { class: 'sc-go', 'aria-hidden': 'true' }, icon('right')),
    );
    const addTile = g => h('div', { class: 'server-card add' },
      serverIcon(g),
      h('div', { class: 'sc-body' }, h('div', { class: 'sc-name' }, g.name), h('div', { class: 'sc-meta' }, 'Bot not added yet')),
      g.invite ? h('a', { class: 'btn small', href: g.invite, target: '_blank', rel: 'noopener' }, icon('plus'), 'Add bot') : null,
    );
    const lockedRow = g => h('div', { class: 'item' },
      h('div', { class: 'locked-name' }, serverIcon(g), h('div', null,
        h('div', { class: 'item-title' }, g.name),
        h('div', { class: 'item-meta' }, 'You need Administrator or Manage Server here, or the owner can add you on Dashboard access.'))),
      h('span', { class: 'tag off' }, icon('lock'), 'No access'),
    );

    let empty = null;
    if (!data.manage.length) {
      empty = h('div', { class: 'server-empty' },
        h('h2', null, me.bot_owner ? "The bot isn't in any servers yet" : 'No servers to manage yet'),
        h('p', null, me.bot_owner && !data.add.length
          ? 'Add it to a server, then come back here. This page updates when you switch back to it.'
          : data.add.length
            ? 'Add the bot to one of your servers below, or ask a server owner to give you access.'
            : "You don't have Administrator or Manage Server in any server the bot can join. Ask a server owner to give you access on their dashboard."),
        me.bot_owner && !data.add.length && invite ? h('a', { class: 'btn primary', href: invite, target: '_blank', rel: 'noopener' }, icon('plus'), 'Add to a server') : null,
      );
    }

    Site.frame(h('div', { class: 'site-page server-page' },
      h('div', { class: 'page-head with-actions' },
        h('div', null, h('h1', null, 'Your servers'), h('p', null, 'Pick a server to open its dashboard.')),
        h('button', { class: 'btn small', onclick: e => { e.currentTarget.classList.add('busy'); Site.servers(true); } }, icon('refresh'), 'Refresh'),
      ),
      empty,
      data.manage.length ? h('div', { class: 'server-grid' }, data.manage.map(card)) : null,
      data.add.length ? h('section', { class: 'server-section' },
        h('h2', null, 'Add the bot'),
        h('p', null, "Servers you manage that the bot isn't in yet."),
        h('div', { class: 'server-grid small' }, data.add.map(addTile))) : null,
      data.locked.length ? h('section', { class: 'server-section' },
        h('h2', null, 'Need access'),
        h('p', null, "The bot is in these servers, but you can't change its settings there."),
        h('div', { class: 'panel' }, h('div', { class: 'list flush' }, data.locked.map(lockedRow)))) : null,
    ));
  },

  /* ═════════════ Add the redirect (Login with Discord isn't set up for this address) ═════════════ */

  async loginSetup() {
    const visit = App.visit;
    document.title = 'Finish setting up Login with Discord';
    const next = new URLSearchParams(location.hash.split('?')[1] || '').get('next') || '#/servers';
    const safeNext = /^#\/[A-Za-z0-9/_-]{0,120}$/.test(next) ? next : '#/servers';
    Site.frame(Site.loading());
    let st;
    try {
      st = await api('GET', '/api/login-setup');
    } catch (e) {
      if (visit !== App.visit) return;
      return Site.frame(h('div', { class: 'site-page narrow' }, pageHead('Login with Discord'), note(e.message)));
    }
    if (visit !== App.visit) return;
    const login = extra => '/login/discord?next=' + encodeURIComponent(safeNext) + extra;
    if (st.ok) {
      // It's listed now (added in another tab): carry on to Discord
      return location.assign(login('&fresh=1'));
    }

    const redirect = h('code', { class: 'copy-text' }, st.redirect_uri);
    const listed = (st.listed || []).filter(Boolean);
    Site.frame(h('div', { class: 'site-page narrow login-setup' },
      pageHead('Add this address to Discord first',
        "Discord only sends people back to addresses listed on the bot's OAuth2 page, and this one isn't there yet. The bot's owner adds it once."),
      panel('Redirect to add', null, [
        h('div', { class: 'panel-body' },
          h('div', { class: 'input-row copy-row' }, redirect,
            h('button', { type: 'button', class: 'btn small', onclick: () => copyText(st.redirect_uri, 'Copied the redirect.') }, icon('copy'), 'Copy')),
          h('ol', { class: 'howto' },
            h('li', null, 'Open ', h('a', { href: st.portal, target: '_blank', rel: 'noopener' }, "your bot's OAuth2 page"), ' in the Discord Developer Portal.'),
            h('li', null, 'Under ', h('b', null, 'Redirects'), ', click ', h('b', null, 'Add Redirect'), ', paste the address above exactly as it is, and click ', h('b', null, 'Save Changes'), '.'),
            h('li', null, 'Come back here and click ', h('b', null, 'Log in with Discord'), '.'),
          ),
          listed.length ? h('div', { class: 'listed' },
            h('div', { class: 'row-help' }, listed.length === 1 ? 'Listed there now (a different address, so it doesn\'t count for this one):' : 'Listed there now (different addresses, so they don\'t count for this one):'),
            h('ul', null, listed.map(u => h('li', null, h('code', null, u))))) : null,
        ),
        h('div', { class: 'panel-foot' },
          h('a', { class: 'btn ghost', href: login('&skip=1') }, 'Go to Discord anyway'),
          h('a', { class: 'btn primary', href: login('&fresh=1') }, icon('login'), 'Log in with Discord')),
      ]),
      note(`It has to match exactly: http or https, localhost or 127.0.0.1, the port number, and nothing after /callback. Open the dashboard from another address too (your PC and the VPS)? Each address needs its own redirect.`, 'info'),
    ));
  },

  /* ═════════════ Bot settings (bot owner) ═════════════ */

  async botSettings() {
    const visit = App.visit;
    if (!S.session.user?.bot_owner) {
      toast("Only the bot's owner can open Bot settings.", { error: true });
      return go('#/servers', true);
    }
    document.title = 'Bot settings';
    Site.frame(Site.loading());
    let st;
    try {
      st = await api('GET', '/api/owner/settings');
    } catch (e) {
      if (visit !== App.visit || e.status === 401) return;
      return Site.frame(h('div', { class: 'site-page' }, pageHead('Bot settings'), note(e.message)));
    }
    if (visit !== App.visit) return;
    Site.drawBotSettings(st);
  },

  drawBotSettings(st) {
    const url = h('input', { class: 'input', id: 'bs-url', value: st.dashboard_url || '', placeholder: 'Optional', spellcheck: 'false', autocomplete: 'off' });
    const secret = h('input', {
      class: 'input', id: 'bs-secret', type: 'password', autocomplete: 'off', spellcheck: 'false',
      placeholder: st.client_secret_set ? 'Saved. Paste a new one to replace it' : 'Paste the client secret',
    });
    const redirect = h('code', { class: 'copy-text' });
    const copyBtn = h('button', { type: 'button', class: 'btn small', onclick: () => copyText(redirect.textContent, 'Copied the redirect.') }, icon('copy'), 'Copy');
    // No website address: Discord sends people back to whatever address they opened the site with
    const drawRedirect = () => {
      const base = url.value.trim().replace(/\/+$/, '') || location.origin;
      redirect.textContent = `${base}/callback`;
    };
    url.addEventListener('input', drawRedirect);
    drawRedirect();

    const save = h('button', { class: 'btn primary', type: 'submit' }, 'Save');
    const form = h('form', { onsubmit: async e => {
      e.preventDefault();
      const res = await act(save, () => api('POST', '/api/owner/settings', { dashboard_url: url.value.trim(), client_secret: secret.value.trim() }));
      if (res) {
        S.session = await api('GET', '/api/session').catch(() => S.session);
        toast(res.discord_login ? 'Saved.' : 'Saved. Logging in needs the client secret.');
        Site.drawBotSettings(res);
      }
    } },
      panel('Login with Discord', st.discord_login
        ? 'Everyone logs in with their Discord account and sees the servers they can manage. The bot token is never typed into the website.'
        : "Off: add the client secret so people can log in.", [
        h('div', { class: 'panel-body' }, h('ol', { class: 'howto' },
          h('li', null, 'Open ', h('a', { href: st.client_id ? `https://discord.com/developers/applications/${st.client_id}/oauth2` : 'https://discord.com/developers/applications', target: '_blank', rel: 'noopener' }, 'OAuth2 for your bot'), ' in the Discord Developer Portal.'),
          h('li', null, 'Under ', h('b', null, 'Redirects'), ', add the redirect shown below and save there. Open the dashboard from another address too (your PC and the VPS)? Add one for each.'),
          h('li', null, 'To change the ', h('b', null, 'Client Secret'), ', click Reset Secret there, paste the new one below and save here.'),
        )),
        row(h('label', { for: 'bs-url' }, 'Website address'), 'Only needed for a domain or HTTPS proxy, like https://dash.example.com. Empty uses the address the dashboard is opened with.', url),
        row('Redirect', 'Add this exact address under Redirects.', h('div', { class: 'input-row copy-row' }, redirect, copyBtn)),
        row(h('label', { for: 'bs-secret' }, 'Client secret'), st.client_secret_set ? 'One is saved. Leave this empty to keep it.' : null, secret),
        row('Client ID', null, h('code', { class: 'copy-text' }, st.client_id || 'Unknown until the bot is online')),
        h('div', { class: 'panel-foot' }, save),
      ]),
    );

    Site.frame(h('div', { class: 'site-page narrow' },
      pageHead('Bot settings', "Only the bot's owner sees this page. These settings are saved in the bot's .env file."),
      h('div', { class: 'stack' },
        form,
        panel('Bot owners', "Bot owners can open every server's dashboard and this page. That's the bot's owner or team in the Developer Portal, and anyone listed in BOT_OWNER_IDS in the .env file. The bot token stays in the .env file on the computer running the bot.", null),
      ),
    ));
  },
};

// Coming back to the Servers page after adding the bot in another tab: show it right away
window.addEventListener('focus', () => {
  if (location.hash === '#/servers' && S.session?.user && document.querySelector('.server-page')) Site.servers(true);
});
