/* Shared helpers and components for the dashboard. */
'use strict';

/* ───────────── state ───────────── */

const S = {
  session: null,     // { user, methods, bot }
  public: null,      // /api/public: bot name, server count, figs
  guilds: null,      // /api/guilds: the Servers page
  gid: null,         // the server whose dashboard is open
  data: null,        // everything from that server's /state
  saved: {},         // settings as the bot has them
  draft: {},         // settings as edited on the page
  errors: {},        // { key: message } from the last save
  live: [],          // functions that redraw previews when the draft changes
  page: 'overview',
};

/* ───────────── DOM ───────────── */

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'selected') el[k] = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else el.setAttribute(k, v === true ? '' : v);
    }
  }
  add(el, kids);
  return el;
}

function add(el, kids) {
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const ICONS = {
  wrench: '<path d="M14.5 3.5a5 5 0 0 0-4.8 6.4L3.5 16.1a1.9 1.9 0 0 0 2.7 2.7l6.2-6.2a5 5 0 0 0 6.4-4.8l-3 3-2.6-.6-.6-2.6z"/>',
  grid: '<rect x="3" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  shield: '<path d="M12 3l7.5 3v5.5c0 4.8-3.3 8.3-7.5 9.5-4.2-1.2-7.5-4.7-7.5-9.5V6z"/><path d="m9 12 2.2 2.2L15.5 10"/>',
  door: '<path d="M3 21h18"/><path d="M6 21V4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21"/><path d="M14.5 12h.01"/>',
  plane: '<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>',
  filter: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="m9.5 7.5 5 5m0-5-5 5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  thumbs: '<path d="M7 10v11"/><path d="M15 5.9 14 10h5.8a2 2 0 0 1 1.9 2.6l-2.3 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.8a2 2 0 0 0 1.8-1.1L12 2a3.1 3.1 0 0 1 3 3.9z"/>',
  smile: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5s1.3 1.8 3.5 1.8 3.5-1.8 3.5-1.8"/><path d="M9 9.5h.01M15 9.5h.01"/>',
  gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
  poll: '<path d="M3 21h18"/><rect x="5" y="11" width="3.5" height="7" rx="1"/><rect x="10.25" y="5" width="3.5" height="13" rx="1"/><rect x="15.5" y="8.5" width="3.5" height="9.5" rx="1"/>',
  slash: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M14.5 7 9.5 17"/>',
  key: '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 9.3-9.3M16 7l3 3M18.5 4.5l2 2"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
  external: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  chev: '<path d="m6 9 6 6 6-6"/>',
  right: '<path d="m9 18 6-6-6-6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  send: '<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
  up: '<path d="m18 15-6-6-6 6"/>',
  ticket: '<path d="M3 8a2 2 0 0 0 2-2h14a2 2 0 0 0 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 0-2 2H5a2 2 0 0 0-2-2v-2a2 2 0 0 0 0-4z"/><path d="M14 6v2M14 11v2M14 16v2"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
  panel: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h6"/><rect x="7" y="15.5" width="4" height="1.5" rx=".5"/><rect x="13" y="15.5" width="4" height="1.5" rx=".5"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  unlock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  idcard: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16a3.4 3.4 0 0 1 6.4 0M14.5 10h4M14.5 13.5h3"/>',
  login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/>',
  servers: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/>',
  rank: '<circle cx="12" cy="9" r="6"/><path d="m8.5 14-1.5 8 5-3 5 3-1.5-8"/>',
  star: '<path d="m12 3 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.4 6.8 19.1l1-5.8L3.5 9.2l5.9-.9z"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  bot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 17h5"/>',
  gavel: '<path d="m14 13-7.5 7.5a2.1 2.1 0 0 1-3-3L11 10"/><path d="m16 16 6-6M8 8l6-6M9 7l8 8"/>',
  scroll: '<path d="M8 21h11a2 2 0 0 0 2-2v-1H10v1a2 2 0 1 1-4 0V5a2 2 0 0 0-2-2H3v3h3"/><path d="M19 17V5a2 2 0 0 0-2-2H4M10 8h6M10 12h6"/>',
  trend: '<path d="m3 17 6-6 4 4 8-8"/><path d="M14 7h7v7"/>',
  bulb: '<path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.3h6c0-1 .4-1.8 1-2.3A7 7 0 0 0 12 2z"/>',
  cake: '<path d="M4 21h16v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2z"/><path d="M4 16c2 0 2-1.5 4-1.5s2 1.5 4 1.5 2-1.5 4-1.5 2 1.5 4 1.5M12 11V7M12 4h.01"/>',
  reply: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 6 6v5"/>',
  mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',
  pin: '<path d="M12 17v5"/><path d="M9 3h6l-1 6 3 4H7l3-4z"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
  pulse: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-6.4A8 8 0 1 1 21 12z"/>',
  game: '<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 11v3M5.5 12.5h3M15 12h.01M18 13.5h.01"/>',
  calendar: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 10h18"/>',
  megaphone: '<path d="M3 11v3a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"/>',
  copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M4 16V5a2 2 0 0 1 2-2h11"/>',
  cog: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
};

/* ───────────── the logo (top left) ───────────── */

const BRAND = {
  name: 'zyrix',
  // the four-point star (same shape as static/logo.svg), drawn in the text color: white on dark, black on light
  star: 'M50.00,2.92 L50.20,3.08 L51.70,11.01 L53.04,16.94 L55.29,24.58 L56.70,28.08 L58.63,31.90 L60.27,34.33 L62.21,36.67 L64.80,39.05 L68.10,41.37 L71.92,43.30 L75.42,44.71 L78.26,45.65 L84.40,47.29 L96.92,49.80 L97.08,50.00 L96.92,50.20 L88.99,51.70 L83.06,53.04 L75.42,55.29 L71.92,56.70 L68.10,58.63 L66.03,60.01 L63.33,62.21 L60.95,64.80 L58.63,68.10 L56.70,71.92 L55.29,75.42 L53.04,83.06 L51.70,88.99 L50.20,96.92 L50.00,97.08 L49.80,96.92 L47.90,87.00 L46.66,81.79 L44.71,75.42 L43.30,71.92 L41.37,68.10 L39.73,65.67 L37.79,63.33 L35.20,60.95 L31.90,58.63 L28.08,56.70 L24.58,55.29 L16.94,53.04 L11.01,51.70 L3.08,50.20 L2.92,50.00 L3.08,49.80 L13.00,47.90 L18.21,46.66 L24.58,44.71 L29.40,42.70 L31.90,41.37 L34.33,39.73 L36.67,37.79 L39.05,35.20 L41.37,31.90 L42.70,29.40 L44.71,24.58 L46.66,18.21 L47.90,13.00 L49.80,3.08Z',
};

/** The zyrix logo: the star and the name. */
function brandMark(size = '') {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 100 100');
  svg.setAttribute('class', 'brand-icon');
  svg.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('d', BRAND.star);
  svg.appendChild(path);
  return h('span', { class: `brand-mark ${size}`.trim() }, svg, h('span', { class: 'brand-name' }, BRAND.name));
}

function icon(name, cls = '') {
  const wrap = document.createElement('span');
  wrap.innerHTML = `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`;
  return wrap.firstChild;
}

/* ───────────── server calls ───────────── */

async function api(method, path, body) {
  const opts = { method, headers: { 'X-Dashboard': '1' }, credentials: 'same-origin' };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let r;
  try {
    r = await fetch(path, opts);
  } catch (e) {
    const err = new Error("Can't reach the bot. Is it still running?");
    err.status = 0;
    throw err;
  }
  let data = {};
  try { data = await r.json(); } catch { /* not JSON */ }
  if (r.status === 401) {
    App.loggedOut(data.error || 'You were logged out. Log in again.');
  }
  if (!r.ok) {
    const err = new Error(data.error || `Something went wrong (${r.status}).`);
    err.status = r.status;
    err.data = data;
    throw err;
  }
  return data;
}

/** A call to the open server's part of the API, e.g. gapi('GET', '/state'). */
function gapi(method, path, body) {
  return api(method, `/api/g/${S.gid}${path}`, body);
}

/** Go to a page of the site. Redirects replace the history entry so Back still works. */
function go(hash, replace = false) {
  if (location.hash === hash) return App.route();
  if (replace) {
    history.replaceState(null, '', hash);
    App.route();
  } else {
    location.hash = hash;
  }
}

/** Link to a page of the open server's dashboard. */
function here(page) {
  return `#/s/${S.gid}/${page}`;
}

/** Run an action from a button: shows busy state, toasts the result. */
async function act(button, fn) {
  if (button) button.classList.add('busy');
  try {
    const res = await fn();
    if (res && res.message) toast(res.message, { url: res.url });
    return res;
  } catch (e) {
    toast(e.message, { error: true });
    return null;
  } finally {
    if (button) button.classList.remove('busy');
  }
}

/* ───────────── toasts & dialog ───────────── */

function toast(message, { error = false, url = null } = {}) {
  const t = h('div', { class: 'toast' + (error ? ' error' : ''), role: error ? 'alert' : 'status' },
    icon(error ? 'alert' : 'check'),
    h('p', null, message),
    url ? h('a', { href: url, target: '_blank', rel: 'noopener' }, 'Open in Discord') : null,
  );
  document.getElementById('toasts').append(t);
  setTimeout(() => t.remove(), error ? 7000 : 4500);
}

function confirmDialog({ title, text, confirm = 'Confirm', danger = false }) {
  const dlg = document.getElementById('dialog');
  return new Promise(resolve => {
    dlg.replaceChildren(
      h('div', { class: 'dialog-body' }, h('h2', null, title), text ? h('p', null, text) : null),
      h('div', { class: 'dialog-actions' },
        h('button', { class: 'btn ghost', onclick: () => dlg.close('no') }, 'Cancel'),
        h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => dlg.close('yes') }, confirm),
      ),
    );
    dlg.onclose = () => resolve(dlg.returnValue === 'yes');
    dlg.returnValue = '';
    dlg.showModal();
  });
}

/* ───────────── time ───────────── */

function ago(unix) {
  const s = Math.max(0, Date.now() / 1000 - unix);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  const d = new Date(unix * 1000);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function span(seconds) {
  seconds = Math.max(0, Math.round(seconds));
  const d = Math.floor(seconds / 86400), hh = Math.floor(seconds % 86400 / 3600), m = Math.floor(seconds % 3600 / 60);
  if (d) return `${d}d ${hh}h`;
  if (hh) return `${hh}h ${m}m`;
  if (m) return `${m}m`;
  return `${seconds}s`;
}

/* ───────────── lookups ───────────── */

const G = {
  channel: id => S.data?.guild.channels.find(c => c.id === String(id)),
  role: id => S.data?.guild.roles.find(r => r.id === String(id)),
  user: id => S.data?.users?.find(u => u.id === String(id)),
  emojiUrl: (id, animated) => `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'webp'}?size=48`,
};

function channelName(id) {
  const c = G.channel(id);
  return c ? c.name : null;
}

function channelItems(types = ['text', 'news']) {
  const cats = {};
  for (const c of S.data.guild.channels) if (c.type === 'category') cats[c.id] = c.name;
  return S.data.guild.channels
    .filter(c => types.includes(c.type))
    .map(c => ({
      id: c.id, label: c.name, search: c.name,
      group: c.type === 'category' ? null : c.parent_id ? cats[c.parent_id] : 'No category',
      lead: () => h('span', { class: 'hash', 'aria-hidden': 'true' }, c.type === 'news' ? '»' : '#'),
      sub: c.type === 'news' ? 'Announcements' : null,
    }));
}

function roleDot(role) {
  const d = h('span', { class: 'dot' });
  if (role && role.color) d.style.background = role.color;
  return d;
}

function roleItems() {
  return S.data.guild.roles.map(r => ({
    id: r.id, label: r.name, search: r.name,
    lead: () => roleDot(r),
    sub: !r.assignable ? (r.managed ? 'Bot role' : 'Above my role') : `${r.members} ${r.members === 1 ? 'member' : 'members'}`,
  }));
}

function emojiNode(text, cls = '') {
  const m = /^<(a?):(\w+):(\d+)>$/.exec(String(text || '').trim());
  if (m) return h('img', { class: cls, src: G.emojiUrl(m[3], m[1]), alt: `:${m[2]}:` });
  return h('span', { class: cls }, text || '');
}

/* ───────────── draft settings ───────────── */

const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const copy = v => JSON.parse(JSON.stringify(v));

function get(key) { return S.draft[key]; }

function set(key, value) {
  S.draft[key] = value;
  if (S.errors[key]) {
    delete S.errors[key];
    document.querySelectorAll(`[data-key="${key}"]`).forEach(el => {
      el.classList.remove('has-error');
      el.querySelector('.field-error')?.remove();
    });
  }
  App.updateSaveBar();
  for (const fn of S.live) { try { fn(key); } catch (e) { console.error(e); } }
}

function dirtyKeys() {
  return Object.keys(S.draft).filter(k => !same(S.draft[k], S.saved[k]));
}

/* ───────────── layout pieces ───────────── */

function pageHead(title, text) {
  return h('header', { class: 'page-head' }, h('h1', null, title), text ? h('p', null, text) : null);
}

function panel(title, text, kids, { actions = null } = {}) {
  return h('section', { class: 'panel' },
    h('div', { class: 'panel-head' },
      h('div', null, h('h2', null, title), text ? h('p', null, text) : null),
      actions ? h('div', { class: 'actions' }, actions) : null,
    ),
    kids,
  );
}

function row(label, help, control, { key = null, wide = false, inline = false } = {}) {
  const err = key && S.errors[key];
  return h('div', { class: `row${wide ? ' wide' : ''}${inline ? ' inline' : ''}${err ? ' has-error' : ''}`, 'data-key': key },
    h('div', { class: 'row-label' }, label, help ? h('div', { class: 'row-help' }, help) : null),
    h('div', { class: 'row-control' }, control, err ? h('div', { class: 'field-error' }, err) : null),
  );
}

function note(text, kind = '') {
  return h('div', { class: `note ${kind}` }, icon(kind === 'good' ? 'check' : 'alert'), h('div', null, text));
}

/* ───────────── inputs bound to settings ───────────── */

function textInput(key, { placeholder = '', max = null, multiline = false, rows = 3, mono = false } = {}) {
  const el = h(multiline ? 'textarea' : 'input', {
    class: 'input', placeholder, rows: multiline ? rows : null, type: multiline ? null : 'text',
    value: get(key) ?? '', spellcheck: multiline ? 'true' : 'false',
  });
  if (mono) el.style.fontFamily = 'Consolas, monospace';
  el.id = 'f-' + key;
  const counter = max ? h('div', { class: 'counter' }) : null;
  const sync = () => {
    if (counter) {
      // only shown when getting close to the limit
      counter.textContent = `${el.value.length} / ${max}`;
      counter.hidden = el.value.length < max * 0.8;
      counter.classList.toggle('over', el.value.length > max);
    }
  };
  el.addEventListener('input', () => { set(key, el.value); sync(); });
  sync();
  return counter ? h('div', null, el, counter) : el;
}

function insertAtCursor(field, text) {
  const start = field.selectionStart ?? field.value.length, end = field.selectionEnd ?? field.value.length;
  field.value = field.value.slice(0, start) + text + field.value.slice(end);
  field.selectionStart = field.selectionEnd = start + text.length;
  field.dispatchEvent(new Event('input'));
  field.focus();
}

function placeholderHelp(key, tokens) {
  return h('div', { class: 'placeholders' }, 'Insert:',
    tokens.map(([tok, title]) => h('button', {
      type: 'button', title,
      onclick: () => insertAtCursor(document.getElementById('f-' + key), tok),
    }, tok)));
}

function toggle(key, label) {
  const input = h('input', { type: 'checkbox', checked: !!get(key), onchange: e => set(key, e.target.checked) });
  return h('label', { class: 'switch' }, input, h('span', { class: 'track' }), h('span', null, label));
}

function colorInput(key) {
  const text = h('input', { class: 'input', value: get(key) || '', maxlength: 7, spellcheck: 'false', 'aria-label': 'Hex color' });
  const swatch = h('input', { type: 'color', class: 'color-swatch', value: get(key) || '#ffffff', 'aria-label': 'Pick a color' });
  swatch.addEventListener('input', () => { text.value = swatch.value; set(key, swatch.value); });
  text.addEventListener('input', () => {
    let v = text.value.trim();
    if (v && !v.startsWith('#')) v = '#' + v;
    if (/^#[0-9a-fA-F]{6}$/.test(v)) swatch.value = v;
    set(key, v);
  });
  return h('div', { class: 'input-row' }, swatch, text);
}

function choiceCards(key, options) {
  const name = 'c-' + key;
  return h('div', { class: 'choices', role: 'radiogroup' }, options.map(o =>
    h('label', { class: 'choice' },
      h('input', { type: 'radio', name, value: String(o.value), checked: same(get(key), o.value), onchange: () => set(key, o.value) }),
      h('b', null, o.label),
      o.text ? h('span', null, o.text) : null,
    )));
}

/* ───────────── picker (channels, roles, members) ───────────── */

let openPicker = null;
document.addEventListener('mousedown', e => {
  if (openPicker && !openPicker.root.contains(e.target)) openPicker.close();
});

function picker({ items = [], value, multiple = false, placeholder = 'Pick one', searchPlaceholder = 'Search',
  onChange, search = null, emptyText = 'Nothing matches that.', addLabel = 'Add', renderChip = null, label = null }) {
  let current = multiple ? [...(value || [])] : (value ?? null);
  const known = new Map(items.map(i => [i.id, i]));
  const root = h('div', { class: 'pick' });
  let pop = null, active = 0, shown = [];

  const btn = h('button', { type: 'button', class: 'pick-btn', 'aria-haspopup': 'listbox', 'aria-expanded': 'false', 'aria-label': label });

  function itemFor(id) {
    return known.get(id) || { id, label: 'Deleted or unknown', lead: () => h('span', { class: 'hash' }, '?') };
  }

  function drawButton() {
    btn.replaceChildren();
    if (multiple) {
      btn.append(icon('plus'), h('span', { class: 'label' }, addLabel));
      return;
    }
    if (current) {
      const it = itemFor(current);
      btn.append(it.lead ? it.lead() : '', h('span', { class: 'label' }, it.label));
      const clear = h('span', { class: 'clear', role: 'button', tabindex: '-1', 'aria-label': 'Clear', title: 'Clear' }, icon('x'));
      clear.addEventListener('click', e => { e.stopPropagation(); choose(null); });
      btn.append(clear);
    } else {
      btn.append(h('span', { class: 'label placeholder' }, placeholder));
    }
    btn.append(icon('chev', 'chev'));
  }

  const chips = multiple ? h('div', { class: 'chips' }) : null;
  function drawChips() {
    if (!chips) return;
    chips.replaceChildren();
    if (!current.length) chips.append(h('span', { class: 'chips-empty' }, 'None yet'));
    for (const id of current) {
      const it = itemFor(id);
      chips.append(renderChip ? renderChip(it) : h('span', { class: 'chip' }, it.lead ? it.lead() : null, h('span', null, it.label),
        h('button', { type: 'button', 'aria-label': `Remove ${it.label}`, onclick: () => choose(id) }, icon('x'))));
    }
  }

  function choose(id) {
    if (multiple) {
      current = current.includes(id) ? current.filter(x => x !== id) : [...current, id];
      drawChips();
      if (pop) drawList();
    } else {
      current = id;
      close();
      drawButton();
    }
    onChange && onChange(multiple ? [...current] : current);
  }

  async function filtered(q) {
    if (search) {
      const res = await search(q);
      res.forEach(i => known.set(i.id, i));
      return res;
    }
    q = q.trim().toLowerCase();
    return q ? items.filter(i => (i.search || i.label).toLowerCase().includes(q)) : items;
  }

  const list = h('div', { class: 'pick-list', role: 'listbox' });
  const input = h('input', { type: 'text', placeholder: searchPlaceholder, 'aria-label': searchPlaceholder, autocomplete: 'off' });
  let seq = 0;

  async function drawList() {
    const mine = ++seq;
    const res = await filtered(input.value);
    if (mine !== seq) return;
    shown = res.filter(i => !i.disabled);
    active = Math.min(active, Math.max(0, shown.length - 1));
    list.replaceChildren();
    if (!res.length) {
      list.append(h('div', { class: 'pick-empty' }, search && !input.value.trim() ? 'Type a name to search' : emptyText));
      return;
    }
    let group;
    res.forEach(it => {
      if (it.group && it.group !== group) {
        group = it.group;
        list.append(h('div', { class: 'pick-group' }, group));
      }
      const chosen = multiple ? current.includes(it.id) : current === it.id;
      const idx = shown.indexOf(it);
      const el = h('button', {
        type: 'button', class: 'pick-item' + (chosen ? ' chosen' : ''), role: 'option',
        'aria-selected': idx === active ? 'true' : 'false', disabled: it.disabled,
        onclick: () => choose(it.id),
        onmousemove: () => { if (active !== idx) { active = idx; markActive(); } },
      }, it.lead ? it.lead() : null, h('span', null, it.label), it.sub && !chosen ? h('span', { class: 'sub' }, it.sub) : null);
      el.dataset.idx = idx;
      list.append(el);
    });
  }

  function markActive() {
    list.querySelectorAll('.pick-item').forEach(el => el.setAttribute('aria-selected', String(+el.dataset.idx === active)));
    list.querySelector(`.pick-item[data-idx="${active}"]`)?.scrollIntoView({ block: 'nearest' });
  }

  input.addEventListener('input', () => { active = 0; drawList(); });
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(shown.length - 1, active + 1); markActive(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(0, active - 1); markActive(); }
    else if (e.key === 'Enter') { e.preventDefault(); if (shown[active]) choose(shown[active].id); }
    else if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); }
    else if (e.key === 'Tab') close();
  });

  function open() {
    if (openPicker && openPicker !== self) openPicker.close();
    pop = h('div', { class: 'pick-pop' },
      h('div', { class: 'pick-search' }, icon('search'), input),
      list,
    );
    root.append(pop);
    const rect = btn.getBoundingClientRect();
    if (window.innerHeight - rect.bottom < 340 && rect.top > 360) pop.classList.add('up');
    btn.setAttribute('aria-expanded', 'true');
    input.value = '';
    active = 0;
    drawList();
    input.focus();
    openPicker = self;
  }

  function close() {
    if (!pop) return;
    pop.remove();
    pop = null;
    btn.setAttribute('aria-expanded', 'false');
    if (openPicker === self) openPicker = null;
  }

  const self = { root, close };
  btn.addEventListener('click', () => (pop ? close() : open()));
  btn.addEventListener('keydown', e => { if (e.key === 'ArrowDown' && !pop) { e.preventDefault(); open(); } });

  drawButton();
  drawChips();
  if (multiple) root.append(h('div', { class: 'pick-multi' }, chips, h('div', null, btn)));
  else root.append(btn);
  return root;
}

function channelPick(key, { multiple = false, placeholder = 'Pick a channel', types } = {}) {
  return picker({
    items: channelItems(types), value: get(key), multiple, placeholder, addLabel: 'Add channel',
    searchPlaceholder: 'Search channels', label: placeholder, onChange: v => set(key, v),
  });
}

function rolePick(key, { multiple = false, placeholder = 'Pick a role' } = {}) {
  return picker({
    items: roleItems(), value: get(key), multiple, placeholder, addLabel: 'Add role',
    searchPlaceholder: 'Search roles', label: placeholder, onChange: v => set(key, v),
  });
}

function memberItem(u) {
  return {
    id: u.id, label: u.name, sub: u.username ? '@' + u.username : null,
    lead: () => u.avatar ? h('img', { src: u.avatar, alt: '' }) : h('span', { class: 'dot' }),
  };
}

let memberTimer = null;
function searchMembers(q) {
  clearTimeout(memberTimer);
  if (!q.trim()) return Promise.resolve([]);
  return new Promise(resolve => {
    memberTimer = setTimeout(async () => {
      try {
        const res = await gapi('GET', '/members?q=' + encodeURIComponent(q.trim()));
        // remember them, so chips and mentions still show their names after the page redraws
        for (const u of res.members) if (S.data && !S.data.users.some(x => x.id === u.id)) S.data.users.push(u);
        resolve(res.members.map(memberItem));
      } catch { resolve([]); }
    }, 180);
  });
}

/** Pick people for a list setting (searches the server's members). */
function memberPick(key, { addLabel = 'Add person' } = {}) {
  return picker({
    items: (S.data.users || []).map(memberItem), value: get(key), multiple: true,
    addLabel, searchPlaceholder: 'Search members by name', search: searchMembers,
    label: addLabel, onChange: v => set(key, v),
    renderChip: it => h('span', { class: 'chip' }, it.lead ? it.lead() : null, h('span', null, it.label),
      h('button', { type: 'button', 'aria-label': `Remove ${it.label}`, onclick: () => {
        set(key, get(key).filter(x => x !== it.id));
        App.render();
      } }, icon('x'))),
  });
}

/** Copy text, with a toast either way. */
async function copyText(text, what = 'Copied.') {
  try {
    await navigator.clipboard.writeText(text);
    toast(what);
  } catch {
    toast("Couldn't copy. Select the text and copy it yourself.", { error: true });
  }
}

/* Word list with chips: type and press Enter, or paste a comma list */
function wordBox(key, { placeholder = 'Type a word and press Enter' } = {}) {
  const chips = h('div', { class: 'chips' });
  const input = h('input', { type: 'text', placeholder, 'aria-label': placeholder, autocomplete: 'off' });
  const draw = () => {
    chips.replaceChildren();
    const words = get(key) || [];
    if (!words.length) chips.append(h('span', { class: 'chips-empty' }, 'No words yet'));
    words.forEach(w => chips.append(h('span', { class: 'chip' }, h('span', null, w),
      h('button', { type: 'button', 'aria-label': `Remove ${w}`, onclick: () => { set(key, (get(key) || []).filter(x => x !== w)); draw(); } }, icon('x')))));
  };
  const commit = () => {
    const parts = input.value.split(/[,\n]/).map(s => s.trim().toLowerCase()).filter(Boolean);
    if (!parts.length) return;
    const words = [...(get(key) || [])];
    for (const p of parts) if (!words.includes(p)) words.push(p);
    set(key, words);
    input.value = '';
    draw();
  };
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); commit(); }
    else if (e.key === 'Backspace' && !input.value && (get(key) || []).length) {
      set(key, get(key).slice(0, -1)); draw();
    }
  });
  input.addEventListener('paste', () => setTimeout(commit, 0));
  input.addEventListener('blur', commit);
  draw();
  return h('div', { class: 'word-box', onclick: e => { if (e.target === e.currentTarget) input.focus(); } }, chips, input);
}

/* Emoji text field with a picker of the server's emojis */
const COMMON_EMOJI = ['👍', '👎', '✅', '❌', '🔥', '⭐', '🎉', '🎁', '💎', '👑', '🚗', '✈️', '🌴', '🏝️', '🌊', '🍹', '🎮', '🎵', '📢', '❤️', '💙', '💚', '💜', '🖤'];

function emojiField(value, onChange) {
  const show = h('span', { class: 'emoji-show' });
  const input = h('input', { class: 'input', value: value || '', placeholder: 'Emoji', title: 'A normal emoji, or a custom one like <:name:id>', 'aria-label': 'Emoji', spellcheck: 'false' });
  const drawShow = () => { show.hidden = !input.value.trim(); show.replaceChildren(emojiNode(input.value)); };
  input.addEventListener('input', () => { drawShow(); onChange(input.value.trim()); });
  const root = h('div', { class: 'emoji-field' });
  let pop = null;
  const close = () => { pop?.remove(); pop = null; document.removeEventListener('mousedown', outside); };
  const outside = e => { if (!root.contains(e.target)) close(); };
  const pickBtn = h('button', { type: 'button', class: 'btn icon', 'aria-label': 'Pick an emoji', title: 'Pick an emoji' }, icon('smile'));
  pickBtn.addEventListener('click', () => {
    if (pop) return close();
    const grid = h('div', { class: 'emoji-grid' });
    const pick = text => { input.value = text; drawShow(); onChange(text); close(); input.focus(); };
    for (const e of S.data.guild.emojis) {
      const text = `<${e.animated ? 'a' : ''}:${e.name}:${e.id}>`;
      grid.append(h('button', { type: 'button', title: `:${e.name}:`, onclick: () => pick(text) }, h('img', { src: G.emojiUrl(e.id, e.animated), alt: `:${e.name}:` })));
    }
    for (const e of COMMON_EMOJI) grid.append(h('button', { type: 'button', onclick: () => pick(e) }, e));
    pop = h('div', { class: 'pick-pop' }, grid);
    root.append(pop);
    document.addEventListener('mousedown', outside);
  });
  drawShow();
  add(root, [show, input, pickBtn]);
  return root;
}

/* ───────────── Discord message preview ───────────── */

function fillPlaceholders(text) {
  const me = S.session?.user;
  return String(text || '')
    .replaceAll('{user}', '<@0>')
    .replaceAll('{username}', me?.name || 'NewMember')
    .replaceAll('{server}', get('server_name') || S.data.guild.name)
    .replaceAll('{member_count}', String(S.data.guild.member_count));
}

function mdInline(raw) {
  // protect code spans first
  const codes = [];
  let s = esc(raw).replace(/`([^`\n]+)`/g, (m, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
  s = s.replace(/&lt;(a?):(\w{2,32}):(\d{15,22})&gt;/g, (m, a, n, id) => `<img class="dc-emoji" alt=":${n}:" src="${G.emojiUrl(id, a)}">`);
  s = s.replace(/&lt;#(\d+)&gt;/g, (m, id) => `<span class="dc-mention">#${esc(channelName(id) || 'unknown')}</span>`);
  s = s.replace(/&lt;@&amp;(\d+)&gt;/g, (m, id) => {
    const r = G.role(id);
    const c = r?.color || '#99aab5';
    return `<span class="dc-role" style="color:${c};background:${c}22">@${esc(r ? r.name : 'unknown-role')}</span>`;
  });
  s = s.replace(/&lt;@!?(\d+)&gt;/g, (m, id) => {
    const name = id === '0' ? (S.session?.user?.name || 'NewMember') : (G.user(id)?.name || 'user');
    return `<span class="dc-mention">@${esc(name)}</span>`;
  });
  s = s.replace(/&lt;t:(\d+)(?::[tTdDfFR])?&gt;/g, (m, t) => `<span class="dc-mention">${esc(new Date(t * 1000).toLocaleString())}</span>`);
  s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/__(.+?)__/g, '<u>$1</u>');
  s = s.replace(/(^|[^*\w])\*(?!\s)([^*]+?)\*(?!\w)/g, '$1<em>$2</em>');
  s = s.replace(/(^|[^_\w])_(?!\s)([^_]+?)_(?!\w)/g, '$1<em>$2</em>');
  s = s.replace(/~~(.+?)~~/g, '<s>$1</s>');
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  return s.replace(/\u0000(\d+)\u0000/g, (m, i) => `<code>${codes[+i]}</code>`);
}

function md(text) {
  const lines = fillPlaceholders(text).split('\n');
  const out = [];
  let para = [], list = [], quote = [];
  const flush = () => {
    if (para.length) { out.push(`<p>${para.map(mdInline).join('\n')}</p>`); para = []; }
    if (list.length) { out.push(`<ul>${list.map(l => `<li>${mdInline(l)}</li>`).join('')}</ul>`); list = []; }
    if (quote.length) { out.push(`<blockquote>${quote.map(mdInline).join('\n')}</blockquote>`); quote = []; }
  };
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let m;
    if ((m = /^>>> ?(.*)$/.exec(line))) {
      flush();
      quote = [m[1], ...lines.slice(i + 1)];
      break;
    }
    if ((m = /^(#{1,3}) (.+)$/.exec(line))) { flush(); out.push(`<h${m[1].length}>${mdInline(m[2])}</h${m[1].length}>`); continue; }
    if ((m = /^-# (.+)$/.exec(line))) { flush(); out.push(`<small>${mdInline(m[1])}</small>`); continue; }
    if ((m = /^\s*[-*] (.+)$/.exec(line))) { if (para.length || quote.length) flush(); list.push(m[1]); continue; }
    if ((m = /^> ?(.*)$/.exec(line))) { if (para.length || list.length) flush(); quote.push(m[1]); continue; }
    if (list.length || quote.length) flush();
    para.push(line);
  }
  flush();
  return out.join('');
}

function dcText(text) {
  return h('div', { class: 'dc-text', html: md(text) });
}

/**
 * blocks: {t:'text', md} | {t:'section', texts:[md], thumb} | {t:'sep', visible} | {t:'gallery', url} | {t:'buttons', items:[{label, emoji, primary}]}
 */
function dcMessage(blocks, { boxed = true, reactions = null, plain = null } = {}) {
  const bot = S.data.bot;
  const avatar = h('div', { class: 'dc-avatar' });
  if (bot.avatar) avatar.style.backgroundImage = `url("${bot.avatar}")`;

  const body = [];
  if (plain != null) body.push(h('div', { class: 'dc-text dc-plain', html: mdInline(fillPlaceholders(plain)) }));
  if (blocks && blocks.length) {
    const kids = blocks.map(b => {
      if (b.t === 'text') return dcText(b.md);
      if (b.t === 'section') {
        if (!b.thumb) return b.texts.map(dcText);
        return h('div', { class: 'dc-section' }, h('div', null, b.texts.map(dcText)),
          h('img', { class: 'dc-thumb', src: b.thumb, alt: '', onerror: e => { e.target.style.visibility = 'hidden'; } }));
      }
      if (b.t === 'sep') return h('div', { class: 'dc-sep' + (b.visible === false ? ' invisible' : '') });
      if (b.t === 'gallery') return h('div', { class: 'dc-gallery' }, h('img', { src: b.url, alt: '', onerror: e => { e.target.style.display = 'none'; } }));
      if (b.t === 'buttons') return h('div', { class: 'dc-buttons' }, b.items.map(it =>
        h('span', { class: 'dc-button' + (it.primary ? ' primary' : '') + (it.danger ? ' danger' : '') + (it.success ? ' success' : '') }, it.emoji ? emojiNode(it.emoji, 'dc-emoji') : null, it.label)));
      if (b.t === 'select') return h('div', { class: 'dc-select' }, h('span', null, b.placeholder || 'Pick one'), icon('chev'));
      return null;
    });
    const box = h('div', { class: boxed ? 'dc-box' : 'dc-text' }, kids);
    box.style.setProperty('--accent', /^#[0-9a-f]{6}$/i.test(get('accent_color') || '') ? get('accent_color') : '#ffffff');
    body.push(box);
  }
  if (reactions) body.push(h('div', { class: 'dc-reactions' }, reactions.map(r => h('span', { class: 'dc-reaction' }, emojiNode(r), '1'))));

  return h('div', { class: 'dc' }, h('div', { class: 'dc-msg' }, avatar, h('div', { style: { minWidth: '0' } },
    h('div', { class: 'dc-head' }, h('span', { class: 'dc-name' }, bot.name), h('span', { class: 'dc-app' }, 'APP'), h('span', { class: 'dc-time' }, 'Today at 4:20 PM')),
    body,
  )));
}

const httpOk = url => /^https?:\/\//.test(url || '');

/** Header block used by most panels: title lines + the server thumbnail if set. */
function headerBlock(texts) {
  return { t: 'section', texts, thumb: httpOk(get('thumbnail_url')) ? get('thumbnail_url') : null };
}

/** A preview column that redraws itself whenever the draft changes. */
function livePreview(title, build) {
  const slot = h('div');
  const draw = () => slot.replaceChildren(build());
  S.live.push(draw);
  draw();
  return h('aside', { class: 'sticky' }, h('div', { class: 'preview-title' }, h('span', null, title)), slot);
}

/* ───────────── split-flap letters ───────────── */

/** A word on split-flap tiles, like a departures board. */
function flapWord(text, width, row = 0, { animate = true, kind = '' } = {}) {
  const chars = String(text).toUpperCase().padEnd(width, ' ').split('');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const wrap = h('div', { class: `flaps ${kind}${animate && !reduced ? ' flip' : ''}`, role: 'img', 'aria-label': text });
  chars.forEach((ch, i) => {
    const f = h('span', { class: 'flap' + (ch === ' ' ? ' blank' : ''), 'aria-hidden': 'true' }, ch === ' ' ? '·' : ch);
    f.style.setProperty('--i', i);
    f.style.setProperty('--r', row);
    wrap.append(f);
  });
  return wrap;
}

/** ['A', 'B', 'C'] → 'A, B or C' */
function listWords(items, last = 'and') {
  if (items.length < 2) return items.join('');
  return `${items.slice(0, -1).join(', ')} ${last} ${items[items.length - 1]}`;
}

/* ───────────── light / dark ───────────── */

function currentTheme() {
  return document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
}

function themeButton() {
  const btn = h('button', { class: 'btn icon small ghost' });
  const draw = () => {
    const light = currentTheme() === 'light';
    const label = light ? 'Switch to dark mode' : 'Switch to light mode';
    btn.setAttribute('aria-label', label);
    btn.title = label;
    btn.replaceChildren(icon(light ? 'moon' : 'sun'));
  };
  btn.addEventListener('click', () => {
    const next = currentTheme() === 'light' ? 'dark' : 'light';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('com-theme', next); } catch { /* storage blocked */ }
    draw();
  });
  draw();
  return btn;
}
