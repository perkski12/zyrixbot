/* The night sky behind the whole website (dark theme): deep blue glows, a slow blue nebula
   (WebGL, drawn small and scaled up so it stays soft) and twinkling stars that shift a little
   as you scroll.
   It stops when the light theme is on or the tab is hidden, stays still for people who turn
   off animations, and runs lighter on slow computers. */
(function () {
  'use strict';
  var root = document.documentElement;
  var reduce = matchMedia('(prefers-reduced-motion: reduce)');
  var systemLight = matchMedia('(prefers-color-scheme: light)');
  var lite = (navigator.hardwareConcurrency || 8) <= 2 || (navigator.deviceMemory || 8) <= 2;
  if (lite) root.classList.add('space-lite');

  var sky = document.createElement('div');
  sky.className = 'space';
  sky.setAttribute('aria-hidden', 'true');
  var glow = document.createElement('div');
  glow.className = 'space-glow';
  var nebulaCanvas = document.createElement('canvas');
  nebulaCanvas.className = 'space-nebula';
  var starCanvas = document.createElement('canvas');
  starCanvas.className = 'space-stars';
  sky.appendChild(glow);
  sky.appendChild(nebulaCanvas);
  sky.appendChild(starCanvas);
  document.body.insertBefore(sky, document.body.firstChild);

  function dark() {
    var t = root.getAttribute('data-theme');
    return t === 'dark' || (t !== 'light' && !systemLight.matches);
  }

  /* ── nebula: streaks of blue light, drawn at 1/4 size, scaled up and blurred ── */
  var nebula = (function () {
    var gl = null;
    try {
      gl = nebulaCanvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, powerPreference: 'low-power' });
    } catch (e) { gl = null; }
    if (!gl) { nebulaCanvas.remove(); return null; }

    var vertex = 'attribute vec2 p; void main() { gl_Position = vec4(p, 0.0, 1.0); }';
    var fragment = [
      'precision mediump float;',
      'uniform vec2 res;',
      'uniform float t;',
      'float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }',
      'float noise(vec2 p) {',
      '  vec2 i = floor(p), f = fract(p);',
      '  vec2 u = f * f * (3.0 - 2.0 * f);',
      '  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);',
      '}',
      'float fbm(vec2 p) {',
      '  float v = 0.0, a = 0.5;',
      '  mat2 m = mat2(1.6, 1.2, -1.2, 1.6);',
      '  for (int i = 0; i < 4; i++) { v += a * noise(p); p = m * p; a *= 0.5; }',
      '  return v;',
      '}',
      'void main() {',
      '  vec2 uv = gl_FragCoord.xy / res;',
      '  float aspect = res.x / res.y;',
      '  vec2 p = vec2(uv.x * aspect, uv.y);',
      '  float s = t * 0.03;',
      // turn the picture so the ribbons run corner to corner
      '  vec2 c = p - vec2(aspect * 0.55, 0.62);',
      '  float ang = -0.42;',
      '  vec2 rp = mat2(cos(ang), sin(ang), -sin(ang), cos(ang)) * c;',
      '  float light = 0.0;',
      '  float core = 0.0;',
      '  for (int i = 0; i < 3; i++) {',
      '    float fi = float(i);',
      // each ribbon bends and drifts slowly, has its own width, and fades out toward its ends
      '    float centre = -0.36 + fi * 0.33 + rp.x * (fi - 1.0) * 0.16 + 0.55 * (fbm(vec2(rp.x * 0.85 + fi * 3.1 + s, fi * 1.7 + s * 0.4)) - 0.5);',
      '    float width = 0.05 + 0.09 * fbm(vec2(rp.x * 1.3 - s * 0.8, fi * 4.0 + 2.0));',
      '    float d = (rp.y - centre) / width;',
      '    float band = exp(-d * d);',
      '    float rays = 0.45 + 0.55 * fbm(vec2(rp.x * 6.0 + fi * 5.0 + s * 1.6, rp.y * 0.6 + fi));',
      '    float along = smoothstep(-1.3, -0.35, rp.x) * (1.0 - smoothstep(0.55, 1.5, rp.x + fi * 0.25));',
      '    float k = band * rays * along * (fi == 1.0 ? 1.0 : 0.72 - fi * 0.08);',
      '    light += k;',
      '    core += pow(band, 6.0) * rays * along * (1.0 - fi * 0.3);',
      '  }',
      // a faint haze around the ribbons so it isn't just lines on black
      '  float haze = fbm(p * 1.1 + vec2(s * 0.7, -s * 0.5));',
      '  light += smoothstep(0.42, 0.85, haze) * 0.32;',
      // brighter toward the top of the screen, like light from above
      '  float top = mix(0.42, 1.1, smoothstep(0.0, 1.0, uv.y));',
      '  light *= top;',
      '  core *= top;',
      '  vec3 deep = vec3(0.02, 0.07, 0.32);',
      '  vec3 blue = vec3(0.10, 0.34, 0.98);',
      '  vec3 pale = vec3(0.62, 0.82, 1.0);',
      '  vec3 col = mix(deep, blue, clamp(light * 1.15, 0.0, 1.0));',
      '  col = mix(col, pale, clamp(core * 0.9, 0.0, 0.85));',
      '  float a = clamp(light * 0.9 + core * 0.3, 0.0, 0.92);',
      '  gl_FragColor = vec4(col * a, a);',
      '}',
    ].join('\n');

    function shader(type, src) {
      var sh = gl.createShader(type);
      gl.shaderSource(sh, src);
      gl.compileShader(sh);
      return gl.getShaderParameter(sh, gl.COMPILE_STATUS) ? sh : null;
    }
    var vs = shader(gl.VERTEX_SHADER, vertex), fs = shader(gl.FRAGMENT_SHADER, fragment);
    var program = vs && fs && gl.createProgram();
    if (!program) { nebulaCanvas.remove(); return null; }
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { nebulaCanvas.remove(); return null; }
    gl.useProgram(program);
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(program, 'p');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    var uRes = gl.getUniformLocation(program, 'res'), uT = gl.getUniformLocation(program, 't');
    var lost = false;
    nebulaCanvas.addEventListener('webglcontextlost', function (e) { e.preventDefault(); lost = true; nebulaCanvas.style.display = 'none'; });

    return {
      draw: function (t) {
        if (lost) return;
        var w = Math.max(32, Math.round((innerWidth + 60) / 4)), h = Math.max(32, Math.round((innerHeight + 60) / 4));
        if (nebulaCanvas.width !== w || nebulaCanvas.height !== h) {
          nebulaCanvas.width = w;
          nebulaCanvas.height = h;
          gl.viewport(0, 0, w, h);
        }
        gl.uniform2f(uRes, w, h);
        gl.uniform1f(uT, t);
        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.drawArrays(gl.TRIANGLES, 0, 6);
      },
    };
  })();

  /* ── stars: the same sky every time (fixed seed), a few with a soft glow ── */
  var stars = (function () {
    var ctx = starCanvas.getContext('2d');
    var list = [], w = 0, h = 0, dpr = 1;
    var sprite = document.createElement('canvas');
    sprite.width = sprite.height = 32;
    var sg = sprite.getContext('2d');
    var grad = sg.createRadialGradient(16, 16, 0, 16, 16, 16);
    grad.addColorStop(0, 'rgba(215, 230, 255, 1)');
    grad.addColorStop(0.25, 'rgba(140, 180, 255, .45)');
    grad.addColorStop(1, 'rgba(80, 130, 255, 0)');
    sg.fillStyle = grad;
    sg.fillRect(0, 0, 32, 32);

    function size() {
      var ratio = Math.min(window.devicePixelRatio || 1, 2);
      if (innerWidth === w && innerHeight === h && ratio === dpr) return;
      w = innerWidth;
      h = innerHeight;
      dpr = ratio;
      starCanvas.width = Math.round(w * dpr);
      starCanvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var seed = 1337;
      var rnd = function () { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      var n = Math.min(900, Math.round(w * h / 5200));
      list = [];
      for (var i = 0; i < n; i++) {
        var big = rnd() < 0.06;
        list.push({
          x: rnd() * w, y: rnd() * h,
          r: big ? 0.9 + rnd() * 0.8 : 0.3 + rnd() * 0.65,
          a: big ? 0.55 + rnd() * 0.4 : 0.18 + rnd() * 0.6,
          speed: 0.4 + rnd() * 1.8, phase: rnd() * 6.283,
          depth: 0.015 + rnd() * 0.09,  // how far it moves when you scroll: far stars barely move
          blue: rnd() < 0.45, big: big,
        });
      }
    }

    return {
      draw: function (t, still) {
        size();
        ctx.clearRect(0, 0, w, h);
        var scroll = still ? 0 : (window.scrollY || 0);
        for (var i = 0; i < list.length; i++) {
          var s = list[i];
          var y = (s.y - scroll * s.depth) % h;
          if (y < 0) y += h;
          var a = s.a * (still ? 1 : 0.6 + 0.4 * Math.sin(t * s.speed + s.phase));
          if (s.big) {
            var g = s.r * 7;
            ctx.globalAlpha = a * 0.55;
            ctx.drawImage(sprite, s.x - g, y - g, g * 2, g * 2);
          }
          ctx.globalAlpha = a;
          ctx.fillStyle = s.blue ? '#cfe0ff' : '#ffffff';
          ctx.beginPath();
          ctx.arc(s.x, y, s.r, 0, 6.283);
          ctx.fill();
        }
        ctx.globalAlpha = 1;
      },
    };
  })();

  /* ── run ── */
  var running = false, last = 0, start = performance.now();
  var fps = lite ? 12 : 30;
  var STILL_T = 42;  // the moment of the nebula shown when nothing moves

  function frame(now) {
    if (!running) return;
    requestAnimationFrame(frame);
    if (now - last < 1000 / fps) return;
    last = now;
    var t = STILL_T + (now - start) / 1000;
    if (nebula && !lite) nebula.draw(t);
    stars.draw(t, false);
  }

  function still() {
    if (nebula) nebula.draw(STILL_T);
    stars.draw(STILL_T, true);
  }

  function update() {
    if (!dark()) { running = false; return; }
    if (reduce.matches) { running = false; still(); return; }
    if (lite && nebula) nebula.draw(STILL_T);
    if (!running) { running = true; last = 0; requestAnimationFrame(frame); }
  }

  window.addEventListener('resize', function () { if (dark() && !running) still(); }, { passive: true });
  new MutationObserver(update).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  [systemLight, reduce].forEach(function (mq) {
    if (mq.addEventListener) mq.addEventListener('change', update); else if (mq.addListener) mq.addListener(update);
  });
  window.Space = { update: update, still: still, running: function () { return running; }, webgl: !!nebula };
  update();
})();
