/* Pages for the features added with the figs: moderation, community, Roblox and support tools.
   Loaded before pages.js, which lists every page in PAGES. */
'use strict';

/* ───────────── helpers ───────────── */

/** A feature's dashboard data (leaderboards, cases, suggestions...) from /state. */
function extra(feature) {
  return (S.data.extras || {})[feature] || {};
}

/** Press a button on a feature's page (post a panel, approve something...). */
async function doAction(btn, feature, action, body = {}) {
  const res = await act(btn, () => gapi('POST', `/do/${feature}/${action}`, body));
  if (res && res.info) {
    S.data.extras = S.data.extras || {};
    S.data.extras[feature] = res.info;
  }
  return res;
}

function oneColumn(...kids) {
  return h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 900px)' } }, h('div', { class: 'stack' }, kids));
}

function numberInput(key, { min = 0, max = 999, width = '96px', label = null } = {}) {
  const el = h('input', { class: 'input', type: 'number', min, max, value: get(key) ?? '', id: 'f-' + key, 'aria-label': label || key, style: { width, flex: 'none' } });
  el.addEventListener('input', () => { if (el.value !== '') set(key, Number(el.value)); });
  return el;
}

function hourSelect(key, { offsetKey = null } = {}) {
  const el = h('select', { class: 'input', id: 'f-' + key, style: { width: '120px' } },
    Array.from({ length: 24 }, (_, i) => h('option', { value: i, selected: get(key) === i }, `${String(i).padStart(2, '0')}:00`)));
  el.addEventListener('change', () => set(key, Number(el.value)));
  return el;
}

/** Several picks from a fixed list, shown as toggle chips. */
function choicesToggle(key, options) {
  const wrap = h('div', { class: 'quick', role: 'group' });
  const draw = () => wrap.replaceChildren(...options.map(([v, label]) => {
    const on = (get(key) || []).includes(v);
    return h('button', { type: 'button', class: on ? 'on' : '', 'aria-pressed': String(on), onclick: () => {
      const cur = new Set(get(key) || []);
      on ? cur.delete(v) : cur.add(v);
      set(key, options.map(o => o[0]).filter(x => cur.has(x)));
      draw();
    } }, label);
  }));
  draw();
  return wrap;
}

/** A row with a channel picker and a button that posts something there. */
function postRow(label, help, feature, action, { button = 'Post panel', keys = [], initial = null } = {}) {
  const post = localChannel(initial);
  const btn = h('button', { class: 'btn primary', onclick: async e => {
    if (!post.value) return toast('Pick a channel first.', { error: true });
    const res = await doAction(e.currentTarget, feature, action, { channel_id: post.value });
    if (res) App.render();
  } }, icon('send'), button);
  return row(label, help, [savedFirstNote(keys), h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), btn)]);
}

function miniStats(items) {
  return h('div', { class: 'mini-stats' }, items.filter(Boolean).map(([n, label]) => h('div', null, h('b', null, n), h('span', null, label))));
}

function personLine(p, extraText = null) {
  p = p || { name: 'Unknown' };
  return h('div', { class: 'linked' },
    p.avatar ? h('img', { src: p.avatar, alt: '' }) : h('span', { class: 'avatar-blank' }),
    h('div', null, h('div', { class: 'item-title' }, p.name), extraText ? h('div', { class: 'item-meta' }, extraText) : null));
}

/** Ask for a line of text in the dialog. Resolves to the text, or null when cancelled. */
function askText({ title, text = '', placeholder = '', confirm = 'OK', danger = false, multiline = true }) {
  const dlg = document.getElementById('dialog');
  const input = h(multiline ? 'textarea' : 'input', { class: 'input', rows: multiline ? 3 : null, placeholder, maxlength: 500 });
  return new Promise(resolve => {
    dlg.replaceChildren(
      h('div', { class: 'dialog-body' }, h('h2', null, title), text ? h('p', null, text) : null, h('div', { style: { marginTop: '12px' } }, input)),
      h('div', { class: 'dialog-actions' },
        h('button', { class: 'btn ghost', onclick: () => dlg.close('no') }, 'Cancel'),
        h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => dlg.close('yes') }, confirm)),
    );
    dlg.onclose = () => resolve(dlg.returnValue === 'yes' ? input.value.trim() : null);
    dlg.returnValue = '';
    dlg.showModal();
    input.focus();
  });
}

/* ───────────── list editor (auto-responses, FAQ, timed messages...) ───────────── */

const REC_OPEN = {};

function setRec(key, i, patch) {
  const v = copy(get(key) || []);
  Object.assign(v[i], patch);
  set(key, v);
}

/**
 * Edit a list setting as cards that open and close.
 * spec: { fields: [{key, label, help, type, ...}], blank: () => row, title: row => text, sub, max, addLabel, empty, actions }
 * Field types: text, textarea, number, toggle, choice, channel, channels, role, roles, emoji, custom
 */
function recordsEditor(key, spec) {
  const wrap = h('div', { class: 'tt-list' });
  const draw = () => {
    wrap.replaceChildren();
    const rows = get(key) || [];
    if (!rows.length) wrap.append(h('div', { class: 'chips-empty' }, spec.empty || 'Nothing yet.'));
    rows.forEach((r, i) => wrap.append(recordCard(key, r, i, spec, draw)));
    if (rows.length < (spec.max || 25)) {
      wrap.append(h('div', null, h('button', { type: 'button', class: 'btn small', onclick: () => {
        set(key, [...(get(key) || []), spec.blank()]);
        REC_OPEN[key] = rows.length;
        draw();
        wrap.querySelectorAll('details.tt')[rows.length]?.querySelector('input, textarea')?.focus();
      } }, icon('plus'), spec.addLabel || 'Add')));
    }
  };
  draw();
  return h('div', { 'data-key': key }, S.errors[key] ? h('div', { class: 'field-error', style: { marginBottom: '10px' } }, S.errors[key]) : null, wrap);
}

function recordCard(key, r, i, spec, redraw) {
  const title = h('span', { class: 'tt-name' }, spec.title(r, i) || 'Untitled');
  const sub = spec.sub ? h('span', { class: 'tt-meta' }, spec.sub(r, i)) : null;
  const refresh = () => {
    const cur = (get(key) || [])[i];
    if (!cur) return;
    title.textContent = spec.title(cur, i) || 'Untitled';
    if (sub) sub.replaceChildren(spec.sub(cur, i));
  };
  const move = d => {
    const v = copy(get(key));
    [v[i], v[i + d]] = [v[i + d], v[i]];
    set(key, v);
    REC_OPEN[key] = i + d;
    redraw();
  };
  const rows = get(key) || [];
  const details = h('details', { class: 'tt', open: REC_OPEN[key] === i },
    h('summary', null,
      spec.lead ? h('span', { class: 'tt-emoji' }, spec.lead(r)) : null,
      h('span', { class: 'tt-head' }, title, sub),
      icon('chev', 'tt-chev')),
    h('div', { class: 'tt-body' },
      spec.fields.map(f => recordField(key, i, f, refresh)),
      h('div', { class: 'tt-foot' },
        spec.actions ? spec.actions(r, i) : null,
        h('span', { style: { flex: '1' } }),
        i > 0 ? h('button', { type: 'button', class: 'btn small ghost', onclick: () => move(-1) }, icon('up'), 'Move up') : null,
        i < rows.length - 1 ? h('button', { type: 'button', class: 'btn small ghost', onclick: () => move(1) }, icon('down'), 'Move down') : null,
        h('button', { type: 'button', class: 'btn small danger', onclick: () => {
          set(key, get(key).filter((_, j) => j !== i));
          REC_OPEN[key] = -1;
          redraw();
        } }, icon('trash'), 'Remove')),
    ),
  );
  details.addEventListener('toggle', () => { if (details.open) REC_OPEN[key] = i; });
  return details;
}

function recordField(key, i, f, refresh) {
  const r = get(key)[i];
  const value = r[f.key];
  const update = v => { setRec(key, i, { [f.key]: v }); refresh(); };
  let control;
  if (f.type === 'text' || f.type === 'textarea' || f.type === 'number') {
    const multi = f.type === 'textarea';
    control = h(multi ? 'textarea' : 'input', {
      class: 'input', value: value ?? '', placeholder: f.placeholder || '', maxlength: f.max || null,
      rows: multi ? (f.rows || 4) : null, type: f.type === 'number' ? 'number' : (multi ? null : 'text'),
      min: f.min ?? null, 'aria-label': f.label, style: f.type === 'number' ? { width: '120px' } : null,
      inputmode: f.numeric ? 'numeric' : null,
    });
    control.addEventListener('input', () => update(f.type === 'number' ? (control.value === '' ? null : Number(control.value)) : control.value));
  } else if (f.type === 'toggle') {
    control = h('label', { class: 'switch' },
      h('input', { type: 'checkbox', checked: !!value, onchange: e => update(e.target.checked) }),
      h('span', { class: 'track' }), h('span', null, f.text || 'On'));
  } else if (f.type === 'choice') {
    control = h('div', { class: 'quick', role: 'group' });
    const draw = cur => control.replaceChildren(...f.options.map(([v, label]) => h('button', {
      type: 'button', class: cur === v ? 'on' : '', 'aria-pressed': String(cur === v),
      onclick: () => { update(v); draw(v); },
    }, label)));
    draw(value);
  } else if (f.type === 'channel' || f.type === 'channels') {
    control = picker({ items: channelItems(f.types), value, multiple: f.type === 'channels', placeholder: f.placeholder || 'Pick a channel',
      addLabel: 'Add channel', label: f.label, searchPlaceholder: 'Search channels', onChange: update });
  } else if (f.type === 'role' || f.type === 'roles') {
    control = picker({ items: roleItems(), value, multiple: f.type === 'roles', placeholder: f.placeholder || 'Pick a role',
      addLabel: 'Add role', label: f.label, searchPlaceholder: 'Search roles', onChange: update });
  } else if (f.type === 'emoji') {
    control = emojiField(value, update);
  } else if (f.type === 'custom') {
    control = f.render(value, update, r);
  }
  return h('div', { class: 'tt-field' },
    h('div', { class: 'row-label' }, f.label, f.help ? h('div', { class: 'row-help' }, f.help) : null),
    h('div', { class: 'row-control' }, control));
}

/** Up to 5 questions for an application form (label, long answer, required). */
function questionsEditor(value, onChange) {
  let qs = copy(value || []);
  const wrap = h('div', { class: 'stack', style: { gap: '8px' } });
  const draw = () => {
    wrap.replaceChildren();
    if (!qs.length) wrap.append(h('div', { class: 'chips-empty' }, 'Add at least one question.'));
    qs.forEach((q, j) => {
      const label = h('input', { class: 'input', value: q.label, maxlength: 45, placeholder: 'e.g. How old are you?', 'aria-label': `Question ${j + 1}` });
      label.addEventListener('input', () => { qs[j].label = label.value; onChange(copy(qs)); });
      const flag = (k, text) => h('label', { class: 'mini-check' },
        h('input', { type: 'checkbox', checked: !!q[k], onchange: e => { qs[j][k] = e.target.checked; onChange(copy(qs)); } }), text);
      wrap.append(h('div', { class: 'q-row' }, label, flag('long', 'Long answer'), flag('required', 'Required'),
        h('button', { type: 'button', class: 'btn icon del', 'aria-label': `Remove question ${j + 1}`, title: 'Remove',
          onclick: () => { qs.splice(j, 1); onChange(copy(qs)); draw(); } }, icon('trash'))));
    });
    if (qs.length < 5) wrap.append(h('div', null, h('button', { type: 'button', class: 'btn small', onclick: () => {
      qs.push({ label: '', long: false, required: true });
      onChange(copy(qs));
      draw();
      wrap.querySelectorAll('.q-row input.input')[qs.length - 1]?.focus();
    } }, icon('plus'), 'Add question')));
  };
  draw();
  return wrap;
}

const TOKENS_USER = [['{user}', 'Mentions the member'], ['{username}', 'Their display name'], ['{server}', 'Server name'], ['{member_count}', 'Member count']];

/* ═════════════ Auto-mod ═════════════ */

const AM_ACTIONS = [
  { value: 'delete', label: 'Delete the message', text: 'And tell them why. The note disappears after a few seconds.' },
  { value: 'timeout_5', label: 'Delete + 5 minute timeout', text: 'Good for spam.' },
  { value: 'timeout_60', label: 'Delete + 1 hour timeout', text: 'Stronger.' },
  { value: 'timeout_1440', label: 'Delete + 1 day timeout', text: 'For servers that get raided.' },
];

function pageAutomod() {
  const recent = extra('automod').recent || [];
  return h('div', null,
    pageHead('Auto-mod', 'Catches spam, invite links, unwanted links, mass mentions and all-caps messages. Staff with Manage Messages are never caught.'),
    oneColumn(
      panel('What to catch', null, [
        row('Spam', 'Too many messages in a short time.', [toggle('am_spam', 'Catch spam'),
          h('div', { class: 'input-row' }, numberInput('am_spam_count', { min: 3, max: 20, label: 'Messages' }), h('span', null, 'messages in'),
            numberInput('am_spam_seconds', { min: 2, max: 60, label: 'Seconds' }), h('span', null, 'seconds'))], { key: 'am_spam' }),
        row('Server invites', null, toggle('am_invites', 'Delete invites to other Discord servers'), { key: 'am_invites', inline: true }),
        row('Links', 'Links to sites you allow below are fine.', [toggle('am_links', 'Delete links'),
          wordBox('am_allowed_links', { placeholder: 'Allowed site, like youtube.com' })], { key: 'am_links' }),
        row('Mass mentions', 'Mentioning this many people or roles in one message. 0 turns it off.', numberInput('am_mentions', { min: 0, max: 50, label: 'Mentions' }), { key: 'am_mentions' }),
        row('All caps', null, toggle('am_caps', 'Delete messages that are mostly capital letters'), { key: 'am_caps', inline: true }),
      ]),
      panel('What happens', null, [
        row('Action', null, choiceCards('am_action', AM_ACTIONS), { key: 'am_action' }),
        row('Warnings', null, toggle('am_warn', 'Also give a warning (counts toward the Moderation punishments)'), { key: 'am_warn', inline: true }),
        row('Log channel', 'Every catch is logged here. Empty uses the main log channel.', channelPick('am_log_channel_id', { placeholder: 'Main log channel' }), { key: 'am_log_channel_id' }),
      ]),
      panel('Never catch', null, [
        row('Roles', null, rolePick('am_ignored_role_ids', { multiple: true }), { key: 'am_ignored_role_ids' }),
        row('Channels', null, channelPick('am_ignored_channel_ids', { multiple: true }), { key: 'am_ignored_channel_ids' }),
      ]),
      panel('Recently caught', recent.length ? 'Since the bot last started.' : 'Nothing caught since the bot last started.',
        recent.length ? h('div', { class: 'list' }, recent.map(x => h('div', { class: 'item' }, h('div', null,
          h('div', { class: 'item-title' }, x.user, h('span', { class: 'tag' }, x.rule)),
          h('div', { class: 'item-meta spread' }, h('span', null, '#' + x.channel), h('span', null, ago(x.t)), x.text ? h('span', null, x.text.slice(0, 120)) : null))))) : null),
    ),
  );
}

/* ═════════════ Moderation ═════════════ */

const CASE_NAMES = { warn: 'Warning', timeout: 'Timeout', untimeout: 'Timeout removed', kick: 'Kick', ban: 'Ban', tempban: 'Temporary ban', softban: 'Softban', unban: 'Unban' };

function pageModeration() {
  const info = extra('moderation');
  const cases = info.cases || [];
  const caseItem = c => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, `#${c.id}`, h('span', { class: 'tag' + (c.action === 'ban' || c.action === 'tempban' ? ' on' : '') }, CASE_NAMES[c.action] || c.action), c.user),
      h('div', { class: 'item-meta spread' }, h('span', null, `By ${c.mod}`), h('span', null, ago(c.t)), c.minutes ? h('span', null, span(c.minutes * 60)) : null),
      c.reason ? h('div', { class: 'item-meta' }, c.reason) : null),
    h('div', { class: 'item-actions' }, h('button', { class: 'btn small icon danger', title: 'Delete case', 'aria-label': `Delete case ${c.id}`, onclick: async e => {
      const b = e.currentTarget;
      if (!await confirmDialog({ title: `Delete case ${c.id}?`, text: 'It disappears from the records. This doesn\'t undo the action in Discord.', confirm: 'Delete', danger: true })) return;
      if (await doAction(b, 'moderation', 'delete-case', { case: c.id })) App.render();
    } }, icon('trash'))));

  return h('div', null,
    pageHead('Moderation', 'Warnings, timeouts, kicks and bans with /warn, /timeout, /kick, /ban, /tempban, /softban, /purge, /lockdown, /role and more. Every action is saved as a numbered case.'),
    oneColumn(
      info.lockdown ? note(`The server is locked down: ${info.lockdown.channels} channel${info.lockdown.channels === 1 ? '' : 's'} locked ${ago(info.lockdown.t)}. End it in Discord with /lockdown end.`, 'warn') : null,
      panel('Settings', null, [
        row('Log channel', 'Every case is posted here. Empty uses the main log channel.', channelPick('mod_log_channel_id', { placeholder: 'Main log channel' }), { key: 'mod_log_channel_id' }),
        row('Tell them', null, toggle('mod_dm', 'DM members when they\'re warned, timed out, kicked or banned'), { key: 'mod_dm', inline: true }),
      ]),
      panel('Automatic punishments', 'What happens when someone reaches a number of warnings. 0 turns a step off.', [
        row('Timeout', null, h('div', { class: 'input-row' }, h('span', null, 'At'), numberInput('mod_warn_timeout', { min: 0, max: 50, label: 'Warnings before a timeout' }),
          h('span', null, 'warnings, for'), numberInput('mod_timeout_minutes', { min: 1, max: 40320, label: 'Timeout minutes' }), h('span', null, 'minutes')), { key: 'mod_warn_timeout' }),
        row('Kick', null, h('div', { class: 'input-row' }, h('span', null, 'At'), numberInput('mod_warn_kick', { min: 0, max: 50, label: 'Warnings before a kick' }), h('span', null, 'warnings')), { key: 'mod_warn_kick' }),
        row('Ban', null, h('div', { class: 'input-row' }, h('span', null, 'At'), numberInput('mod_warn_ban', { min: 0, max: 50, label: 'Warnings before a ban' }), h('span', null, 'warnings')), { key: 'mod_warn_ban' }),
      ]),
      (info.warned || []).length ? panel('Most warnings', null, h('div', { class: 'list' }, info.warned.map(w => h('div', { class: 'item' },
        personLine(w.name ? w : { name: w.user }, `${w.count} warning${w.count === 1 ? '' : 's'}`),
        h('div', { class: 'item-actions' }, h('button', { class: 'btn small', onclick: async e => {
          if (await doAction(e.currentTarget, 'moderation', 'clear-warnings', { user_id: w.id })) App.render();
        } }, 'Clear warnings')))))) : null,
      (info.tempbans || []).length ? panel('Temporary bans', 'They\'re unbanned by themselves when the time is up.', h('div', { class: 'list' }, info.tempbans.map(t => h('div', { class: 'item' },
        h('div', null, h('div', { class: 'item-title' }, t.user), h('div', { class: 'item-meta' }, `Unbanned ${until(t.until)}`)),
        h('div', { class: 'item-actions' }, h('button', { class: 'btn small', onclick: async e => {
          if (await doAction(e.currentTarget, 'moderation', 'end-tempban', { user_id: t.user_id })) App.render();
        } }, 'Unban now')))))) : null,
      panel('Cases', cases.length ? `${info.total} in total. Newest first.` : 'No cases yet.', cases.length ? h('div', { class: 'list' }, cases.slice(0, 60).map(caseItem)) : null),
    ),
  );
}

/** "in 3 days", "in 2 hours" (for things that end by themselves). */
function until(unix) {
  const s = unix - Date.now() / 1000;
  if (s <= 60) return 'any moment now';
  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
  for (const [unit, n] of [['week', 604800], ['day', 86400], ['hour', 3600]]) {
    if (s >= n) return rtf.format(Math.round(s / n), unit);
  }
  return rtf.format(Math.round(s / 60), 'minute');
}

/* ═════════════ Utility ═════════════ */

const UTILITY_COMMANDS = [
  ['userinfo', 'A member\'s roles, join date and key permissions'], ['serverinfo', 'Members, channels, boosts and more'],
  ['avatar', 'Anyone\'s profile picture, full size'], ['banner', 'Anyone\'s profile banner'], ['membercount', 'How many members the server has'],
  ['ping', 'How fast the bot answers'], ['botinfo', 'Servers, uptime and the dashboard link'], ['reminder set', 'Reminds you later, here or in your DMs'],
  ['afk', 'Tells people you\'re away when they mention you'], ['say', 'Staff: post a message as the bot'],
  ['snipe', 'Staff: the last deleted or edited message in a channel'], ['steal', 'Staff: add an emoji from another server'],
];

function pageUtility() {
  const info = extra('utility');
  return h('div', null,
    pageHead('Utility', 'Handy commands for everyone, and a few for staff. Turn single commands off on the Commands page.'),
    oneColumn(
      panel('Settings', null, [
        row('AFK', null, toggle('util_afk', 'Let members set an AFK message with /afk'), { key: 'util_afk', inline: true }),
        row('AFK nickname', null, toggle('util_afk_nick', 'Put [AFK] in front of their nickname while they\'re away'), { key: 'util_afk_nick', inline: true }),
        row('Snipe', 'Only the last deleted and last edited message of each channel, kept for 10 minutes and never saved.',
          toggle('util_snipe', 'Let staff see the last deleted or edited message with /snipe'), { key: 'util_snipe', inline: true }),
      ]),
      info.reminders || info.afk ? note([info.reminders && `${info.reminders} reminder${info.reminders === 1 ? '' : 's'} waiting`, info.afk && `${info.afk} member${info.afk === 1 ? '' : 's'} AFK`].filter(Boolean).join(', ') + '.', 'good') : null,
      panel('Commands', null, h('div', { class: 'list' }, UTILITY_COMMANDS.map(([name, what]) => h('div', { class: 'item' },
        h('div', null, h('div', { class: 'item-title' }, '/' + name), h('div', { class: 'item-meta' }, what)))))),
    ),
  );
}

/* ═════════════ Server logs ═════════════ */

const LOG_EVENTS = [['message_delete', 'Deleted messages'], ['message_edit', 'Edited messages'], ['member_join', 'Joins'], ['member_leave', 'Leaves'],
  ['member_roles', 'Role changes'], ['member_nick', 'Nickname changes'], ['member_ban', 'Bans'], ['member_unban', 'Unbans'], ['voice', 'Voice joins and leaves'], ['channels', 'Channels made or deleted']];

function pageLogs() {
  return h('div', null,
    pageHead('Server logs', 'A record of what happens in the server, posted in a staff channel.'),
    oneColumn(
      !S.saved.logs_channel_id ? note('Pick a log channel to turn logging on.', 'info') : null,
      panel('Where', null, [
        row('Log channel', null, channelPick('logs_channel_id'), { key: 'logs_channel_id' }),
        row('Message log channel', 'Deleted and edited messages go here instead, if you pick one.', channelPick('logs_message_channel_id', { placeholder: 'Same as the log channel' }), { key: 'logs_message_channel_id' }),
        row('Don\'t log messages from', null, channelPick('logs_ignored_channel_ids', { multiple: true }), { key: 'logs_ignored_channel_ids' }),
      ]),
      panel('What to log', null, h('div', { class: 'panel-body' }, choicesToggle('logs_events', LOG_EVENTS))),
    ),
  );
}

/* ═════════════ Leveling ═════════════ */

function pageLeveling() {
  const info = extra('leveling');
  const top = info.top || [];
  const announce = h('div');
  const drawAnnounce = () => announce.replaceChildren(get('lvl_announce') === 'custom' ? channelPick('lvl_channel_id') : '');
  S.live.push(k => { if (k === 'lvl_announce') drawAnnounce(); });
  drawAnnounce();

  const board = top.length ? h('div', { class: 'list' }, top.slice(0, 50).map((p, i) => h('div', { class: 'item' },
    h('div', { class: 'lb-row' },
      h('span', { class: 'lb-place' }, i + 1),
      personLine(p, `Level ${p.level}, ${p.xp.toLocaleString()} XP, ${p.msgs.toLocaleString()} messages`),
      h('div', { class: 'lb-bar', title: `${p.into} / ${p.need} XP to the next level` }, h('span', { style: { width: `${Math.round(100 * p.into / p.need)}%` } }))),
    h('div', { class: 'item-actions' }, h('button', { class: 'btn small ghost', onclick: async e => {
      const b = e.currentTarget;
      if (!await confirmDialog({ title: `Reset ${p.name}'s XP?`, text: 'They go back to level 0 and lose their level roles.', confirm: 'Reset', danger: true })) return;
      if (await doAction(b, 'leveling', 'reset', { user_id: p.id })) App.render();
    } }, 'Reset'))))) : null;

  return h('div', null,
    pageHead('Leveling', 'Members earn XP for chatting and level up. /rank shows a member\'s level and /leaderboard the top members.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Earning XP', null, [
          row('Leveling', null, toggle('lvl_enabled', 'Members earn XP'), { key: 'lvl_enabled', inline: true }),
          row('XP per message', 'A random amount in this range.', h('div', { class: 'input-row' }, numberInput('lvl_xp_min', { min: 1, max: 500, label: 'Least XP' }),
            h('span', null, 'to'), numberInput('lvl_xp_max', { min: 1, max: 500, label: 'Most XP' })), { key: 'lvl_xp_min' }),
          row('Cooldown', 'Seconds before the next message earns XP again, so spam doesn\'t pay.', numberInput('lvl_cooldown', { min: 0, max: 3600, label: 'Seconds' }), { key: 'lvl_cooldown' }),
          row('No XP in', null, channelPick('lvl_no_xp_channel_ids', { multiple: true }), { key: 'lvl_no_xp_channel_ids' }),
          row('No XP for', null, rolePick('lvl_no_xp_role_ids', { multiple: true }), { key: 'lvl_no_xp_role_ids' }),
        ]),
        panel('Level-up message', null, [
          row('Where', null, [chipChoice('lvl_announce', [['channel', 'Where they chatted'], ['custom', 'A channel'], ['dm', 'By DM'], ['off', 'Don\'t announce']]), announce], { key: 'lvl_announce' }),
          row('Message', null, [textInput('lvl_message', { multiline: true, rows: 2, max: 500 }),
            placeholderHelp('lvl_message', [['{user}', 'Mentions them'], ['{level}', 'Their new level'], ['{server}', 'Server name']])], { key: 'lvl_message' }),
        ]),
        panel('Level roles', 'Roles members get when they reach a level.', [
          h('div', { class: 'panel-body stack' },
            recordsEditor('lvl_roles', {
              max: 50, addLabel: 'Add level role', empty: 'No level roles yet.',
              blank: () => ({ level: 5, role_id: null }),
              title: r => `Level ${r.level || '?'}`, sub: r => G.role(r.role_id)?.name || 'No role picked',
              fields: [
                { key: 'level', label: 'Level', type: 'number', min: 1 },
                { key: 'role_id', label: 'Role', type: 'role' },
              ],
            }),
            toggle('lvl_stack', 'Keep the roles from lower levels')),
        ]),
      ),
      h('aside', { class: 'sticky' },
        h('div', { class: 'preview-title' }, 'Leaderboard'),
        h('div', { class: 'panel' },
          top.length ? board : h('div', { class: 'empty', style: { borderTop: 'none' } }, 'Nobody has XP yet.'),
          top.length ? h('div', { class: 'panel-foot' }, h('button', { class: 'btn small danger', onclick: async e => {
            const b = e.currentTarget;
            if (!await confirmDialog({ title: 'Reset everyone\'s XP?', text: 'Every member goes back to level 0. This can\'t be undone.', confirm: 'Reset everyone', danger: true })) return;
            if (await doAction(b, 'leveling', 'reset', { all: true })) App.render();
          } }, 'Reset everyone')) : null)),
    ),
  );
}

/* ═════════════ Suggestions ═════════════ */

const SUG_ACTIONS = [['approved', 'Approve', 'check'], ['considering', 'Considering', 'refresh'], ['implemented', 'Added', 'plus'], ['denied', 'Deny', 'x']];
let sugFilter = 'open';

function pageSuggestions() {
  const info = extra('suggestions');
  const all = info.items || [];
  const shown = sugFilter === 'all' ? all : all.filter(s => s.status === sugFilter || (sugFilter === 'open' && s.status === 'considering'));
  const counts = k => all.filter(s => s.status === k).length;
  const filters = h('div', { class: 'quick' }, [['open', `Open (${counts('open') + counts('considering')})`], ['approved', `Approved (${counts('approved')})`],
    ['implemented', `Added (${counts('implemented')})`], ['denied', `Denied (${counts('denied')})`], ['all', `All (${all.length})`]].map(([k, label]) =>
    h('button', { type: 'button', class: sugFilter === k ? 'on' : '', onclick: () => { sugFilter = k; App.render(); } }, label)));

  const item = s => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, `#${s.number}`, h('span', { class: 'tag' + (s.status === 'approved' || s.status === 'implemented' ? ' on' : s.status === 'denied' ? ' off' : '') }, info.statuses?.[s.status] || s.status)),
      h('div', { class: 'sug-text' }, s.text),
      h('div', { class: 'item-meta spread' }, h('span', null, `By ${s.author?.name || 'someone'}`), h('span', null, `👍 ${s.up}  👎 ${s.down}`), h('span', null, ago(s.t))),
      s.reason ? h('div', { class: 'item-meta' }, `Reason: ${s.reason}`) : null),
    h('div', { class: 'item-actions' },
      h('a', { class: 'btn small ghost', href: s.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open'),
      SUG_ACTIONS.filter(([k]) => k !== s.status).map(([k, label, ic]) => h('button', { class: 'btn small', onclick: async e => {
        const b = e.currentTarget;
        const reason = await askText({ title: `${label}: suggestion #${s.number}`, text: 'Add a reason if you like. Everyone can see it on the suggestion.', placeholder: 'Reason (optional)', confirm: label });
        if (reason === null) return;
        if (await doAction(b, 'suggestions', 'set-status', { id: s.id, status: k, reason })) App.render();
      } }, icon(ic), label))));

  return h('div', null,
    pageHead('Suggestions', 'Members suggest ideas with /suggest or the button on a suggestion panel, and vote with 👍 and 👎. Staff decide from Discord or here.'),
    oneColumn(
      panel('Settings', null, [
        row('Suggestion channel', 'Where suggestions are posted.', channelPick('sug_channel_id'), { key: 'sug_channel_id' }),
        row('Anonymous', null, toggle('sug_anonymous', 'Hide who made each suggestion'), { key: 'sug_anonymous', inline: true }),
        row('Results', null, toggle('sug_dm_result', 'DM members when their suggestion is approved or denied'), { key: 'sug_dm_result', inline: true }),
        row('Staff roles', 'Can approve and deny. Anyone with Manage Server always can.', rolePick('sug_staff_role_ids', { multiple: true }), { key: 'sug_staff_role_ids' }),
        postRow('Suggestion panel', 'A message with a button that opens the suggestion form. Optional: /suggest works too.', 'suggestions', 'panel'),
      ]),
      panel('Suggestions', null, [h('div', { class: 'panel-body' }, filters),
        shown.length ? h('div', { class: 'list' }, shown.map(item)) : h('div', { class: 'empty' }, 'Nothing here.')]),
    ),
  );
}

/* ═════════════ Starboard ═════════════ */

function pageStarboard() {
  const info = extra('starboard');
  return h('div', null,
    pageHead('Starboard', 'Messages that get enough stars are reposted in a starboard channel, so the best moments are easy to find.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Settings', null, [
          row('Starboard channel', null, channelPick('star_channel_id'), { key: 'star_channel_id' }),
          row('Emoji', 'The reaction that counts as a star.', emojiField(get('star_emoji'), v => set('star_emoji', v)), { key: 'star_emoji' }),
          row('Stars needed', null, numberInput('star_threshold', { min: 1, max: 100, label: 'Stars needed' }), { key: 'star_threshold' }),
          row('Self-stars', null, toggle('star_self', 'Count people starring their own message'), { key: 'star_self', inline: true }),
          row('Ignore channels', null, channelPick('star_ignored_channel_ids', { multiple: true }), { key: 'star_ignored_channel_ids' }),
        ]),
        info.posted ? note(`${info.posted} message${info.posted === 1 ? '' : 's'} on the starboard so far.`, 'good') : null,
      ),
      livePreview('Starboard post', () => dcMessage([
        { t: 'section', texts: [`${get('star_emoji') || '⭐'} **${get('star_threshold') || 3}** in <#0>`, '**Member**'], thumb: null },
        { t: 'text', md: 'This message got enough stars to make the starboard.' },
        { t: 'buttons', items: [{ label: 'Jump to message' }] },
      ])),
    ),
  );
}

/* ═════════════ Birthdays ═════════════ */

function pageBirthdays() {
  const info = extra('birthdays');
  const upcoming = info.upcoming || [];
  const local = h('span', { class: 'row-help' });
  const drawLocal = () => {
    const d = new Date();
    d.setUTCHours(get('bday_hour') ?? 14, 0, 0, 0);
    local.textContent = `That's ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} where you are.`;
  };
  S.live.push(k => { if (k === 'bday_hour') drawLocal(); });
  drawLocal();
  return h('div', null,
    pageHead('Birthdays', 'Members save their birthday with /birthday-set. On the day, the bot wishes them a happy birthday and gives them the birthday role.'),
    oneColumn(
      panel('Settings', null, [
        row('Channel', 'Where birthday wishes are posted.', channelPick('bday_channel_id'), { key: 'bday_channel_id' }),
        row('Birthday role', 'Given for the day. Optional.', [rolePick('bday_role_id'), roleWarning('bday_role_id', 'give it out')], { key: 'bday_role_id' }),
        row('Time', 'When wishes go out each day (UTC).', [hourSelect('bday_hour'), local], { key: 'bday_hour' }),
        row('Message', null, [textInput('bday_message', { multiline: true, rows: 2, max: 500 }), placeholderHelp('bday_message', [['{user}', 'Mentions them'], ['{server}', 'Server name']])], { key: 'bday_message' }),
      ]),
      panel('Upcoming birthdays', upcoming.length ? `${info.count} saved.` : 'Nobody has saved a birthday yet.', upcoming.length ? h('div', { class: 'list' }, upcoming.slice(0, 40).map(b => h('div', { class: 'item' },
        personLine(b, b.days === 0 ? `${b.date}, today 🎉` : `${b.date}, in ${b.days} day${b.days === 1 ? '' : 's'}`),
        h('div', { class: 'item-actions' }, h('button', { class: 'btn small icon ghost', title: 'Remove', 'aria-label': `Remove ${b.name}'s birthday`, onclick: async e => {
          if (await doAction(e.currentTarget, 'birthdays', 'remove', { user_id: b.id })) App.render();
        } }, icon('trash')))))) : null, { actions: h('button', { class: 'btn small', onclick: e => doAction(e.currentTarget, 'birthdays', 'check-now') }, icon('refresh'), 'Check today now') }),
    ),
  );
}

/* ═════════════ Auto-responses ═════════════ */

const MATCH_KINDS = [['contains', 'Contains'], ['word', 'Has the word'], ['exact', 'Is exactly'], ['starts', 'Starts with']];

function pageAutoresponses() {
  return h('div', null,
    pageHead('Auto-responses', 'The bot answers messages that match a trigger. Good for "what\'s the IP?" and other questions people ask a lot.'),
    oneColumn(
      panel('Responses', 'The first one that matches answers. Case doesn\'t matter.', h('div', { class: 'panel-body' }, recordsEditor('ar_rules', {
        max: 50, addLabel: 'Add auto-response', empty: 'No auto-responses yet.',
        blank: () => ({ trigger: '', match: 'contains', response: '', reply: true, channel_ids: [] }),
        title: r => r.trigger ? `“${r.trigger}”` : 'New auto-response',
        sub: r => `${(MATCH_KINDS.find(m => m[0] === r.match) || MATCH_KINDS[0])[1]}${(r.channel_ids || []).length ? `, in ${r.channel_ids.length} channel${r.channel_ids.length === 1 ? '' : 's'}` : ''}`,
        fields: [
          { key: 'trigger', label: 'Trigger', type: 'text', max: 100, placeholder: 'e.g. server ip' },
          { key: 'match', label: 'Match when the message', type: 'choice', options: MATCH_KINDS },
          { key: 'response', label: 'Reply with', help: 'Use {user} to mention them.', type: 'textarea', max: 2000 },
          { key: 'reply', label: 'Style', type: 'toggle', text: 'Reply to their message' },
          { key: 'channel_ids', label: 'Only in', help: 'Leave empty for every channel.', type: 'channels' },
        ],
      }))),
      panel('Cooldown', null, [row('Cooldown', 'Seconds before the same response can fire again in a channel.', numberInput('ar_cooldown', { min: 0, max: 3600, label: 'Seconds' }), { key: 'ar_cooldown' })]),
    ),
  );
}

/* ═════════════ Announcements ═════════════ */

const annForm = { title: '', text: '', ping: null, image: '' };

function pageAnnouncements() {
  const post = localChannel(null);
  const previewSlot = h('div');
  const drawPreview = () => previewSlot.replaceChildren(dcMessage([
    { t: 'text', md: [annForm.ping ? `<@&${annForm.ping}>` : '', annForm.title ? `## ${annForm.title}` : '', annForm.text || 'Your message shows here.'].filter(Boolean).join('\n') },
    ...(httpOk(annForm.image) ? [{ t: 'gallery', url: annForm.image }] : []),
  ]));
  const title = h('input', { class: 'input', value: annForm.title, maxlength: 200, placeholder: 'Optional', 'aria-label': 'Title' });
  title.addEventListener('input', () => { annForm.title = title.value; drawPreview(); });
  const text = h('textarea', { class: 'input', rows: 6, value: annForm.text, maxlength: 3500, 'aria-label': 'Message' });
  text.addEventListener('input', () => { annForm.text = text.value; drawPreview(); });
  const image = h('input', { class: 'input', value: annForm.image, placeholder: 'https://… (optional)', 'aria-label': 'Image link' });
  image.addEventListener('input', () => { annForm.image = image.value.trim(); drawPreview(); });
  const ping = picker({ items: roleItems(), value: annForm.ping, placeholder: 'Nobody', label: 'Ping a role', searchPlaceholder: 'Search roles', onChange: v => { annForm.ping = v; drawPreview(); } });
  drawPreview();
  const send = h('button', { class: 'btn primary', onclick: async e => {
    if (!post.value) return toast('Pick a channel first.', { error: true });
    const res = await doAction(e.currentTarget, 'announcements', 'send', { channel_id: post.value, title: annForm.title, text: annForm.text, ping_role_id: annForm.ping, image_url: annForm.image });
    if (res) { Object.assign(annForm, { title: '', text: '', image: '' }); App.render(); }
  } }, icon('send'), 'Post');

  const lastSent = extra('announcements').last_sent || {};
  const savedIds = new Set((S.saved.ann_messages || []).map(m => m.id));
  return h('div', null,
    pageHead('Announcements', 'Post a message as the bot, and set up timed messages that repeat (rules reminders, store links, the server IP...). Staff can also use /announce.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Post a message', null, [
          row('Title', null, title), row('Message', 'Supports Discord formatting.', text), row('Image', null, image), row('Ping', null, ping),
          row('Channel', null, h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), send)),
        ]),
        panel('Timed messages', 'Posted again and again on a timer. The first one goes out within a minute of saving.', h('div', { class: 'panel-body' }, recordsEditor('ann_messages', {
          max: 25, addLabel: 'Add timed message', empty: 'No timed messages yet.',
          blank: () => ({ name: '', channel_id: null, title: '', text: '', every_hours: 24, ping_role_id: null, enabled: true }),
          title: r => r.name || r.title || 'Timed message',
          sub: r => `${r.enabled ? `Every ${r.every_hours} h` : 'Paused'}${r.channel_id ? ` in #${channelName(r.channel_id) || 'deleted'}` : ''}${lastSent[r.id] ? `, last sent ${ago(lastSent[r.id])}` : ''}`,
          fields: [
            { key: 'name', label: 'Name', help: 'Only shown here.', type: 'text', max: 80, placeholder: 'e.g. Rules reminder' },
            { key: 'channel_id', label: 'Channel', type: 'channel' },
            { key: 'title', label: 'Title', type: 'text', max: 200, placeholder: 'Optional' },
            { key: 'text', label: 'Message', type: 'textarea', max: 2000 },
            { key: 'every_hours', label: 'Every', type: 'choice', options: [[1, '1 hour'], [3, '3 hours'], [6, '6 hours'], [12, '12 hours'], [24, '1 day'], [72, '3 days'], [168, '1 week']] },
            { key: 'ping_role_id', label: 'Ping', type: 'role', placeholder: 'Nobody' },
            { key: 'enabled', label: 'On', type: 'toggle', text: 'Post this on its timer' },
          ],
          actions: r => savedIds.has(r.id) ? h('button', { type: 'button', class: 'btn small', onclick: e => doAction(e.currentTarget, 'announcements', 'send-timed', { id: r.id }) }, icon('send'), 'Send now') : null,
        }))),
      ),
      h('aside', { class: 'sticky' }, h('div', { class: 'preview-title' }, 'Preview'), previewSlot),
    ),
  );
}

/* ═════════════ Join-to-create voice ═════════════ */

function pageTempvoice() {
  const active = extra('tempvoice').active || 0;
  return h('div', null,
    pageHead('Voice channels', 'Joining the join-to-create channel makes a voice channel just for you. It\'s deleted when everyone leaves.'),
    oneColumn(
      panel('Settings', null, [
        row('Join-to-create channel', 'A voice channel. Make one called "➕ Join to create".', channelPick('tv_hub_channel_id', { types: ['voice', 'stage_voice'], placeholder: 'Pick a voice channel' }), { key: 'tv_hub_channel_id' }),
        row('Category', 'Where new channels go. Empty uses the join-to-create channel\'s category.', channelPick('tv_category_id', { types: ['category'], placeholder: 'Same category' }), { key: 'tv_category_id' }),
        row('Channel name', null, [textInput('tv_name', { max: 80 }), placeholderHelp('tv_name', [['{user}', 'Their name']])], { key: 'tv_name' }),
        row('People limit', '0 means no limit. Owners can change it with /vc-limit.', numberInput('tv_limit', { min: 0, max: 99, label: 'Limit' }), { key: 'tv_limit' }),
      ]),
      note(`Channel owners can use /vc-limit, /vc-rename, /vc-lock and /vc-unlock. ${active ? `${active} channel${active === 1 ? ' is' : 's are'} open right now.` : ''} The bot needs Manage Channels and Move Members.`, 'info'),
    ),
  );
}

/* ═════════════ Channel tools ═════════════ */

const STAT_TOKENS = [['{members}', 'Everyone'], ['{humans}', 'People'], ['{bots}', 'Bots'], ['{boosts}', 'Boosts'], ['{channels}', 'Channels'], ['{roles}', 'Roles']];

function pageChanneltools() {
  const info = extra('channeltools');
  const values = info.values || {};
  const example = t => String(t || '').replace(/\{(\w+)\}/g, (m, k) => k in values ? Number(values[k]).toLocaleString() : m);
  return h('div', null,
    pageHead('Channel tools', 'Sticky messages, stat channels and a counting game.'),
    oneColumn(
      panel('Sticky messages', 'Always reposted at the bottom of the channel, a few seconds after someone writes.', h('div', { class: 'panel-body' }, recordsEditor('sticky_messages', {
        max: 15, addLabel: 'Add sticky message', empty: 'No sticky messages yet.',
        blank: () => ({ channel_id: null, text: '' }),
        title: r => r.channel_id ? '#' + (channelName(r.channel_id) || 'deleted') : 'Pick a channel', sub: r => (r.text || '').slice(0, 60),
        fields: [{ key: 'channel_id', label: 'Channel', type: 'channel' }, { key: 'text', label: 'Message', type: 'textarea', max: 1500 }],
      }))),
      panel('Stat channels', 'A channel whose name shows a live number, updated every 10 minutes. Voice channels nobody can join work best.', [
        h('div', { class: 'panel-body' }, recordsEditor('stat_channels', {
          max: 10, addLabel: 'Add stat channel', empty: 'No stat channels yet.',
          blank: () => ({ channel_id: null, template: 'Members: {members}' }),
          title: r => example(r.template) || 'New stat channel', sub: r => r.channel_id ? '#' + (channelName(r.channel_id) || 'deleted') : 'No channel picked',
          fields: [
            { key: 'channel_id', label: 'Channel', type: 'channel', types: ['voice', 'text', 'news', 'stage_voice', 'category'] },
            { key: 'template', label: 'Name', help: `Use ${STAT_TOKENS.map(t => t[0]).join(' ')}.`, type: 'text', max: 80 },
          ],
        })),
        h('div', { class: 'panel-foot' }, h('button', { class: 'btn small', onclick: e => doAction(e.currentTarget, 'channeltools', 'refresh-stats') }, icon('refresh'), 'Update names now')),
      ]),
      panel('Counting', 'Members count up one number at a time. The same person can\'t count twice in a row.', [
        row('Counting channel', null, channelPick('count_channel_id'), { key: 'count_channel_id' }),
        row('Mistakes', null, toggle('count_reset_on_fail', 'A wrong number starts the count over'), { key: 'count_reset_on_fail', inline: true }),
        row('Count', null, h('div', { class: 'input-row' }, h('b', null, `${info.count || 0}`), h('span', { class: 'row-help' }, `Best: ${info.best || 0}`),
          h('button', { class: 'btn small', onclick: async e => { if (await doAction(e.currentTarget, 'channeltools', 'reset-count')) App.render(); } }, 'Start over')), { inline: true }),
      ]),
    ),
  );
}

/* ═════════════ Applications ═════════════ */

let appFilter = 'pending';

function pageApplications() {
  const info = extra('applications');
  const items = info.items || [];
  const shown = appFilter === 'all' ? items : items.filter(i => i.status === appFilter);
  const decide = async (btn, i, decision) => {
    let reason = '';
    if (decision === 'denied') {
      reason = await askText({ title: `Deny application #${i.number}?`, text: 'They get a DM. Add a reason if you like.', placeholder: 'Reason (optional)', confirm: 'Deny', danger: true });
      if (reason === null) return;
    }
    if (await doAction(btn, 'applications', 'decide', { number: i.number, decision, reason })) App.render();
  };
  const item = i => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, `#${i.number} ${i.form}`, h('span', { class: 'tag' + (i.status === 'accepted' ? ' on' : i.status === 'denied' ? ' off' : ' warn') },
        { pending: 'Waiting', accepted: 'Accepted', denied: 'Denied' }[i.status])),
      h('div', { class: 'item-meta spread' }, h('span', null, i.user?.name), h('span', null, ago(i.t)), i.decided_by ? h('span', null, `By ${i.decided_by}`) : null),
      h('details', { class: 'answers', open: i.status === 'pending' }, h('summary', null, 'Answers'),
        h('dl', null, i.answers.map(([q, a]) => [h('dt', null, q), h('dd', null, a || 'No answer')]))),
      i.reason ? h('div', { class: 'item-meta' }, `Reason: ${i.reason}`) : null),
    h('div', { class: 'item-actions' },
      i.url ? h('a', { class: 'btn small ghost', href: i.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open') : null,
      i.status === 'pending' ? [
        h('button', { class: 'btn small', onclick: e => decide(e.currentTarget, i, 'accepted') }, icon('check'), 'Accept'),
        h('button', { class: 'btn small danger', onclick: e => decide(e.currentTarget, i, 'denied') }, icon('x'), 'Deny')] : null));

  return h('div', null,
    pageHead('Applications', 'Staff applications, whitelist applications, partner requests... Members answer up to 5 questions, and staff accept or deny in a review channel.'),
    oneColumn(
      panel('Applications', 'Each one gets a button on the panel.', h('div', { class: 'panel-body' }, recordsEditor('app_forms', {
        max: 10, addLabel: 'Add application', empty: 'No applications yet.',
        blank: () => ({ name: 'Staff', emoji: '📝', description: '', questions: [{ label: 'Why do you want to join the team?', long: true, required: true }], review_channel_id: null, reviewer_role_ids: [], accept_role_id: null, open: true }),
        title: r => r.name || 'New application', sub: r => `${(r.questions || []).length} question${(r.questions || []).length === 1 ? '' : 's'}${r.open ? '' : ', closed'}`,
        lead: r => emojiNode(r.emoji || '📝', 'dc-emoji'),
        fields: [
          { key: 'name', label: 'Name', type: 'text', max: 80 },
          { key: 'emoji', label: 'Emoji', type: 'emoji' },
          { key: 'description', label: 'Description', help: 'Shown on the panel.', type: 'text', max: 100, placeholder: 'Optional' },
          { key: 'questions', label: 'Questions', help: 'Up to 5.', type: 'custom', render: (v, update) => questionsEditor(v, update) },
          { key: 'review_channel_id', label: 'Review channel', help: 'Answers go here with Accept and Deny buttons.', type: 'channel' },
          { key: 'reviewer_role_ids', label: 'Reviewers', help: 'Anyone with Manage Server can always review.', type: 'roles' },
          { key: 'accept_role_id', label: 'Role when accepted', type: 'role', placeholder: 'No role' },
          { key: 'open', label: 'Open', type: 'toggle', text: 'Taking applications' },
        ],
      }))),
      panel('Panel', null, [
        row('Title', null, textInput('app_panel_title', { max: 200 }), { key: 'app_panel_title' }),
        row('Text', null, textInput('app_panel_text', { multiline: true, rows: 2, max: 1000 }), { key: 'app_panel_text' }),
        postRow('Post the panel', 'Posted panels update by themselves when you save changes.', 'applications', 'panel', { keys: ['app_forms', 'app_panel_title', 'app_panel_text'] }),
      ]),
      panel('Submitted', info.pending ? `${info.pending} waiting for review.` : null, [
        h('div', { class: 'panel-body' }, h('div', { class: 'quick' }, [['pending', 'Waiting'], ['accepted', 'Accepted'], ['denied', 'Denied'], ['all', 'All']].map(([k, l]) =>
          h('button', { type: 'button', class: appFilter === k ? 'on' : '', onclick: () => { appFilter = k; App.render(); } }, l)))),
        shown.length ? h('div', { class: 'list' }, shown.map(item)) : h('div', { class: 'empty' }, 'Nothing here.')]),
    ),
  );
}

/* ═════════════ FAQ ═════════════ */

function pageFaq() {
  return h('div', null,
    pageHead('FAQ', 'A panel with a dropdown of common questions. Picking one shows the answer to just that person. /faq answers in the channel.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Questions', null, h('div', { class: 'panel-body' }, recordsEditor('faq_entries', {
          max: 25, addLabel: 'Add question', empty: 'No questions yet.',
          blank: () => ({ question: '', answer: '', emoji: '' }),
          title: r => r.question || 'New question', lead: r => emojiNode(r.emoji || '❔', 'dc-emoji'),
          fields: [
            { key: 'question', label: 'Question', type: 'text', max: 100 },
            { key: 'emoji', label: 'Emoji', type: 'emoji' },
            { key: 'answer', label: 'Answer', help: 'Supports Discord formatting.', type: 'textarea', max: 2000 },
          ],
        }))),
        panel('Panel', null, [
          row('Title', null, textInput('faq_title', { max: 200 }), { key: 'faq_title' }),
          row('Text', null, textInput('faq_text', { multiline: true, rows: 2, max: 1000 }), { key: 'faq_text' }),
          postRow('Post the panel', 'Posted panels update by themselves when you save new questions.', 'faq', 'panel', { keys: ['faq_entries', 'faq_title', 'faq_text'] }),
        ]),
      ),
      livePreview('Preview', () => dcMessage([
        { t: 'text', md: `## ${get('faq_title') || 'FAQ'}` }, ...(get('faq_text') ? [{ t: 'text', md: get('faq_text') }] : []),
        (get('faq_entries') || []).length ? { t: 'select', placeholder: 'Pick a question' } : { t: 'text', md: '-# No questions yet.' },
      ])),
    ),
  );
}

/* ═════════════ Status page ═════════════ */

const STATUS_STATES = [['operational', '🟢 Operational'], ['maintenance', '🔧 Maintenance'], ['degraded', '🟡 Degraded'], ['partial', '🟠 Partial outage'], ['major', '🔴 Major outage']];

function statusBlocks() {
  const parts = (get('status_components') || []).filter(p => p.name);
  const order = STATUS_STATES.map(s => s[0]);
  const worst = parts.reduce((w, p) => order.indexOf(p.state) > order.indexOf(w) ? p.state : w, 'operational');
  const label = s => STATUS_STATES.find(x => x[0] === s)[1];
  const head = worst === 'operational' ? '## 🟢 All systems operational' : `## ${label(worst)}`;
  return [{ t: 'text', md: head },
    { t: 'text', md: parts.map(p => `${label(p.state).split(' ')[0]} **${p.name}**: ${label(p.state).split(' ').slice(1).join(' ')}`).join('\n') || '-# Nothing added yet.' },
    ...(get('status_note') ? [{ t: 'text', md: `> ${get('status_note')}` }] : []), { t: 'text', md: '-# Updated just now' }];
}

function pageStatus() {
  const info = extra('status');
  return h('div', null,
    pageHead('Status page', 'A message that shows whether each part of your service is working. It updates by itself when you save, or when staff use /status-set.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Parts', null, h('div', { class: 'panel-body' }, recordsEditor('status_components', {
          max: 20, addLabel: 'Add part', empty: 'Add the parts of your service, like "Game server" or "Website".',
          blank: () => ({ name: '', state: 'operational' }),
          title: r => r.name || 'New part', sub: r => (STATUS_STATES.find(s => s[0] === r.state) || STATUS_STATES[0])[1],
          fields: [{ key: 'name', label: 'Name', type: 'text', max: 80 }, { key: 'state', label: 'Status', type: 'choice', options: STATUS_STATES }],
        }))),
        panel('Message', null, [
          row('Note', 'Shown under the list, like "We\'re working on it, back in 20 minutes".', textInput('status_note', { multiline: true, rows: 2, max: 1000 }), { key: 'status_note' }),
          row('Channel', null, channelPick('status_channel_id'), { key: 'status_channel_id' }),
          row(info.posted ? 'Status message' : 'Post it', info.posted ? 'Posted. It updates by itself.' : null, h('div', { class: 'input-row' },
            savedFirstNote(['status_channel_id']),
            h('button', { class: 'btn primary', onclick: async e => { if (await doAction(e.currentTarget, 'status', 'post', { new: !info.posted })) App.render(); } }, icon('send'), info.posted ? 'Update now' : 'Post status message'),
            info.url ? h('a', { class: 'btn ghost', href: info.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open') : null)),
        ]),
        (info.history || []).length ? panel('Recent changes', null, h('div', { class: 'list' }, info.history.map(x => h('div', { class: 'item' }, h('div', null,
          h('div', { class: 'item-title' }, x.name, h('span', { class: 'tag' }, (STATUS_STATES.find(s => s[0] === x.state) || [0, x.state])[1])),
          h('div', { class: 'item-meta spread' }, h('span', null, ago(x.t)), h('span', null, `By ${x.by}`))))))) : null,
      ),
      livePreview('Status message', () => dcMessage(statusBlocks())),
    ),
  );
}

/* ═════════════ Reviews ═════════════ */

function starBar(spread) {
  const max = Math.max(1, ...spread);
  return h('div', { class: 'star-bars' }, [5, 4, 3, 2, 1].map(n => h('div', null, h('span', null, `${n} ★`),
    h('div', { class: 'lb-bar' }, h('span', { style: { width: `${Math.round(100 * spread[n - 1] / max)}%` } })), h('b', null, spread[n - 1]))));
}

function pageReviews() {
  const info = extra('reviews');
  const items = info.items || [];
  return h('div', null,
    pageHead('Reviews', 'Members leave a 1-5 star review with /review. It\'s posted in the reviews channel. One review per member a day.'),
    oneColumn(
      panel('Settings', null, [
        row('Reviews channel', null, channelPick('rev_channel_id'), { key: 'rev_channel_id' }),
        row('Who can review', 'Only members with this role. Empty lets anyone review.', rolePick('rev_role_id', { placeholder: 'Anyone' }), { key: 'rev_role_id' }),
      ]),
      info.count ? panel(`${info.average} ★ average`, `From ${info.count} review${info.count === 1 ? '' : 's'}.`, h('div', { class: 'panel-body' }, starBar(info.spread))) : null,
      panel('Reviews', items.length ? null : 'No reviews yet.', items.length ? h('div', { class: 'list' }, items.map(r => h('div', { class: 'item' },
        h('div', null, h('div', { class: 'item-title' }, '★'.repeat(r.stars) + '☆'.repeat(5 - r.stars), h('span', { class: 'tag' }, `#${r.number}`)),
          h('div', { class: 'sug-text' }, r.text), h('div', { class: 'item-meta spread' }, h('span', null, r.user?.name), h('span', null, ago(r.t)))),
        h('div', { class: 'item-actions' },
          r.url ? h('a', { class: 'btn small ghost', href: r.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open') : null,
          h('button', { class: 'btn small icon danger', title: 'Delete', 'aria-label': `Delete review ${r.number}`, onclick: async e => {
            const b = e.currentTarget;
            if (!await confirmDialog({ title: `Delete review #${r.number}?`, text: 'It\'s deleted from Discord too.', confirm: 'Delete', danger: true })) return;
            if (await doAction(b, 'reviews', 'delete', { number: r.number })) App.render();
          } }, icon('trash')))))) : null),
    ),
  );
}

/* ═════════════ Roblox: game & group ═════════════ */

function gameCard(g) {
  return h('div', { class: 'group-found' },
    h('div', null, h('b', null, g.name), h('div', { class: 'row-help' }, `${g.playing.toLocaleString()} playing, ${g.visits.toLocaleString()} visits, ${g.favorites.toLocaleString()} favorites`)),
    h('a', { class: 'btn small ghost', href: `https://www.roblox.com/games/${g.place_id}`, target: '_blank', rel: 'noopener' }, icon('external'), 'Open game'));
}

function pageRobloxGame() {
  const info = extra('roblox-game');
  const place = textInput('rbx_place_id', { placeholder: 'Like 1234567' });
  place.setAttribute('inputmode', 'numeric');
  const found = h('div');
  if (info.game) found.append(gameCard(info.game));
  const look = h('button', { class: 'btn', onclick: async e => {
    const res = await doAction(e.currentTarget, 'roblox-game', 'lookup', { place_id: get('rbx_place_id') });
    if (res?.game) found.replaceChildren(gameCard(res.game));
  } }, icon('search'), 'Look up');
  return h('div', null,
    pageHead('Game & group', 'Live stats for your Roblox game, and your group\'s shouts posted in Discord. Members can check the game with /game.'),
    oneColumn(
      panel('Game', null, [
        row('Place ID', 'The number in your game\'s link: roblox.com/games/1234567.', [h('div', { class: 'input-row' }, place, look), found], { key: 'rbx_place_id' }),
        row('Live stats channel', 'A message with the player count, visits and favorites, updated every 5 minutes.', channelPick('rbx_stats_channel_id'), { key: 'rbx_stats_channel_id' }),
        row('', null, h('div', { class: 'input-row' }, savedFirstNote(['rbx_place_id', 'rbx_stats_channel_id']),
          h('button', { class: 'btn primary', onclick: async e => { if (await doAction(e.currentTarget, 'roblox-game', 'post-stats', { new: !info.stats_posted })) App.render(); } },
            icon('send'), info.stats_posted ? 'Update now' : 'Post live stats'))),
      ]),
      panel('Group shouts', S.saved.roblox_group_id ? `New shouts in group ${S.saved.roblox_group_id} are posted here within 5 minutes.` : null, [
        !S.saved.roblox_group_id ? h('div', { class: 'panel-body' }, h('div', { class: 'note info' }, icon('alert'), h('div', null, 'Add your group ID on the ', h('a', { href: here('roblox-ranks') }, 'Role binds'), ' page first.'))) : null,
        row('Shout channel', null, channelPick('rbx_shout_channel_id'), { key: 'rbx_shout_channel_id' }),
      ]),
    ),
  );
}

/* ═════════════ Roblox: sessions ═════════════ */

const sessForm = { type: null, notes: '' };

function pageSessions() {
  const info = extra('roblox-sessions');
  const types = info.types || [];
  if (!types.includes(sessForm.type)) sessForm.type = types[0] || null;
  const typeChips = h('div', { class: 'quick' });
  const drawTypes = () => typeChips.replaceChildren(...types.map(t => h('button', { type: 'button', class: sessForm.type === t ? 'on' : '', onclick: () => { sessForm.type = t; drawTypes(); } }, t)));
  drawTypes();
  const notes = h('input', { class: 'input', value: sessForm.notes, maxlength: 500, placeholder: 'Optional, like "Bring your uniform"', 'aria-label': 'Notes' });
  notes.addEventListener('input', () => { sessForm.notes = notes.value; });
  const startBtn = h('button', { class: 'btn primary', onclick: async e => {
    if (await doAction(e.currentTarget, 'roblox-sessions', 'start', { type: sessForm.type, notes: sessForm.notes })) { sessForm.notes = ''; App.render(); }
  } }, icon('send'), 'Announce');

  return h('div', null,
    pageHead('Sessions', 'Announce trainings, shifts and events with a ping and a button to join the game. Hosts use /session-start and /session-end in Discord.'),
    oneColumn(
      panel('Start a session', null, [
        row('Kind', null, typeChips), row('Notes', null, notes),
        row('', null, h('div', { class: 'input-row' }, savedFirstNote(['sess_channel_id', 'sess_types', 'sess_ping_role_id', 'sess_link']), startBtn)),
      ]),
      (info.active || []).length ? panel('Running now', null, h('div', { class: 'list' }, info.active.map(s => h('div', { class: 'item' },
        h('div', null, h('div', { class: 'item-title' }, `${s.emoji || '📅'} ${s.type}`, h('span', { class: 'tag on live' }, 'Live')),
          h('div', { class: 'item-meta spread' }, h('span', null, `Host: ${s.host}`), h('span', null, `Started ${ago(s.started)}`))),
        h('div', { class: 'item-actions' },
          h('a', { class: 'btn small ghost', href: s.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open'),
          h('button', { class: 'btn small', onclick: async e => { if (await doAction(e.currentTarget, 'roblox-sessions', 'end', { id: s.id })) App.render(); } }, 'End')))))) : null,
      panel('Settings', null, [
        row('Channel', 'Where sessions are announced.', channelPick('sess_channel_id'), { key: 'sess_channel_id' }),
        row('Ping', 'Role pinged when a session starts.', rolePick('sess_ping_role_id', { placeholder: 'Nobody' }), { key: 'sess_ping_role_id' }),
        row('Hosts', 'Who can start sessions. Anyone with Manage Server always can.', rolePick('sess_host_role_ids', { multiple: true }), { key: 'sess_host_role_ids' }),
        row('Join link', 'Empty uses your game from Game & group.', textInput('sess_link', { placeholder: 'https://www.roblox.com/games/…' }), { key: 'sess_link' }),
        row('Kinds of sessions', null, recordsEditor('sess_types', {
          max: 10, addLabel: 'Add kind', blank: () => ({ name: '', emoji: '📅' }),
          title: r => r.name || 'New kind', lead: r => emojiNode(r.emoji || '📅', 'dc-emoji'),
          fields: [{ key: 'name', label: 'Name', type: 'text', max: 50 }, { key: 'emoji', label: 'Emoji', type: 'emoji' }],
        }), { key: 'sess_types' }),
      ]),
      (info.history || []).length ? panel('Past sessions', null, h('div', { class: 'list' }, info.history.map(s => h('div', { class: 'item' }, h('div', null,
        h('div', { class: 'item-title' }, `${s.emoji || '📅'} ${s.type}`),
        h('div', { class: 'item-meta spread' }, h('span', null, `Host: ${s.host}`), h('span', null, ago(s.started)), h('span', null, `Lasted ${span(s.ended - s.started)}`))))))) : null,
    ),
  );
}

/* ═════════════ Pieces added to existing pages ═════════════ */

/** Welcome page: join roles, a DM and goodbye messages. */
function welcomeExtras() {
  return [
    panel('Join roles', 'Given to everyone who joins. /autorole changes these too.', [
      row('Members', null, [rolePick('join_role_ids', { multiple: true })], { key: 'join_role_ids' }),
      row('Bots', 'Bots get these instead.', rolePick('join_bot_role_ids', { multiple: true }), { key: 'join_bot_role_ids' }),
    ]),
    panel('Welcome DM', 'Sent privately to new members. Leave it empty to send nothing.', [
      row('Message', null, [textInput('welcome_dm', { multiline: true, rows: 3, max: 1500 }), placeholderHelp('welcome_dm', TOKENS_USER)], { key: 'welcome_dm', wide: true }),
    ]),
    panel('Goodbye messages', null, [
      row('Post a goodbye', null, toggle('goodbye_enabled', 'When someone leaves'), { key: 'goodbye_enabled', inline: true }),
      row('Channel', null, channelPick('goodbye_channel_id'), { key: 'goodbye_channel_id' }),
      row('Message', null, [textInput('goodbye_message', { multiline: true, rows: 2, max: 1000 }), placeholderHelp('goodbye_message', [['{username}', 'Their name'], ['{server}', 'Server name'], ['{member_count}', 'Member count']])], { key: 'goodbye_message' }),
    ]),
  ];
}

/** Verification page: who's allowed to verify, and keeping roles up to date. */
function robloxScreening() {
  return panel('Who can verify', null, [
    row('Account age', 'Keeps out brand new alt accounts. 0 lets any account verify.', h('div', { class: 'input-row' },
      numberInput('rbx_min_age_days', { min: 0, max: 3650, label: 'Days' }), h('span', null, 'days old or more')), { key: 'rbx_min_age_days' }),
    row('Blocked groups', 'Accounts in these Roblox groups can\'t verify. Type a group ID and press Enter.', wordBox('rbx_blacklist_groups', { placeholder: 'Group ID, like 1234567' }), { key: 'rbx_blacklist_groups' }),
    row('Auto-update', 'Re-check everyone\'s ranks, badges and passes on a timer.', chipChoice('rbx_auto_update_hours', [[0, 'Off'], [6, 'Every 6 h'], [12, 'Every 12 h'], [24, 'Every day'], [72, 'Every 3 days']]), { key: 'rbx_auto_update_hours' }),
  ]);
}

/** Role binds page: badge and game pass roles. */
function robloxBinds() {
  const bind = (key, idKey, what, placeholder) => recordsEditor(key, {
    max: 25, addLabel: `Add ${what} role`, empty: `No ${what} roles yet.`,
    blank: () => ({ [idKey]: '', role_id: null, name: '' }),
    title: r => r.name || (r[idKey] ? `${what[0].toUpperCase() + what.slice(1)} ${r[idKey]}` : `New ${what} role`),
    sub: r => G.role(r.role_id)?.name || 'No role picked',
    fields: [
      { key: idKey, label: `${what[0].toUpperCase() + what.slice(1)} ID`, help: `The number in the ${what}'s link.`, type: 'text', max: 15, placeholder, numeric: true },
      { key: 'name', label: 'Name', help: 'Only shown here, to tell them apart.', type: 'text', max: 100, placeholder: 'Optional' },
      { key: 'role_id', label: 'Role', type: 'role' },
    ],
  });
  return [
    panel('Badge roles', 'Members who own a badge from your game get a role.', h('div', { class: 'panel-body' }, bind('rbx_badge_roles', 'badge_id', 'badge', 'Like 2124567890'))),
    panel('Game pass roles', 'Members who bought a game pass get a role. Their Roblox inventory has to be public.', h('div', { class: 'panel-body' }, bind('rbx_pass_roles', 'pass_id', 'game pass', 'Like 12345678'))),
  ];
}

/** Ticket types page: auto-close, ratings, support hours, saved replies. */
function ticketExtras() {
  return [
    panel('Extras', null, [
      row('Auto-close', 'Close tickets nobody has written in for this long.', chipChoice('ticket_autoclose_hours', [[0, 'Off'], [12, '12 h'], [24, '1 day'], [48, '2 days'], [72, '3 days'], [168, '1 week']]), { key: 'ticket_autoclose_hours' }),
      row('Ratings', null, toggle('ticket_rating', 'Ask members to rate the help (1-5 stars) when their ticket closes'), { key: 'ticket_rating', inline: true }),
      row('DM to open', null, toggle('ticket_dm_open', 'Members can DM the bot to open a ticket (uses the first ticket type)'), { key: 'ticket_dm_open', inline: true }),
    ]),
    panel('Support hours', 'Tickets opened outside these hours get a note saying replies may be slower.', [
      row('Support hours', null, toggle('ticket_hours_on', 'Use support hours'), { key: 'ticket_hours_on', inline: true }),
      row('Open from', null, h('div', { class: 'input-row' }, hourSelect('ticket_hours_start'), h('span', null, 'to'), hourSelect('ticket_hours_end')), { key: 'ticket_hours_start' }),
      row('Time zone', 'Hours from UTC.', (() => {
        const el = h('select', { class: 'input', style: { width: '160px' } }, Array.from({ length: 27 }, (_, i) => i - 12).map(n =>
          h('option', { value: n, selected: get('ticket_utc_offset') === n }, `UTC${n >= 0 ? '+' : ''}${n}`)));
        el.addEventListener('change', () => set('ticket_utc_offset', Number(el.value)));
        return el;
      })(), { key: 'ticket_utc_offset' }),
      row('Away message', null, textInput('ticket_offline_message', { multiline: true, rows: 2, max: 1000 }), { key: 'ticket_offline_message' }),
    ]),
    panel('Saved replies', 'Staff send these in tickets with /snippet.', h('div', { class: 'panel-body' }, recordsEditor('ticket_snippets', {
      max: 25, addLabel: 'Add saved reply', empty: 'No saved replies yet.',
      blank: () => ({ name: '', text: '' }), title: r => r.name || 'New saved reply', sub: r => (r.text || '').slice(0, 60),
      fields: [{ key: 'name', label: 'Name', help: 'What staff type after /snippet.', type: 'text', max: 32 }, { key: 'text', label: 'Text', help: 'Use {user} to mention the member.', type: 'textarea', max: 2000 }],
    }))),
  ];
}

/** Tickets page: how members rated the help. */
function ticketRatings() {
  const r = extra('tickets');
  if (!r.count) return S.saved.ticket_rating ? panel('Ratings', 'No ratings yet. Members are asked when their ticket closes.', null) : null;
  return panel(`${r.average} ★ average rating`, `From ${r.count} rating${r.count === 1 ? '' : 's'}.`, [
    h('div', { class: 'panel-body' }, starBar(r.spread)),
    r.staff.length ? h('div', { class: 'list' }, r.staff.map(s => h('div', { class: 'item' }, personLine(s, `${s.average} ★ from ${s.count} claimed ticket${s.count === 1 ? '' : 's'}`)))) : null,
  ]);
}

/* ═════════════ Bot profile (server owner only) ═════════════ */

// undefined = not changed, '' = back to the normal one, 'data:…' = a new picture
const profForm = { gid: null, nick: undefined, avatar: undefined, banner: undefined };
const profReset = () => Object.assign(profForm, { nick: undefined, avatar: undefined, banner: undefined });

function profileValue(key) {
  const p = S.data.profile || {};
  if (profForm[key] === undefined) return key === 'nick' ? p.nick : p[key];
  return profForm[key];
}

function imagePicker(key, label, { disabled = false, onPick }) {
  const input = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp', hidden: true, 'aria-label': `Upload ${label}` });
  input.addEventListener('change', () => {
    const file = input.files[0];
    input.value = '';
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/gif', 'image/webp'].includes(file.type)) return toast('Pick a PNG, JPG, GIF or WebP image.', { error: true });
    if (file.size > 10 * 1024 * 1024) return toast('That image is over 10 MB. Discord takes images up to 10 MB.', { error: true });
    const reader = new FileReader();
    reader.onload = () => onPick(reader.result);
    reader.readAsDataURL(file);
  });
  const custom = profileValue(key);
  return h('div', { class: 'input-row', style: { flexWrap: 'wrap' } },
    input,
    h('button', { type: 'button', class: 'btn small', disabled, onclick: () => input.click() }, icon('plus'), custom ? `Change ${label}` : `Upload ${label}`),
    custom ? h('button', { type: 'button', class: 'btn small ghost', disabled, onclick: () => onPick('') }, `Use the normal ${label}`) : null);
}

function profileCard() {
  const p = S.data.profile || {};
  const avatar = profileValue('avatar') || p.default_avatar;
  const banner = profileValue('banner') || p.default_banner;
  const name = profileValue('nick') || p.global_name || p.name;
  const accent = /^#[0-9a-f]{6}$/i.test(get('accent_color') || '') ? get('accent_color') : '#ffffff';
  return h('div', { class: 'pf-card' },
    h('div', { class: 'pf-banner', style: banner ? { backgroundImage: `url("${banner}")` } : { background: accent } }),
    h('div', { class: 'pf-body' },
      h('div', { class: 'pf-avatar', style: avatar ? { backgroundImage: `url("${avatar}")` } : {} }),
      h('div', { class: 'pf-name' }, name),
      h('div', { class: 'pf-user' }, p.name || '', h('span', { class: 'dc-app' }, 'APP')),
      h('div', { class: 'pf-note' }, `How members of ${S.data.guild.name} see the bot`)));
}

function pageProfile() {
  if (profForm.gid !== S.gid) { profReset(); profForm.gid = S.gid; }
  const p = S.data.profile || {};
  const owner = !!S.data.you?.owner;
  const dirty = ['nick', 'avatar', 'banner'].some(k => profForm[k] !== undefined);
  const nick = h('input', { class: 'input', value: profileValue('nick') || '', maxlength: 32, placeholder: p.global_name || p.name || '', disabled: !owner, 'aria-label': 'Name in this server' });
  nick.addEventListener('input', () => { profForm.nick = nick.value; drawPreview(); bar.hidden = false; });
  const previewSlot = h('div');
  const drawPreview = () => previewSlot.replaceChildren(profileCard());
  drawPreview();

  const save = h('button', { class: 'btn primary', onclick: async e => {
    const body = {};
    for (const k of ['nick', 'avatar', 'banner']) if (profForm[k] !== undefined) body[k] = profForm[k];
    const res = await act(e.currentTarget, () => gapi('POST', '/profile', body));
    if (res) {
      S.data.profile = res.profile;
      profReset();
      App.render();
    }
  } }, 'Save profile');
  const bar = h('div', { class: 'panel-foot', hidden: !dirty },
    h('button', { class: 'btn ghost', onclick: () => { profReset(); App.render(); } }, 'Undo'),
    save);
  const pick = key => v => { profForm[key] = v; App.render(); };

  return h('div', null,
    pageHead('Bot profile', 'Give the bot its own name, picture and banner in this server. Other servers keep the normal ones.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        !owner ? note('Only the server owner can change these. You can look, but saving is turned off for you.', 'info') : null,
        panel('Profile in this server', null, [
          row('Name', 'Empty uses the bot\'s normal name. Up to 32 characters.', nick),
          row('Profile picture', 'Square images work best. PNG, JPG, GIF or WebP up to 10 MB. GIFs move.', imagePicker('avatar', 'picture', { disabled: !owner, onPick: pick('avatar') })),
          row('Banner', 'Shown at the top of the bot\'s profile. Wide images work best, like 680 × 240.', imagePicker('banner', 'banner', { disabled: !owner, onPick: pick('banner') })),
          owner ? bar : null,
        ]),
        owner ? note('Discord only lets bots change their profile a few times in a while, so pick your images before saving.', 'info') : null,
      ),
      h('aside', { class: 'sticky' }, h('div', { class: 'preview-title' }, 'Preview'), previewSlot),
    ),
  );
}
