/* Runs before the page draws so the saved light/dark choice doesn't flash. */
(function () {
  try {
    var t = localStorage.getItem('com-theme');
    if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t);
  } catch (e) { /* storage blocked: follow the system setting */ }
})();
