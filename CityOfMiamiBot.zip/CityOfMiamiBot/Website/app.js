/* Boot, routing, logging in, the server dashboard layout and saving. */
'use strict';

const LOGIN_ERRORS = {
  expired: 'That Discord login took too long. Try again.',
  discord: "Discord login didn't work. Try again.",
  off: "Logging in isn't set up on this bot yet. The bot's owner needs to add the bot's Client Secret (the bot's console says how).",
};

const LABELS = {
  server_name: 'Server name', accent_color: 'Accent color', city_emoji: 'Server emoji', thumbnail_url: 'Thumbnail',
  banner_url: 'Banner', support_url: 'Support server link', website_url: 'Website link', log_channel_id: 'Log channel',
  wl_panel_title: 'WL panel title', wl_panel_sections: 'WL panel text', welcome_title: 'Welcome title',
  welcome_message: 'Welcome text', priority_roles: 'Priority roles', filter_message: 'Filter warning',
  honeypot_message: 'Honeypot DM', figs: 'Figs', dashboard_user_ids: 'People with access',
  roblox_panel_title: 'Verify panel title', roblox_panel_text: 'Verify panel text', roblox_group_id: 'Group ID',
  roblox_rank_roles: 'Rank roles', roblox_nickname: 'Nicknames',
};

/* ───────────── the waiting screen (opening a server, the bot starting) ───────────── */

/** The blurred dashboard shape behind the waiting card (decoration only). */
function gateBackdrop() {
  const bars = (n, cls) => Array.from({ length: n }, (_, i) => h('div', { class: cls, style: { width: `${55 + (i * 37) % 40}%` } }));
  return h('div', { class: 'gate-backdrop', 'aria-hidden': 'true' },
    h('div', { class: 'sk-side' }, h('div', { class: 'sk-brand' }), bars(11, 'sk-bar')),
    h('div', { class: 'sk-main' },
      h('div', { class: 'sk-title' }),
      h('div', { class: 'sk-board' }, Array.from({ length: 8 }, (_, r) => h('div', { class: 'sk-row' },
        h('div', { class: 'sk-bar' }), h('div', { class: 'sk-bar dim' }),
        h('div', { class: 'sk-flaps' }, Array.from({ length: 9 }, (_, i) => h('span', { class: i < 2 + (r * 3) % 6 ? 'lit' : '' })))))),
      h('div', { class: 'sk-cards' }, h('div'), h('div')),
    ),
  );
}

/** Put content in the waiting card, creating the waiting screen if it isn't showing yet. */
function popup(kids) {
  let card = document.querySelector('.popup');
  if (!card) {
    App.leaveServer();
    card = h('div', { class: 'popup', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'popup-title' });
    App.root().replaceChildren(h('main', { class: 'gate' }, gateBackdrop(), h('div', { class: 'gate-dim' }), card));
  }
  card.replaceChildren(...[kids].flat(Infinity).filter(Boolean));
  return card;
}

function popupHead(title, text) {
  const bot = S.session?.bot;
  const face = bot?.avatar ? h('img', { class: 'popup-face', src: bot.avatar, alt: '' }) : h('div', { class: 'popup-face blank' }, icon('slash'));
  return [face, h('h1', { id: 'popup-title' }, title), text ? h('p', { class: 'lead' }, text) : null];
}

let lastHash = location.hash;

const App = {
  root: () => document.getElementById('root'),
  visit: 0,

  async boot() {
    const params = new URLSearchParams(location.search);
    const loginError = params.get('login_error');
    if (loginError) {
      history.replaceState(null, '', location.pathname + location.hash);
      S.notice = LOGIN_ERRORS[loginError] || null;
    }
    try {
      S.session = await App.askSession();
      S.offline = false;
    } catch (e) {
      // On Netlify the website stays up while the bot is off: show the home page with what the bot
      // saved there last time (site-info.json), and check back now and then
      const saved = await fetch('/site-info.json', { cache: 'no-cache' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
      if (saved && Array.isArray(saved.figs)) {
        S.offline = true;
        S.public = { ...saved, online: false };
        S.session = { user: null, methods: {}, bot: null };
        App.route();
        App.checkBack();
        return;
      }
      return App.message("Can't reach the bot", e.message + ' Retrying…', () => App.boot());
    }
    App.route();
  },

  /** Who's logged in. Gives up after 10 seconds (a bot that's off can take long to fail through Netlify). */
  askSession() {
    return Promise.race([
      api('GET', '/api/session'),
      new Promise((_, fail) => setTimeout(() => fail(Object.assign(new Error("Can't reach the bot."), { status: 0 })), 10000)),
    ]);
  },

  /** While the bot is off: every 20 seconds, see if it's back, then show the live page (same scroll spot). */
  checkBack() {
    clearTimeout(App.wake);
    App.wake = setTimeout(async () => {
      let session;
      try { session = await App.askSession(); } catch { return App.checkBack(); }
      S.session = session;
      S.offline = false;
      const y = window.scrollY;
      await Promise.resolve(App.route());
      window.scrollTo(0, y);
      toast(`${S.public?.name || 'The bot'} is back online.`);
    }, 20000);
  },

  /* ── which page to show ──
     #/                  home page (anyone)
     #/login             Login with Discord (old links)
     #/login-setup       "add this redirect in the Developer Portal" (before Discord would refuse it)
     #/servers           your servers
     #/bot               bot settings (bot owner)
     #/s/<id>/<page>     one server's dashboard */

  route() {
    clearTimeout(App.timer);
    App.visit = (App.visit || 0) + 1; // pages check this after loading, in case you moved on
    const parts = location.hash.replace(/^#\/?/, '').split('?')[0].split('/').filter(Boolean);
    const where = parts[0] || '';
    lastHash = location.hash;

    if (S.offline) return Site.home(); // the bot is off: only the home page works
    if (where === 'login') return S.session.user ? go('#/servers', true) : App.login('#/servers');
    if (where === 'login-setup') return Site.loginSetup();
    if (!where) return Site.home();
    if (!S.session.user) return Site.home({ needLogin: true });
    if (where === 'servers') return Site.servers();
    if (where === 'bot') return Site.botSettings();
    if (where === 's' && /^\d{5,22}$/.test(parts[1] || '')) return App.openServer(parts[1], parts[2] || 'overview');
    go('#/servers', true); // old links like #/overview
  },

  /** Log in with Discord, then come back to `next` (a page of this site). */
  login(next = '#/servers') {
    if (!S.session?.methods?.discord) return Site.home({ needLogin: true });
    location.assign('/login/discord?next=' + encodeURIComponent(next));
  },

  /** Forget the open server (when going to the home page or Servers page). */
  leaveServer() {
    S.data = null;
    S.gid = null;
    S.page = null;
    S.errors = {};
    App.app = App.nav = App.main = App.bar = null;
  },

  /** The session ended (the login expired): back to the home page. */
  loggedOut(message) {
    if (S.session) S.session.user = null;
    App.leaveServer();
    S.notice = message;
    history.replaceState(null, '', '#/');
    App.route();
  },

  popupWait(title, text) {
    popup([popupHead(title, text), h('div', { class: 'spinner', role: 'status', 'aria-label': 'Working' })]);
  },

  message(title, text, retry = null) {
    App.popupWait(title, text);
    if (retry) App.timer = setTimeout(retry, 4000);
  },

  /* ── one server's dashboard ── */

  async openServer(gid, page) {
    if (S.gid === gid && S.data && App.app) return App.showPage(page);
    App.leaveServer();
    S.gid = gid;
    App.root().replaceChildren(h('div', { class: 'gate' }, h('div', { class: 'spinner', role: 'status', 'aria-label': 'Opening the dashboard' })));

    let data;
    try {
      data = await gapi('GET', '/state');
    } catch (e) {
      if (S.gid !== gid || e.status === 401) return;
      if (e.status === 403 || e.status === 404) {
        toast(e.message, { error: true });
        return go('#/servers', true);
      }
      return App.message("Can't reach the bot", e.message + ' Retrying…', () => App.openServer(gid, page));
    }
    if (S.gid !== gid) return; // switched to another page while loading
    if (!data.ready) {
      App.popupWait('Starting the bot', 'Connecting to Discord. This takes a few seconds.');
      App.timer = setTimeout(() => { S.gid = null; App.openServer(gid, page); }, 1500);
      return;
    }
    App.apply(data);
    App.loadedAt = Date.now();
    App.shell();
    App.showPage(page);
  },

  showPage(id) {
    const page = PAGES.find(p => p.id === id) || PAGES[0];
    const changed = S.page !== page.id;
    S.page = page.id;
    App.drawNav();
    App.render();
    if (changed) {
      window.scrollTo(0, 0);
      if (Date.now() - (App.loadedAt || 0) > 5000) App.refresh();
    }
  },

  /** Take fresh data from the bot without throwing away unsaved edits. */
  apply(data) {
    const dirty = S.data ? dirtyKeys() : [];
    S.data = data;
    S.saved = copy(data.config);
    const draft = copy(data.config);
    for (const k of dirty) draft[k] = S.draft[k];
    S.draft = draft;
  },

  async refresh() {
    const gid = S.gid;
    if (!gid || !S.data) return;
    try {
      const data = await gapi('GET', '/state');
      if (S.gid !== gid || !S.data || !data.ready) return;
      const page = S.page;
      App.apply(data);
      App.drawNav();
      const typing = document.activeElement && document.querySelector('.main')?.contains(document.activeElement) && document.activeElement.matches('input, textarea');
      if (!typing && !openPicker && page === S.page && ['overview', 'giveaways', 'reaction-roles', 'honeypot', 'tickets', 'roblox'].includes(page)) App.render();
    } catch (e) {
      if (S.gid === gid && (e.status === 403 || e.status === 404)) {
        S.draft = copy(S.saved);
        toast(e.message, { error: true });
        go('#/servers', true);
      }
    }
  },

  /* ── layout ── */

  shell() {
    const g = S.data.guild;
    const me = S.session.user;

    App.nav = h('nav', { class: 'nav', 'aria-label': 'Dashboard pages' });
    App.main = h('main', { class: 'main', id: 'main', tabindex: '-1' });
    App.saveText = h('p', null);
    App.saveBtn = h('button', { class: 'btn primary', onclick: () => App.save() }, 'Save changes');
    App.bar = h('div', { class: 'savebar', role: 'region', 'aria-label': 'Unsaved changes' },
      App.saveText,
      h('button', { class: 'btn ghost', onclick: () => App.reset() }, 'Undo changes'),
      App.saveBtn,
    );

    const appEl = h('div', { class: 'app' },
      h('div', { class: 'topbar' },
        h('button', { class: 'btn icon ghost', 'aria-label': 'Open menu', onclick: () => App.menu(true) }, icon('menu')),
        h('a', { class: 'topbar-brand', href: '#/', 'aria-label': `${BRAND.name} home page` }, brandMark('small')),
        h('span', { class: 'topbar-server' }, g.name),
      ),
      h('aside', { class: 'side' },
        h('a', { class: 'brand', href: '#/', 'aria-label': `${BRAND.name} home page` }, brandMark()),
        serverSwitcher(g),
        App.nav,
        h('div', { class: 'me' },
          me.avatar ? h('img', { src: me.avatar, alt: '' }) : h('span', { class: 'avatar-blank' }),
          h('div', { style: { minWidth: '0' } }, h('div', { class: 'me-name' }, me.name), h('div', { class: 'me-how' }, howLoggedIn(me))),
          themeButton(),
          h('button', { class: 'btn icon small ghost', 'aria-label': 'Log out', title: 'Log out', onclick: () => App.logout() }, icon('logout')),
        ),
      ),
      h('div', { class: 'main-wrap' }, App.main),
      App.bar,
    );
    App.app = appEl;
    App.root().replaceChildren(appEl);
    App.drawNav();
    App.updateSaveBar();
  },

  /** The menu. Only tabs of figs that are on show up. `fresh` tabs get a short highlight. */
  drawNav(fresh = []) {
    if (!App.nav || !S.data) return;
    const tabs = new Set(S.data.tabs || []);
    const kids = [];
    let box = h('div');
    let boxHas = false;
    const flush = () => { if (boxHas) kids.push(box); };
    for (const p of PAGES) {
      if (p.group) {
        flush();
        box = h('div', { class: 'nav-group' }, h('div', { class: 'nav-group-name' }, p.group));
        boxHas = false;
        continue;
      }
      if (!tabs.has(p.id)) continue;
      const count = p.count ? p.count() : null;
      box.append(h('a', {
        href: here(p.id), class: fresh.includes(p.id) ? 'fresh' : null,
        'aria-current': S.page === p.id ? 'page' : null, onclick: () => App.menu(false),
      }, icon(p.icon), h('span', null, p.name), count ? h('span', { class: 'count' }, count) : null));
      boxHas = true;
    }
    flush();
    App.nav.replaceChildren(...kids);
  },

  menu(open) {
    if (!App.app) return;
    App.app.classList.toggle('menu-open', open);
    App.app.querySelector('.scrim')?.remove();
    if (open) App.app.append(h('div', { class: 'scrim', onclick: () => App.menu(false) }));
  },

  render() {
    if (!S.data || !App.main) return;
    const page = PAGES.find(p => p.id === S.page) || PAGES[0];
    if (openPicker) openPicker.close();
    S.live = [];
    let content;
    try {
      content = (S.data.tabs || []).includes(page.id) ? page.render() : pageLocked(page);
    } catch (e) {
      console.error(e);
      content = h('div', null, pageHead(page.name), note(`This page hit an error: ${e.message}`));
    }
    App.main.replaceChildren(h('div', { class: 'main-inner' }, content));
    document.title = `${page.name} · ${S.data.guild.name}`;
  },

  /* ── saving ── */

  updateSaveBar() {
    if (!App.bar) return;
    const n = dirtyKeys().length;
    App.bar.classList.toggle('show', n > 0);
    const mac = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
    App.saveText.replaceChildren('Unsaved changes', h('span', null, `${n} ${n === 1 ? 'setting' : 'settings'}`), h('kbd', null, mac ? '⌘S' : 'Ctrl+S'));
  },

  async save() {
    const keys = dirtyKeys();
    if (!keys.length) return;
    const changes = {};
    for (const k of keys) changes[k] = S.draft[k];
    App.saveBtn.classList.add('busy');
    try {
      const res = await gapi('PATCH', '/config', { changes });
      S.saved = copy(res.config);
      S.draft = copy(res.config);
      S.errors = {};
      toast(res.changed.length ? 'Saved. The bot is using the new settings now.' : 'Nothing needed saving.');
      for (const n of res.notes || []) toast(n);
      App.updateSaveBar();
      App.render();
      App.refresh();
    } catch (e) {
      const fields = e.data?.fields;
      if (fields) {
        S.errors = fields;
        const names = Object.keys(fields).map(k => LABELS[k] || k.replaceAll('_', ' '));
        toast(`Fix ${names.join(', ')} and save again. ${Object.values(fields)[0]}`, { error: true });
        App.render();
      } else {
        toast(e.message, { error: true });
      }
      App.bar.classList.remove('shake');
      void App.bar.offsetWidth;
      App.bar.classList.add('shake');
    } finally {
      App.saveBtn.classList.remove('busy');
    }
  },

  reset() {
    S.draft = copy(S.saved);
    S.errors = {};
    App.updateSaveBar();
    App.render();
  },

  async logout() {
    if (S.data && dirtyKeys().length && !await confirmDialog({ title: 'Log out without saving?', text: 'Your unsaved changes will be lost.', confirm: 'Log out', danger: true })) return;
    try { await api('POST', '/api/logout'); } catch { /* ignore */ }
    if (S.data) S.draft = copy(S.saved);
    S.session = await api('GET', '/api/session').catch(() => ({ ...S.session, user: null }));
    S.guilds = null;
    App.leaveServer();
    go('#/', true);
  },
};

function howLoggedIn(me) {
  return me.bot_owner ? 'Bot owner' : 'Discord login';
}

/** The server name at the top of the menu. Opens a list of your other servers. */
function serverSwitcher(g) {
  const iconEl = h('span', { class: 'sw-icon' });
  if (g.icon) iconEl.style.backgroundImage = `url("${g.icon}")`;
  else iconEl.textContent = g.name.slice(0, 1).toUpperCase();
  const root = h('div', { class: 'switcher' });
  const btn = h('button', { type: 'button', class: 'sw-btn', 'aria-haspopup': 'true', 'aria-expanded': 'false' },
    iconEl, h('span', { class: 'sw-name' }, g.name), icon('chev', 'chev'));
  let pop = null;

  const close = () => {
    pop?.remove();
    pop = null;
    btn.setAttribute('aria-expanded', 'false');
    document.removeEventListener('mousedown', outside);
  };
  const outside = e => { if (!root.contains(e.target)) close(); };

  const fill = list => {
    const others = list.filter(x => x.id !== g.id);
    pop.replaceChildren(
      others.length ? h('div', { class: 'pick-list' }, others.map(x => h('a', { class: 'pick-item', href: `#/s/${x.id}/overview`, onclick: close },
        x.icon ? h('img', { src: x.icon, alt: '' }) : h('span', { class: 'sw-mini' }, x.name.slice(0, 1).toUpperCase()),
        h('span', null, x.name)))) : h('div', { class: 'pick-empty' }, 'No other servers to manage.'),
      h('a', { class: 'sw-all', href: '#/servers', onclick: close }, icon('servers'), 'All servers'),
    );
  };

  btn.addEventListener('click', async () => {
    if (pop) return close();
    pop = h('div', { class: 'pick-pop sw-pop' }, h('div', { class: 'pick-empty' }, h('span', { class: 'spinner small' })));
    root.append(pop);
    btn.setAttribute('aria-expanded', 'true');
    document.addEventListener('mousedown', outside);
    if (S.guilds?.ready) return fill(S.guilds.manage);
    try {
      S.guilds = await api('GET', '/api/guilds');
      if (pop) fill(S.guilds.manage || []);
    } catch { if (pop) fill([]); }
  });
  btn.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  root.append(btn);
  return root;
}

/* ───────────── page changes ───────────── */

window.addEventListener('hashchange', async () => {
  const next = location.hash;
  if (App.guarding) return;
  // Leaving a server with unsaved changes: ask first
  if (S.data && dirtyKeys().length && !next.startsWith(`#/s/${S.gid}/`)) {
    App.guarding = true;
    history.replaceState(null, '', lastHash);
    const ok = await confirmDialog({ title: 'Leave without saving?', text: `Your unsaved changes in ${S.data.guild.name} will be lost.`, confirm: 'Leave', danger: true });
    App.guarding = false;
    if (!ok) return;
    S.draft = copy(S.saved);
    history.replaceState(null, '', next);
  }
  App.route();
});
window.addEventListener('beforeunload', e => {
  if (S.data && dirtyKeys().length) { e.preventDefault(); e.returnValue = ''; }
});
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && S.data && dirtyKeys().length) {
    e.preventDefault();
    App.save();
  }
});
setInterval(() => { if (S.data && !document.hidden) App.refresh(); }, 30000);

App.boot();
