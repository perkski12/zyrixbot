/* Home page: what the bot does, scrolling down from the hero.
   Each feature has a preview drawn like Discord, using the bot's real wording. Some of them can
   be clicked through (whitelist, tickets, Roblox, giveaways); nothing is sent anywhere, it all
   happens on the page. */

const Show = (() => {
  const TONY = { name: 'Tony', tone: '#34508f' };
  const MARIA = { name: 'Maria', tone: '#5a4f8c', role: 'Staff' };
  const ELENA = { name: 'Elena', tone: '#2f6f7a' };
  const DRE = { name: 'Dre', tone: '#6b5a3a' };

  function time() {
    return 'Today at ' + new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }

  function avatar(who) {
    if (who.star) {  // the zyrix star on a dark blue circle
      const ns = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(ns, 'svg');
      svg.setAttribute('viewBox', '-30 -30 160 160');
      svg.setAttribute('aria-hidden', 'true');
      const path = document.createElementNS(ns, 'path');
      path.setAttribute('d', BRAND.star);
      svg.appendChild(path);
      return h('span', { class: 'dc-avatar dc-star' }, svg);
    }
    return who.avatar
      ? h('img', { class: 'dc-avatar', src: who.avatar, alt: '' })
      : h('span', { class: 'dc-avatar dc-letter', style: { background: who.tone || '#4e5058' } }, who.name.slice(0, 1));
  }

  function mention(name) {
    return h('span', { class: 'dc-mention' }, '@' + name);
  }

  /** One Discord message: avatar, name (APP tag for the bot), time, then whatever goes in it. */
  function message(who, ...content) {
    return h('div', { class: 'dc-msg dc-in' },
      avatar(who),
      h('div', { class: 'dc-msg-body' },
        h('div', { class: 'dc-head' },
          h('span', { class: 'dc-name' }, who.name),
          who.bot ? h('span', { class: 'dc-app' }, 'APP') : null,
          h('span', { class: 'dc-time' }, time())),
        ...content));
  }

  /** The bot's boxed messages (Components V2 containers), with the white accent stripe. */
  function box(...children) {
    return h('div', { class: 'dc-box dc-text' }, ...children);
  }

  const title = text => h('h2', null, text);
  const line = (...parts) => h('p', null, ...parts);
  const small = text => h('small', null, text);
  const sep = () => h('div', { class: 'dc-sep' });

  function dcButton(label, { kind = '', emoji = '', onClick, disabled = false } = {}) {
    return h('button', { type: 'button', class: `dc-button ${kind}`.trim(), disabled, onclick: onClick },
      emoji ? h('span', { 'aria-hidden': 'true' }, emoji) : null, label);
  }

  /** A Discord channel: the bar with its name and the messages under it. */
  function windowFrame(channel, { tabs = null, hint = '' } = {}) {
    const name = h('span', { class: 'dw-channel' }, channel);
    const body = h('div', { class: 'dw-body', 'aria-live': 'polite' });
    const foot = h('div', { class: 'dw-foot' });
    const el = h('div', { class: 'dw' },
      h('div', { class: 'dw-bar' }, h('span', { class: 'dw-hash', 'aria-hidden': 'true' }, '#'), name,
        tabs, hint ? h('span', { class: 'dw-hint' }, hint) : null),
      body, foot);
    return {
      el, body, foot,
      channel: text => { name.textContent = text; },
      clear: () => { body.replaceChildren(); foot.replaceChildren(); },
      // like Discord, a channel shows its newest messages (also once the page has drawn it)
      add: node => { body.append(node); requestAnimationFrame(() => { body.scrollTop = body.scrollHeight; }); return node; },
      later: (ms, fn) => setTimeout(fn, reduced() ? 0 : ms),
    };
  }

  const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

  function again(w, start) {
    return h('button', { type: 'button', class: 'dw-again', onclick: start }, icon('refresh'), 'Start over');
  }

  /* ── 1. Whitelist ── */
  function whitelistPreview(bot) {
    let mode = 'wl';
    const tabs = h('span', { class: 'dw-tabs', role: 'group', 'aria-label': 'Whitelist mode' });
    const w = windowFrame('whitelist', { tabs });
    const drawTabs = () => tabs.replaceChildren(
      ...[['wl', 'Direct WL'], ['vouch', 'Vouch mode']].map(([id, label]) =>
        h('button', { type: 'button', class: mode === id ? 'on' : '', 'aria-pressed': String(mode === id), onclick: () => { mode = id; start(); } }, label)));

    function start() {
      drawTabs();
      w.clear();
      w.add(h('p', { class: 'dw-note' }, mode === 'wl'
        ? 'Direct WL: a new player types wl in this channel and gets the whitelist role.'
        : 'Vouch mode: someone who is already whitelisted vouches for a new player.'));
      // someone earlier, so the channel looks like a real one before anything is clicked
      if (mode === 'wl') {
        w.add(message(DRE, line('wl')));
        w.add(message(bot, box(title('Whitelisted Successfully'), line(mention('Dre'), ' has been whitelisted!'))));
      } else {
        w.add(message(ELENA, line('vouch ', mention('Dre'))));
        w.add(message(bot, box(title('Vouch Successful'), line(mention('Dre'), ' has been whitelisted by ', mention('Elena'), '!'))));
      }
      const who = mode === 'wl' ? TONY : MARIA;
      const text = mode === 'wl' ? 'wl' : 'vouch @Tony';
      const send = h('button', { type: 'button', class: 'dw-send', onclick: () => {
        send.disabled = true;
        w.add(message(who, mode === 'wl' ? line('wl') : line('vouch ', mention('Tony'))));
        w.later(650, () => {
          w.add(message(bot, mode === 'wl'
            ? box(title('Whitelisted Successfully'), line(mention('Tony'), ' has been whitelisted!'))
            : box(title('Vouch Successful'), line(mention('Tony'), ' has been whitelisted by ', mention('Maria'), '!'))));
          w.foot.replaceChildren(h('span', { class: 'dw-done' }, icon('check'), 'Tony got the Whitelisted role'), again(w, start));
        });
      } }, icon('send'), 'Send');
      w.foot.replaceChildren(h('div', { class: 'dw-composer' },
        h('span', { class: 'dw-typed' }, h('b', null, who.name + ': '), text), send));
    }
    start();
    return w.el;
  }

  /* ── 2. Tickets ── */
  function ticketsPreview(bot) {
    const w = windowFrame('support');
    const types = [['🎫', 'Support', 'Questions or problems? Talk to staff.'], ['🚨', 'Report a player', 'Someone broke the rules.'], ['⚖️', 'Ban appeal', 'Ask staff to look at your ban again.']];

    function start() {
      w.clear();
      w.channel('support');
      const menu = h('div', { class: 'dc-options', hidden: true, role: 'listbox', 'aria-label': 'Ticket types' },
        types.map(([emoji, name, about]) => h('button', { type: 'button', role: 'option', class: 'dc-option', onclick: () => open(emoji, name) },
          h('span', { 'aria-hidden': 'true' }, emoji), h('span', null, h('b', null, name), h('small', null, about)))));
      const select = h('button', { type: 'button', class: 'dc-select', 'aria-haspopup': 'listbox', onclick: () => { menu.hidden = !menu.hidden; } },
        'Pick a ticket type', icon('down'));
      w.add(message(bot, box(title('Open a ticket'), line('Pick what you need and a private channel opens for you and staff.'), select, menu)));
      w.foot.replaceChildren(h('span', { class: 'dw-hint-line' }, 'Pick a ticket type to open one'));
    }

    function open(emoji, name) {
      w.clear();
      w.channel('ticket-0042');
      const close = dcButton('Close', { kind: 'danger', emoji: '🔒', onClick: () => closeTicket(close, claim) });
      const claim = dcButton('Claim', { emoji: '🙋', onClick: () => {
        claim.disabled = true;
        w.add(message(bot, box(title('🙋 Ticket claimed'), line(mention('Maria'), ' will help you with this ticket.'))));
      } });
      w.add(message(bot, box(
        title(`${emoji} ${name} ticket`),
        line('Hey ', mention('Tony'), ', thanks for opening a ticket!\nTell us what you need and staff will be with you soon.'),
        sep(), h('div', { class: 'dc-buttons' }, close, claim), small('Ticket 0042'))));
      w.foot.replaceChildren(h('span', { class: 'dw-hint-line' }, 'Staff can claim it, then close it'), again(w, start));
    }

    function closeTicket(close, claim) {
      close.disabled = claim.disabled = true;
      w.add(message(bot, box(title('🔒 Ticket closed'), line('Closed by ', mention('Maria')), sep(),
        h('div', { class: 'dc-buttons' }, dcButton('Save transcript', { emoji: '📄' }), dcButton('Reopen', { emoji: '🔓' }), dcButton('Delete', { kind: 'danger', emoji: '⛔' })))));
      w.foot.replaceChildren(h('span', { class: 'dw-done' }, icon('check'), 'Transcript saved for staff'), again(w, start));
    }

    start();
    return w.el;
  }

  /* ── 3. Roblox verification ── */
  function robloxPreview(bot) {
    const w = windowFrame('verify');
    const only = () => h('small', { class: 'dc-ephemeral' }, 'Only you can see this');

    function start() {
      w.clear();
      const go = dcButton('Verify with Roblox', { kind: 'success', emoji: '✅', onClick: () => {
        go.disabled = true;
        w.add(message(bot, box(title("Prove it's your account"),
          h('p', null, '1. Open your Roblox profile: ', h('strong', null, 'builderman'), '\n2. Click the pencil next to ', h('strong', null, 'About'), ' and paste these words anywhere:'),
          h('code', { class: 'dc-codeblock' }, 'sunny maple rocket'),
          line('3. Save, come back here and press ', h('strong', null, 'Done'), '.'),
          h('div', { class: 'dc-buttons' }, dcButton('Done', { kind: 'success', emoji: '✅', onClick: done }), dcButton('Open profile'), dcButton('Cancel'))), only()));
      } });
      w.add(message(bot, box(title('Verify with Roblox'), line('Link your Roblox account to get access to the server. It takes about a minute.'),
        h('div', { class: 'dc-buttons' }, go))));
      w.foot.replaceChildren(h('span', { class: 'dw-hint-line' }, 'Members verify in about a minute'));
    }

    function done(e) {
      e.currentTarget.disabled = true;
      w.add(message(bot, box(title("✅ You're verified"),
        line('Linked to ', h('strong', null, 'Builder Man'), ' (@builderman). You can remove the words from your profile now.'),
        small('Roles: Verified, Member, Officer (group rank). Nickname: Builder Man')), only()));
      w.foot.replaceChildren(h('span', { class: 'dw-done' }, icon('check'), 'Roles and nickname set from Roblox'), again(w, start));
    }

    start();
    return w.el;
  }

  /* ── 4. Moderation (a log, no clicking) ── */
  function moderationPreview(bot) {
    const w = windowFrame('mod-logs');
    w.add(message(bot, box(title('⚠️ Case 12: Warning'), line(mention('hot_head'), ' (hot_head) by ', mention('Maria')), line('Reason: Spamming caps in #general'))));
    w.add(message(bot, box(title('⏳ Case 13: Timeout for 1 hour'), line(mention('hot_head'), ' (hot_head) by ', mention(bot.name)), line('Reason: Reached 3 warnings'))));
    w.add(message(bot, box(title('🔨 Case 14: Ban'), line(mention('raid_alt_77'), ' (raid_alt_77) by ', mention(bot.name)), line('Reason: Honeypot: posted in the trap channel'))));
    w.foot.replaceChildren(h('span', { class: 'dw-hint-line' }, 'Every action gets a case number'));
    return w.el;
  }

  /* ── 5. Leveling (no clicking) ── */
  function levelingPreview(bot) {
    const w = windowFrame('general');
    w.add(message(ELENA, line('gg that chase was insane')));
    w.add(message(bot, line('GG ', mention('Elena'), ', you just reached ', h('strong', null, 'level 12'), '!')));
    const rows = [['🥇', 'Elena', 12, 7140], ['🥈', 'Tony', 11, 6010], ['🥉', 'Maria', 9, 4320], ['4.', 'Dre', 7, 2900]];
    w.add(message(bot, box(title('🏆 Leaderboard'),
      h('div', { class: 'dc-board' }, rows.map(([medal, name, level, xp]) =>
        h('div', { class: 'dc-board-row' }, h('span', null, medal), mention(name), h('span', null, `level ${level} (${xp.toLocaleString()} XP)`)))))));
    w.foot.replaceChildren(h('span', { class: 'dw-hint-line' }, 'Level roles are given on their own'));
    return w.el;
  }

  /* ── 6. Community: welcome and giveaways ── */
  function communityPreview(bot, server) {
    const w = windowFrame('giveaways');
    let entries = 127, joined = false;
    const count = h('strong', null, String(entries));
    const join = dcButton('Join Giveaway', { kind: 'primary', emoji: '🎉', onClick: () => {
      joined = !joined;
      entries += joined ? 1 : -1;
      count.textContent = String(entries);
      join.lastChild.textContent = joined ? 'Leave Giveaway' : 'Join Giveaway';
      note.hidden = !joined;
    } });
    const note = h('small', { class: 'dc-ephemeral', hidden: true }, "You're in! Good luck.");
    w.add(message(bot, box(title(`Welcome To ${server}`), line('Welcome here ', mention('Tony'), ", make sure to read these below so you're ready to jump in!"))));
    w.add(message(bot, box(title('🎉 Giveaway'), h('h3', null, '$50 store credit'), sep(),
      h('p', null, h('strong', null, 'Winners:'), ' 1\n', h('strong', null, 'Ends:'), ' in 2 days\n', h('strong', null, 'Hosted By:'), ' ', mention('Maria'), '\n', h('strong', null, 'Entries:'), ' ', count),
      h('div', { class: 'dc-buttons' }, join), note)));
    w.foot.replaceChildren(h('span', { class: 'dw-hint-line' }, 'Winners are picked and pinged when it ends'));
    return w.el;
  }

  /* ── the mini dashboard ── */
  function dashboardPreview(server) {
    const rows = [['Whitelist', '#whitelist', 'WL MODE'], ['Tickets', '3 types', 'READY'], ['Leveling', '#general', 'ON'], ['Auto-mod', 'spam, invites', 'ON']];
    const nav = [['grid', 'Overview', true], ['shield', 'Whitelist'], ['ticket', 'Tickets'], ['trend', 'Leveling'], ['bolt', 'Auto-mod']];
    return h('div', { class: 'mini-dash', 'aria-hidden': 'true' },
      h('div', { class: 'mini-side' },
        brandMark('small'),
        h('div', { class: 'mini-server' }, h('span', null, server.slice(0, 1)), server),
        nav.map(([ic, name, on]) => h('div', { class: on ? 'mini-nav on' : 'mini-nav' }, icon(ic), name))),
      h('div', { class: 'mini-main' },
        h('div', { class: 'mini-title' }, server),
        h('div', { class: 'board mini-board' },
          rows.map(([name, where, status], i) => h('div', { class: 'mini-row' },
            h('b', null, name), h('span', { class: 'mini-where' }, where), flapWord(status, 7, i, { animate: false, kind: 'mini' }))))));
  }

  /* ── commands, with search ── */
  function commandsSection(commands) {
    const SHOWN = 12;
    let all = false;
    const grid = h('div', { class: 'cmd-grid' });
    const more = h('button', { type: 'button', class: 'btn' });
    const empty = h('p', { class: 'cmd-empty', hidden: true }, 'No command matches that. Try a word like ticket, warn or roblox.');
    const search = h('input', { class: 'input', type: 'search', placeholder: 'Search commands', 'aria-label': 'Search commands' });

    function draw() {
      const q = search.value.trim().toLowerCase().replace(/^\//, '');
      const found = commands.filter(c => !q || c.name.includes(q) || c.description.toLowerCase().includes(q) || c.feature.toLowerCase().includes(q));
      const list = q || all ? found : found.slice(0, SHOWN);
      grid.replaceChildren(...list.map(c => h('div', { class: 'cmd-card' },
        h('code', null, '/' + c.name), h('span', null, c.description), h('small', null, c.feature))));
      empty.hidden = found.length > 0;
      more.hidden = !!q || found.length <= SHOWN;
      more.textContent = all ? 'Show fewer' : `Show all ${commands.length} commands`;
    }
    search.addEventListener('input', draw);
    more.addEventListener('click', () => { all = !all; draw(); });
    draw();
    return h('section', { class: 'site-section', id: 'commands' },
      h('div', { class: 'section-head' },
        h('h2', null, `${commands.length} slash commands`),
        h('p', null, 'Everything on the dashboard works from Discord too: use / or type the prefix, like ,ban @someone spam. Staff commands only work for people with the right permissions.')),
      h('div', { class: 'cmd-search' }, icon('search'), search),
      grid, empty, h('div', { class: 'cmd-more' }, more));
  }

  /* ── a feature row: words on one side, the preview on the other ── */
  function row({ id, title: heading, text, points, commands = [], preview, flip = false }) {
    return h('section', { class: `show-row${flip ? ' flip' : ''}`, id },
      h('div', { class: 'show-copy' },
        h('h3', null, heading),
        h('p', null, text),
        h('ul', { class: 'show-points' }, points.map(p => h('li', null, icon('check'), h('span', null, p)))),
        commands.length ? h('div', { class: 'show-cmds' }, commands.map(c => h('code', null, '/' + c))) : null),
      h('div', { class: 'show-preview' }, preview));
  }

  /** Everything below the hero on the home page. */
  function sections(pub, actions) {
    // the previews are branded zyrix: the bot (with the star as its picture) and the server
    const bot = { name: BRAND.name, star: true, bot: true };
    const server = BRAND.name;
    return [
      h('section', { class: 'site-section show', id: 'features' },
        h('div', { class: 'section-head' },
          h('h2', null, 'What it does'),
          h('p', null, 'A few of the things it runs for you. The previews below work: click through them.')),
        row({
          id: 'whitelist', title: 'Whitelist your city',
          text: 'New players type wl in your whitelist channel and get the role, or switch to vouch mode so only whitelisted members can let people in.',
          points: ['Direct WL or vouch mode, switch any time', 'Takes away the Unverified role', 'Every whitelist is logged for staff'],
          commands: ['turnonwl', 'turnoffwl'], preview: whitelistPreview(bot),
        }),
        row({
          id: 'tickets', title: 'Tickets like Ticket Tool', flip: true,
          text: 'Members pick what they need from a panel and get a private channel with staff. Staff claim it, close it, and a transcript is saved.',
          points: ['Ticket types with their own questions and staff roles', 'Claim, close, reopen and transcripts', 'Ratings, auto-close and opening hours'],
          commands: ['ticket-claim', 'ticket-close', 'ticket-add', 'snippet'], preview: ticketsPreview(bot),
        }),
        row({
          id: 'roblox', title: 'Roblox verification',
          text: 'Members prove they own their Roblox account by pasting a few words into their profile. The bot sets their nickname and gives roles for their group rank, badges and game passes.',
          points: ['No outside website or account needed', 'Roles from group ranks, badges and game passes', 'Live game stats, group shouts and sessions'],
          commands: ['verify', 'roblox-whois', 'roblox-update'], preview: robloxPreview(bot),
        }),
        row({
          id: 'moderation', title: 'Moderation that keeps a record', flip: true,
          text: 'Warnings, timeouts, kicks and bans each get a case number in your log channel. Auto-mod catches spam, invites, links and caps, and a honeypot channel bans raid bots.',
          points: ['Temporary bans and roles that end by themselves', 'Lock down every channel at once, or nuke one', 'Auto-mod, word filter, honeypot and server logs'],
          commands: ['warn', 'tempban', 'lockdown start', 'role add', 'purge'], preview: moderationPreview(bot),
        }),
        row({
          id: 'leveling', title: 'Levels and leaderboards',
          text: 'Members earn XP for chatting. They get a message when they level up and roles at the levels you pick.',
          points: ['Pick the XP per message and the cooldown', 'Roles at any level', 'Leaderboard and rank cards'],
          commands: ['rank', 'leaderboard', 'xp-give'], preview: levelingPreview(bot),
        }),
        row({
          id: 'community', title: 'Welcomes, giveaways and more', flip: true,
          text: 'Greet new members, run giveaways and polls, and keep the server busy with suggestions, starboard, birthdays and join-to-create voice channels.',
          points: ['Welcome and goodbye messages, join roles', 'Giveaways with entries and rerolls', 'Suggestions, polls, starboard and birthdays'],
          commands: ['giveaway', 'suggest', 'birthday-set', 'polls'], preview: communityPreview(bot, server),
        }),
      ),
      h('section', { class: 'site-section dash-show' },
        h('div', { class: 'show-row' },
          h('div', { class: 'show-copy' },
            h('h3', null, 'Every setting on a website'),
            h('p', null, 'Log in with Discord, pick your server and change anything: channels, roles, messages and panels. The status board shows what is on at a glance.'),
            h('ul', { class: 'show-points' }, ['Previews of every message before you post it', 'Give other people access to your server', 'Slash commands keep working'].map(p => h('li', null, icon('check'), h('span', null, p)))),
          ),
          h('div', { class: 'show-preview' }, dashboardPreview(server)))),
      actions.figs,
      pub.commands && pub.commands.length ? commandsSection(pub.commands) : null,
      actions.steps,
      h('section', { class: 'site-cta' },
        h('h2', null, `Add ${BRAND.name} to your server`),
        h('p', null, 'Turn on the figs you want and set it up in a few minutes.'),
        h('div', { class: 'hero-actions' }, actions.invite, serversButton('big'))),
    ];
  }

  return { sections };
})();
