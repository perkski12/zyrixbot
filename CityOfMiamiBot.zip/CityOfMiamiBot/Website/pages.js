/* One function per dashboard page. Each returns the page's DOM. */
'use strict';

// Tabs show up in the menu when they're in the server's `tabs` (core tabs + tabs of figs that are on)
const PAGES = [
  { id: 'overview', name: 'Overview', icon: 'grid', render: pageOverview },
  { id: 'figs', name: 'Figs', icon: 'layers', render: pageFigs },
  { group: 'Server' },
  { id: 'general', name: 'General', icon: 'sliders', render: pageGeneral },
  { id: 'profile', name: 'Bot profile', icon: 'bot', render: pageProfile },
  { id: 'whitelist', name: 'Whitelist', icon: 'shield', render: pageWhitelist },
  { id: 'welcome', name: 'Welcome', icon: 'door', render: pageWelcome },
  { id: 'priority', name: 'Priority roles', icon: 'plane', render: pagePriority },
  { id: 'announcements', name: 'Announcements', icon: 'megaphone', render: pageAnnouncements },
  { id: 'utility', name: 'Utility', icon: 'wrench', render: pageUtility },
  { group: 'Roblox' },
  { id: 'roblox', name: 'Verification', icon: 'idcard', render: pageRoblox },
  { id: 'roblox-ranks', name: 'Role binds', icon: 'rank', render: pageRobloxRanks },
  { id: 'roblox-game', name: 'Game & group', icon: 'game', render: pageRobloxGame },
  { id: 'roblox-sessions', name: 'Sessions', icon: 'calendar', render: pageSessions, count: () => (extra('roblox-sessions').active || []).length || null },
  { group: 'Moderation' },
  { id: 'automod', name: 'Auto-mod', icon: 'bolt', render: pageAutomod },
  { id: 'moderation', name: 'Moderation', icon: 'gavel', render: pageModeration },
  { id: 'logs', name: 'Server logs', icon: 'scroll', render: pageLogs },
  { id: 'filter', name: 'Word filter', icon: 'filter', render: pageFilter },
  { id: 'honeypot', name: 'Honeypot', icon: 'target', render: pageHoneypot },
  { group: 'Community' },
  { id: 'leveling', name: 'Leveling', icon: 'trend', render: pageLeveling },
  { id: 'suggestions', name: 'Suggestions', icon: 'bulb', render: pageSuggestions, count: () => (extra('suggestions').items || []).filter(s => s.status === 'open').length || null },
  { id: 'starboard', name: 'Starboard', icon: 'star', render: pageStarboard },
  { id: 'birthdays', name: 'Birthdays', icon: 'cake', render: pageBirthdays },
  { id: 'reaction-roles', name: 'Reaction roles', icon: 'smile', render: pageReactionRoles },
  { id: 'giveaways', name: 'Giveaways', icon: 'gift', render: pageGiveaways, count: () => S.data.stats.giveaways_live || null },
  { id: 'polls', name: 'Polls', icon: 'poll', render: pagePolls },
  { id: 'react', name: 'React channels', icon: 'thumbs', render: pageReact },
  { id: 'autoresponses', name: 'Auto-responses', icon: 'reply', render: pageAutoresponses },
  { id: 'tempvoice', name: 'Voice channels', icon: 'mic', render: pageTempvoice },
  { id: 'channeltools', name: 'Channel tools', icon: 'pin', render: pageChanneltools },
  { group: 'Support' },
  { id: 'tickets', name: 'Tickets', icon: 'ticket', render: pageTickets, count: () => openTicketCount() || null },
  { id: 'ticket-types', name: 'Ticket types', icon: 'list', render: pageTicketTypes },
  { id: 'ticket-panels', name: 'Ticket panels', icon: 'panel', render: pageTicketPanels },
  { id: 'applications', name: 'Applications', icon: 'file', render: pageApplications, count: () => extra('applications').pending || null },
  { id: 'faq', name: 'FAQ', icon: 'help', render: pageFaq },
  { id: 'status', name: 'Status page', icon: 'pulse', render: pageStatus },
  { id: 'reviews', name: 'Reviews', icon: 'chat', render: pageReviews },
  { group: 'Bot' },
  { id: 'commands', name: 'Commands', icon: 'slash', render: pageCommands },
  { id: 'access', name: 'Dashboard access', icon: 'key', render: pageAccess },
];

const HONEYPOT_ACTIONS = [
  { value: 'softban', label: 'Softban', text: 'Ban and unban right away. Wipes their last 24h of messages; they can rejoin.' },
  { value: 'kick', label: 'Kick', text: 'Removes them from the server. They can rejoin.' },
  { value: 'ban', label: 'Ban', text: 'Permanent ban. Wipes their last 24h of messages.' },
  { value: 'timeout_60', label: 'Timeout for 1 hour', text: 'Mutes them. They stay in the server.' },
  { value: 'timeout_1440', label: 'Timeout for 1 day', text: 'Mutes them. They stay in the server.' },
  { value: 'timeout_10080', label: 'Timeout for 1 week', text: 'Mutes them. They stay in the server.' },
];

function emoji() { return get('city_emoji') || ''; }

function channelLabel(id, fallback = 'No channel') {
  const name = channelName(id);
  return name ? '#' + name : fallback;
}

/** Post-to-channel control used on several pages (local value, not a setting). */
function localChannel(initial, placeholder = 'Pick a channel') {
  const state = { value: initial || null };
  state.el = picker({
    items: channelItems(), value: state.value, placeholder, label: placeholder,
    searchPlaceholder: 'Search channels', onChange: v => { state.value = v; },
  });
  return state;
}

function savedFirstNote(keys) {
  const dirty = dirtyKeys().filter(k => keys.includes(k));
  return dirty.length ? note('Save your changes first. Posting uses the saved settings.') : null;
}

/* ═════════════ Overview ═════════════ */

function flaps(text, kind, rowIndex, width) {
  const chars = text.toUpperCase().padEnd(width, ' ').split('');
  const wrap = h('div', { class: `flaps ${kind}${S.flipped ? '' : ' flip'}`, 'aria-label': text });
  chars.forEach((ch, i) => {
    const f = h('span', { class: 'flap' + (ch === ' ' ? ' blank' : ''), 'aria-hidden': 'true' }, ch === ' ' ? '·' : ch);
    f.style.setProperty('--i', i);
    f.style.setProperty('--r', rowIndex);
    wrap.append(f);
  });
  return wrap;
}

function boardRows() {
  const c = S.saved, st = S.data.stats;
  const words = (c.filtered_words || []).length;
  const prio = (c.priority_roles || []).length;
  const reacts = c.react_channel_ids || [];
  const live = st.giveaways_live;
  const wlReady = c.whitelist_channel_id && c.whitelist_role_id;
  const welcomeOn = c.welcome_enabled && c.welcome_channel_id;
  return [
    { page: 'whitelist', icon: 'shield', name: 'Whitelist', where: c.whitelist_channel_id ? channelLabel(c.whitelist_channel_id) : null,
      status: !wlReady ? 'Not set' : c.wl_enabled ? 'WL mode' : 'Vouch only', kind: wlReady ? 'on' : 'warn' },
    { page: 'welcome', icon: 'door', name: 'Welcome', where: c.welcome_channel_id ? channelLabel(c.welcome_channel_id) : null,
      status: welcomeOn ? 'On' : 'Off', kind: welcomeOn ? 'on' : 'off' },
    { page: 'filter', icon: 'filter', name: 'Word filter', where: words ? `${words} filtered ${words === 1 ? 'word' : 'words'}` : null,
      status: words ? 'On' : 'Off', kind: words ? 'on' : 'off' },
    { page: 'honeypot', icon: 'target', name: 'Honeypot', where: c.honeypot_channel_id ? channelLabel(c.honeypot_channel_id) : null,
      status: c.honeypot_channel_id ? `${st.honeypot_catches} caught` : 'Off', kind: c.honeypot_channel_id ? 'on' : 'off' },
    { page: 'priority', icon: 'plane', name: 'Priority roles', where: prio ? `${prio} ${prio === 1 ? 'tier' : 'tiers'}` : null,
      status: prio ? 'Ready' : 'Not set', kind: prio ? 'on' : 'warn' },
    { page: 'react', icon: 'thumbs', name: 'React channels', where: reacts.length ? reacts.slice(0, 2).map(id => channelLabel(id, '#deleted')).join(', ') + (reacts.length > 2 ? ` +${reacts.length - 2}` : '') : null,
      status: reacts.length ? 'On' : 'Off', kind: reacts.length ? 'on' : 'off' },
    { page: 'reaction-roles', icon: 'smile', name: 'Reaction roles', where: st.reaction_panels ? `${st.reaction_panels} ${st.reaction_panels === 1 ? 'panel' : 'panels'}` : null,
      status: st.reaction_panels ? 'On' : 'None', kind: st.reaction_panels ? 'on' : 'off' },
    { page: 'giveaways', icon: 'gift', name: 'Giveaways', where: live ? `${live} running` : null,
      status: live ? `${live} live` : 'None', kind: live ? 'on' : 'off' },
    ticketBoardRow(),
    robloxBoardRow(),
    ...newBoardRows(c),
    { page: 'roblox-ranks', icon: 'rank', name: 'Group ranks', where: c.roblox_group_id ? `Group ${c.roblox_group_id}` : null,
      status: !c.roblox_group_id ? 'Not set' : (c.roblox_rank_roles || []).length ? `${new Set(c.roblox_rank_roles.map(b => b.rank)).size} ranks` : 'No ranks',
      kind: c.roblox_group_id ? 'on' : 'warn' },
  ].filter(r => (S.data.tabs || []).includes(r.page));
}

function newBoardRows(c) {
  const n = (k) => (c[k] || []).length;
  const set_ = (v, on = 'On') => v ? on : 'Not set';
  const ex = extra;
  const reviews = ex('reviews'), apps = ex('applications'), sess = ex('roblox-sessions');
  return [
    { page: 'announcements', icon: 'megaphone', name: 'Timed messages', where: n('ann_messages') ? `${n('ann_messages')} on a timer` : null, status: n('ann_messages') ? 'On' : 'None', kind: n('ann_messages') ? 'on' : 'off' },
    { page: 'automod', icon: 'bolt', name: 'Auto-mod', where: [c.am_spam && 'spam', c.am_invites && 'invites', c.am_links && 'links', c.am_caps && 'caps'].filter(Boolean).join(', ') || null, status: 'On', kind: 'on' },
    { page: 'moderation', icon: 'gavel', name: 'Moderation', where: ex('moderation').lockdown ? 'Server locked down' : ex('moderation').total ? `${ex('moderation').total} cases` : null,
      status: ex('moderation').lockdown ? 'Lockdown' : 'Ready', kind: ex('moderation').lockdown ? 'warn' : 'on' },
    { page: 'utility', icon: 'wrench', name: 'Utility', where: [ex('utility').reminders && `${ex('utility').reminders} reminders`, ex('utility').afk && `${ex('utility').afk} AFK`].filter(Boolean).join(', ') || null, status: 'Ready', kind: 'on' },
    { page: 'logs', icon: 'scroll', name: 'Server logs', where: c.logs_channel_id ? channelLabel(c.logs_channel_id) : null, status: set_(c.logs_channel_id), kind: c.logs_channel_id ? 'on' : 'warn' },
    { page: 'leveling', icon: 'trend', name: 'Leveling', where: ex('leveling').members ? `${ex('leveling').members} ranked` : null, status: c.lvl_enabled ? 'On' : 'Off', kind: c.lvl_enabled ? 'on' : 'off' },
    { page: 'suggestions', icon: 'bulb', name: 'Suggestions', where: c.sug_channel_id ? channelLabel(c.sug_channel_id) : null, status: set_(c.sug_channel_id), kind: c.sug_channel_id ? 'on' : 'warn' },
    { page: 'starboard', icon: 'star', name: 'Starboard', where: c.star_channel_id ? channelLabel(c.star_channel_id) : null, status: set_(c.star_channel_id), kind: c.star_channel_id ? 'on' : 'warn' },
    { page: 'birthdays', icon: 'cake', name: 'Birthdays', where: ex('birthdays').count ? `${ex('birthdays').count} saved` : null, status: set_(c.bday_channel_id), kind: c.bday_channel_id ? 'on' : 'warn' },
    { page: 'autoresponses', icon: 'reply', name: 'Auto-responses', where: n('ar_rules') ? `${n('ar_rules')} triggers` : null, status: n('ar_rules') ? 'On' : 'None', kind: n('ar_rules') ? 'on' : 'off' },
    { page: 'tempvoice', icon: 'mic', name: 'Voice channels', where: c.tv_hub_channel_id ? channelLabel(c.tv_hub_channel_id) : null, status: set_(c.tv_hub_channel_id), kind: c.tv_hub_channel_id ? 'on' : 'warn' },
    { page: 'channeltools', icon: 'pin', name: 'Channel tools', where: [n('sticky_messages') && `${n('sticky_messages')} sticky`, n('stat_channels') && `${n('stat_channels')} stats`, c.count_channel_id && 'counting'].filter(Boolean).join(', ') || null,
      status: n('sticky_messages') || n('stat_channels') || c.count_channel_id ? 'On' : 'None', kind: n('sticky_messages') || n('stat_channels') || c.count_channel_id ? 'on' : 'off' },
    { page: 'applications', icon: 'file', name: 'Applications', where: n('app_forms') ? `${n('app_forms')} forms` : null, status: apps.pending ? `${apps.pending} waiting` : n('app_forms') ? 'Ready' : 'None', kind: n('app_forms') ? 'on' : 'warn' },
    { page: 'faq', icon: 'help', name: 'FAQ', where: n('faq_entries') ? `${n('faq_entries')} questions` : null, status: n('faq_entries') ? 'Ready' : 'None', kind: n('faq_entries') ? 'on' : 'warn' },
    { page: 'status', icon: 'pulse', name: 'Status page', where: n('status_components') ? `${n('status_components')} parts` : null, status: n('status_components') ? ({ operational: 'All good', maintenance: 'Upkeep', degraded: 'Degraded', partial: 'Partial', major: 'Outage' }[ex('status').overall] || 'All good') : 'Not set', kind: n('status_components') ? 'on' : 'warn' },
    { page: 'reviews', icon: 'chat', name: 'Reviews', where: reviews.count ? `${reviews.count} reviews` : null, status: reviews.count ? `${reviews.average} stars` : set_(c.rev_channel_id, 'Ready'), kind: c.rev_channel_id ? 'on' : 'warn' },
    { page: 'roblox-game', icon: 'game', name: 'Game stats', where: ex('roblox-game').game ? ex('roblox-game').game.name : null, status: c.rbx_place_id ? 'On' : 'Not set', kind: c.rbx_place_id ? 'on' : 'warn' },
    { page: 'roblox-sessions', icon: 'calendar', name: 'Sessions', where: c.sess_channel_id ? channelLabel(c.sess_channel_id) : null, status: (sess.active || []).length ? 'Live' : set_(c.sess_channel_id, 'Ready'), kind: c.sess_channel_id ? 'on' : 'warn' },
  ];
}

function featureOn(feature) {
  return !feature || (S.data.features || []).includes(feature);
}

/* ── server facts on the Overview ── */

function since(unix) {
  const s = Date.now() / 1000 - unix;
  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
  for (const [unit, n] of [['year', 31557600], ['month', 2629800], ['day', 86400], ['hour', 3600]]) {
    if (s >= n) return rtf.format(-Math.floor(s / n), unit);
  }
  return 'just now';
}

function fullDate(unix) {
  return new Date(unix * 1000).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function languageName(code) {
  try { return new Intl.DisplayNames([navigator.language || 'en'], { type: 'language' }).of(code) || code; } catch { return code; }
}

const num = n => n == null ? '—' : Number(n).toLocaleString();
const plural = (n, one, many = one + 's') => `${num(n)} ${n === 1 ? one : many}`;

/** Discord's online count (the cache doesn't have it). Kept a minute so the page's auto refresh doesn't ask again. */
async function serverLive() {
  const keep = S.liveInfo;
  if (keep && keep.gid === S.gid && Date.now() - keep.at < 60000) return keep.data;
  const data = await gapi('GET', '/server-info').catch(() => ({ online: null }));
  S.liveInfo = { gid: S.gid, at: Date.now(), data };
  return data;
}

function serverStats(sv) {
  const online = h('b', { class: 'stat-num' }, S.liveInfo?.gid === S.gid ? num(S.liveInfo.data.online) : '…');
  const onlineSub = h('span', { class: 'stat-sub' }, 'Discord\'s count');
  serverLive().then(live => {
    online.textContent = num(live.online);
    if (live.online == null) onlineSub.textContent = "Discord didn't say right now";
    if (live.owner && !S.data.server.owner.name) { S.data.server.owner = live.owner; drawOwner(); }
  });
  const cell = (label, value, sub) => h('div', { class: 'stat' }, h('span', { class: 'stat-label' }, label), value, sub);
  return h('section', { class: 'server-stats', 'aria-label': 'Server numbers' },
    cell('Members', h('b', { class: 'stat-num' }, num(sv.members)),
      h('span', { class: 'stat-sub' }, sv.bots != null ? `${plural(sv.humans, 'person', 'people')}, ${plural(sv.bots, 'bot')}` : 'Bots included')),
    cell('Online now', online, onlineSub),
    cell('New this week', h('b', { class: 'stat-num' }, num(sv.joined_week)),
      h('span', { class: 'stat-sub' }, sv.joined_week != null ? 'Joined in the last 7 days' : 'Still loading members')),
    cell('Boosts', h('b', { class: 'stat-num' }, num(sv.boosts)),
      h('span', { class: 'stat-sub' }, sv.boost_level ? `Level ${sv.boost_level}` : 'No boost level yet')),
  );
}

const ownerSlot = { el: null };

function drawOwner() {
  const o = S.data.server.owner || {};
  if (!ownerSlot.el) return;
  ownerSlot.el.replaceChildren(o.name
    ? h('span', { class: 'owner' },
        o.avatar ? h('img', { src: o.avatar, alt: '' }) : h('span', { class: 'avatar-blank' }),
        h('span', null, h('b', null, o.display), o.display !== o.name ? h('span', { class: 'row-help' }, ` @${o.name}`) : null))
    : h('span', { class: 'row-help' }, 'Looking them up…'),
    o.id ? copyChip(o.id, 'Copied the owner\'s ID.', 'Copy ID') : null);
}

function copyChip(text, done, label = 'Copy') {
  return h('button', { type: 'button', class: 'btn small ghost copy-chip', title: label, onclick: () => copyText(text, done) }, icon('copy'), label);
}

function serverInfoPanel(sv) {
  ownerSlot.el = h('div', { class: 'info-value owner-row' });
  drawOwner();
  const ch = sv.channels || {};
  const channels = [[ch.text, 'text'], [ch.announcement, 'announcement'], [ch.voice, 'voice'], [ch.stage, 'stage'],
    [ch.forum, 'forum'], [ch.categories, 'category', 'categories']]
    .filter(([n]) => n).map(([n, one, many]) => `${num(n)} ${n === 1 ? one : (many || one)}`).join(', ');
  const item = (label, value) => value == null || value === '' ? null
    : h('div', { class: 'info-row' }, h('dt', null, label), h('dd', null, value));
  return panel('Server info', null, h('dl', { class: 'info-list' },
    item('Server ID', h('div', { class: 'info-value' }, h('code', null, sv.id), copyChip(sv.id, 'Copied the server ID.'))),
    h('div', { class: 'info-row' }, h('dt', null, 'Owner'), h('dd', null, ownerSlot.el)),
    item('Created', sv.created ? `${fullDate(sv.created)} (${since(sv.created)})` : null),
    item('Bot added', sv.bot_joined ? `${fullDate(sv.bot_joined)} (${since(sv.bot_joined)})` : null),
    item('Members', sv.bots != null ? `${num(sv.members)}: ${plural(sv.humans, 'person', 'people')} and ${plural(sv.bots, 'bot')}` : num(sv.members)),
    item('Channels', channels || 'None'),
    item('Roles', num(sv.roles)),
    item('Emojis', sv.emoji_limit ? `${num(sv.emojis)} of ${num(sv.emoji_limit)}` : num(sv.emojis)),
    item('Stickers', sv.sticker_limit ? `${num(sv.stickers)} of ${num(sv.sticker_limit)}` : num(sv.stickers)),
    item('Boosts', `${plural(sv.boosts, 'boost')}${sv.boost_level ? `, level ${sv.boost_level}` : ''}`),
    item('Verification', sv.verification),
    item('Language', sv.locale ? languageName(sv.locale) : null),
    item('Invite link', sv.vanity ? h('div', { class: 'info-value' }, h('code', null, `discord.gg/${sv.vanity}`), copyChip(`https://discord.gg/${sv.vanity}`, 'Copied the invite link.')) : null),
    item('Description', sv.description),
  ));
}

function pageOverview() {
  const d = S.data, g = d.guild, sv = d.server || {};
  const icon_ = h('div', { class: 'icon' });
  if (g.icon) icon_.style.backgroundImage = `url("${g.icon}")`;
  else icon_.textContent = g.name.slice(0, 1).toUpperCase();

  const uptime = span(Date.now() / 1000 - d.bot.started);
  const strip = h('div', { class: 'server-strip' }, icon_, h('div', null,
    h('h1', null, g.name),
    h('div', { class: 'facts' },
      (sv.badges || []).map(b => h('span', { class: 'badge' }, b)),
      h('span', { class: 'online' }, `${d.bot.name} is online`),
      featureOn('whitelist') && d.stats.whitelisted != null ? h('span', null, h('b', null, d.stats.whitelisted.toLocaleString()), ' whitelisted') : null,
      featureOn('roblox-verify') && d.roblox ? h('span', null, h('b', null, d.roblox.linked.toLocaleString()), ' linked to Roblox') : null,
      d.bot.latency_ms != null ? h('span', null, h('b', null, d.bot.latency_ms + ' ms'), ' ping') : null,
      h('span', null, 'Up ', h('b', null, uptime)),
    ),
  ));

  const rows = boardRows();
  const width = Math.max(10, ...rows.map(r => r.status.length));
  const noFigs = !(S.saved.figs || []).length;
  const board = noFigs ? h('section', { class: 'fig-start' },
    h('h2', null, 'What kind of server is this?'),
    h('p', null, "Turn on one or more figs. Each one opens the tabs that kind of server needs. You can change this any time on the Figs page."),
    figCards(),
  ) : !rows.length ? null : h('div', { class: 'board', role: 'table', 'aria-label': 'Feature status' },
    h('div', { class: 'board-row board-cols', role: 'row' },
      h('span', { role: 'columnheader' }, 'Feature'), h('span', { role: 'columnheader' }, 'Where'),
      h('span', { role: 'columnheader' }, 'Status'), h('span')),
    rows.map((r, i) => h('a', { class: 'board-row', href: here(r.page), role: 'row' },
      h('span', { class: 'board-feature', role: 'cell' }, icon(r.icon), r.name),
      h('span', { class: 'board-where' + (r.where ? '' : ' none'), role: 'cell' }, r.where || 'Not set up'),
      h('span', { class: 'board-status', role: 'cell' }, flaps(r.status, r.kind, i, width)),
      h('span', { class: 'board-go' }, icon('right')),
    )),
  );
  S.flipped = true;

  // problems worth fixing
  const warnings = [];
  const wlRole = G.role(S.saved.whitelist_role_id);
  if (featureOn('whitelist') && wlRole && !wlRole.assignable) warnings.push(`My role is below ${wlRole.name}, so I can't whitelist anyone. Drag my role above it in Server Settings → Roles.`);
  const rbRole = G.role(S.saved.roblox_verified_role_id);
  if (featureOn('roblox-verify') && rbRole && !rbRole.assignable) warnings.push(`My role is below ${rbRole.name}, so I can't give it to verified members. Drag my role above it in Server Settings → Roles.`);
  if (!noFigs && !d.guild.bot_perms.administrator && !d.guild.bot_perms.manage_roles) warnings.push('I need the Manage Roles permission to give out roles.');

  const perms = d.guild.bot_perms;
  const admin = perms.administrator;
  const permRows = [
    ['manage_roles', 'Manage Roles', 'giving out roles', null],
    ['manage_nicknames', 'Manage Nicknames', 'Roblox nicknames', ['roblox-verify']],
    ['manage_messages', 'Manage Messages', 'deleting filtered words', ['filter']],
    ['add_reactions', 'Add Reactions', '👍/👎 channels and reaction roles', ['react', 'reaction-roles']],
    ['ban_members', 'Ban Members', 'honeypot softban and ban', ['honeypot']],
    ['kick_members', 'Kick Members', 'honeypot kick', ['honeypot']],
    ['moderate_members', 'Timeout Members', 'honeypot timeouts', ['honeypot']],
    ['manage_channels', 'Manage Channels', 'making ticket channels', ['tickets']],
  ].filter(([, , , needs]) => !needs || needs.some(featureOn));

  const activity = d.activity.length
    ? h('ul', { class: 'activity' }, d.activity.slice(0, 12).map(a => h('li', null,
        a.avatar ? h('img', { src: a.avatar, alt: '' }) : h('span', { class: 'avatar-blank' }),
        h('div', null, h('span', { class: 'who' }, a.user), ' ', a.text.charAt(0).toLowerCase() + a.text.slice(1),
          h('div', { class: 'when' }, ago(a.t))))))
    : h('div', { class: 'empty' }, 'Nothing has been changed from the dashboard yet.');

  return h('div', null,
    strip,
    warnings.length ? h('div', { class: 'stack', style: { marginBottom: '20px' } }, warnings.map(w => note(w))) : null,
    d.server ? serverStats(sv) : null,
    board,
    h('div', { class: 'overview-grid' },
      d.server ? serverInfoPanel(sv) : null,
      h('div', { class: 'stack' },
        panel('Bot permissions', admin ? 'I have Administrator, so everything is covered.' : 'What my role lets me do in this server.',
          h('ul', { class: 'perm-list' }, permRows.map(([k, name, why]) => {
            const ok = admin || perms[k];
            return h('li', null, h('span', { class: ok ? 'ok' : 'no' }, icon(ok ? 'check' : 'alert')),
              h('span', null, h('b', null, name), h('span', { class: 'row-help', style: { display: 'inline', marginLeft: '6px' } }, why)));
          }))),
        panel('Recent changes', 'Who changed what on this dashboard.', activity),
      ),
    ),
  );
}

/* ═════════════ General ═════════════ */

function imageRow(key, label, help, kind) {
  const img = h('img', { class: `img-preview ${kind}`, alt: '' });
  const update = () => {
    const url = get(key);
    img.hidden = !httpOk(url);
    if (httpOk(url) && img.getAttribute('src') !== url) img.src = url;
  };
  img.addEventListener('error', () => { img.hidden = true; });
  S.live.push(k => { if (k === key) update(); });
  update();
  return row(label, help, [textInput(key, { placeholder: 'https://…' }), img], { key });
}

function pageGeneral() {
  return h('div', null,
    pageHead('General', 'Name, colors and images used on every message the bot sends.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Server', null, [
          row('Server name', 'Shown on panels and in {server}.', textInput('server_name', { max: 100 }), { key: 'server_name' }),
          row('Accent color', 'The stripe down the side of every panel.', colorInput('accent_color'), { key: 'accent_color' }),
          row('Server emoji', 'Used on buttons, titles and the sneak peek reaction.', emojiField(get('city_emoji'), v => set('city_emoji', v)), { key: 'city_emoji' }),
        ]),
        panel('Images', 'Paste image links. Discord CDN or catbox links work well.', [
          imageRow('thumbnail_url', 'Thumbnail', 'The small square image in the corner of panels.', 'thumb'),
          imageRow('banner_url', 'Banner', 'The wide image on the WL panel and welcome message.', 'banner'),
        ]),
        panel('Links', 'Shown as buttons on panels like the WL panel. Leave one empty to hide its button.', [
          row('Support server', null, textInput('support_url', { placeholder: 'https://discord.gg/…' }), { key: 'support_url' }),
          row('Website', null, textInput('website_url', { placeholder: 'https://…' }), { key: 'website_url' }),
        ]),
        panel('Logs', null, [
          row('Log channel', 'Bot logs go here when a feature has no log channel of its own.',
            channelPick('log_channel_id'), { key: 'log_channel_id' }),
        ]),
      ),
      livePreview('Preview', () => dcMessage([
        headerBlock([`## ${emoji()} ${get('server_name') || 'Your server'}`, 'This is how panels look with your color, emoji and thumbnail.']),
        { t: 'sep' },
        ...(httpOk(get('banner_url')) ? [{ t: 'gallery', url: get('banner_url') }] : []),
        { t: 'text', md: '**Whitelisted Successfully**\n{user} has been whitelisted!' },
        ...(get('support_url') || get('website_url') ? [{ t: 'buttons', items: [
          get('support_url') ? { label: 'Support Server', emoji: emoji() } : null,
          get('website_url') ? { label: 'Website', emoji: emoji() } : null,
        ].filter(Boolean) }] : []),
      ])),
    ),
  );
}

/* ═════════════ Whitelist ═════════════ */

function textBlocks(key, { addLabel = 'Add a block', max = 8 } = {}) {
  const wrap = h('div', { class: 'stack', style: { gap: '8px' } });
  const draw = () => {
    wrap.replaceChildren();
    const blocks = get(key) || [];
    blocks.forEach((text, i) => {
      const ta = h('textarea', { class: 'input', rows: Math.min(8, Math.max(3, text.split('\n').length + 1)), value: text, 'aria-label': `Block ${i + 1}` });
      ta.addEventListener('input', () => { const b = [...get(key)]; b[i] = ta.value; set(key, b); });
      wrap.append(h('div', { class: 'block-row' }, ta,
        h('button', { type: 'button', class: 'btn icon del', 'aria-label': `Remove block ${i + 1}`, title: 'Remove',
          onclick: () => { set(key, get(key).filter((_, j) => j !== i)); draw(); } }, icon('trash'))));
    });
    if (blocks.length < max) {
      wrap.append(h('div', null, h('button', { type: 'button', class: 'btn small', onclick: () => { set(key, [...(get(key) || []), '']); draw(); wrap.querySelectorAll('textarea')[blocks.length]?.focus(); } }, icon('plus'), addLabel)));
    }
  };
  draw();
  return wrap;
}

function wlPanelBlocks() {
  const blocks = [headerBlock([`# ${get('wl_panel_title') || 'WL System'}`, ...(get('wl_panel_subtitle') ? [get('wl_panel_subtitle')] : [])]), { t: 'sep' }];
  if (httpOk(get('banner_url'))) blocks.push({ t: 'gallery', url: get('banner_url') }, { t: 'sep' });
  (get('wl_panel_sections') || []).filter(s => s.trim()).forEach((s, i) => {
    if (i) blocks.push({ t: 'sep', visible: false });
    blocks.push({ t: 'text', md: s });
  });
  const buttons = [
    get('support_url') ? { label: 'Support Server', emoji: emoji() } : null,
    get('website_url') ? { label: 'Website', emoji: emoji() } : null,
  ].filter(Boolean);
  if (buttons.length) blocks.push({ t: 'sep' }, { t: 'buttons', items: buttons });
  if (get('wl_panel_footer')) blocks.push({ t: 'sep', visible: false }, { t: 'text', md: '-# ' + get('wl_panel_footer') });
  return blocks;
}

function roleWarning(key, what) {
  const slot = h('div');
  const draw = () => {
    const r = G.role(get(key));
    slot.replaceChildren(r && !r.assignable ? note(`My role is below ${r.name}, so I can't ${what}. Drag my role above it in Server Settings → Roles.`) : '');
  };
  S.live.push(k => { if (k === key) draw(); });
  draw();
  return slot;
}

function pageWhitelist() {
  const post = localChannel(S.saved.whitelist_channel_id);
  const postBtn = h('button', { class: 'btn primary', onclick: e => act(e.currentTarget, () => {
    if (!post.value) throw new Error('Pick a channel to post the panel in.');
    return gapi('POST', '/actions/wl-panel', { channel_id: post.value });
  }) }, icon('send'), 'Post panel');

  return h('div', null,
    pageHead('Whitelist', 'How new members get whitelisted, and the panel that explains it.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('How members get whitelisted', 'Same switch as /turnonwl and /turnoffwl.', h('div', { class: 'panel-body' },
          choiceCards('wl_enabled', [
            { value: true, label: 'Type wl', text: 'Anyone types wl in the whitelist channel and gets the role.' },
            { value: false, label: 'Vouch only', text: 'Whitelisted members type vouch @user to let someone in.' },
          ]))),
        panel('Channel and roles', null, [
          row('Whitelist channel', 'Where people type wl or vouch.', channelPick('whitelist_channel_id'), { key: 'whitelist_channel_id' }),
          row('Whitelist role', 'Given when someone is whitelisted.', [rolePick('whitelist_role_id'), roleWarning('whitelist_role_id', 'give it out')], { key: 'whitelist_role_id' }),
          row('Unverified role', 'Taken away once someone is whitelisted. Optional.', [rolePick('unverified_role_id'), roleWarning('unverified_role_id', 'take it away')], { key: 'unverified_role_id' }),
        ]),
        panel('WL panel', 'The message that explains how to get in. Supports Discord formatting like **bold** and # headings.', [
          row('Title', null, textInput('wl_panel_title', { max: 200 }), { key: 'wl_panel_title' }),
          row('Subtitle', null, textInput('wl_panel_subtitle', { max: 500 }), { key: 'wl_panel_subtitle' }),
          row('Text blocks', 'Each block is separated by a gap.', textBlocks('wl_panel_sections'), { key: 'wl_panel_sections' }),
          row('Footer', 'Small grey text at the bottom.', textInput('wl_panel_footer', { max: 200 }), { key: 'wl_panel_footer' }),
          row('Post the panel', 'Sends a fresh copy. Old copies stay as they are.', [
            savedFirstNote(['wl_panel_title', 'wl_panel_subtitle', 'wl_panel_sections', 'wl_panel_footer', 'thumbnail_url', 'banner_url', 'support_url', 'website_url', 'accent_color', 'city_emoji']),
            h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), postBtn),
          ]),
        ]),
      ),
      livePreview('WL panel preview', () => dcMessage(wlPanelBlocks())),
    ),
  );
}

/* ═════════════ Welcome ═════════════ */

function welcomeBlocks() {
  const header = [`## ${get('welcome_title') || ''}`];
  if (get('welcome_message')) header.push(get('welcome_message'));
  const blocks = [headerBlock(header), { t: 'sep' }];
  if (httpOk(get('banner_url'))) blocks.push({ t: 'gallery', url: get('banner_url') }, { t: 'sep' });
  const links = (get('welcome_links') || []).map(id => `- <#${id}>`);
  if (links.length) blocks.push({ t: 'text', md: links.join('\n') });
  if (get('welcome_footer')) blocks.push({ t: 'sep', visible: false }, { t: 'text', md: '-# ' + get('welcome_footer') });
  return blocks;
}

const TOKENS_WELCOME = [['{user}', 'Mentions the new member'], ['{username}', 'Their display name'], ['{server}', 'Server name'], ['{member_count}', 'How many members the server has']];

function pageWelcome() {
  const testBtn = h('button', { class: 'btn', onclick: e => act(e.currentTarget, () => gapi('POST', '/actions/welcome-test', {})) }, icon('send'), 'Send a test');

  return h('div', null,
    pageHead('Welcome', 'The message posted when someone joins, roles they get, a welcome DM and goodbye messages.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Welcome messages', null, [
          row('Post a welcome', null, toggle('welcome_enabled', 'When someone joins'), { key: 'welcome_enabled', inline: true }),
          row('Channel', null, channelPick('welcome_channel_id'), { key: 'welcome_channel_id' }),
          row('Test it', 'Sends the saved message to the welcome channel, with you as the new member.', [savedFirstNote(['welcome_title', 'welcome_message', 'welcome_links', 'welcome_footer', 'welcome_channel_id']), h('div', null, testBtn)]),
        ]),
        panel('Message', 'Supports Discord formatting like **bold**, *italics* and - lists.', [
          row('Title', null, textInput('welcome_title', { max: 200 }), { key: 'welcome_title' }),
          row('Text', null, [textInput('welcome_message', { multiline: true, rows: 4, max: 1500 }), placeholderHelp('welcome_message', TOKENS_WELCOME)], { key: 'welcome_message' }),
          row('Channel links', 'Listed under the banner so new members know where to go.', channelPick('welcome_links', { multiple: true }), { key: 'welcome_links' }),
          row('Footer', 'Small grey text at the bottom.', textInput('welcome_footer', { max: 200 }), { key: 'welcome_footer' }),
        ]),
        ...welcomeExtras(),
      ),
      livePreview('Preview', () => dcMessage(welcomeBlocks())),
    ),
  );
}

/* ═════════════ Priority roles ═════════════ */

function pagePriority() {
  const list = h('div', { class: 'prio-rows' });
  const draw = () => {
    list.replaceChildren();
    const rows = get('priority_roles') || [];
    if (!rows.length) list.append(h('div', { class: 'chips-empty' }, 'No priority roles yet. Add the first one below.'));
    rows.forEach((r, i) => {
      const name = h('input', { class: 'input', value: r.name, placeholder: 'Name staff will pick, e.g. privatejet', 'aria-label': `Name ${i + 1}` });
      name.addEventListener('input', () => { const v = copy(get('priority_roles')); v[i].name = name.value; set('priority_roles', v); });
      const pick = picker({ items: roleItems(), value: r.role_id, placeholder: 'Pick the role', label: `Role ${i + 1}`, searchPlaceholder: 'Search roles',
        onChange: id => { const v = copy(get('priority_roles')); v[i].role_id = id; set('priority_roles', v); } });
      pick.classList.add('prio-role');
      list.append(h('div', { class: 'prio-row' },
        h('span', { class: 'prio-rank', 'aria-hidden': 'true' }, i + 1),
        name, pick,
        h('button', { type: 'button', class: 'btn icon del', 'aria-label': `Remove ${r.name || 'row'}`, title: 'Remove',
          onclick: () => { set('priority_roles', get('priority_roles').filter((_, j) => j !== i)); draw(); } }, icon('trash')),
      ));
    });
  };
  draw();
  const addBtn = h('button', { type: 'button', class: 'btn', onclick: () => {
    const v = get('priority_roles') || [];
    if (v.length >= 25) return toast('Discord shows up to 25 choices, so 25 is the limit.', { error: true });
    set('priority_roles', [...v, { name: '', role_id: null }]);
    draw();
    list.querySelectorAll('input')[v.length]?.focus();
  } }, icon('plus'), 'Add priority role');

  return h('div', null,
    pageHead('Priority roles', 'The roles staff can hand out with /give-prio. /removeall-prio takes all of them off someone.'),
    h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 860px)' } },
      h('div', { class: 'stack' },
        panel('Tiers', 'Staff pick these by name when running /give-prio. New ones show up in the command right after saving.',
          h('div', { class: 'panel-body stack' }, list, h('div', null, addBtn)), {}),
      ),
    ),
  );
}

/* ═════════════ Word filter ═════════════ */

function pageFilter() {
  const users = memberPick('filter_whitelist_users');

  return h('div', null,
    pageHead('Word filter', "Words that get deleted, and who's allowed to say them."),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Filtered words', 'Messages with these get deleted, even when the word is inside a longer word. Same list as /filter-add and /filter-remove.',
          h('div', { class: 'panel-body' }, wordBox('filtered_words'), S.errors.filtered_words ? h('div', { class: 'field-error' }, S.errors.filtered_words) : null)),
        panel('Allowed words', "Never deleted, even if a filtered word is inside them. Same as /filter-allow. For example, allow “class” so it isn't caught by a shorter word inside it.",
          h('div', { class: 'panel-body' }, wordBox('allowed_words', { placeholder: 'Type an allowed word and press Enter' }))),
        panel('Whitelisted people', 'Their messages are never filtered. Same as /wlfilter.', h('div', { class: 'panel-body' }, users)),
        panel('Warning', null, [
          row('Warning message', 'Posted after a message is deleted.', [textInput('filter_message', { multiline: true, rows: 2, max: 500 }), placeholderHelp('filter_message', [['{user}', 'Mentions the person']])], { key: 'filter_message' }),
        ]),
      ),
      livePreview('Warning preview', () => dcMessage(null, { plain: get('filter_message') || '' })),
    ),
  );
}

/* ═════════════ Honeypot ═════════════ */

function honeypotWarningBlocks() {
  const action = get('honeypot_action') || 'softban';
  const result = action.startsWith('timeout') ? 'timed out' : 'removed from the server';
  return [
    headerBlock([`## ${emoji()} Do Not Type Here`, `This channel is a trap for spam bots and hacked accounts.\nAnyone who sends a message here is **automatically ${result}**.`, `-# ${S.data.stats.honeypot_catches} caught so far`]),
  ];
}

function pageHoneypot() {
  const catches = S.data.stats.honeypot_catches;
  const perms = S.data.guild.bot_perms;
  const needed = { softban: 'ban_members', ban: 'ban_members', kick: 'kick_members' };
  const permSlot = h('div');
  const drawPerm = () => {
    const a = get('honeypot_action') || 'softban';
    const p = needed[a] || 'moderate_members';
    const names = { ban_members: 'Ban Members', kick_members: 'Kick Members', moderate_members: 'Timeout Members' };
    permSlot.replaceChildren(!perms.administrator && !perms[p] ? note(`I need the ${names[p]} permission for this.`) : '');
  };
  S.live.push(k => { if (k === 'honeypot_action') drawPerm(); });
  drawPerm();

  const on = !!S.saved.honeypot_channel_id;
  return h('div', null,
    pageHead('Honeypot', 'A trap channel that catches spam bots and hacked accounts. Staff with Manage Messages are never caught.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        on ? note(`On. Watching ${channelLabel(S.saved.honeypot_channel_id)}.`, 'good') : note('Off. Pick a trap channel to turn it on.', 'info'),
        panel('Trap', 'Same settings as the /honeypot menu.', [
          row('Trap channel', "Pick an empty channel nobody should type in. I'll post a warning there when you save.", channelPick('honeypot_channel_id'), { key: 'honeypot_channel_id' }),
          row('Log channel', 'Each catch is logged here. Leave empty to use the main log channel.', channelPick('honeypot_log_channel_id', { placeholder: 'Main log channel' }), { key: 'honeypot_log_channel_id' }),
        ]),
        panel('What happens to them', null, h('div', { class: 'panel-body stack', style: { gap: '10px' } }, choiceCards('honeypot_action', HONEYPOT_ACTIONS), permSlot)),
        panel('Message sent to them', 'Sent by DM before the action. Leave empty to send nothing.', [
          row('DM text', null, [textInput('honeypot_message', { multiline: true, rows: 3, max: 1000 }), placeholderHelp('honeypot_message', [['{server}', 'Server name']])], { key: 'honeypot_message', wide: true }),
        ]),
        panel('Catches', null, [
          row('Total caught', null, h('div', { class: 'input-row' },
            h('b', { style: { fontSize: '22px', fontFamily: 'var(--display)', minWidth: '48px' } }, String(catches)),
            h('button', { class: 'btn small', disabled: !on, onclick: e => act(e.currentTarget, () => gapi('POST', '/actions/honeypot-repost')) }, icon('refresh'), 'Repost warning'),
            h('button', { class: 'btn small danger', disabled: !catches, onclick: async e => {
              const b = e.currentTarget;
              if (await confirmDialog({ title: 'Reset the catch count?', text: 'The counter goes back to 0. This only changes the number.', confirm: 'Reset', danger: true })) {
                const res = await act(b, () => gapi('POST', '/actions/honeypot-reset'));
                if (res) { S.data.stats.honeypot_catches = 0; App.render(); }
              }
            } }, 'Reset count'),
          ), { inline: true }),
        ]),
      ),
      livePreview('Warning in the trap channel', () => dcMessage(honeypotWarningBlocks())),
    ),
  );
}

/* ═════════════ React channels ═════════════ */

function pageReact() {
  return h('div', null,
    pageHead('React channels', 'Channels where every message gets 👍 and 👎. Same as /reactchannel.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Channels', 'Good for suggestions, polls and screenshots.', h('div', { class: 'panel-body' }, channelPick('react_channel_ids', { multiple: true }))),
      ),
      livePreview('What members see', () => h('div', { class: 'dc' }, h('div', { class: 'dc-msg' },
        h('div', { class: 'dc-avatar', style: { background: '#e67e22' } }),
        h('div', null, h('div', { class: 'dc-head' }, h('span', { class: 'dc-name' }, 'Member'), h('span', { class: 'dc-time' }, 'Today at 4:20 PM')),
          h('div', { class: 'dc-text' }, h('p', null, 'Can we get a new car dealership downtown?')),
          h('div', { class: 'dc-reactions' }, h('span', { class: 'dc-reaction' }, '👍 1'), h('span', { class: 'dc-reaction' }, '👎 1')))))),
    ),
  );
}

/* ═════════════ Reaction roles ═════════════ */

const rrForm = { title: 'Reaction Roles', rows: [{ emoji: '', role_id: null }] };

function pageReactionRoles() {
  const post = localChannel(null);
  const previewSlot = h('div');
  const drawPreview = () => {
    const rows = rrForm.rows.filter(r => r.emoji && r.role_id);
    const list = rows.map(r => `${r.emoji} → <@&${r.role_id}>`).join('\n') || '-# Add roles to see them here';
    previewSlot.replaceChildren(dcMessage([
      headerBlock([`## ${rrForm.title || 'Reaction Roles'}`, `**${get('server_name')}** React to the certain emoji to receive the certain role`, list]),
    ], { reactions: rows.length ? rows.map(r => r.emoji) : null }));
  };

  const rowsWrap = h('div', { class: 'stack', style: { gap: '8px' } });
  const drawRows = () => {
    rowsWrap.replaceChildren();
    rrForm.rows.forEach((r, i) => {
      const pick = picker({ items: roleItems(), value: r.role_id, placeholder: 'Pick a role', label: `Role ${i + 1}`, searchPlaceholder: 'Search roles',
        onChange: id => { r.role_id = id; drawPreview(); } });
      rowsWrap.append(h('div', { class: 'rr-row' },
        emojiField(r.emoji, v => { r.emoji = v; drawPreview(); }),
        pick,
        h('button', { type: 'button', class: 'btn icon del', 'aria-label': `Remove row ${i + 1}`, title: 'Remove', disabled: rrForm.rows.length === 1,
          onclick: () => { rrForm.rows.splice(i, 1); drawRows(); drawPreview(); } }, icon('trash'))));
    });
    if (rrForm.rows.length < 20) {
      rowsWrap.append(h('div', null, h('button', { type: 'button', class: 'btn small', onclick: () => { rrForm.rows.push({ emoji: '', role_id: null }); drawRows(); } }, icon('plus'), 'Add role')));
    }
  };
  drawRows();
  drawPreview();

  const title = h('input', { class: 'input', value: rrForm.title, 'aria-label': 'Panel title', maxlength: 200 });
  title.addEventListener('input', () => { rrForm.title = title.value; drawPreview(); });

  const postBtn = h('button', { class: 'btn primary', onclick: async e => {
    const res = await act(e.currentTarget, () => {
      if (!post.value) throw new Error('Pick a channel to post the panel in.');
      return gapi('POST', '/reaction-roles', { channel_id: post.value, title: rrForm.title, rows: rrForm.rows });
    });
    if (res) {
      S.data.reaction_panels = res.reaction_panels;
      S.data.stats.reaction_panels = res.reaction_panels.length;
      rrForm.rows = [{ emoji: '', role_id: null }];
      App.render();
    }
  } }, icon('send'), 'Post panel');

  const panels = S.data.reaction_panels;
  const list = panels.length ? h('div', { class: 'list' }, panels.map(p => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, p.title),
      h('div', { class: 'item-meta' }, p.channel ? '#' + p.channel : 'Channel unknown (made before the dashboard)'),
      h('div', { class: 'chips', style: { marginTop: '8px' } }, p.rows.map(r => {
        const role = G.role(r.role_id);
        return h('span', { class: 'chip', style: { paddingRight: '9px' } }, emojiNode(r.emoji, 'dc-emoji'), roleDot(role), h('span', null, role ? role.name : 'Deleted role'));
      })),
    ),
    h('div', { class: 'item-actions' },
      p.url ? h('a', { class: 'btn small ghost', href: p.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open') : null,
      h('button', { class: 'btn small danger', onclick: async e => {
        const b = e.currentTarget;
        if (!await confirmDialog({ title: 'Delete this panel?', text: 'The message is deleted from Discord and reacting stops giving roles. Members keep roles they already have.', confirm: 'Delete panel', danger: true })) return;
        const res = await act(b, () => gapi('DELETE', '/reaction-roles/' + p.id));
        if (res) { S.data.reaction_panels = res.reaction_panels; S.data.stats.reaction_panels = res.reaction_panels.length; App.render(); }
      } }, icon('trash'), 'Delete'),
    ),
  ))) : h('div', { class: 'empty' }, 'No panels yet. Post one above or with /reactionrole.');

  return h('div', null,
    pageHead('Reaction roles', 'Panels members react to for a role. Panels made with /reactionrole show up here too.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Post a new panel', null, [
          row('Title', null, title),
          row('Roles', 'Pick an emoji and the role it gives. Custom emojis have to be from a server I\'m in.', rowsWrap),
          row('Channel', null, h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), postBtn)),
        ]),
        panel('Panels', null, list),
      ),
      h('aside', { class: 'sticky' }, h('div', { class: 'preview-title' }, 'Preview'), previewSlot),
    ),
  );
}

/* ═════════════ Giveaways ═════════════ */

const gwForm = { prize: '', duration: '1d', winners: 1 };

function pageGiveaways() {
  const post = localChannel(null);
  const prize = h('input', { class: 'input', value: gwForm.prize, placeholder: 'e.g. Lamborghini Huracán', maxlength: 200, 'aria-label': 'Prize' });
  prize.addEventListener('input', () => { gwForm.prize = prize.value; });
  const duration = h('input', { class: 'input', value: gwForm.duration, placeholder: '30m, 2h, 1d, 1d12h', 'aria-label': 'Length', style: { maxWidth: '160px' } });
  const quick = h('div', { class: 'quick' });
  const drawQuick = () => {
    quick.replaceChildren(...['30m', '1h', '12h', '1d', '3d', '1w'].map(v => h('button', { type: 'button', class: gwForm.duration === v ? 'on' : '',
      onclick: () => { gwForm.duration = v; duration.value = v; drawQuick(); } }, v)));
  };
  duration.addEventListener('input', () => { gwForm.duration = duration.value; drawQuick(); });
  drawQuick();
  const winners = h('input', { class: 'input', type: 'number', min: 1, max: 50, value: gwForm.winners, 'aria-label': 'Winners', style: { maxWidth: '100px' } });
  winners.addEventListener('input', () => { gwForm.winners = winners.value; });

  const startBtn = h('button', { class: 'btn primary', onclick: async e => {
    const res = await act(e.currentTarget, () => {
      if (!post.value) throw new Error('Pick a channel for the giveaway.');
      return gapi('POST', '/giveaways', { channel_id: post.value, prize: gwForm.prize, duration: gwForm.duration, winners: Number(gwForm.winners) });
    });
    if (res) { gwForm.prize = ''; updateGiveaways(res.giveaways); }
  } }, icon('gift'), 'Start giveaway');

  const now = Date.now() / 1000;
  const all = S.data.giveaways;
  const item = gw => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, gw.prize, gw.ended ? h('span', { class: 'tag off' }, 'Ended') : h('span', { class: 'tag on live' }, 'Live')),
      h('div', { class: 'item-meta spread' },
        h('span', null, `#${gw.channel}`),
        h('span', null, gw.ended ? `Ended ${ago(gw.end)}` : `Ends in ${span(gw.end - now)}`),
        h('span', null, `${gw.entries} ${gw.entries === 1 ? 'entry' : 'entries'}`),
        h('span', null, `${gw.winners} ${gw.winners === 1 ? 'winner' : 'winners'}`)),
    ),
    h('div', { class: 'item-actions' },
      h('a', { class: 'btn small ghost', href: gw.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open'),
      !gw.ended ? h('button', { class: 'btn small', onclick: async e => {
        const b = e.currentTarget;
        if (!await confirmDialog({ title: 'End this giveaway now?', text: `Winners for “${gw.prize}” are picked right away.`, confirm: 'End and pick winners' })) return;
        const res = await act(b, () => gapi('POST', `/giveaways/${gw.id}/end`));
        if (res) updateGiveaways(res.giveaways);
      } }, 'End now') : h('button', { class: 'btn small', onclick: async e => {
        const res = await act(e.currentTarget, () => gapi('POST', `/giveaways/${gw.id}/reroll`));
        if (res) updateGiveaways(res.giveaways);
      } }, icon('refresh'), 'Reroll'),
      h('button', { class: 'btn small icon danger', 'aria-label': 'Delete giveaway', title: 'Delete', onclick: async e => {
        const b = e.currentTarget;
        if (!await confirmDialog({ title: 'Delete this giveaway?', text: 'The giveaway message is deleted from Discord and no winners are picked.', confirm: 'Delete giveaway', danger: true })) return;
        const res = await act(b, () => gapi('DELETE', `/giveaways/${gw.id}`));
        if (res) updateGiveaways(res.giveaways);
      } }, icon('trash')),
    ),
  );
  const live = all.filter(g => !g.ended), ended = all.filter(g => g.ended);

  return h('div', null,
    pageHead('Giveaways', 'Start, end and reroll giveaways. Ones started with /giveaway show up here too.'),
    h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 860px)' } },
      h('div', { class: 'stack' },
        panel('Start a giveaway', null, [
          row('Prize', null, prize),
          row('Length', null, h('div', { class: 'input-row', style: { flexWrap: 'wrap' } }, duration, quick)),
          row('Winners', null, winners),
          row('Channel', null, h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), startBtn)),
        ]),
        panel('Running', null, live.length ? h('div', { class: 'list' }, live.map(item)) : h('div', { class: 'empty' }, 'No giveaways running right now.')),
        ended.length ? panel('Ended', null, h('div', { class: 'list' }, ended.slice(0, 15).map(item))) : null,
      ),
    ),
  );
}

function updateGiveaways(list) {
  S.data.giveaways = list;
  S.data.stats.giveaways_live = list.filter(g => !g.ended).length;
  App.render();
}

/* ═════════════ Polls ═════════════ */

const pollForm = { question: '', answers: ['', ''], hours: 24, multiple: false };

function pagePolls() {
  const post = localChannel(null);
  const previewSlot = h('div');
  const drawPreview = () => {
    const answers = pollForm.answers.filter(a => a.trim());
    previewSlot.replaceChildren(h('div', { class: 'dc' }, h('div', { class: 'dc-msg' },
      h('div', { class: 'dc-avatar', style: S.data.bot.avatar ? { backgroundImage: `url("${S.data.bot.avatar}")` } : {} }),
      h('div', { style: { minWidth: '0' } },
        h('div', { class: 'dc-head' }, h('span', { class: 'dc-name' }, S.data.bot.name), h('span', { class: 'dc-app' }, 'APP')),
        h('div', { class: 'dc-box', style: { borderLeft: 'none', background: '#2b2d31' } },
          h('div', { class: 'dc-text' }, h('h3', null, pollForm.question || 'Your question')),
          h('small', { style: { color: '#949ba4' } }, pollForm.multiple ? 'Select one or more answers' : 'Select one answer'),
          (answers.length ? answers : ['Answer 1', 'Answer 2']).map(a => h('div', { style: { background: '#383a40', borderRadius: '8px', padding: '10px 12px' } }, a)),
          h('small', { style: { color: '#949ba4' } }, `0 votes · ${pollForm.hours >= 24 && pollForm.hours % 24 === 0 ? pollForm.hours / 24 + 'd' : pollForm.hours + 'h'} left`),
        ),
      ))));
  };

  const question = h('input', { class: 'input', value: pollForm.question, maxlength: 300, placeholder: 'What should we add next?', 'aria-label': 'Question' });
  question.addEventListener('input', () => { pollForm.question = question.value; drawPreview(); });

  const answersWrap = h('div', { class: 'stack', style: { gap: '8px' } });
  const drawAnswers = () => {
    answersWrap.replaceChildren();
    pollForm.answers.forEach((a, i) => {
      const input = h('input', { class: 'input', value: a, maxlength: 55, placeholder: `Answer ${i + 1}`, 'aria-label': `Answer ${i + 1}` });
      input.addEventListener('input', () => { pollForm.answers[i] = input.value; drawPreview(); });
      answersWrap.append(h('div', { class: 'answer-row' }, input,
        h('button', { type: 'button', class: 'btn icon del', disabled: pollForm.answers.length <= 2, 'aria-label': `Remove answer ${i + 1}`, title: 'Remove',
          onclick: () => { pollForm.answers.splice(i, 1); drawAnswers(); drawPreview(); } }, icon('trash'))));
    });
    if (pollForm.answers.length < 10) answersWrap.append(h('div', null, h('button', { type: 'button', class: 'btn small', onclick: () => { pollForm.answers.push(''); drawAnswers(); answersWrap.querySelectorAll('input')[pollForm.answers.length - 1]?.focus(); } }, icon('plus'), 'Add answer')));
  };
  drawAnswers();

  const hours = h('div', { class: 'quick' });
  const drawHours = () => hours.replaceChildren(...[[1, '1 hour'], [8, '8 hours'], [24, '1 day'], [72, '3 days'], [168, '1 week'], [336, '2 weeks']].map(([v, l]) =>
    h('button', { type: 'button', class: pollForm.hours === v ? 'on' : '', 'aria-pressed': String(pollForm.hours === v), onclick: () => { pollForm.hours = v; drawHours(); drawPreview(); } }, l)));
  drawHours();

  const multi = h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: pollForm.multiple, onchange: e => { pollForm.multiple = e.target.checked; drawPreview(); } }), h('span', { class: 'track' }), h('span', null, 'Let people pick more than one'));

  const postBtn = h('button', { class: 'btn primary', onclick: async e => {
    const res = await act(e.currentTarget, () => {
      if (!post.value) throw new Error('Pick a channel for the poll.');
      return gapi('POST', '/polls', { channel_id: post.value, ...pollForm });
    });
    if (res) { Object.assign(pollForm, { question: '', answers: ['', ''] }); App.render(); }
  } }, icon('send'), 'Post poll');
  drawPreview();

  return h('div', null,
    pageHead('Polls', 'Post a Discord poll. Same as /polls, with up to 10 answers.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('New poll', null, [
          row('Question', null, question),
          row('Answers', '55 characters each.', answersWrap),
          row('Open for', null, hours),
          row('Answers per person', null, multi, { inline: true }),
          row('Channel', null, h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), postBtn)),
        ]),
      ),
      h('aside', { class: 'sticky' }, h('div', { class: 'preview-title' }, 'Preview'), previewSlot),
    ),
  );
}

/* ═════════════ Commands ═════════════ */

function figsWithFeature(feature) {
  return S.data.figs.figs.filter(f => f.features.some(x => x.id === feature));
}

function pageCommands() {
  const cmds = S.data.commands;
  const ready = cmds.filter(c => featureOn(c.feature)), off = cmds.filter(c => !featureOn(c.feature));
  const opts = c => c.options.length ? h('div', { class: 'cmd-opts' }, c.options.map(o => h('span', { class: 'cmd-opt' + (o.required ? ' req' : ''), title: o.description || '' }, o.name + (o.required ? '' : '?')))) : null;

  const list = h('div', { class: 'list' }, ready.map(c => {
    const input = h('input', { type: 'checkbox', checked: !(get('disabled_commands') || []).includes(c.name), 'aria-label': `/${c.name} on` });
    input.addEventListener('change', () => {
      const offSet = new Set(get('disabled_commands') || []);
      input.checked ? offSet.delete(c.name) : offSet.add(c.name);
      set('disabled_commands', [...offSet].sort());
    });
    return h('div', { class: 'item' },
      h('div', null,
        h('div', { class: 'item-title' }, h('span', { class: 'cmd-name' }, '/' + c.name),
          c.needs.length ? h('span', { class: 'tag' }, c.needs.join(', ')) : h('span', { class: 'tag' }, 'Everyone')),
        h('div', { class: 'item-meta' }, c.description),
        opts(c),
      ),
      h('label', { class: 'switch' }, input, h('span', { class: 'track' }), h('span', { class: 'sr-only' }, 'On')),
    );
  }));

  const offList = h('div', { class: 'list' }, off.map(c => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, h('span', { class: 'cmd-name' }, '/' + c.name),
        h('span', { class: 'tag off' }, listWords(figsWithFeature(c.feature).map(f => f.name), 'or'))),
      h('div', { class: 'item-meta' }, c.description),
    ),
  )));

  return h('div', null,
    pageHead('Commands', 'Every command works three ways: here on the dashboard, as a slash command, or typed with your prefix. Turn any of them off here.'),
    h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 860px)' } },
      h('div', { class: 'stack' },
        panel('Prefix commands', 'Every command below also works by typing the prefix in front of it. Same options, same permissions.', [
          row('Prefix commands', null, toggle('prefix_enabled', 'Answer commands typed with the prefix'), { key: 'prefix_enabled', inline: true }),
          row('Prefix', 'Type help after it to see what you can use. Mentioning the bot works as a prefix too.', textInput('prefix', { max: 5, placeholder: ',' }), { key: 'prefix' }),
          prefixExamples(),
        ]),
        featureOn('fivem-tools') ? panel('/verify-female defaults', 'Used when staff leave the role or log channel empty in the command.', [
          row('Role', null, rolePick('female_role_id'), { key: 'female_role_id' }),
          row('Log channel', null, channelPick('female_log_channel_id'), { key: 'female_log_channel_id' }),
        ]) : null,
        panel('Slash commands', `${ready.length} commands. A ? after an option means it's optional. To choose who can see each slash command, use Server Settings → Integrations → ${S.data.bot.name}.`,
          cmds.length ? list : h('div', { class: 'empty' }, "The bot hasn't loaded any commands. Check the console for errors.")),
        off.length ? panel('Part of figs that are off', `These answer with a hint until you turn on the fig they belong to on the Figs page.`, offList,
          { actions: h('a', { class: 'btn small', href: here('figs') }, icon('layers'), 'Figs') }) : null,
      ),
    ),
  );
}

/** How a few slash commands look with the prefix (updates as the prefix is typed). */
function prefixExamples() {
  const slot = h('div', { class: 'prefix-examples', 'aria-label': 'Examples' });
  const draw = () => {
    const p = (get('prefix') || ',').trim() || ',';
    const ex = [['/ban user:@bob reason:spamming', `${p}ban @bob spamming`], ['/tempban user:@bob duration:3d', `${p}tempban @bob 3d`],
      ['/role add member:@bob role:VIP', `${p}role add @bob VIP`], ['/timeout member:@bob minutes:10', `${p}timeout @bob 10m`],
      ['/softban member:@bob reason:spam days:3', `${p}softban @bob spam days=3`]];
    slot.replaceChildren(...ex.map(([slash, typed]) =>
      h('div', { class: 'prefix-example' }, h('code', null, typed), h('span', null, 'is the same as'), h('code', { class: 'dim' }, slash))));
  };
  S.live.push(key => { if (!key || key === 'prefix') draw(); });  // follows the prefix as it's typed
  draw();
  return slot;
}

/* ═════════════ Dashboard access ═════════════ */

function pageAccess() {
  const me = S.session.user, you = S.data.you || {};
  const discordOn = S.session.methods.discord;
  const why = you.bot_owner ? 'You own the bot, so you can open every server.'
    : you.owner ? 'You own this server.'
      : 'You have Administrator or Manage Server here, or someone gave you access.';

  return h('div', null,
    pageHead('Dashboard access', "Who can open this server's dashboard."),
    h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 860px)' } },
      h('div', { class: 'stack' },
        !discordOn ? h('div', { class: 'note info' }, icon('alert'), h('div', null,
          "Login with Discord is off on this bot, so the people and roles below can't log in yet. ",
          me.bot_owner ? h('a', { href: '#/bot' }, 'Turn it on in Bot settings.') : "Ask the bot's owner to turn it on.")) : null,
        panel('Who else can open it', 'The server owner and anyone with Administrator or Manage Server can always open this dashboard. Add more people or roles here.', [
          row('People', 'They log in with Discord and see this server on their Servers page.', memberPick('dashboard_user_ids'), { key: 'dashboard_user_ids' }),
          row('Roles', 'Members with any of these roles can open it too.', rolePick('dashboard_role_ids', { multiple: true }), { key: 'dashboard_role_ids' }),
        ]),
        panel('You', null, h('div', { class: 'panel-body' }, h('div', { class: 'input-row' },
          me.avatar ? h('img', { src: me.avatar, alt: '', class: 'you-face' }) : null,
          h('div', null, h('b', null, me.name), h('div', { class: 'row-help' }, why)),
        ))),
      ),
    ),
  );
}

/* ═════════════ Tickets ═════════════ */

function ticketData() {
  return S.data.tickets || { tickets: [], panels: [], transcripts: [], count: 0 };
}

function openTicketCount() {
  return ticketData().tickets.filter(t => t.status === 'open').length;
}

function ticketBoardRow() {
  const panels = ticketData().panels.length, open = openTicketCount();
  return {
    page: 'tickets', icon: 'ticket', name: 'Tickets',
    where: panels ? `${panels} ${panels === 1 ? 'panel' : 'panels'}` : null,
    status: open ? `${open} open` : panels ? 'Ready' : 'No panel', kind: panels ? 'on' : 'warn',
  };
}

function updateTickets(t) {
  if (t) S.data.tickets = t;
  App.drawNav();
  App.render();
}

async function ticketAction(btn, tk, action) {
  const res = await act(btn, () => gapi('POST', `/tickets/${tk.id}/${action}`, {}));
  if (res) updateTickets(res.tickets);
}

function pageTickets() {
  const t = ticketData();
  const open = t.tickets.filter(x => x.status === 'open'), closed = t.tickets.filter(x => x.status === 'closed');

  const item = tk => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, '#' + tk.name,
        tk.status === 'open' ? h('span', { class: 'tag on' }, 'Open') : h('span', { class: 'tag off' }, 'Closed'),
        tk.claimed_by ? h('span', { class: 'tag' }, `Claimed by ${tk.claimed_by.name}`) : null),
      h('div', { class: 'item-meta spread' },
        h('span', null, tk.type), h('span', null, `Opened by ${tk.opener?.name || 'unknown'}`), h('span', null, ago(tk.created))),
      tk.answers.length ? h('details', { class: 'answers' },
        h('summary', null, `Form answers (${tk.answers.length})`),
        h('dl', null, tk.answers.map(([q, a]) => [h('dt', null, q), h('dd', null, a || 'No answer')]))) : null,
    ),
    h('div', { class: 'item-actions' },
      h('a', { class: 'btn small ghost', href: tk.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open'),
      tk.status === 'open'
        ? h('button', { class: 'btn small', onclick: e => ticketAction(e.currentTarget, tk, 'close') }, icon('lock'), 'Close')
        : h('button', { class: 'btn small', onclick: e => ticketAction(e.currentTarget, tk, 'reopen') }, icon('unlock'), 'Reopen'),
      h('button', { class: 'btn small icon', title: 'Save transcript', 'aria-label': `Save a transcript of #${tk.name}`,
        onclick: e => ticketAction(e.currentTarget, tk, 'transcript') }, icon('file')),
      h('button', { class: 'btn small icon danger', title: 'Delete', 'aria-label': `Delete #${tk.name}`, onclick: async e => {
        const b = e.currentTarget;
        if (!await confirmDialog({ title: `Delete #${tk.name}?`, text: 'A transcript is saved to the log channel first, then the channel is deleted.', confirm: 'Delete ticket', danger: true })) return;
        const res = await act(b, () => gapi('DELETE', `/tickets/${tk.id}`));
        if (res) updateTickets(res.tickets);
      } }, icon('trash')),
    ),
  );

  const transcript = tr => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, '#' + tr.channel),
      h('div', { class: 'item-meta spread' },
        h('span', null, tr.type), h('span', null, `Opened by ${tr.opener_name || 'unknown'}`),
        h('span', null, `Saved ${ago(tr.saved)}`), h('span', null, `${tr.messages} ${tr.messages === 1 ? 'message' : 'messages'}`)),
    ),
    h('div', { class: 'item-actions' },
      h('a', { class: 'btn small', href: `/transcripts/${S.gid}/${encodeURIComponent(tr.id)}`, target: '_blank', rel: 'noopener' }, icon('file'), 'View'),
    ),
  );

  return h('div', null,
    pageHead('Tickets', 'Open tickets and saved transcripts. Staff handle tickets in Discord with the buttons, or from here.'),
    h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 900px)' } },
      h('div', { class: 'stack' },
        !t.panels.length ? h('div', { class: 'note info' }, icon('alert'),
          h('div', null, "No ticket panel is posted yet, so members can't open tickets. ",
            h('a', { href: here('ticket-panels') }, 'Post one on the Ticket panels page.'))) : null,
        panel('Open tickets', open.length ? null : 'Nothing open right now.', open.length ? h('div', { class: 'list' }, open.map(item)) : null),
        closed.length ? panel('Closed tickets', 'Closed tickets stay until staff delete them. Deleting saves a transcript.', h('div', { class: 'list' }, closed.map(item))) : null,
        ticketRatings(),
        panel('Transcripts', t.transcripts.length ? 'Saved when a ticket is deleted, or with Save transcript.' : 'None yet. One is saved every time a ticket is deleted.',
          t.transcripts.length ? h('div', { class: 'list' }, t.transcripts.slice(0, 50).map(transcript)) : null),
      ),
    ),
  );
}

/* ═════════════ Ticket types ═════════════ */

const TICKET_TOKENS = [['{user}', 'Mentions the member'], ['{type}', 'Ticket type name'], ['{number}', 'Ticket number'], ['{server}', 'Server name']];
let openType = 0;

function setType(i, patch) {
  const v = copy(get('ticket_types') || []);
  Object.assign(v[i], patch);
  set('ticket_types', v);
}

function newTicketType() {
  return {
    id: '', name: 'New ticket type', emoji: '📩', description: '', category_id: null, support_role_ids: [],
    ping_support: true, name_format: 'ticket-{number}', welcome_message: 'Hey {user}, thanks for opening a ticket!', questions: [],
  };
}

function chipChoice(key, options) {
  const wrap = h('div', { class: 'quick', role: 'group' });
  const draw = () => wrap.replaceChildren(...options.map(([v, label]) => h('button', {
    type: 'button', class: get(key) === v ? 'on' : '', 'aria-pressed': String(get(key) === v),
    onclick: () => { set(key, v); draw(); },
  }, label)));
  draw();
  return wrap;
}

function ticketPreview(t, number = 1) {
  if (!t) return h('div', { class: 'empty' }, 'Add a ticket type to see its first message.');
  const fillT = text => (text || '').replaceAll('{type}', t.name || '').replaceAll('{number}', String(number).padStart(4, '0'));
  const pings = ['{user}', ...(t.ping_support ? (t.support_role_ids || []).map(r => `<@&${r}>`) : [])].join(' ');
  const blocks = [{ t: 'text', md: `## ${t.emoji ? t.emoji + ' ' : ''}${t.name || 'Ticket'} ticket` }];
  if ((t.welcome_message || '').trim()) blocks.push({ t: 'text', md: fillT(t.welcome_message) });
  const qs = (t.questions || []).filter(q => q.label.trim());
  if (qs.length) blocks.push({ t: 'sep' }, { t: 'text', md: qs.map(q => `**${q.label}**\nTheir answer shows here`).join('\n\n') });
  blocks.push({ t: 'sep' }, { t: 'buttons', items: [{ label: 'Close', emoji: '🔒', danger: true }, ...(get('ticket_claim') ? [{ label: 'Claim', emoji: '🙋' }] : [])] });
  blocks.push({ t: 'text', md: `-# Ticket ${String(number).padStart(4, '0')}` });
  return dcMessage(blocks, { plain: pings });
}

function typeEditor(t, i, redraw) {
  const input = (key, opts = {}) => {
    const el = h(opts.multi ? 'textarea' : 'input', {
      class: 'input', value: t[key] || '', placeholder: opts.placeholder || '', rows: opts.multi ? 4 : null,
      maxlength: opts.max || null, id: opts.id || null, 'aria-label': opts.label || null,
    });
    el.addEventListener('input', () => {
      setType(i, { [key]: el.value });
      if (key === 'name') summaryName.textContent = el.value || 'Untitled';
    });
    return el;
  };
  const summaryName = h('span', { class: 'tt-name' }, t.name || 'Untitled');
  const cat = t.category_id ? channelName(t.category_id) : null;
  const staff = (t.support_role_ids || []).length;

  const questions = h('div', { class: 'stack', style: { gap: '8px' } });
  const drawQuestions = () => {
    questions.replaceChildren();
    const qs = get('ticket_types')[i].questions || [];
    if (!qs.length) questions.append(h('div', { class: 'chips-empty' }, 'No questions. The ticket opens right away.'));
    qs.forEach((q, j) => {
      const label = h('input', { class: 'input', value: q.label, maxlength: 45, placeholder: 'e.g. What is your in-game name?', 'aria-label': `Question ${j + 1}` });
      label.addEventListener('input', () => { const v = copy(get('ticket_types')[i].questions); v[j].label = label.value; setType(i, { questions: v }); });
      const flag = (key, text) => h('label', { class: 'mini-check' },
        h('input', { type: 'checkbox', checked: !!q[key], onchange: e => { const v = copy(get('ticket_types')[i].questions); v[j][key] = e.target.checked; setType(i, { questions: v }); } }),
        text);
      questions.append(h('div', { class: 'q-row' }, label, flag('long', 'Long answer'), flag('required', 'Required'),
        h('button', { type: 'button', class: 'btn icon del', 'aria-label': `Remove question ${j + 1}`, title: 'Remove',
          onclick: () => { setType(i, { questions: get('ticket_types')[i].questions.filter((_, k) => k !== j) }); drawQuestions(); } }, icon('trash'))));
    });
    if (qs.length < 5) questions.append(h('div', null, h('button', { type: 'button', class: 'btn small', onclick: () => {
      setType(i, { questions: [...(get('ticket_types')[i].questions || []), { label: '', long: false, required: true }] });
      drawQuestions();
      questions.querySelectorAll('.q-row input.input')[qs.length]?.focus();
    } }, icon('plus'), 'Add question')));
  };
  drawQuestions();

  const field = (label, help, control) => h('div', { class: 'tt-field' },
    h('div', { class: 'row-label' }, label, help ? h('div', { class: 'row-help' }, help) : null), h('div', { class: 'row-control' }, control));

  const details = h('details', { class: 'tt', open: i === openType },
    h('summary', null,
      h('span', { class: 'tt-emoji' }, emojiNode(t.emoji, 'dc-emoji')),
      h('span', { class: 'tt-head' }, summaryName,
        h('span', { class: 'tt-meta' }, h('span', null, cat || 'No category'), h('span', null, `${staff} staff ${staff === 1 ? 'role' : 'roles'}`))),
      icon('chev', 'tt-chev'),
    ),
    h('div', { class: 'tt-body' },
      field('Name', 'Shown on the panel button.', input('name', { max: 80, label: 'Name' })),
      field('Emoji', null, emojiField(t.emoji, v => setType(i, { emoji: v }))),
      field('Description', 'Shown under the name in dropdown panels.', input('description', { max: 100, placeholder: 'Optional', label: 'Description' })),
      field('Category', 'Where new tickets of this type go. Leave empty for the top of the channel list.',
        picker({ items: channelItems(['category']), value: t.category_id, placeholder: 'No category', label: 'Category',
          searchPlaceholder: 'Search categories', onChange: v => setType(i, { category_id: v }) })),
      field('Staff roles', 'These roles can see and handle these tickets. Admins always can.',
        picker({ items: roleItems(), value: t.support_role_ids, multiple: true, addLabel: 'Add role', label: 'Add staff role',
          searchPlaceholder: 'Search roles', onChange: v => setType(i, { support_role_ids: v }) })),
      field('Ping staff', null, h('label', { class: 'switch' },
        h('input', { type: 'checkbox', checked: !!t.ping_support, onchange: e => setType(i, { ping_support: e.target.checked }) }),
        h('span', { class: 'track' }), h('span', null, 'Mention the staff roles when a ticket opens'))),
      field('Channel name', 'Use {number}, {user} and {type}.', input('name_format', { max: 60, label: 'Channel name' })),
      field('First message', 'Posted at the top of every new ticket.',
        [input('welcome_message', { multi: true, max: 2000, id: `f-tt-welcome-${i}`, label: 'First message' }), placeholderHelp(`tt-welcome-${i}`, TICKET_TOKENS)]),
      field('Questions', 'Asked in a form before the ticket opens. Up to 5. Answers show in the ticket.', questions),
      h('div', { class: 'tt-foot' },
        h('button', { type: 'button', class: 'btn small danger', onclick: async () => {
          if (!await confirmDialog({ title: `Remove “${t.name || 'this type'}”?`, text: 'Panels stop showing it after you save. Open tickets of this type keep working.', confirm: 'Remove', danger: true })) return;
          set('ticket_types', get('ticket_types').filter((_, k) => k !== i));
          openType = Math.max(0, Math.min(openType, get('ticket_types').length - 1));
          redraw();
        } }, icon('trash'), 'Remove ticket type'),
      ),
    ),
  );
  details.addEventListener('toggle', () => {
    if (details.open) {
      openType = i;
      document.querySelectorAll('details.tt').forEach(d => { if (d !== details) d.open = false; });
      S.live.forEach(fn => fn('ticket_types'));
    }
  });
  return details;
}

function pageTicketTypes() {
  const list = h('div', { class: 'tt-list' });
  const draw = () => {
    list.replaceChildren();
    const types = get('ticket_types') || [];
    if (!types.length) list.append(h('div', { class: 'empty', style: { borderTop: 'none' } }, 'No ticket types. Add one so members can open tickets.'));
    types.forEach((t, i) => list.append(typeEditor(t, i, draw)));
  };
  draw();
  const addBtn = h('button', { type: 'button', class: 'btn', onclick: () => {
    const types = get('ticket_types') || [];
    if (types.length >= 25) return toast('Discord shows up to 25 choices, so 25 ticket types is the limit.', { error: true });
    set('ticket_types', [...types, newTicketType()]);
    openType = types.length;
    draw();
    list.lastElementChild?.querySelector('input')?.select();
  } }, icon('plus'), 'Add ticket type');

  return h('div', null,
    pageHead('Ticket types', 'The kinds of tickets members can open, who handles them, and what gets asked first.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Settings', null, [
          row('Log channel', 'Openings, closings and transcripts are posted here. Empty uses the main log channel.',
            channelPick('ticket_log_channel_id', { placeholder: 'Main log channel' }), { key: 'ticket_log_channel_id' }),
          row('Tickets per member', 'How many open tickets one member can have at a time.',
            chipChoice('ticket_max_open', [[1, '1'], [2, '2'], [3, '3'], [5, '5'], [0, 'No limit']]), { key: 'ticket_max_open' }),
          row('Claim button', null, toggle('ticket_claim', 'Staff can claim tickets'), { key: 'ticket_claim', inline: true }),
          row('Transcript DMs', null, toggle('ticket_dm_transcript', 'DM the member a transcript when their ticket is deleted'), { key: 'ticket_dm_transcript', inline: true }),
        ]),
        panel('Ticket types', S.errors.ticket_types ? null : 'Click one to edit it.', [
          S.errors.ticket_types ? h('div', { class: 'panel-body' }, h('div', { class: 'field-error' }, S.errors.ticket_types)) : null,
          h('div', { class: 'panel-body stack' }, list, h('div', null, addBtn)),
        ]),
        ...ticketExtras(),
      ),
      livePreview('First message in a new ticket', () => ticketPreview((get('ticket_types') || [])[openType])),
    ),
  );
}

/* ═════════════ Ticket panels ═════════════ */

const tpForm = {
  editing: null,
  title: 'Open a ticket',
  description: 'Need help? Pick what it is about and a private channel opens with staff.',
  style: 'buttons',
  type_ids: null,
};

function savedTypes() {
  return S.saved.ticket_types || [];
}

function panelBlocks(p) {
  const types = (p.type_ids || []).map(id => savedTypes().find(t => t.id === id)).filter(Boolean);
  const blocks = [headerBlock([`## ${p.title || 'Open a ticket'}`, ...(p.description ? [p.description] : [])])];
  if (types.length) {
    blocks.push({ t: 'sep' });
    if (p.style === 'dropdown') blocks.push({ t: 'select', placeholder: 'Pick a ticket type' });
    else blocks.push({ t: 'buttons', items: types.map(t => ({ label: t.name, emoji: t.emoji })) });
  } else {
    blocks.push({ t: 'text', md: '-# No ticket types are picked for this panel yet.' });
  }
  return blocks;
}

function pageTicketPanels() {
  const t = ticketData();
  if (tpForm.type_ids === null) tpForm.type_ids = savedTypes().map(x => x.id);
  tpForm.type_ids = tpForm.type_ids.filter(id => savedTypes().some(x => x.id === id));
  const editing = tpForm.editing ? t.panels.find(p => p.id === tpForm.editing) : null;
  if (tpForm.editing && !editing) tpForm.editing = null;

  const previewSlot = h('div');
  const drawPreview = () => previewSlot.replaceChildren(dcMessage(panelBlocks(tpForm)));

  const title = h('input', { class: 'input', value: tpForm.title, maxlength: 200, 'aria-label': 'Panel title' });
  title.addEventListener('input', () => { tpForm.title = title.value; drawPreview(); });
  const desc = h('textarea', { class: 'input', rows: 3, value: tpForm.description, maxlength: 2000, 'aria-label': 'Panel description' });
  desc.addEventListener('input', () => { tpForm.description = desc.value; drawPreview(); });

  const style = h('div', { class: 'choices', role: 'radiogroup' }, [
    ['buttons', 'Buttons', 'One button per ticket type. Best for up to 5 types.'],
    ['dropdown', 'Dropdown', 'A menu members pick from. Good for many types.'],
  ].map(([v, label, text]) => h('label', { class: 'choice' },
    h('input', { type: 'radio', name: 'tp-style', value: v, checked: tpForm.style === v, onchange: () => { tpForm.style = v; drawPreview(); } }),
    h('b', null, label), h('span', null, text))));

  const types = picker({
    items: savedTypes().map(x => ({ id: x.id, label: x.name, lead: () => h('span', { class: 'emoji-show' }, emojiNode(x.emoji)) })),
    value: tpForm.type_ids, multiple: true, addLabel: 'Add ticket type', label: 'Add ticket type', searchPlaceholder: 'Search ticket types',
    onChange: v => { tpForm.type_ids = v; drawPreview(); },
  });

  const post = localChannel(null);
  const resetForm = () => Object.assign(tpForm, { editing: null, title: 'Open a ticket', description: 'Need help? Pick what it is about and a private channel opens with staff.', style: 'buttons', type_ids: null });
  const submit = h('button', { class: 'btn primary', onclick: async e => {
    const body = { title: tpForm.title, description: tpForm.description, style: tpForm.style, type_ids: tpForm.type_ids };
    const res = await act(e.currentTarget, () => {
      if (editing) return gapi('POST', `/tickets/panels/${editing.id}`, body);
      if (!post.value) throw new Error('Pick a channel to post the panel in.');
      return gapi('POST', '/tickets/panels', { ...body, channel_id: post.value });
    });
    if (res) { resetForm(); updateTickets(res.tickets); }
  } }, icon('send'), editing ? 'Save panel' : 'Post panel');

  const list = t.panels.length ? h('div', { class: 'list' }, t.panels.map(p => h('div', { class: 'item' },
    h('div', null,
      h('div', { class: 'item-title' }, p.title, h('span', { class: 'tag' }, p.style === 'dropdown' ? 'Dropdown' : 'Buttons'),
        editing && editing.id === p.id ? h('span', { class: 'tag on' }, 'Editing') : null),
      h('div', { class: 'item-meta' }, p.channel ? '#' + p.channel : 'Channel deleted'),
      h('div', { class: 'chips', style: { marginTop: '8px' } }, p.type_ids.map(id => {
        const tt = savedTypes().find(x => x.id === id);
        return h('span', { class: 'chip', style: { paddingRight: '10px' } }, tt ? emojiNode(tt.emoji, 'dc-emoji') : null, h('span', null, tt ? tt.name : 'Removed type'));
      })),
    ),
    h('div', { class: 'item-actions' },
      h('a', { class: 'btn small ghost', href: p.url, target: '_blank', rel: 'noopener' }, icon('external'), 'Open'),
      h('button', { class: 'btn small', onclick: () => {
        Object.assign(tpForm, { editing: p.id, title: p.title, description: p.description, style: p.style, type_ids: [...p.type_ids] });
        App.render();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } }, 'Edit'),
      h('button', { class: 'btn small icon danger', title: 'Delete', 'aria-label': `Delete panel ${p.title}`, onclick: async e => {
        const b = e.currentTarget;
        if (!await confirmDialog({ title: 'Delete this panel?', text: 'The message is deleted from Discord. Open tickets keep working.', confirm: 'Delete panel', danger: true })) return;
        const res = await act(b, () => gapi('DELETE', `/tickets/panels/${p.id}`));
        if (res) { if (tpForm.editing === p.id) resetForm(); updateTickets(res.tickets); }
      } }, icon('trash')),
    ),
  ))) : h('div', { class: 'empty' }, 'No panels yet. Post one above so members can open tickets.');

  drawPreview();
  const dirtyTypes = dirtyKeys().includes('ticket_types');

  return h('div', null,
    pageHead('Ticket panels', 'The message members click to open a ticket. Post it in a channel everyone can see.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        dirtyTypes ? note('Save your ticket type changes first. Panels use the saved ticket types.') : null,
        !savedTypes().length ? h('div', { class: 'note info' }, icon('alert'), h('div', null, 'Add a ticket type first. ', h('a', { href: here('ticket-types') }, 'Go to Ticket types.'))) : null,
        panel(editing ? 'Edit panel' : 'New panel', editing ? `Changes show up in #${editing.channel || 'the channel'} right away.` : null, [
          row('Title', null, title),
          row('Description', null, desc),
          row('Style', null, style),
          row('Ticket types', 'Shown in this order.', types),
          editing
            ? row('', null, h('div', { class: 'input-row' }, submit, h('button', { class: 'btn ghost', onclick: () => { resetForm(); App.render(); } }, 'Cancel')))
            : row('Channel', null, h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), submit)),
        ]),
        panel('Posted panels', 'Panels update by themselves when you save changes to ticket types.', list),
      ),
      h('aside', { class: 'sticky' }, h('div', { class: 'preview-title' }, 'Preview'), previewSlot),
    ),
  );
}

/* ═════════════ Figs ═════════════ */

function tabsFor(figIds) {
  const tabs = new Set(S.data.figs.core_tabs);
  for (const f of S.data.figs.figs) if (figIds.includes(f.id)) for (const x of f.features) x.tabs.forEach(t => tabs.add(t));
  return [...tabs];
}

function featuresFor(figIds) {
  const out = new Set();
  for (const f of S.data.figs.figs) if (figIds.includes(f.id)) f.features.forEach(x => out.add(x.id));
  return [...out].sort();
}

function pageName(id) {
  return PAGES.find(p => p.id === id)?.name || id;
}

/** Turn a fig on or off. Saves right away so its tabs open (or close) in the menu. */
async function setFig(f, on, input) {
  const before = (S.data.tabs || []).slice();
  const figs = on ? [...new Set([...(S.saved.figs || []), f.id])] : (S.saved.figs || []).filter(x => x !== f.id);
  input.disabled = true;
  try {
    const res = await gapi('PATCH', '/config', { changes: { figs } });
    S.saved.figs = copy(res.config.figs);
    S.draft.figs = copy(res.config.figs);
    S.data.config.figs = copy(res.config.figs);
    S.data.tabs = tabsFor(res.config.figs);
    S.data.features = featuresFor(res.config.figs);
    const opened = S.data.tabs.filter(t => !before.includes(t));
    const hidden = before.filter(t => !S.data.tabs.includes(t));
    const named = tabs => tabs.length > 4 ? `${tabs.length} tabs, like ${listWords(tabs.slice(0, 3).map(pageName))}` : listWords(tabs.map(pageName));
    if (on) toast(opened.length ? `${f.name} is on. Opened ${named(opened)}.` : `${f.name} is on. Its tabs were already open.`);
    else toast(hidden.length ? `${f.name} is off. Hid ${named(hidden)}.` : `${f.name} is off. Its tabs stay because another fig uses them.`);
    App.drawNav(opened);
    App.render();
  } catch (e) {
    input.checked = !on;
    input.disabled = false;
    toast(e.message, { error: true });
  }
}

function figCard(f) {
  const on = (S.saved.figs || []).includes(f.id);
  const input = h('input', { type: 'checkbox', checked: on, onchange: e => setFig(f, e.target.checked, e.target) });
  const tabs = [...new Set(f.features.flatMap(x => x.tabs))];
  return h('div', { class: 'fig-card' + (on ? ' on' : ''), onclick: e => { if (!e.target.closest('.switch, a')) input.click(); } },
    h('div', { class: 'fig-top' },
      flapWord(figCode(f), figCode(f).length, 0, { animate: false, kind: 'mini' }),
      h('label', { class: 'switch' }, input, h('span', { class: 'track' }), h('span', { class: 'sr-only' }, `${f.name} on`)),
    ),
    h('h3', null, f.name),
    h('p', null, f.blurb),
    h('div', { class: 'fig-tabs' }, h('span', { class: 'fig-tabs-label' }, on ? 'Tabs it opened' : 'Opens'),
      h('div', { class: 'chips' }, tabs.map(t => h('span', { class: 'chip' }, h('span', null, pageName(t)))))),
  );
}

function figCards(only = null) {
  const figs = S.data.figs.figs.filter(f => !only || only.includes(f.id));
  return h('div', { class: 'fig-grid' }, figs.map(figCard));
}

function pageFigs() {
  const on = (S.saved.figs || []).length;
  return h('div', null,
    pageHead('Figs', 'Pick what kind of server this is. Each fig turns on its features and opens their tabs in the menu. Mix as many as you like.'),
    figCards(),
    h('p', { class: 'fine' }, on
      ? 'Turning a fig off hides its tabs and pauses its features in this server. Their settings are kept for when you turn it back on.'
      : 'Nothing is on yet, so only the basic tabs show in the menu.'),
  );
}

/** A tab whose fig is off: say which fig it belongs to, with a switch to turn it on. */
function pageLocked(page) {
  const figs = S.data.figs.figs.filter(f => f.features.some(x => x.tabs.includes(page.id)));
  return h('div', null,
    pageHead(page.name, figs.length
      ? `This tab comes with ${listWords(figs.map(f => f.name), 'or')}. Turn ${figs.length === 1 ? 'it' : 'one'} on to use it.`
      : "This tab isn't available."),
    figs.length ? figCards(figs.map(f => f.id)) : null,
  );
}

/* ═════════════ Roblox verification ═════════════ */

function robloxInfo() {
  return S.data.roblox || { linked: 0, recent: [], nicknames: {} };
}

function robloxBoardRow() {
  const c = S.saved, rb = robloxInfo();
  const role = c.roblox_verified_role_id ? G.role(c.roblox_verified_role_id) : null;
  return {
    page: 'roblox', icon: 'idcard', name: 'Roblox verify', where: role ? '@' + role.name : null,
    status: !c.roblox_verified_role_id ? 'Not set' : rb.linked ? `${rb.linked} linked` : 'Ready',
    kind: c.roblox_verified_role_id ? 'on' : 'warn',
  };
}

const NICK_CHOICES = [
  { value: '{display}', label: 'Roblox display name', text: 'Like Builderman' },
  { value: '{roblox}', label: 'Roblox username', text: 'Like builderman_42' },
  { value: '{display} (@{roblox})', label: 'Both', text: 'Like Builderman (@builderman_42)' },
  { value: '', label: "Don't change nicknames", text: 'Members keep the name they have.' },
];

function robloxPanelBlocks() {
  return [
    { t: 'text', md: `## ${get('roblox_panel_title') || 'Verify with Roblox'}` },
    { t: 'text', md: get('roblox_panel_text') || 'Link your Roblox account to get access.' },
    { t: 'sep' },
    { t: 'buttons', items: [{ label: 'Verify with Roblox', emoji: '✅', success: true }] },
  ];
}

function updateEveryoneButton(rb) {
  return h('button', { class: 'btn small', disabled: !rb.linked, title: rb.linked ? null : 'Nobody has linked an account yet',
    onclick: e => act(e.currentTarget, () => gapi('POST', '/roblox/update-all', {})) }, icon('refresh'), "Update everyone's roles");
}

function pageRoblox() {
  const rb = robloxInfo();
  const perms = S.data.guild.bot_perms;
  const post = localChannel(null);
  const postBtn = h('button', { class: 'btn primary', onclick: e => act(e.currentTarget, () => {
    if (!post.value) throw new Error('Pick a channel to post the panel in.');
    return gapi('POST', '/roblox/panel', { channel_id: post.value });
  }) }, icon('send'), 'Post panel');

  const nickNote = h('div');
  const drawNick = () => nickNote.replaceChildren(get('roblox_nickname') && !perms.administrator && !perms.manage_nicknames
    ? note('I need the Manage Nicknames permission to change nicknames.') : '');
  S.live.push(k => { if (k === 'roblox_nickname') drawNick(); });
  drawNick();

  const linked = rb.recent.length ? h('div', { class: 'list' }, rb.recent.map(m => h('div', { class: 'item' },
    h('div', { class: 'linked' },
      m.avatar ? h('img', { src: m.avatar, alt: '' }) : h('span', { class: 'avatar-blank' }),
      h('div', null,
        h('div', { class: 'item-title' }, m.name),
        h('div', { class: 'item-meta spread' }, h('span', null, `Roblox: ${m.roblox}`), m.at ? h('span', null, `Verified ${ago(m.at)}`) : null)),
    ),
    h('div', { class: 'item-actions' },
      h('a', { class: 'btn small ghost', href: `https://www.roblox.com/users/${m.roblox_id}/profile`, target: '_blank', rel: 'noopener' }, icon('external'), 'Profile')),
  ))) : h('div', { class: 'empty' }, 'Nobody has verified yet. Post the verify panel so members can start.');

  return h('div', null,
    pageHead('Roblox verification', 'Members prove they own a Roblox account by putting a few words in their Roblox profile. Then they get the verified role and a nickname. They can also start with /verify.'),
    h('div', { class: 'layout' },
      h('div', { class: 'stack' },
        panel('Roles', null, [
          row('Verified role', 'Given once someone links their account.', [rolePick('roblox_verified_role_id'), roleWarning('roblox_verified_role_id', 'give it out')], { key: 'roblox_verified_role_id' }),
          row('Unverified role', 'Taken away once someone links their account. Optional.', [rolePick('roblox_unverified_role_id'), roleWarning('roblox_unverified_role_id', 'take it away')], { key: 'roblox_unverified_role_id' }),
        ]),
        robloxScreening(),
        panel('Nicknames', "Set when someone verifies, and again with /roblox-update. Discord doesn't let bots rename the server owner.",
          h('div', { class: 'panel-body stack', style: { gap: '10px' } }, choiceCards('roblox_nickname', NICK_CHOICES), nickNote)),
        panel('More', null, [
          row('Auto-verify', null, toggle('roblox_auto_verify', 'Give roles right away when someone who already linked joins'), { key: 'roblox_auto_verify', inline: true }),
          row('Log channel', 'Each verification is logged here. Empty uses the main log channel.',
            channelPick('roblox_log_channel_id', { placeholder: 'Main log channel' }), { key: 'roblox_log_channel_id' }),
        ]),
        panel('Verify panel', 'The message members click to start. Supports Discord formatting like **bold**.', [
          row('Title', null, textInput('roblox_panel_title', { max: 200 }), { key: 'roblox_panel_title' }),
          row('Text', null, textInput('roblox_panel_text', { multiline: true, rows: 3, max: 1000 }), { key: 'roblox_panel_text' }),
          row('Post the panel', 'Sends a fresh copy. Its button keeps working after the bot restarts.', [
            savedFirstNote(['roblox_panel_title', 'roblox_panel_text', 'accent_color']),
            h('div', { class: 'input-row' }, h('div', { style: { flex: '1', minWidth: '0' } }, post.el), postBtn),
          ]),
        ]),
        panel('Linked members', rb.linked
          ? `${rb.linked.toLocaleString()} ${rb.linked === 1 ? 'member has' : 'members have'} linked a Roblox account. Newest first.`
          : null, linked, { actions: updateEveryoneButton(rb) }),
      ),
      livePreview('Verify panel preview', () => dcMessage(robloxPanelBlocks())),
    ),
  );
}

/* ═════════════ Roblox group ranks ═════════════ */

const rank = { id: null, group: null, loading: false, error: null };

async function lookUpGroup(id) {
  id = String(id || '').trim();
  if (!id) return;
  Object.assign(rank, { id, loading: true, error: null });
  if (S.page === 'roblox-ranks') App.render();
  try {
    rank.group = (await gapi('GET', '/roblox/group?id=' + encodeURIComponent(id))).group;
  } catch (e) {
    rank.group = null;
    rank.error = e.message;
  }
  rank.loading = false;
  if (S.page === 'roblox-ranks') App.render();
}

function rolesForRank(n) {
  return (get('roblox_rank_roles') || []).filter(b => b.rank === n).map(b => b.role_id);
}

function setRankRoles(n, ids) {
  const rest = (get('roblox_rank_roles') || []).filter(b => b.rank !== n);
  set('roblox_rank_roles', [...rest, ...ids.map(id => ({ rank: n, role_id: id }))].sort((a, b) => b.rank - a.rank));
}

function rankRow(n, name, sub) {
  const pick = picker({
    items: roleItems(), value: rolesForRank(n), multiple: true, addLabel: 'Add role', label: `Roles for ${name}`,
    searchPlaceholder: 'Search roles', onChange: v => setRankRoles(n, v),
  });
  return h('div', { class: 'rank-row' },
    h('span', { class: 'rank-num', title: `Rank ${n}` }, n),
    h('div', { class: 'rank-name' }, h('b', null, name), sub ? h('div', { class: 'row-help' }, sub) : null),
    pick,
  );
}

function pageRobloxRanks() {
  const saved = S.saved.roblox_group_id;
  if (saved && rank.id !== saved && !rank.loading) setTimeout(() => lookUpGroup(saved), 0);

  const idInput = textInput('roblox_group_id', { placeholder: 'Like 1234567' });
  idInput.setAttribute('inputmode', 'numeric');
  idInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); lookUpGroup(get('roblox_group_id')); } });
  const lookBtn = h('button', { class: 'btn' + (rank.loading ? ' busy' : ''), onclick: () => lookUpGroup(get('roblox_group_id')) }, icon('search'), 'Look up');

  const g = rank.group && rank.group.id === String(get('roblox_group_id') || '').trim() ? rank.group : null;
  const found = g ? h('div', { class: 'group-found' },
    h('div', null, h('b', null, g.name), h('div', { class: 'row-help' }, `${g.members.toLocaleString()} members, ${g.roles.length} ranks`)),
    h('a', { class: 'btn small ghost', href: `https://www.roblox.com/groups/${g.id}`, target: '_blank', rel: 'noopener' }, icon('external'), 'Open group'),
  ) : rank.error && rank.id === String(get('roblox_group_id') || '').trim() ? h('div', { class: 'field-error' }, rank.error) : null;

  // One row per rank in the group, highest first. Binds for ranks the group doesn't have anymore are listed too.
  const binds = get('roblox_rank_roles') || [];
  let ranks;
  if (g) {
    const known = new Set(g.roles.map(r => r.rank));
    ranks = [
      ...[...g.roles].sort((a, b) => b.rank - a.rank).map(r => rankRow(r.rank, r.name, `${r.members.toLocaleString()} in the group`)),
      ...[...new Set(binds.filter(b => !known.has(b.rank)).map(b => b.rank))].map(n => rankRow(n, `Rank ${n}`, "The group doesn't have this rank anymore")),
    ];
  } else {
    ranks = [...new Set(binds.map(b => b.rank))].sort((a, b) => b - a).map(n => rankRow(n, `Rank ${n}`, null));
  }

  return h('div', null,
    pageHead('Role binds', "Give Discord roles from members' Roblox group rank, the badges they own and the game passes they bought. Roles update when someone verifies or runs /roblox-update."),
    h('div', { class: 'layout', style: { gridTemplateColumns: 'minmax(0, 900px)' } },
      h('div', { class: 'stack' },
        !featureOn('roblox-verify') ? note('Ranks come from linked Roblox accounts, so turn on Roblox verification too.') : null,
        panel('Group', null, [
          row('Group ID', "The number in your group's link: roblox.com/groups/1234567.", [h('div', { class: 'input-row' }, idInput, lookBtn), found], { key: 'roblox_group_id' }),
          row('Group member role', 'Given to everyone in the group, whatever their rank. Optional.', rolePick('roblox_group_member_role_id'), { key: 'roblox_group_member_role_id' }),
        ]),
        panel('Rank roles', g ? 'Pick the roles each rank gets. Members lose them when their rank changes.' : 'Look up your group to pick roles for each of its ranks.', [
          S.errors.roblox_rank_roles ? h('div', { class: 'panel-body' }, h('div', { class: 'field-error' }, S.errors.roblox_rank_roles)) : null,
          ranks.length ? h('div', { class: 'rank-rows' }, ranks) : (g ? null : h('div', { class: 'empty' }, rank.loading ? 'Looking up the group…' : 'No rank roles yet.')),
        ], { actions: updateEveryoneButton(robloxInfo()) }),
        ...robloxBinds(),
      ),
    ),
  );
}
