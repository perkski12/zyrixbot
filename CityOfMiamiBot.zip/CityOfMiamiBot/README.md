# City Of Miami Bot

A Discord bot with a public website. Anyone can add the bot to their server, log in with Discord and set it up from a dashboard. Each server picks **figs** (FiveM Server, Roblox Server, Community Server, Support Server, or any mix), and the dashboard opens the tabs that kind of server needs.

Every slash command still works. The dashboard and the commands change the same settings, so a change in one shows up in the other right away. Each server has its own settings.

## Start it

1. Install Python 3.10 or newer: https://www.python.org/downloads/
2. Open a terminal in this folder and run:
   ```
   pip install -r requirements.txt
   ```
3. Start the bot:
   ```
   python main.py
   ```
4. The first time, the bot's window asks for two things. Paste each one and press Enter (what you paste stays hidden):
   - **Bot token:** at https://discord.com/developers/applications pick your bot, go to **Bot** and click **Reset Token**. On that same page, turn on **Server Members Intent** and **Message Content Intent** (the bot needs both).
   - **Client Secret:** same app, **OAuth2** page, copy the **Client Secret** (click **Reset Secret** if it's hidden). The website uses it to log people in with Discord.

   - **Netlify token (optional):** puts the website online at a free `yourname.netlify.app` address, see **Put the website online**. Press Enter to skip.

   They're saved in the `.env` file, so after the first time the bot starts by itself. The bot token is never typed into the website.
5. The window then lists one or more **redirects**, like `http://localhost:8080/callback`. On the same **OAuth2** page, under **Redirects**, add each one and click **Save Changes**.
6. Open the website:
   - **Bot on your PC:** it opens in your browser by itself, at **http://localhost:8080**.
   - **Bot on a VPS (Linux or Windows):** the console prints the link to open on your PC, like **http://203.0.113.5:8080**. `localhost` only means "this computer", so on your PC type that link, not localhost. (http://localhost:8080 works on the VPS itself.) Or double-click **Open Dashboard.bat** on your PC: it opens the right link for you.
7. Click **Servers**, log in with Discord, and pick a server.

Running the bot somewhere you can't type in its window (a background service)? Put the token and the client secret in `.env` yourself as `DISCORD_TOKEN=` and `DISCORD_CLIENT_SECRET=`.

**The link doesn't load on your PC?**
- **Firewall.** The VPS firewall is blocking the port.
  - **Linux VPS:** run `sudo ufw allow 8080/tcp`.
  - **Windows VPS:** click **Allow** when Windows asks about the firewall, or run the `netsh` command the console prints in an admin Command Prompt.
  - Some hosts also have a firewall in their control panel: allow port 8080 there too.
- **Two copies running.** Close every old bot window first. If port 8080 is taken, the console says so and uses the next port (8081...), so check the link it prints.
- **Old page after an update.** Press **Ctrl+F5** on the dashboard to reload it.

**localhost:8080 shows a plain list of links like "Inspectable WebContents", "Friends List", "Steam"?** That's Steam, not the bot: Steam's web debugger uses port 8080 on your PC. The bot notices and moves to the next free port (8081...), saves it in `.env` as `DASHBOARD_PORT`, and prints the link to open. Add that port's redirect too, like `http://localhost:8081/callback`. Bot on a VPS? `localhost` on your PC is your PC, so open the VPS link the console prints, or use **Open Dashboard.bat** (it also steers around Steam).

**"Invalid OAuth2 redirect_uri"?** The address you opened the website with isn't under **Redirects** yet. The website checks this before sending you to Discord: if it's missing, it shows the exact redirect to add, with a Copy button and a link to your bot's OAuth2 page, and the console lists the missing ones once the bot is online. Add it, click **Save Changes** in the Developer Portal, then **Log in with Discord**. It has to match exactly, port included (`http://localhost:8081/callback` isn't `http://localhost:8080/callback`).

## The website

| Page | Who sees it | What's on it |
| --- | --- | --- |
| Home | Everyone | What the bot does, the figs, **Add to Discord** and **Servers** |
| Servers | Logged in | Servers you can manage, servers you can add the bot to, and ones you need access for |
| A server's dashboard | People with access to that server | Figs, and the tabs of the figs that are on |
| Bot settings | Only you (the bot's owner) | The client secret, the website address and the redirect to add in Discord |

### Who can open a server's dashboard

- The server owner, and anyone with **Administrator** or **Manage Server** there.
- People or roles the owner adds on that server's **Dashboard access** page.
- You, the bot's owner: the owner (or team) of the bot in the Developer Portal, and anyone listed in `BOT_OWNER_IDS` in `.env`. Log in with Discord like everyone else; bot owners see every server the bot is in, and **Bot settings**.

### Logging in

Everyone logs in the same way: click **Servers** (top right, the home page, or the bottom of the page) and log in with Discord. You stay logged in on that browser for 7 days. Opened a server's link while logged out? After logging in you land back on that server.

If you reset the bot token in the Developer Portal, the bot's window asks for the new one when Discord stops accepting the old one. (Or put it in `.env` as `DISCORD_TOKEN=` and restart.)

### Bot profile: the bot's name, picture and banner in one server

On a server's **Bot profile** page (under Server), the **server owner** can give the bot its own name, profile picture and banner in that server. Other servers keep the bot's normal ones. A preview shows how members will see it before you save.

- Only the server owner can save. Everyone else with access, bot owners included, can look but not change it.
- Pictures: PNG, JPG, GIF or WebP, up to 10 MB. GIFs move. **Use the normal picture** (or banner) puts back the bot's usual one. An empty name uses the bot's normal name.
- Discord only lets bots change their profile a few times in a while. If you save too often, the page says so: wait a few minutes and try again.
- For the name, the bot's role needs **Change Nickname** (bots get it by default).

## Login with Discord: redirects and the client secret

Discord sends people back to the address they opened the website with, so each address needs its own redirect under **OAuth2 → Redirects** in the Developer Portal:

| You open the website at | Add this redirect |
| --- | --- |
| http://localhost:8080 (on the computer running the bot) | `http://localhost:8080/callback` |
| http://YOUR-VPS-IP:8080 (your PC, bot on a VPS) | `http://YOUR-VPS-IP:8080/callback` |
| https://dash.example.com (a domain, see below) | `https://dash.example.com/callback` |

The console prints the ones you need every time the bot starts. Once you're logged in, **Bot settings** (top right, bot owner only) shows the redirect for the address you're on, and lets you change the client secret or set a fixed website address (`DASHBOARD_URL`, only needed for a domain or HTTPS proxy). No restart needed. The same settings live in `.env` as `DISCORD_CLIENT_SECRET` and `DASHBOARD_URL`.

## Figs

A fig is a server type. Turn them on on the **Figs** page of each server's dashboard. Each fig turns on its features and opens their tabs in the menu. Any mix works: features two figs share show up once, and turning a fig off hides its tabs but keeps their settings.

| Fig | What it turns on |
| --- | --- |
| FiveM Server | Whitelist, priority roles, sneak peeks, `/verify-female`, welcome, tickets, applications, announcements, giveaways, polls, reaction roles |
| Roblox Server | Roblox verification, role binds (group ranks, badges, game passes), game stats and group shouts, sessions, leveling, suggestions, applications, tickets, auto-responses, announcements, voice channels, channel tools, welcome, giveaways, polls, reaction roles |
| Community Server | Leveling, suggestions, starboard, birthdays, reaction roles, giveaways, polls, react channels, auto-responses, announcements, voice channels, channel tools, applications, FAQ, tickets, welcome |
| Support Server | Tickets (with ratings, auto-close, saved replies, support hours, DM to open), FAQ, status page, reviews, applications, suggestions, auto-responses, announcements, channel tools, welcome, reaction roles, polls |

Every fig also gets **auto-mod, moderation, server logs, the word filter, the honeypot and the utility commands**.

Slash commands of a fig that's off answer with "comes with the … fig, turn it on in the dashboard", and their features don't run in that server.

City Of Miami keeps everything it had: when you update, its old `config.json` moves over to it automatically, with **FiveM Server** and **Community Server** turned on.

## Three ways to use every command

Every command works on the website, as a slash command, or typed with a prefix (`,` unless you change it on the **Commands** page):

| Slash command | With the prefix |
| --- | --- |
| `/ban user:@bob reason:spamming` | `,ban @bob spamming` |
| `/tempban user:@bob duration:3d` | `,tempban @bob 3d` |
| `/role add member:@bob role:VIP` | `,role add @bob VIP` |
| `/timeout member:@bob minutes:10` | `,timeout @bob 10m` (or `,mute @bob 10m`) |
| `/softban member:@bob reason:spam days:3` | `,softban @bob spam days=3` |

- The last text option takes the rest of the line (the reason, the message). Options that come after it go as `name=value`, like `days=3` or `channel=#announcements`.
- Members, roles and channels can be mentioned, pasted as an ID or typed by name (`,role add @bob Server Booster`).
- `,help` lists what you can use in that server, and `,help ban` shows how a command is written. Mentioning the bot works as a prefix too (`@zyrix help`).
- Short versions: `,mute`, `,unmute`, `,clear`, `,warns`, `,ui`, `,av`, `,remind`, `,reminders`, `,tb`.
- Prefix commands run the same code as the slash commands, with the same permissions, figs and on/off switches. Answers are visible to everyone in the channel, and commands that open a form (like `/announce`) only work as slash commands. Who can use a prefix command is decided by the member's server permissions (Discord's per-command settings under Server Settings → Integrations only apply to slash commands).

## Every feature

**Moderation (every fig)**
- **Auto-mod**: deletes spam, invites to other servers, links (except sites you allow), mass mentions and all caps. Can also time people out and give a warning. Staff are never caught.
- **Moderation**: `/warn`, `/warnings`, `/delwarn`, `/clearwarns`, `/timeout`, `/untimeout`, `/kick`, `/ban` (works on people who aren't in the server too), `/tempban` (unbans by itself), `/softban` (wipes their recent messages, they can rejoin), `/unban`, `/nick`, `/modlogs` (everything on someone's record), `/case view` and `/case reason`. Every action is a numbered case on the dashboard, where you can also end a temporary ban early. Pick how many warnings lead to a timeout, kick or ban.
- **Channels**: `/purge` (only a member's, only bots', or only messages with a word in them), `/slowmode`, `/lock`, `/unlock`, `/hide`, `/unhide`, `/lockdown start` and `/lockdown end` (every channel at once, and back exactly how it was), `/nuke` (a fresh copy of the channel, asks first).
- **Voice**: `/voice kick`, `/voice move`, `/voice mute`, `/voice unmute`.
- **Roles**: `/role add`, `/role remove`, `/role temp` (comes off by itself), `/role info`, `/role members`, `/roleall` (give or take a role for everyone), and `/autorole add`, `/autorole remove`, `/autorole list` for the roles people get when they join (the same as the join roles on the Welcome page).
- **Utility**: `/userinfo`, `/serverinfo`, `/avatar`, `/banner`, `/membercount`, `/ping`, `/botinfo`, `/reminder set`, `/reminder list`, `/reminder cancel`, `/afk` (tells people you're away when they mention you), and for staff `/say`, `/snipe` (the last deleted or edited message in a channel, kept 10 minutes, never saved) and `/steal` (add an emoji from another server). AFK and snipe can be turned off on the Utility page.
- **Server logs**: deleted and edited messages, joins, leaves, role and nickname changes, bans, voice and channels. Pick what's logged.
- **Welcome**: welcome message, join roles (separate ones for bots), a welcome DM and goodbye messages.

**Community**
- **Leveling**: XP for chatting, level-up messages, roles at the levels you pick, `/rank`, `/leaderboard`, `/xp-give`, `/xp-reset`, and a leaderboard on the dashboard.
- **Suggestions**: `/suggest` or a panel button, 👍/👎 vote buttons, staff approve, deny or "considering" with a reason (in Discord or on the dashboard), and the author gets a DM.
- **Starboard**: messages with enough ⭐ (or your emoji) get reposted in a starboard channel.
- **Birthdays**: `/birthday-set`, `/birthday-remove`, `/birthdays`; a wish and a birthday role on the day.
- **Auto-responses**: the bot answers messages that match a trigger, like "server ip".
- **Announcements**: post as the bot from the dashboard or `/announce`, plus timed messages that repeat every few hours.
- **Voice channels**: join the "join to create" channel to get your own voice channel, deleted when everyone leaves. `/vc-limit`, `/vc-rename`, `/vc-lock`, `/vc-unlock`.
- **Channel tools**: sticky messages, stat channels (like "Members: 1,204") and a counting game.

**Roblox**
- **Verification**: members put a few words in their Roblox profile to prove it's theirs, then get the verified role and a nickname. You can require a minimum account age, block Roblox groups (like rival groups), and re-check everyone automatically every few hours. `/verify`, `/roblox-update`, `/roblox-unlink`, `/roblox-whois`, `/roblox-profile`.
- **Role binds**: roles from group rank, from badges members own and from game passes they bought.
- **Game & group**: `/game` and a live stats message (players, visits, favorites, group members) updated every 5 minutes; new group shouts posted in a channel.
- **Sessions**: hosts announce trainings, shifts and events with `/session-start` (ping + "Join the game" button) and `/session-end`, or from the dashboard.

**Support**
- **Tickets**: like Ticket Tool (see below), plus auto-close for quiet tickets, 1-5 star ratings after closing (averages per staff member on the dashboard), saved replies with `/snippet`, support hours with a "we're away" note, and opening a ticket by DMing the bot.
- **Applications**: forms with up to 5 questions, a panel with a button per application (or `/apply`), answers in a review channel with Accept / Deny, a role when accepted, and a DM either way.
- **FAQ**: a panel with a dropdown of questions; the answer shows only to whoever picked it. `/faq` answers in the channel.
- **Status page**: a message showing which parts of your service work, updated from the dashboard or `/status-set`. `/status` shows it to anyone.
- **Reviews**: `/review` with 1-5 stars, posted in a reviews channel, with the average on the dashboard.

## Roblox setup

1. Pick the **Verified role** (and an **Unverified role** to take away, if you use one) and how nicknames should look on the **Verification** page. Save.
2. Post the **verify panel** in a channel everyone can see.
3. Members click **Verify with Roblox**, type their Roblox username, put the words the bot gives them in their Roblox profile's **About**, and press **Done**.

A Roblox account linked in one server works in every server with the bot. On **Role binds**, type your group ID (the number in your group's link), click **Look up**, and pick roles for each rank; add badge and game pass roles below it. On **Game & group**, add your game's place ID (the number in the game's link).

The bot needs **Manage Roles**, and **Manage Nicknames** for nicknames. Its role has to be above the roles it gives out. Game pass roles only work for members whose Roblox inventory is public.

## Tickets

Works like Ticket Tool. Members click a panel, a private channel opens that only they and your staff can see, and a transcript is saved when it's deleted.

1. **Ticket types** page: edit the ready-made "Support" type or add more (like "Report a player" or "Staff application"). For each one, pick the category tickets go in and the staff roles that handle them. You can add up to 5 questions that members answer before the ticket opens. The extras (auto-close, ratings, support hours, saved replies) are on the same page. Save.
2. **Ticket panels** page: write a title, pick the ticket types, pick a channel everyone can see, and click **Post panel**.

In a ticket, **Close** hides the channel from the member, **Claim** lets the member know who's helping, and **Delete** saves an HTML transcript to the log channel and DMs it to the member. Staff commands: `/ticket-add`, `/ticket-remove`, `/ticket-close`, `/ticket-claim`, `/ticket-rename`, `/snippet`. The **Tickets** page lists open and closed tickets, ratings and every saved transcript.

## Put the website online

Login with Discord works from anywhere once the website is reachable. The best setup is an HTTPS address in front of the dashboard:

**With a domain and Caddy** (on the VPS, Caddy gets the HTTPS certificate by itself):
1. Point your domain (like `dash.example.com`) at the VPS IP.
2. Install Caddy and put this in its Caddyfile:
   ```
   dash.example.com {
       reverse_proxy 127.0.0.1:8080
   }
   ```
3. In `.env`, set `DASHBOARD_BEHIND_PROXY=true` (the website then only listens to Caddy).
4. In `.env`, set `DASHBOARD_URL=https://dash.example.com` (or set it on **Bot settings** later).
5. Under **Redirects** in the Developer Portal, add `https://dash.example.com/callback`, then start the bot.

A **Cloudflare Tunnel** works the same way: point it at `http://127.0.0.1:8080` and set `DASHBOARD_BEHIND_PROXY=true`.

**On Netlify (a free `yourname.netlify.app` address with HTTPS), with the bot on your PC.** Nothing to install and nothing to drag around. The website's files (the `Website` folder) live on Netlify, so the address stays up even while your PC is off (it shows the bot as offline). Every time the bot starts, it connects your PC to that address by itself.

1. Make a free account at https://app.netlify.com, then a token for the bot: open https://app.netlify.com/user/applications#personal-access-tokens, click **New access token**, type any description, pick when it expires, click **Generate token** and copy it.
2. Start the bot. The first time, its window asks for the token (paste it, it stays hidden), then a site name. Type a new name like `zyrix-bot` for `zyrix-bot.netlify.app`, or the name of a site you already have on Netlify (an old one from dragging the Netlify folder works too). Both are saved in `.env` as `NETLIFY_TOKEN` and `NETLIFY_SITE`.
3. In the Developer Portal, under **OAuth2 → Redirects**, add `https://zyrix-bot.netlify.app/callback` (your name) and save. The bot's window lists it too.
4. Open `https://zyrix-bot.netlify.app` and click **Servers**. Use that address from now on: logging in from `localhost` sends you there anyway.

What the bot does each time it starts: it gets a free temporary tunnel from Cloudflare (Cloudflare's small `cloudflared` program, which the bot downloads into the `tools` folder the first time and checks against the fingerprint GitHub lists for it), then uploads the `Website` folder to your Netlify site with rules that send logins and the dashboard's data through the tunnel to your PC. The `[Website]` lines in its window say how it's going. **The website is live and connected to this PC** means everything works.

Good to know:
- The dashboard and logging in need the PC on and awake (Settings, System, Power: set sleep to Never). The home page works either way.
- Cloudflare's free quick tunnels are meant for testing and come with no uptime promise. If the tunnel drops, the bot opens a new one and uploads again by itself (Netlify takes 3 uploads a minute and 100 a day, plenty for this).
- Skipped the question? Remove the `NETLIFY_SITE=off` line from `.env` and restart the bot. Set `NETLIFY_SITE=off` to stop using Netlify.
- **"Netlify didn't accept the access token"**: it expired or was deleted. Remove the `NETLIFY_TOKEN` line from `.env` and restart: the bot asks for a new one.
- **"Uploaded, but ... can't reach this PC yet"**: Cloudflare's tunnel sometimes needs a few minutes. If it stays like that, restart the bot. Some school or work networks block Cloudflare tunnels.
- Don't set `DASHBOARD_URL` or `DASHBOARD_BEHIND_PROXY` for this: the bot uses the Netlify address by itself while it runs.

The same works with the bot on a VPS, though a domain with Caddy (above) is sturdier there.

**Without a domain:** nothing to set up. On a VPS the bot already opens the website to your PC at `http://YOUR-VPS-IP:8080` (see **Start it**). That link isn't encrypted, so logins travel as plain text: fine for getting started, but use a domain with HTTPS for a website other people use.

On game-server style hosts (Pterodactyl panels and similar) it works the same way; the port your host gives you is picked up automatically.

### Who can open the website (`DASHBOARD_HOST` in `.env`)

| Setting | What it does |
| --- | --- |
| `auto` (default) | http://localhost:8080 works on the machine running the bot, and other computers can reach it at that machine's IP (your PC → http://YOUR-VPS-IP:8080). Behind a proxy: only the proxy. |
| `127.0.0.1` | Only the machine the bot runs on. Reach a VPS from your PC with the Open Dashboard file (Linux VPS). |

### One click from your PC: the Open Dashboard file

1. Copy **Open Dashboard.bat** to your Windows PC and double-click it.
2. The first time, type your VPS's IP address, like `123.45.67.89`.
3. It opens the dashboard in your browser. It tries the direct link first. If the VPS doesn't answer there (firewall closed, or `DASHBOARD_HOST=127.0.0.1`), it makes a private, encrypted SSH connection instead and opens **http://localhost:8080**. That needs a Linux VPS, and it asks for your VPS username and password.

On a Mac or Linux PC, run `ssh -N -L 8080:127.0.0.1:8080 root@YOUR-VPS-IP` and open http://localhost:8080. Set `DASHBOARD_HOST=127.0.0.1` if you want this to be the only way in.

### Keep the bot running after you close SSH

```
screen -S bot
python3 main.py
```
Press **Ctrl+A** then **D** to leave it running. `screen -r bot` brings it back.

## Updating from the last version

**Coming from the version with the token popup:** the website doesn't take the bot token anymore, everyone logs in with Discord. Your token is already in `.env`, so the bot starts as usual. If you never added a client secret, the window asks for it the first time; then add the redirects it prints (see **Login with Discord** above), open the website, click **Servers** and log in with Discord. The account that owns the bot in the Developer Portal is recognized as the bot owner by itself. Use a different Discord account? Put its user ID in `BOT_OWNER_IDS` in `.env`.

**Coming from the version with the Netlify folder and Tailscale:** the website's files moved to the `Website` folder, and the bot puts them on Netlify itself. Delete the old `Netlify` folder and `dashboard/static`, and you can uninstall Tailscale (or run `tailscale funnel reset`). The first time the new version starts, it asks for a Netlify token and suggests your old site's name: press Enter to keep that address. It clears the old `DASHBOARD_URL` in `.env` by itself.

Unzip the new version over your old folder (don't delete the old folder first: your `.env` and `data` folder are only there). The zip has no `.env` or `data`, so your token and settings stay, along with `giveaways.json`, `reaction_roles.json`, `tickets.json` and the `transcripts` folder. If your `.env` still has the old `DASHBOARD_HOST=127.0.0.1` default, the bot switches it to `auto` the first time it starts. (Starting fresh in a new folder? Copy `.env.example` to `.env`.) The first time the new version starts, `config.json` moves to City Of Miami's settings in `data/guilds/` (the old file is kept as `config.old.json`).

If the bot is in several servers when you update and it picks the wrong one, set `DASHBOARD_GUILD_ID` in `.env` to City Of Miami's server ID, delete the new file in `data/guilds/`, rename `config.old.json` back to `config.json` and start again.

The bot's invite link now also asks for **Manage Nicknames** (Roblox nicknames), **Move Members** and **Connect** (join-to-create voice channels, `/voice`), **Mute Members** (`/voice mute`) and **Create Expressions** (`/steal`). In servers that already have the bot, give its role those permissions if you use those features.

Moderation and role commands only work on people and roles below the bot's highest role, so drag the bot's role near the top in **Server Settings → Roles**.

## Files the bot keeps

| File | What's in it |
| --- | --- |
| `data/guilds/` | Each server's settings, one file per server |
| `data/audit/` | Each server's recent dashboard changes |
| `data/roblox_links.json` | Which Discord member linked which Roblox account |
| `data/*.json` | Records for the other features: moderation cases, levels, suggestions, birthdays, applications, reviews, ratings, sessions and so on |
| `giveaways.json` | Running and ended giveaways |
| `reaction_roles.json` | Reaction role panels |
| `tickets.json` | Open tickets, ticket panels and the list of transcripts |
| `transcripts/` | Saved ticket transcripts (HTML pages) |
| `.env` | Bot token, client secret and website settings |
| `.dashboard_secret` | Keeps people logged in across restarts. Delete it to log everyone out. |
| `Open Dashboard.bat` | For your PC: opens the dashboard of a bot running on a VPS |

Never share `.env` or `.dashboard_secret`.

To run the bot without the website, put the token in `.env` yourself and set `DASHBOARD_ENABLED=false`.

---

The features are in `commands/Staff/`, one file each (figs are defined in `commands/Staff/figs.py`). The website is in `dashboard/`.
