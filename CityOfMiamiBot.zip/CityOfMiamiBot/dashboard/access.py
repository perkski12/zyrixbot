"""
Who can open which server's dashboard, and the list of servers on the Servers page.

A person can manage a server when the bot is in it and they:
  • own the server, or have Administrator or Manage Server, or
  • were given access on that server's Dashboard access page (by role or by name), or
  • are the bot's owner: the owner (or team) of the bot in the Discord Developer Portal, or
    someone listed in BOT_OWNER_IDS in .env.
"""

import asyncio
import os
import re
import time

import aiohttp

from commands.Staff.wl_embed import get_config
from .auth import member_can_use
from .envfile import save_env_value
from .setup import invite_url

DISCORD_API = "https://discord.com/api/v10"
ADMINISTRATOR, MANAGE_GUILD = 0x8, 0x20


class LoginExpired(Exception):
    pass


async def fetch_user_guilds(access_token: str) -> list[dict]:
    """The servers a Discord user is in (needs the 'guilds' login scope)."""
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=12)) as http:
            async with http.get(f"{DISCORD_API}/users/@me/guilds",
                                headers={"Authorization": f"Bearer {access_token}"}) as r:
                if r.status == 401:
                    raise LoginExpired()
                if r.status == 429:
                    await asyncio.sleep(float((await r.json()).get("retry_after", 1)))
                    return await fetch_user_guilds(access_token)
                r.raise_for_status()
                return await r.json()
    except aiohttp.ClientError:
        return []


class Access:
    def __init__(self, runner):
        self.runner = runner
        self._guild_cache: dict[str, tuple[float, list]] = {}
        self._redirects: tuple[float, list | None] = (0.0, None)

    async def redirect_uris(self, fresh: bool = False) -> list[str] | None:
        """
        The redirects listed on the bot's OAuth2 page in the Developer Portal, or None when that
        can't be read right now (bot offline, Discord didn't answer). Kept for a few seconds only,
        so a redirect added in the Portal counts right away.
        """
        at, cached = self._redirects
        if not fresh and cached is not None and time.time() - at < 10:
            return cached
        bot = self.bot
        if bot is None or not bot.is_ready():
            return None
        try:
            info = await asyncio.wait_for(bot.application_info(), timeout=6)
        except Exception:
            return None
        uris = getattr(info, "redirect_uris", None)
        if uris is None:
            return None  # an older discord.py that doesn't say
        uris = [str(u) for u in uris]
        self._redirects = (time.time(), uris)
        return uris

    @property
    def bot(self):
        return self.runner.bot

    # ── who's who ──

    def owner_ids(self) -> set[str]:
        ids = {x.strip() for x in os.getenv("BOT_OWNER_IDS", "").split(",") if x.strip().isdigit()}
        app = getattr(self.bot, "application", None) if self.bot else None
        if app is not None:
            owner = getattr(app, "owner", None)
            if owner is not None:
                ids.add(str(owner.id))
            team = getattr(app, "team", None)
            for m in getattr(team, "members", None) or []:
                ids.add(str(m.id))
        return ids

    def is_bot_owner(self, user: dict | None) -> bool:
        if not user:
            return False
        return user.get("id") is not None and str(user["id"]) in self.owner_ids()

    def can_manage(self, user: dict | None, guild) -> bool:
        if not user or guild is None:
            return False
        if self.is_bot_owner(user):
            return True
        if user.get("id") is None:
            return False
        return member_can_use(guild.get_member(int(user["id"])), guild, get_config(guild))

    def open_server(self, user: dict | None, gid) -> tuple:
        """(guild, None) when the user may manage that server, otherwise (None, (status, message))."""
        bot = self.bot
        try:
            gid = int(gid)
        except (TypeError, ValueError):
            return None, (404, "That isn't a server.")
        guild = bot.get_guild(gid) if bot is not None and bot.is_ready() else None
        if guild is None:
            return None, (404, "The bot isn't in that server, or is still starting.")
        if not self.can_manage(user, guild):
            return None, (403, "You don't have access to this server's dashboard. Ask the owner to add you.")
        return guild, None

    # ── the Servers page ──

    async def user_guilds(self, user: dict) -> list[dict]:
        """The user's Discord servers, cached for a minute so the page stays fast."""
        token = user.get("at")
        if not token:
            return []
        cached = self._guild_cache.get(user["id"])
        if cached and cached[0] > time.time():
            return cached[1]
        guilds = await fetch_user_guilds(token)
        self._guild_cache[user["id"]] = (time.time() + 60, guilds)
        return guilds

    def _card(self, g) -> dict:
        conf = get_config(g)
        return {
            "id": str(g.id), "name": g.name, "icon": g.icon.url if g.icon else None,
            "members": g.member_count or len(g.members), "figs": list(conf.get("figs", [])),
        }

    async def guild_list(self, user: dict) -> dict:
        """Servers you can manage, servers you can add the bot to, and ones you need access for."""
        bot = self.bot
        manage, add, locked, seen = [], [], [], set()
        if bot is None or not bot.is_ready():
            return {"manage": [], "add": [], "locked": [], "ready": False}

        for entry in await self.user_guilds(user):
            gid = int(entry["id"])
            seen.add(gid)
            g = bot.get_guild(gid)
            perms = int(entry.get("permissions") or 0)
            admin = bool(entry.get("owner")) or bool(perms & (ADMINISTRATOR | MANAGE_GUILD))
            icon = (f"https://cdn.discordapp.com/icons/{gid}/{entry['icon']}.png?size=128" if entry.get("icon") else None)
            if g is not None:
                if self.can_manage(user, g):
                    manage.append(self._card(g))
                else:
                    locked.append({"id": str(gid), "name": entry.get("name", g.name), "icon": icon})
            elif admin:
                link = invite_url(bot)
                add.append({"id": str(gid), "name": entry.get("name", ""), "icon": icon,
                            "invite": f"{link}&guild_id={gid}&disable_guild_select=true" if link else None})

        if self.is_bot_owner(user):  # the bot owner sees every server the bot is in
            for g in bot.guilds:
                if g.id not in seen:
                    manage.append({**self._card(g), "owner_view": True})

        key = lambda x: x["name"].lower()  # noqa: E731
        return {"manage": sorted(manage, key=key), "add": sorted(add, key=key), "locked": sorted(locked, key=key), "ready": True}

    # ── the public home page ──

    def public_info(self) -> dict:
        from commands.Staff.figs import figs_for_client
        bot = self.bot
        user = bot.user if bot is not None else None
        online = bot is not None and bot.is_ready()
        return {
            "name": user.name if user else "Bot",
            "avatar": user.display_avatar.url if user else None,
            "online": online,
            "servers": len(bot.guilds) if online else 0,
            "members": sum((g.member_count or 0) for g in bot.guilds) if online else 0,
            "invite": invite_url(bot) if online else None,
            "commands": self.public_commands() if online else [],
            **figs_for_client(),
        }

    def public_commands(self) -> list:
        """The bot's slash commands for the home page: name, what it does, and which feature it belongs to."""
        from commands.Staff.figs import COMMAND_FEATURES, FEATURES
        out = []
        for cmd in sorted(self.bot.tree.get_commands(), key=lambda c: c.name):
            feature = COMMAND_FEATURES.get(cmd.name)
            # a command group shows each of its subcommands: /role add, /role remove...
            for sub in getattr(cmd, "commands", None) or [cmd]:
                out.append({
                    "name": cmd.name if sub is cmd else f"{cmd.name} {sub.name}",
                    "description": getattr(sub, "description", "") or "",
                    "feature": FEATURES[feature][0] if feature in FEATURES else "General",
                })
        return out


def bot_settings(auth, client_id: str, site: str, body: dict | None = None) -> tuple[int, dict]:
    """
    The Bot settings page (bot owner only): read, or save Login with Discord settings to .env.
    `site` is the address the page was opened with, for the redirect to add in the Developer Portal.
    """
    if body is not None:
        url = str(body.get("dashboard_url", auth.base_url) or "").strip().rstrip("/")
        if url and not re.match(r"^https?://[^/\s]+$", url):
            return 400, {"error": "The website address should look like https://dash.example.com, with nothing after the domain."}
        secret = str(body.get("client_secret") or "").strip()
        if secret and not re.match(r"^[A-Za-z0-9_-]{20,64}$", secret):
            return 400, {"error": "That doesn't look like a client secret. Copy it again from OAuth2 in the Developer Portal."}
        save_env_value("DASHBOARD_URL", url)
        if secret:
            save_env_value("DISCORD_CLIENT_SECRET", secret)
        auth.reload()
    return 200, {
        "client_id": client_id, "client_secret_set": bool(auth.client_secret),
        "dashboard_url": auth.base_url,
        "redirect_uri": auth.redirect_uri(auth.base_url or site),
        "discord_login": auth.discord_enabled,
    }
