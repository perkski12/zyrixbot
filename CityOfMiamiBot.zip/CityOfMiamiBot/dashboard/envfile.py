"""Reading and writing the .env file (no extra package needed)."""

import os

ENV_FILE = ".env"


def load_env(path: str = ENV_FILE):
    """Read KEY=value lines from .env into the environment."""
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            value = value.strip().strip('"').strip("'")
            os.environ.setdefault(key.strip(), value)


# Older .env files came with DASHBOARD_HOST=127.0.0.1, which keeps a VPS's dashboard away from
# your PC. Files still on that old default are switched to auto (works on a PC and on a VPS).
OLD_HOST_HELP = ("# 127.0.0.1 = only the machine the bot runs on", "# 127.0.0.1 = only this machine.")
HOST_HELP = [
    "# Who can open the website:",
    "# auto      = recommended. http://localhost:8080 works on the machine running the bot, and your",
    "#             PC can open a VPS's dashboard at http://YOUR-VPS-IP:8080 (the console prints the link).",
    "# 127.0.0.1 = only the machine the bot runs on (reach a VPS with \"Open Dashboard.bat\")",
]


def upgrade_env(path: str = ENV_FILE) -> bool:
    """Switch an old .env that still has the old DASHBOARD_HOST=127.0.0.1 default to auto."""
    if not os.path.exists(path):
        return False
    with open(path, "r", encoding="utf-8") as f:
        lines = f.read().splitlines()
    if not any(line.startswith(OLD_HOST_HELP) for line in lines):
        return False
    try:
        i = next(n for n, line in enumerate(lines) if line.strip() == "DASHBOARD_HOST=127.0.0.1")
    except StopIteration:
        return False
    start = i
    while start > 0 and lines[start - 1].startswith("#") and not lines[start - 1].startswith("# ──"):
        start -= 1
    lines[start:i + 1] = HOST_HELP + ["DASHBOARD_HOST=auto"]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return True


def save_env_value(key: str, value: str, path: str = ENV_FILE):
    """Set KEY=value in .env, keeping every other line as it is."""
    lines = []
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    for i, line in enumerate(lines):
        if line.strip().startswith(f"{key}="):
            lines[i] = f"{key}={value}"
            break
    else:
        lines.append(f"{key}={value}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.environ[key] = value
