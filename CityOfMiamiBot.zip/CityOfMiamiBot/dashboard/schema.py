"""
Every setting the dashboard can change, and how to check it.

Discord IDs are too big for JavaScript numbers, so they travel to the browser as
strings and are turned back into ints here before going into config.json.
"""

import re
import secrets

HEX_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
CUSTOM_EMOJI = re.compile(r"^<a?:[A-Za-z0-9_]{2,32}:\d{15,22}>$")
SNOWFLAKE = re.compile(r"^\d{15,22}$")


class Invalid(ValueError):
    pass


def _id(value, what: str) -> int:
    text = str(value).strip()
    if not SNOWFLAKE.match(text):
        raise Invalid(f"That isn't a valid {what} ID.")
    return int(text)


class Field:
    kind = "any"

    def clean(self, value, guild):
        return value

    def to_client(self, value):
        return value


class Str(Field):
    kind = "text"

    def __init__(self, max_len: int, required: bool = False):
        self.max_len, self.required = max_len, required

    def clean(self, value, guild):
        if value is None:
            value = ""
        if not isinstance(value, str):
            raise Invalid("Expected text.")
        value = value.replace("\r\n", "\n").strip()
        if self.required and not value:
            raise Invalid("This can't be empty.")
        if len(value) > self.max_len:
            raise Invalid(f"Keep it under {self.max_len} characters.")
        return value


class Prefix(Field):
    """The prefix for prefix commands, like , or ! or zy. (1-5 characters, no spaces)."""
    kind = "text"

    def clean(self, value, guild):
        value = str(value or "").strip()
        if not value:
            raise Invalid("Pick a prefix, like , or !")
        if len(value) > 5 or any(c.isspace() for c in value):
            raise Invalid("Use 1-5 characters with no spaces, like , or !")
        if value.startswith(("/", "@", "#", "<")):
            raise Invalid("/, @, # and < already mean something in Discord. Try , or ! instead.")
        return value


class Url(Field):
    kind = "url"

    def clean(self, value, guild):
        value = (value or "").strip()
        if value and not re.match(r"^https?://\S+$", value):
            raise Invalid("Links have to start with http:// or https://")
        if len(value) > 500:
            raise Invalid("That link is too long.")
        return value


class Color(Field):
    kind = "color"

    def clean(self, value, guild):
        value = str(value or "").strip()
        if not HEX_COLOR.match(value):
            raise Invalid("Use a hex color like #ffffff.")
        return value.lower()


class Emoji(Field):
    kind = "emoji"

    def clean(self, value, guild):
        value = str(value or "").strip()
        if CUSTOM_EMOJI.match(value):
            return value
        if value and len(value) <= 8 and not any(c.isalnum() or c.isspace() for c in value):
            return value  # a normal emoji like 🌴
        raise Invalid("Use a normal emoji, or a custom one written like <:name:123456789012345678>.")


class Bool(Field):
    kind = "bool"

    def clean(self, value, guild):
        if not isinstance(value, bool):
            raise Invalid("Expected on or off.")
        return value


class Enum(Field):
    kind = "enum"

    def __init__(self, options):
        self.options = list(options)

    def clean(self, value, guild):
        if value not in self.options:
            raise Invalid("That option isn't available.")
        return value


class Channel(Field):
    kind = "channel"

    def clean(self, value, guild):
        if value in (None, "", 0, "0"):
            return None
        cid = _id(value, "channel")
        if guild is not None and guild.get_channel(cid) is None:
            raise Invalid("That channel isn't in the server anymore.")
        return cid

    def to_client(self, value):
        return str(value) if value else None


class Role(Field):
    kind = "role"

    def clean(self, value, guild):
        if value in (None, "", 0, "0"):
            return None
        rid = _id(value, "role")
        if guild is not None:
            role = guild.get_role(rid)
            if role is None:
                raise Invalid("That role isn't in the server anymore.")
            if role.is_default():
                raise Invalid("@everyone can't be used here.")
        return rid

    def to_client(self, value):
        return str(value) if value else None


class IdList(Field):
    def __init__(self, item: Field, max_items: int, what: str):
        self.item, self.max_items, self.what = item, max_items, what

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list.")
        out = []
        for v in value:
            cleaned = self.item.clean(v, guild) if self.item else _id(v, self.what)
            if cleaned and cleaned not in out:
                out.append(cleaned)
        if len(out) > self.max_items:
            raise Invalid(f"You can pick up to {self.max_items}.")
        return out

    def to_client(self, value):
        return [str(v) for v in (value or [])]


class WordList(Field):
    kind = "words"

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list of words.")
        out = []
        for w in value:
            w = str(w).strip().lower()
            if not w:
                continue
            if len(w) > 100:
                raise Invalid("Words have to be under 100 characters.")
            if w not in out:
                out.append(w)
        if len(out) > 1000:
            raise Invalid("That's more than 1000 words.")
        return out


class TextList(Field):
    kind = "textlist"

    def __init__(self, max_items: int, item_max: int):
        self.max_items, self.item_max = max_items, item_max

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list.")
        out = [str(v).replace("\r\n", "\n").strip() for v in value]
        out = [v for v in out if v]
        if len(out) > self.max_items:
            raise Invalid(f"You can have up to {self.max_items}.")
        if any(len(v) > self.item_max for v in out):
            raise Invalid(f"Each block has to be under {self.item_max} characters.")
        return out


class RoleMap(Field):
    """{name: role_id} for priority roles. Order is kept."""
    kind = "rolemap"

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list of name and role pairs.")
        out = {}
        role = Role()
        for row in value:
            name = str((row or {}).get("name", "")).strip()
            if not name:
                raise Invalid("Every priority role needs a name.")
            if len(name) > 100:
                raise Invalid("Names have to be under 100 characters.")
            if name in out:
                raise Invalid(f"The name “{name}” is used twice.")
            rid = role.clean(row.get("role_id"), guild)
            if not rid:
                raise Invalid(f"Pick a role for “{name}”.")
            out[name] = rid
        if len(out) > 25:
            raise Invalid("Discord shows up to 25 choices, so keep it to 25 priority roles.")
        return out

    def to_client(self, value):
        return [{"name": k, "role_id": str(v)} for k, v in (value or {}).items()]


class Int(Field):
    kind = "int"

    def __init__(self, low: int, high: int):
        self.low, self.high = low, high

    def clean(self, value, guild):
        try:
            value = int(value)
        except (TypeError, ValueError):
            raise Invalid("Expected a number.")
        if not self.low <= value <= self.high:
            raise Invalid(f"Pick a number from {self.low} to {self.high}.")
        return value


TYPE_ID = re.compile(r"^[a-z0-9]{3,20}$")


class TicketTypes(Field):
    """The kinds of tickets members can open."""
    kind = "tickettypes"

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list of ticket types.")
        if len(value) > 25:
            raise Invalid("Discord shows up to 25 choices, so keep it to 25 ticket types.")
        out, seen = [], set()
        text, emoji, roles = Str(80, required=True), Emoji(), IdList(Role(), 10, "role")
        for i, raw in enumerate(value, start=1):
            if not isinstance(raw, dict):
                raise Invalid("Every ticket type needs settings.")
            try:
                name = text.clean(raw.get("name"), guild)
            except Invalid:
                raise Invalid(f"Ticket type {i} needs a name.")
            tid = str(raw.get("id") or "").lower()
            if not TYPE_ID.match(tid) or tid in seen:
                tid = re.sub(r"[^a-z0-9]", "", name.lower())[:12] or "type"
                while tid in seen or len(tid) < 3:
                    tid += secrets.token_hex(2)
            seen.add(tid)

            em = str(raw.get("emoji") or "").strip()
            if em:
                try:
                    em = emoji.clean(em, guild)
                except Invalid:
                    raise Invalid(f"The emoji for “{name}” isn't valid.")

            cat = raw.get("category_id")
            cat_id = None
            if cat not in (None, "", 0, "0"):
                cat_id = _id(cat, "category")
                if guild is not None:
                    ch = guild.get_channel(cat_id)
                    if ch is None or ch.type.name != "category":
                        raise Invalid(f"The category for “{name}” isn't in the server anymore.")

            fmt = Str(60).clean(raw.get("name_format") or "ticket-{number}", guild) or "ticket-{number}"
            questions = []
            for q in (raw.get("questions") or [])[:6]:
                label = str((q or {}).get("label", "")).strip()
                if not label:
                    continue
                if len(label) > 45:
                    raise Invalid(f"Questions can be 45 characters at most (Discord's limit): “{label[:20]}…”")
                questions.append({"label": label, "long": bool(q.get("long")), "required": bool(q.get("required", True))})
            if len(questions) > 5:
                raise Invalid(f"“{name}” has more than 5 questions. Discord forms fit 5.")

            out.append({
                "id": tid, "name": name, "emoji": em,
                "description": Str(100).clean(raw.get("description"), guild),
                "category_id": cat_id,
                "support_role_ids": roles.clean(raw.get("support_role_ids") or [], guild),
                "ping_support": bool(raw.get("ping_support", True)),
                "name_format": fmt,
                "welcome_message": Str(2000).clean(raw.get("welcome_message"), guild),
                "questions": questions,
            })
        return out

    def to_client(self, value):
        return [
            {**t, "category_id": str(t["category_id"]) if t.get("category_id") else None,
             "support_role_ids": [str(r) for r in t.get("support_role_ids", [])]}
            for t in (value or [])
        ]


class FigList(Field):
    kind = "figs"

    def clean(self, value, guild):
        from commands.Staff.figs import FIGS
        if not isinstance(value, list):
            raise Invalid("Expected a list of figs.")
        out = []
        for fid in value:
            if fid not in FIGS:
                raise Invalid(f"There's no fig called {fid}.")
            if fid not in out:
                out.append(fid)
        return out


class OptionalBigInt(Field):
    """A Roblox ID (group, place, badge, game pass): a positive number, or empty."""
    kind = "bigint"

    def __init__(self, what: str = "Roblox group"):
        self.what = what

    def clean(self, value, guild):
        if value in (None, "", 0, "0"):
            return None
        text = str(value).strip()
        if not text.isdigit() or len(text) > 15:
            raise Invalid(f"That isn't a valid {self.what} ID. It's the number in its link.")
        return int(text)

    def to_client(self, value):
        return str(value) if value else None


class RankRoles(Field):
    """[{rank, role_id}] for Roblox group ranks."""
    kind = "rankroles"

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list of rank and role pairs.")
        out, seen, role = [], set(), Role()
        for row in value:
            try:
                rank = int((row or {}).get("rank"))
            except (TypeError, ValueError):
                raise Invalid("Every rank needs a number from 1 to 255.")
            if not 1 <= rank <= 255:
                raise Invalid("Roblox ranks go from 1 to 255.")
            rid = role.clean(row.get("role_id"), guild)
            if not rid:
                continue  # rank without a role: nothing to give
            if (rank, rid) in seen:
                continue
            seen.add((rank, rid))
            out.append({"rank": rank, "role_id": rid})
        if len(out) > 60:
            raise Invalid("That's more than 60 rank roles.")
        return out

    def to_client(self, value):
        return [{"rank": r["rank"], "role_id": str(r["role_id"])} for r in (value or [])]


class OptEmoji(Emoji):
    """An emoji, or nothing."""

    def clean(self, value, guild):
        if value in (None, ""):
            return ""
        return super().clean(value, guild)


class Choices(Field):
    """Several picks from a fixed list."""
    kind = "choices"

    def __init__(self, options):
        self.options = list(options)

    def clean(self, value, guild):
        if not isinstance(value, list) or any(v not in self.options for v in value):
            raise Invalid("One of those options isn't available.")
        return [o for o in self.options if o in value]


class NumList(Field):
    """Roblox IDs, like groups to keep out."""
    kind = "numlist"

    def __init__(self, max_items: int, what: str):
        self.max_items, self.item = max_items, OptionalBigInt(what)

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list.")
        out = []
        for v in value:
            n = self.item.clean(v, guild)
            if n and n not in out:
                out.append(n)
        if len(out) > self.max_items:
            raise Invalid(f"You can add up to {self.max_items}.")
        return out

    def to_client(self, value):
        return [str(v) for v in (value or [])]


class Records(Field):
    """
    A list of rows that all have the same fields, like auto-responses or FAQ entries.
    fields:   {key: (Field, value when missing)}
    required: {key: what to tell people when it's empty}
    ids:      give every row a short id that stays the same when rows are edited
    """
    kind = "records"

    def __init__(self, fields: dict, max_items: int, what: str, required: dict | None = None, ids: bool = False):
        self.fields, self.max_items, self.what = fields, max_items, what
        self.required, self.ids = required or {}, ids

    def clean(self, value, guild):
        if not isinstance(value, list):
            raise Invalid("Expected a list.")
        if len(value) > self.max_items:
            raise Invalid(f"You can have up to {self.max_items} {self.what}.")
        out, seen = [], set()
        name = self.what[:-1] if self.what.endswith("s") else self.what
        for i, row in enumerate(value, 1):
            if not isinstance(row, dict):
                raise Invalid("Expected a list of rows.")
            clean = {}
            for key, (field, missing) in self.fields.items():
                raw = row.get(key)
                try:
                    clean[key] = field.clean(missing if raw is None else raw, guild)
                except Invalid as e:
                    raise Invalid(f"{name.capitalize()} {i}: {e}")
            for key, message in self.required.items():
                if clean.get(key) in (None, "", []):
                    raise Invalid(f"{name.capitalize()} {i}: {message}.")
            if self.ids:
                rid = str(row.get("id") or "")
                if not TYPE_ID.match(rid) or rid in seen:
                    rid = secrets.token_hex(4)
                seen.add(rid)
                clean["id"] = rid
            out.append(clean)
        return out

    def to_client(self, value):
        rows = []
        for row in value or []:
            r = {k: f.to_client(row.get(k)) for k, (f, _) in self.fields.items()}
            if self.ids:
                r["id"] = row.get("id")
            rows.append(r)
        return rows


AM_ACTIONS = ["delete", "timeout_5", "timeout_60", "timeout_1440"]
LOG_EVENTS = ["message_delete", "message_edit", "member_join", "member_leave", "member_roles", "member_nick",
              "member_ban", "member_unban", "voice", "channels"]
STATUS_STATES = ["operational", "degraded", "partial", "major", "maintenance"]
ROLE_LIST = lambda n=25: IdList(Role(), n, "role")  # noqa: E731
CHANNEL_LIST = lambda n=50: IdList(Channel(), n, "channel")  # noqa: E731

HONEYPOT_ACTIONS = ["softban", "kick", "ban", "timeout_60", "timeout_1440", "timeout_10080"]

NICKNAME_FORMATS = ["", "{display}", "{roblox}", "{display} (@{roblox})"]

FIELDS: dict[str, Field] = {
    # Figs
    "figs": FigList(),

    # General
    "server_name": Str(100),
    "accent_color": Color(),
    "city_emoji": Emoji(),
    "thumbnail_url": Url(),
    "banner_url": Url(),
    "support_url": Url(),
    "website_url": Url(),
    "log_channel_id": Channel(),

    # Whitelist
    "wl_enabled": Bool(),
    "whitelist_channel_id": Channel(),
    "whitelist_role_id": Role(),
    "unverified_role_id": Role(),
    "wl_panel_title": Str(200, required=True),
    "wl_panel_subtitle": Str(500),
    "wl_panel_sections": TextList(8, 1000),
    "wl_panel_footer": Str(200),

    # Welcome
    "welcome_enabled": Bool(),
    "welcome_channel_id": Channel(),
    "welcome_title": Str(200, required=True),
    "welcome_message": Str(1500),
    "welcome_links": IdList(Channel(), 15, "channel"),
    "welcome_footer": Str(200),

    # Priority roles
    "priority_roles": RoleMap(),

    # Word filter
    "filtered_words": WordList(),
    "allowed_words": WordList(),
    "filter_whitelist_users": IdList(None, 200, "user"),
    "filter_message": Str(500, required=True),

    # Honeypot
    "honeypot_channel_id": Channel(),
    "honeypot_log_channel_id": Channel(),
    "honeypot_action": Enum(HONEYPOT_ACTIONS),
    "honeypot_message": Str(1000),

    # React channels
    "react_channel_ids": IdList(Channel(), 50, "channel"),

    # Commands
    "female_role_id": Role(),
    "female_log_channel_id": Channel(),
    "disabled_commands": TextList(100, 32),

    # Dashboard access
    "dashboard_role_ids": IdList(Role(), 25, "role"),
    "dashboard_user_ids": IdList(None, 50, "user"),

    # Tickets
    "ticket_log_channel_id": Channel(),
    "ticket_max_open": Int(0, 10),
    "ticket_claim": Bool(),
    "ticket_dm_transcript": Bool(),
    "ticket_types": TicketTypes(),

    # Roblox
    "roblox_verified_role_id": Role(),
    "roblox_unverified_role_id": Role(),
    "roblox_nickname": Enum(NICKNAME_FORMATS),
    "roblox_auto_verify": Bool(),
    "roblox_log_channel_id": Channel(),
    "roblox_panel_title": Str(200, required=True),
    "roblox_panel_text": Str(1000),
    "roblox_group_id": OptionalBigInt(),
    "roblox_group_member_role_id": Role(),
    "roblox_rank_roles": RankRoles(),

    # Roblox extras
    "rbx_min_age_days": Int(0, 3650),
    "rbx_blacklist_groups": NumList(25, "Roblox group"),
    "rbx_auto_update_hours": Int(0, 168),
    "rbx_badge_roles": Records({"badge_id": (OptionalBigInt("badge"), None), "role_id": (Role(), None), "name": (Str(100), "")},
                               25, "badge roles", {"badge_id": "add the badge ID", "role_id": "pick a role"}),
    "rbx_pass_roles": Records({"pass_id": (OptionalBigInt("game pass"), None), "role_id": (Role(), None), "name": (Str(100), "")},
                              25, "game pass roles", {"pass_id": "add the game pass ID", "role_id": "pick a role"}),
    "rbx_place_id": OptionalBigInt("place"),
    "rbx_stats_channel_id": Channel(),
    "rbx_shout_channel_id": Channel(),
    "sess_channel_id": Channel(),
    "sess_ping_role_id": Role(),
    "sess_host_role_ids": ROLE_LIST(10),
    "sess_link": Url(),
    "sess_types": Records({"name": (Str(50), ""), "emoji": (OptEmoji(), "")}, 10, "session types", {"name": "give it a name"}),

    # Welcome extras
    "join_role_ids": ROLE_LIST(10),
    "join_bot_role_ids": ROLE_LIST(10),
    "welcome_dm": Str(1500),
    "goodbye_enabled": Bool(),
    "goodbye_channel_id": Channel(),
    "goodbye_message": Str(1000),

    # Auto-mod
    "am_invites": Bool(),
    "am_links": Bool(),
    "am_allowed_links": WordList(),
    "am_spam": Bool(),
    "am_spam_count": Int(3, 20),
    "am_spam_seconds": Int(2, 60),
    "am_mentions": Int(0, 50),
    "am_caps": Bool(),
    "am_action": Enum(AM_ACTIONS),
    "am_warn": Bool(),
    "am_ignored_role_ids": ROLE_LIST(),
    "am_ignored_channel_ids": CHANNEL_LIST(),
    "am_log_channel_id": Channel(),

    # Moderation
    "mod_log_channel_id": Channel(),
    "mod_dm": Bool(),
    "mod_warn_timeout": Int(0, 50),
    "mod_timeout_minutes": Int(1, 40320),
    "mod_warn_kick": Int(0, 50),
    "mod_warn_ban": Int(0, 50),

    # Prefix commands
    "prefix": Prefix(),
    "prefix_enabled": Bool(),

    # Utility
    "util_snipe": Bool(),
    "util_afk": Bool(),
    "util_afk_nick": Bool(),

    # Server logs
    "logs_channel_id": Channel(),
    "logs_message_channel_id": Channel(),
    "logs_events": Choices(LOG_EVENTS),
    "logs_ignored_channel_ids": CHANNEL_LIST(),

    # Leveling
    "lvl_enabled": Bool(),
    "lvl_xp_min": Int(1, 500),
    "lvl_xp_max": Int(1, 500),
    "lvl_cooldown": Int(0, 3600),
    "lvl_announce": Enum(["channel", "dm", "custom", "off"]),
    "lvl_channel_id": Channel(),
    "lvl_message": Str(500, required=True),
    "lvl_roles": Records({"level": (Int(1, 1000), 1), "role_id": (Role(), None)}, 50, "level roles", {"role_id": "pick a role"}),
    "lvl_stack": Bool(),
    "lvl_no_xp_channel_ids": CHANNEL_LIST(),
    "lvl_no_xp_role_ids": ROLE_LIST(),

    # Suggestions
    "sug_channel_id": Channel(),
    "sug_anonymous": Bool(),
    "sug_staff_role_ids": ROLE_LIST(),
    "sug_dm_result": Bool(),

    # Starboard
    "star_channel_id": Channel(),
    "star_emoji": Emoji(),
    "star_threshold": Int(1, 100),
    "star_self": Bool(),
    "star_ignored_channel_ids": CHANNEL_LIST(),

    # Birthdays
    "bday_channel_id": Channel(),
    "bday_role_id": Role(),
    "bday_message": Str(500, required=True),
    "bday_hour": Int(0, 23),

    # Auto-responses
    "ar_rules": Records({"trigger": (Str(100), ""), "match": (Enum(["contains", "word", "exact", "starts"]), "contains"),
                         "response": (Str(2000), ""), "reply": (Bool(), True), "channel_ids": (CHANNEL_LIST(25), [])},
                        50, "auto-responses", {"trigger": "add a trigger", "response": "add a reply"}),
    "ar_cooldown": Int(0, 3600),

    # Timed messages
    "ann_messages": Records({"name": (Str(80), ""), "channel_id": (Channel(), None), "title": (Str(200), ""),
                             "text": (Str(2000), ""), "every_hours": (Int(1, 720), 24), "ping_role_id": (Role(), None),
                             "enabled": (Bool(), True)},
                            25, "timed messages", {"channel_id": "pick a channel", "text": "add the text"}, ids=True),

    # Join-to-create voice
    "tv_hub_channel_id": Channel(),
    "tv_category_id": Channel(),
    "tv_name": Str(80, required=True),
    "tv_limit": Int(0, 99),

    # Channel tools
    "sticky_messages": Records({"channel_id": (Channel(), None), "text": (Str(1500), "")}, 15, "sticky messages",
                               {"channel_id": "pick a channel", "text": "add the text"}),
    "stat_channels": Records({"channel_id": (Channel(), None), "template": (Str(80), "")}, 10, "stat channels",
                             {"channel_id": "pick a channel", "template": "add the name"}),
    "count_channel_id": Channel(),
    "count_reset_on_fail": Bool(),

    # Ticket extras
    "ticket_autoclose_hours": Int(0, 720),
    "ticket_rating": Bool(),
    "ticket_snippets": Records({"name": (Str(32), ""), "text": (Str(2000), "")}, 25, "snippets",
                               {"name": "give it a name", "text": "add the text"}),
    "ticket_hours_on": Bool(),
    "ticket_hours_start": Int(0, 23),
    "ticket_hours_end": Int(0, 23),
    "ticket_utc_offset": Int(-12, 14),
    "ticket_offline_message": Str(1000),
    "ticket_dm_open": Bool(),

    # Applications
    "app_forms": Records({
        "name": (Str(80), ""), "emoji": (OptEmoji(), ""), "description": (Str(100), ""),
        "questions": (Records({"label": (Str(45), ""), "long": (Bool(), False), "required": (Bool(), True)},
                              5, "questions", {"label": "write the question"}), []),
        "review_channel_id": (Channel(), None), "reviewer_role_ids": (ROLE_LIST(10), []),
        "accept_role_id": (Role(), None), "open": (Bool(), True),
    }, 10, "applications", {"name": "give it a name", "questions": "add at least one question",
                            "review_channel_id": "pick the channel staff review answers in"}, ids=True),
    "app_panel_title": Str(200, required=True),
    "app_panel_text": Str(1000),

    # FAQ
    "faq_entries": Records({"question": (Str(100), ""), "answer": (Str(2000), ""), "emoji": (OptEmoji(), "")},
                           25, "questions", {"question": "write the question", "answer": "write the answer"}),
    "faq_title": Str(200, required=True),
    "faq_text": Str(1000),

    # Status page
    "status_channel_id": Channel(),
    "status_components": Records({"name": (Str(80), ""), "state": (Enum(STATUS_STATES), "operational")}, 20, "parts",
                                 {"name": "give it a name"}),
    "status_note": Str(1000),

    # Reviews
    "rev_channel_id": Channel(),
    "rev_role_id": Role(),
}


def config_to_client(config: dict) -> dict:
    return {key: field.to_client(config.get(key)) for key, field in FIELDS.items()}


def clean_patch(patch: dict, guild) -> tuple[dict, dict]:
    """Check every changed setting. Returns (clean values, {key: error message})."""
    cleaned, errors = {}, {}
    for key, value in patch.items():
        field = FIELDS.get(key)
        if field is None:
            errors[key] = "Unknown setting."
            continue
        try:
            cleaned[key] = field.clean(value, guild)
        except Invalid as e:
            errors[key] = str(e)
    return cleaned, errors
