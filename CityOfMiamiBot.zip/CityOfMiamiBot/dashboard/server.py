"""
The website. It runs inside the bot (same program), so it sees the bot's live servers,
channels, roles and settings. aiohttp comes with discord.py, so there's nothing extra to install.

The pages themselves live in the Website folder. With NETLIFY_SITE and NETLIFY_TOKEN in .env, the
bot also puts that folder on Netlify and connects it to this PC by itself (netlify.py).

  /                      public home page, Servers page and each server's dashboard (one page app)
  /api/public            bot name, server count, figs (no login)
  /api/session           who's logged in
  /login/discord         Login with Discord (identify + guilds), the only way to log in
  /api/guilds            the Servers page: your servers and what you can do with them
  /api/owner/settings    Discord login settings (bot owner only)
  /api/g/<server id>/…   one server's dashboard (Api in api.py)
"""

import asyncio
import ipaddress
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import traceback
from pathlib import Path
from urllib.parse import quote, urlencode

import aiohttp
from aiohttp import web

from commands.Staff.wl_embed import guild_context
from . import netlify
from .access import Access, LoginExpired, bot_settings
from .api import Api, ApiError, Req
from .auth import Auth, COOKIE, STATE_COOKIE, SESSION_SECONDS
from .envfile import save_env_value
from .setup import bot_id_from_token, bot_status

# The website's own files (pages, styles, scripts, icons). The same folder goes on Netlify (netlify.py).
STATIC = Path(__file__).resolve().parent.parent / "Website"
NEXT_COOKIE = "com_oauth_next"
NEXT_SHAPE = re.compile(r"^#/[A-Za-z0-9/_-]{0,120}$")  # where to go after logging in (a page of this site)
DISCORD_API = "https://discord.com/api/v10"

CSP = (
    "default-src 'self'; "
    "img-src 'self' https: data:; "
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
    "font-src 'self' https://fonts.gstatic.com; "
    "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
)


def behind_proxy() -> bool:
    """True when Caddy, nginx or a Cloudflare tunnel passes visitors on to the dashboard."""
    return os.getenv("DASHBOARD_BEHIND_PROXY", "").strip().lower() in ("1", "true", "yes", "on")


def _json(data, status: int = 200):
    return web.json_response(data, status=status)


def build_app(runner, auth: Auth, api: Api, access: Access) -> web.Application:

    def site(request: web.Request) -> str:
        """The website's address as the visitor sees it (for the Discord redirect)."""
        if behind_proxy():
            scheme = request.headers.get("X-Forwarded-Proto", "https").split(",")[0].strip()
            host = request.headers.get("X-Forwarded-Host", "").split(",")[0].strip() or request.host
        else:
            scheme, host = request.scheme, request.host
        return auth.site_url(scheme, host)

    def secure(request) -> bool:
        return site(request).startswith("https://")

    def set_session(resp: web.StreamResponse, request, token: str):
        resp.set_cookie(COOKIE, token, max_age=SESSION_SECONDS, httponly=True,
                        samesite="Lax", secure=secure(request), path="/")

    def client_id() -> str:
        """The bot's application ID. Works before the bot is online too: a bot token starts with it."""
        bot = runner.bot
        live = bot and (bot.application_id or (bot.user.id if bot.user else None))
        return auth.client_id or str(live or bot_id_from_token(runner.token or "") or "")

    def current_user(request: web.Request) -> dict | None:
        session = auth.unsign(request.cookies.get(COOKIE))
        if not session:
            return None
        user = {"id": session.get("id"), "name": session.get("name"), "avatar": session.get("avatar"),
                "method": session.get("method"), "at": session.get("at")}
        user["bot_owner"] = access.is_bot_owner(user)
        return user

    def public_user(user: dict | None) -> dict | None:
        return {k: v for k, v in user.items() if k != "at"} if user else None

    def csrf_ok(request) -> bool:
        return request.method == "GET" or request.headers.get("X-Dashboard") == "1"

    @web.middleware
    async def middleware(request: web.Request, handler):
        try:
            resp = await handler(request)
        except web.HTTPException as e:
            resp = e
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        resp.headers.setdefault("Content-Security-Policy", CSP)
        if request.path.startswith("/static/"):
            resp.headers.setdefault("Cache-Control", "no-cache")  # after an update, browsers fetch the new files
        else:
            # API answers, logins and transcripts are per person: nothing in between (Netlify, Cloudflare) may keep them
            resp.headers.setdefault("Cache-Control", "no-store")
        if isinstance(resp, web.HTTPException) and resp.status >= 300:
            raise resp
        return resp

    # ── pages ──

    async def index(request):
        return web.FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})

    async def favicon(request):  # browsers also ask for /favicon.ico by themselves
        return web.FileResponse(STATIC / "favicon.ico", headers={"Cache-Control": "no-cache", "Content-Type": "image/x-icon"})

    async def public_info(request):
        return _json(access.public_info())

    # ── logging in ──

    async def session_info(request):
        return _json({
            "user": public_user(current_user(request)),
            "methods": {"discord": auth.discord_enabled},
            "bot": bot_status(runner),
        })

    async def login_setup(request):
        """For the "add this redirect" page: the address to add and what's listed already."""
        listed = await access.redirect_uris(fresh=True) if auth.discord_enabled else None
        redirect = auth.redirect_uri(site(request))
        cid = client_id()
        return _json({
            "discord": auth.discord_enabled, "redirect_uri": redirect,
            "listed": listed, "ok": None if listed is None else redirect in listed,
            "portal": f"https://discord.com/developers/applications/{cid}/oauth2" if cid else "https://discord.com/developers/applications",
        })

    async def logout(request):
        resp = _json({"ok": True})
        resp.del_cookie(COOKIE, path="/")
        return resp

    async def discord_login(request):
        if not auth.discord_enabled:
            raise web.HTTPFound("/?login_error=off")
        after = request.query.get("next", "")
        redirect = auth.redirect_uri(site(request))
        # Discord only shows "Invalid OAuth2 redirect_uri" when this address isn't listed under
        # Redirects, so check first and show which one to add (skip=1: go to Discord anyway)
        if request.query.get("skip") != "1":
            listed = await access.redirect_uris(fresh=request.query.get("fresh") == "1")
            if listed is not None and redirect not in listed:
                print(f"[Dashboard] Someone tried to log in, but {redirect} isn't under Redirects in the Developer Portal yet.")
                raise web.HTTPFound("/#/login-setup" + (f"?next={quote(after)}" if NEXT_SHAPE.match(after) else ""))
        state = secrets.token_urlsafe(24)
        url = "https://discord.com/oauth2/authorize?" + urlencode({
            "client_id": client_id(), "response_type": "code", "scope": "identify guilds",
            "redirect_uri": redirect, "state": state, "prompt": "none",
        })
        resp = web.HTTPFound(url)
        resp.set_cookie(STATE_COOKIE, state, max_age=600, httponly=True, samesite="Lax", secure=secure(request), path="/")
        if NEXT_SHAPE.match(after):
            resp.set_cookie(NEXT_COOKIE, after, max_age=600, httponly=True, samesite="Lax", secure=secure(request), path="/")
        else:
            resp.del_cookie(NEXT_COOKIE, path="/")
        raise resp

    async def discord_callback(request):
        def fail(reason: str):
            resp = web.HTTPFound(f"/?login_error={reason}")
            resp.del_cookie(STATE_COOKIE, path="/")
            return resp

        code, state = request.query.get("code"), request.query.get("state")
        if not auth.discord_enabled or not code or not state or state != request.cookies.get(STATE_COOKIE):
            raise fail("expired")
        try:
            async with aiohttp.ClientSession() as http:
                async with http.post(f"{DISCORD_API}/oauth2/token", data={
                    "client_id": client_id(), "client_secret": auth.client_secret,
                    "grant_type": "authorization_code", "code": code, "redirect_uri": auth.redirect_uri(site(request)),
                }) as r:
                    if r.status != 200:
                        print(f"[Dashboard] Discord login failed ({r.status}): {await r.text()}")
                        raise fail("discord")
                    token = await r.json()
                async with http.get(f"{DISCORD_API}/users/@me",
                                    headers={"Authorization": f"Bearer {token['access_token']}"}) as r:
                    user = await r.json()
        except aiohttp.ClientError as e:
            print(f"[Dashboard] Couldn't reach Discord for login: {e}")
            raise fail("discord")

        after = request.cookies.get(NEXT_COOKIE, "")
        resp = web.HTTPFound("/" + (after if NEXT_SHAPE.match(after) else "#/servers"))
        resp.del_cookie(STATE_COOKIE, path="/")
        resp.del_cookie(NEXT_COOKIE, path="/")
        set_session(resp, request, auth.discord_session(user, token["access_token"]))
        raise resp

    # ── your servers, bot settings ──

    async def guild_list(request):
        user = current_user(request)
        if user is None:
            return _json({"error": "Log in to see your servers."}, 401)
        try:
            return _json(await access.guild_list(user))
        except LoginExpired:
            return _json({"error": "Your Discord login expired. Log in again."}, 401)

    async def owner_settings(request):
        user = current_user(request)
        if user is None:
            return _json({"error": "You're logged out. Log in again."}, 401)
        if not access.is_bot_owner(user):
            return _json({"error": "Only the bot's owner can see this."}, 403)
        body = None
        if request.method == "POST":
            if not csrf_ok(request):
                return _json({"error": "Bad request."}, 400)
            try:
                body = await request.json()
            except Exception:
                body = {}
            body = body if isinstance(body, dict) else {}
        status, data = bot_settings(auth, client_id(), site(request), body)
        return _json(data, status)

    # ── one server's dashboard ──

    def server_for(request, user):
        guild, problem = access.open_server(user, request.match_info.get("gid"))
        return guild, (_json({"error": problem[1]}, problem[0]) if problem else None)

    async def transcript_page(request):
        """A saved ticket transcript (needs access to that server)."""
        user = current_user(request)
        if user is None:
            raise web.HTTPFound("/")
        guild, error = server_for(request, user)
        if error:
            raise web.HTTPNotFound(text="That transcript doesn't exist, or you don't have access to it.")
        cog = runner.bot.get_cog("Tickets")
        record = cog.find_transcript(request.match_info["id"], guild.id) if cog else None
        path = os.path.join("transcripts", os.path.basename(record["file"])) if record else None
        if not path or not os.path.isfile(path):
            raise web.HTTPNotFound(text="That transcript doesn't exist anymore.")
        return web.FileResponse(path, headers={
            "Content-Type": "text/html; charset=utf-8",
            "Content-Security-Policy": "default-src 'none'; img-src https: data:; style-src 'unsafe-inline'; sandbox",
        })

    def make_handler(name: str):
        method = getattr(api, name)

        async def handler(request: web.Request):
            user = current_user(request)
            if user is None:
                return _json({"error": "You're logged out. Log in again."}, 401)
            if not csrf_ok(request):
                return _json({"error": "Bad request."}, 400)
            guild, error = server_for(request, user)
            if error:
                return error

            body = {}
            if request.can_read_body:
                try:
                    body = await request.json()
                except Exception:
                    return _json({"error": "That request wasn't valid JSON."}, 400)
            params = {k: v for k, v in request.match_info.items() if k != "gid"}
            req = Req(public_user(user), body if isinstance(body, dict) else {}, params, dict(request.query))
            try:
                with guild_context(guild):  # `config` = this server's settings while the handler runs
                    return _json(await method(req))
            except ApiError as e:
                return _json({"error": e.message, **e.extra}, e.status)
            except Exception as e:
                traceback.print_exc()
                return _json({"error": f"Something broke on the bot's side: {e}"}, 500)

        return handler

    app = web.Application(middlewares=[middleware], client_max_size=24 * 1024 ** 2)  # room for profile pictures
    app.router.add_get("/", index)
    app.router.add_get("/api/public", public_info)
    app.router.add_get("/favicon.ico", favicon)
    app.router.add_get("/api/session", session_info)
    app.router.add_post("/api/logout", logout)
    app.router.add_get("/login/discord", discord_login)
    app.router.add_get("/api/login-setup", login_setup)
    app.router.add_get("/callback", discord_callback)
    app.router.add_get("/api/guilds", guild_list)
    app.router.add_route("*", "/api/owner/settings", owner_settings)
    app.router.add_get("/transcripts/{gid}/{id}", transcript_page)
    for http_method, path, name in Api.ROUTES:
        app.router.add_route(http_method, "/api/g/{gid}" + path, make_handler(name))
    app.router.add_static("/static/", STATIC, append_version=False)
    return app


LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")


def _guess_ip() -> str | None:
    """This machine's main IP address (on most VPSes, the public one)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))  # no data is sent, this just picks the network card
            return s.getsockname()[0]
    except OSError:
        return None


def headless() -> bool:
    """True on a server with no screen (a VPS), where there's no browser to open."""
    return sys.platform.startswith("linux") and not (os.getenv("DISPLAY") or os.getenv("WAYLAND_DISPLAY"))


def windows_server() -> bool:
    """A Windows VPS: Windows Server, or the bot was started in a Remote Desktop session."""
    if sys.platform != "win32":
        return False
    if os.getenv("SESSIONNAME", "").upper().startswith("RDP"):
        return True
    try:
        import platform
        return "server" in (platform.win32_edition() or "").lower()
    except Exception:
        return False


def on_server() -> bool:
    """True on a VPS (Linux without a screen, or a Windows VPS)."""
    return headless() or windows_server()


def _ask_port(addr: str, port: int, path: str) -> bytes | None:
    """GET `path` from something listening on this computer. None if nothing listens there."""
    try:
        with socket.create_connection((addr, port), timeout=0.4) as s:
            s.settimeout(0.8)
            data = b""
            try:
                s.sendall(f"GET {path} HTTP/1.0\r\nHost: localhost\r\n\r\n".encode())
                while len(data) < 65536:
                    chunk = s.recv(8192)
                    if not chunk:
                        break
                    data += chunk
            except OSError:
                pass  # it's there, it just doesn't speak HTTP
            return data
    except OSError:
        return None


def port_owner(port: int) -> str | None:
    """
    What already answers on this port on this computer: None when it's free, "bot" (this bot,
    started twice), "Steam" (its web debugger sits on 8080), or "another program".
    Windows lets two programs share a port this way, and then the browser opens the other one,
    so a port that only failed to bind isn't enough to go by.
    """
    for addr in ("127.0.0.1", "::1"):
        found = _ask_port(addr, port, "/api/public")
        if found is None:
            continue
        if b'"figs"' in found:
            return "bot"
        page = (_ask_port(addr, port, "/") or b"") + found
        if b"Inspectable WebContents" in page or b"Steam" in page:
            return "Steam"
        return "another program"
    return None


PORT_TAKEN = {
    "bot": "the bot is already running in another window (close the old one)",
    "Steam": "Steam is using it on this computer (Steam's web debugger)",
    "another program": "another program on this computer is using it",
}


def pick_host() -> str:
    """
    The address the website listens on. DASHBOARD_HOST=auto (the default) listens on every
    address, so http://localhost:8080 works on the machine running the bot AND other computers
    can reach it (your PC → http://VPS-IP:8080). Behind Caddy / nginx / a Cloudflare tunnel,
    only the proxy reaches it.
    """
    raw = os.getenv("DASHBOARD_HOST", "").strip()
    if raw.lower() in ("", "auto"):
        return "127.0.0.1" if behind_proxy() else "0.0.0.0"
    return raw


async def public_ip() -> str | None:
    """This machine's address on the internet, for the link to open on your PC."""
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3)) as http:
            async with http.get("https://api.ipify.org") as r:
                text = (await r.text()).strip()
        ipaddress.ip_address(text)
        return text
    except Exception:
        return None


def _is_private(ip: str) -> bool:
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return True


def firewall_blocks(port: int) -> bool | None:
    """True if ufw is on and doesn't allow the port, False if it's fine, None if we can't tell."""
    if not sys.platform.startswith("linux") or not shutil.which("ufw"):
        return None
    try:
        out = subprocess.run(["ufw", "status"], capture_output=True, text=True, timeout=3).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    if "Status: active" not in out:
        return None if "Status: inactive" not in out else False
    return not re.search(rf"^{port}(/tcp)?\s+ALLOW", out, re.M)


def moved_url(base: str, old: int, new: int) -> str | None:
    """http://localhost:8080 → http://localhost:8081 when the website moved ports. Domains are left alone."""
    m = re.match(r"^(https?://)(localhost|127\.0\.0\.1|\d{1,3}(?:\.\d{1,3}){3}|\[[0-9a-fA-F:]+\]):(\d+)$", base or "")
    if not m or int(m.group(3)) != old:
        return None
    return f"{m.group(1)}{m.group(2)}:{new}"


async def check_redirects(bot_runner, auth, access, sites: list[str]):
    """Once the bot is online, say which redirects are still missing in the Developer Portal."""
    for _ in range(90):
        if bot_runner.state == "online":
            break
        await asyncio.sleep(1)
    else:
        return
    listed = await access.redirect_uris(fresh=True)
    if listed is None:
        return
    missing = [auth.redirect_uri(s) for s in sites if auth.redirect_uri(s) not in listed]
    if not missing:
        print("[Dashboard] The redirects are set up in the Developer Portal. Login with Discord is ready.")
        return
    print("[Dashboard] ------------------------------------------------------------")
    print("[Dashboard] Login with Discord won't work yet: add these under Redirects")
    print("[Dashboard] (Developer Portal → your bot → OAuth2 → Redirects → Add Redirect → Save Changes):")
    for r in missing:
        print(f"[Dashboard]     {r}")
    if listed:
        print("[Dashboard] Listed there now: " + ", ".join(listed))
    print("[Dashboard] ------------------------------------------------------------")


def print_login_help(auth, sites: list[str]):
    """Logging in is Login with Discord only, so say how to set it up (or that it's ready)."""
    if auth.discord_enabled:
        print("[Dashboard] Log in with Discord. In the Developer Portal (your bot → OAuth2 → Redirects), these must be listed:")
    else:
        print("[Dashboard] Nobody can log in to the website yet: it needs your bot's Client Secret.")
        print("[Dashboard]   1. discord.com/developers/applications → your bot → OAuth2 → copy the Client Secret")
        print("[Dashboard]   2. Put it in the .env file as DISCORD_CLIENT_SECRET=... (or start the bot in a window and paste it when asked)")
        print("[Dashboard]   3. On the same OAuth2 page, under Redirects, add:")
    for s in sites:
        print(f"[Dashboard]        {auth.redirect_uri(s)}")


async def start_dashboard(bot_runner) -> str | None:
    """Start the website. Returns its address, or None if it's turned off / couldn't start."""
    if os.getenv("DASHBOARD_ENABLED", "true").strip().lower() in ("0", "false", "no", "off"):
        print("[Dashboard] Turned off in .env")
        return None

    host = pick_host()
    port = int(os.getenv("DASHBOARD_PORT") or os.getenv("PORT") or os.getenv("SERVER_PORT") or 8080)
    # reachable from other devices, not just this machine (directly, or through a proxy)
    public = host not in LOCAL_HOSTS or behind_proxy()

    # The website on Netlify (netlify.py): its address is the website's address while the bot runs.
    # Only for this run: the .env file keeps its own DASHBOARD_URL.
    netlify_site = netlify.configured()
    own_url = os.getenv("DASHBOARD_URL", "")
    if netlify_site:
        os.environ["DASHBOARD_URL"] = netlify.site_url(netlify_site)

    auth, api, access = Auth(bot_runner), Api(bot_runner), Access(bot_runner)
    runner = web.AppRunner(build_app(bot_runner, auth, api, access), access_log=None)
    await runner.setup()
    wanted, taken_by = port, None
    # A public address (a domain, a Netlify site you point by hand) is set up to reach this exact port:
    # moving would cut it off. The bot's own Netlify link follows the port, so it can move.
    pinned = not netlify_site and bool(auth.base_url) and moved_url(auth.base_url, wanted, wanted) is None
    for port in range(wanted, wanted + 10):  # port taken: try the next one
        owner = port_owner(port)
        if owner is None:
            try:
                await web.TCPSite(runner, host, port).start()
                break
            except PermissionError:
                owner = "only an administrator can use it here (run the bot as administrator, or as root on Linux)"
            except OSError as e:
                owner = f"it's in use ({e.strerror or e})"
        reason = PORT_TAKEN.get(owner, owner)
        print(f"[Dashboard] Port {port} is taken: {reason}.")
        if pinned:
            print(f"[Dashboard] The website isn't running: {auth.base_url} is set up to reach port {port}, so it can't move to another one.")
            print(f"[Dashboard] Free port {port} (close what's using it), or change DASHBOARD_PORT and update {auth.base_url} to match.")
            return None
        taken_by = taken_by or owner
    else:
        print(f"[Dashboard] Couldn't start on ports {wanted}-{wanted + 9}. Change DASHBOARD_PORT in .env.")
        return None
    if port != wanted:
        print(f"[Dashboard] Using port {port} instead.")
        # Keep the new address next time too (Login with Discord needs the same address every time),
        # unless it's only the bot running twice, or a hosting panel picked the port
        panel_port = not os.getenv("DASHBOARD_PORT") and (os.getenv("PORT") or os.getenv("SERVER_PORT"))
        if taken_by != "bot" and not panel_port:
            save_env_value("DASHBOARD_PORT", str(port))
            os.environ["DASHBOARD_PORT"] = str(port)
            print(f"[Dashboard] Saved DASHBOARD_PORT={port} in .env, so the website keeps this address.")
            # A DASHBOARD_URL like http://localhost:8080 would now send logins back to the other program
            moved = moved_url(auth.base_url, wanted, port)
            if moved:
                save_env_value("DASHBOARD_URL", moved)
                os.environ["DASHBOARD_URL"] = moved
                auth.reload()
                print(f"[Dashboard] DASHBOARD_URL in .env pointed at port {wanted}: changed it to {moved}.")

    url = f"http://localhost:{port}"
    sites = [auth.base_url] if auth.base_url else [url]  # addresses people open the website with
    if netlify_site:
        print("[Dashboard] ------------------------------------------------------------")
        print(f"[Dashboard]   Website:  {auth.base_url}")
        print("[Dashboard]   It's on Netlify and connects to this PC by itself (see the [Website] lines).")
        print(f"[Dashboard]   On this PC it also opens at {url}, but log in on the Netlify address.")
        print("[Dashboard] ------------------------------------------------------------")
    elif behind_proxy() and host in LOCAL_HOSTS:
        print(f"[Dashboard] Running on port {port} behind your proxy (HTTPS site: {auth.base_url or 'set DASHBOARD_URL'})")
    elif public and on_server():
        ip = host if host not in ("0.0.0.0", "::") else (await public_ip() or _guess_ip())
        print("[Dashboard] ------------------------------------------------------------")
        print(f"[Dashboard]   On your PC, open:   http://{ip or 'YOUR-VPS-IP'}:{port}")
        print(f"[Dashboard]   On this VPS:        {url}")
        print("[Dashboard] ------------------------------------------------------------")
        if ip and not auth.base_url:
            sites.append(f"http://{ip}:{port}")
        if ip and _is_private(ip) and host in ("0.0.0.0", "::"):
            print("[Dashboard]   (that's a private address: from your PC, use the VPS IP your host's control panel shows)")
        if sys.platform == "win32":
            print(f"[Dashboard] Doesn't load on your PC? Windows Firewall blocks port {port} at first. If Windows asks, click Allow,")
            print("[Dashboard] or run this once in an admin Command Prompt on the VPS:")
            print(f'[Dashboard]   netsh advfirewall firewall add rule name="Bot dashboard" dir=in action=allow protocol=TCP localport={port}')
            print("[Dashboard] Also allow the port in your host's control panel if it has a firewall there.")
        else:
            blocked = firewall_blocks(port)
            if blocked:
                print(f"[Dashboard] The VPS firewall blocks port {port}. Run this once to open it:  sudo ufw allow {port}/tcp")
            elif blocked is None:
                print(f"[Dashboard] Doesn't load on your PC? Allow port {port} in the VPS firewall (sudo ufw allow {port}/tcp)")
                print("[Dashboard] and in your host's control panel if it has a firewall there.")
    else:
        print(f"[Dashboard] Open {url} in your browser")
        lan = _guess_ip() if host in ("0.0.0.0", "::") else None
        if lan and _is_private(lan):
            print(f"[Dashboard] Other devices on the same Wi-Fi: http://{lan}:{port}")
    print_login_help(auth, sites)
    if netlify_site:
        def give_up():
            # It can't work this time: logging in goes back to this PC's own address
            if own_url:
                os.environ["DASHBOARD_URL"] = own_url
            else:
                os.environ.pop("DASHBOARD_URL", None)
            auth.reload()
            print(f"[Website] Not on Netlify this time. The website still works on this PC: {own_url or url}")

        local = {"0.0.0.0": "127.0.0.1", "::": "[::1]", "": "127.0.0.1"}.get(host) or (f"[{host}]" if ":" in host else host)
        link = netlify.Link(bot_runner, access, netlify_site, os.getenv("NETLIFY_TOKEN", "").strip(),
                            f"http://{local}:{port}", CSP, give_up=give_up)
        bot_runner.link = link
        link.start()
    if auth.discord_enabled:
        asyncio.get_running_loop().create_task(check_redirects(bot_runner, auth, access, sites))
    bot_runner.web = runner
    return url
