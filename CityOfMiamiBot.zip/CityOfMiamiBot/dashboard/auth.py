"""
Logins for the dashboard: Login with Discord, nothing else. The bot token never goes into the
website; it lives in the .env file (the console asks for it the first time).

Turn Login with Discord on by putting the bot's Client Secret in .env as DISCORD_CLIENT_SECRET
(the console asks for it too). Who can open which server is decided in access.py.

Sessions are signed cookies.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time

SECRET_FILE = ".dashboard_secret"
COOKIE = "com_dashboard"
STATE_COOKIE = "com_oauth_state"
SESSION_SECONDS = 7 * 86400


def _load_secret() -> bytes:
    env = os.getenv("DASHBOARD_SECRET", "").strip()
    if env:
        return env.encode()
    try:
        with open(SECRET_FILE, "r", encoding="utf-8") as f:
            value = f.read().strip()
            if value:
                return value.encode()
    except FileNotFoundError:
        pass
    value = secrets.token_hex(32)
    with open(SECRET_FILE, "w", encoding="utf-8") as f:
        f.write(value)
    return value.encode()


def default_avatar(user_id: int | str) -> str:
    return f"https://cdn.discordapp.com/embed/avatars/{(int(user_id) >> 22) % 6}.png"


HOST_SHAPE = re.compile(r"^[A-Za-z0-9.\-]+(:\d{1,5})?$|^\[[0-9A-Fa-f:.]+\](:\d{1,5})?$")


class Auth:
    def __init__(self, runner):
        self.runner = runner
        self.reload()
        self.secret = _load_secret()

    def reload(self):
        """Pick up Discord login settings (after they're changed on the Bot settings page)."""
        self.client_id = os.getenv("DISCORD_CLIENT_ID", "").strip()
        self.client_secret = os.getenv("DISCORD_CLIENT_SECRET", "").strip()
        self.base_url = os.getenv("DASHBOARD_URL", "").strip().rstrip("/")

    @property
    def discord_enabled(self) -> bool:
        return bool(self.client_secret)

    def site_url(self, scheme: str, host: str) -> str:
        """The website's address: DASHBOARD_URL if it's set, otherwise the address it was opened with."""
        if self.base_url:
            return self.base_url
        scheme = scheme if scheme in ("http", "https") else "http"
        host = host if HOST_SHAPE.match(host or "") else "localhost"
        return f"{scheme}://{host}"

    def redirect_uri(self, site: str) -> str:
        """Where Discord sends people back to. It has to be listed under OAuth2 → Redirects."""
        return f"{site}/callback"

    # ── signing ──

    def _sig(self, data: str) -> str:
        return hmac.new(self.secret, data.encode(), hashlib.sha256).hexdigest()

    def sign(self, payload: dict) -> str:
        data = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode().rstrip("=")
        return f"{data}.{self._sig(data)}"

    def unsign(self, token: str | None) -> dict | None:
        if not token or "." not in token:
            return None
        data, sig = token.rsplit(".", 1)
        if not hmac.compare_digest(sig, self._sig(data)):
            return None
        try:
            payload = json.loads(base64.urlsafe_b64decode(data + "=" * (-len(data) % 4)))
        except (ValueError, json.JSONDecodeError):
            return None
        if payload.get("exp", 0) < time.time():
            return None
        if payload.get("method") != "discord" or not payload.get("id"):
            return None  # old bot token logins from before Login with Discord was the only way in
        return payload

    # ── sessions ──

    def discord_session(self, user: dict, access_token: str = "") -> str:
        uid = str(user["id"])
        avatar = (
            f"https://cdn.discordapp.com/avatars/{uid}/{user['avatar']}.png?size=64"
            if user.get("avatar") else default_avatar(uid)
        )
        return self.sign({
            "method": "discord", "id": uid, "name": user.get("global_name") or user.get("username", "Unknown"),
            "avatar": avatar, "at": access_token, "exp": int(time.time()) + SESSION_SECONDS,
        })


def member_can_use(member, guild, config: dict) -> bool:
    """The server owner, Administrator, Manage Server, or someone given access on the Dashboard access page."""
    if member is None:
        return False
    if guild.owner_id == member.id:
        return True
    perms = member.guild_permissions
    if perms.administrator or perms.manage_guild:
        return True
    if member.id in set(config.get("dashboard_user_ids", [])):
        return True
    allowed = set(config.get("dashboard_role_ids", []))
    return any(r.id in allowed for r in member.roles)
