"""
The website on Netlify while the bot runs on your PC. Nothing to install or set up by hand.

Netlify only hosts files, and your router keeps the internet away from your PC, so each time the
bot starts it does this by itself:

  1. It starts a Cloudflare quick tunnel. Cloudflare's small cloudflared program (the bot downloads
     it into the tools folder the first time) connects out from this PC and gets a temporary
     https://<random-words>.trycloudflare.com address that reaches the website on this PC.
  2. It uploads the Website folder to your Netlify site, with rules that pass logins and the
     dashboard's data on to that address. The address changes every start, so every start uploads.

https://yoursite.netlify.app then always shows the website, also while the PC is off (the bot
shows as offline), and the dashboard works whenever the bot runs.

Set up once in .env (the bot's window asks for both the first time):
  NETLIFY_TOKEN   a Netlify personal access token (app.netlify.com/user/applications)
  NETLIFY_SITE    the site's name: yoursite for yoursite.netlify.app (off = don't use Netlify)
"""
import asyncio
import atexit
import hashlib
import io
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import threading
import time
import zipfile
from pathlib import Path

import aiohttp

ROOT = Path(__file__).resolve().parent.parent
WEBSITE = ROOT / "Website"
TOOLS = ROOT / "tools"

API = "https://api.netlify.com/api/v1"
TOKEN_PAGE = "https://app.netlify.com/user/applications#personal-access-tokens"
RELEASES = "https://api.github.com/repos/cloudflare/cloudflared/releases/latest"
DOWNLOADS = "https://github.com/cloudflare/cloudflared/releases/"  # the only place the program comes from
LATEST = DOWNLOADS + "latest/download/"

TUNNEL_ADDRESS = re.compile(r"https://(?!api\.)[a-z0-9-]+\.trycloudflare\.com")
SITE_NAME = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
OFF = ("off", "no", "false", "0", "none")
# What the bot answers itself. Everything else (the pages, styles, icons) is a file on Netlify.
PROXIED = ("/api/*", "/login/*", "/callback", "/transcripts/*")
SKIP_FILES = {"desktop.ini", "thumbs.db"}
HEADERS = {"User-Agent": "discord-bot-dashboard"}
POLL_SECONDS = 2
DEPLOYS_PER_MINUTE = 3  # Netlify's limit (and 100 a day)


def say(line: str):
    print(f"[Website] {line}", flush=True)


# ── settings ──

def site_name(raw: str | None) -> str | None:
    """yoursite, yoursite.netlify.app or https://yoursite.netlify.app/ → yoursite (None if it can't be a site name)."""
    text = re.sub(r"^https?://", "", (raw or "").strip().lower()).split("/")[0]
    if text.endswith(".netlify.app"):
        text = text[: -len(".netlify.app")]
    return text if SITE_NAME.match(text) else None


def site_url(name: str) -> str:
    return f"https://{name}.netlify.app"


def turned_off() -> bool:
    return os.getenv("NETLIFY_SITE", "").strip().lower() in OFF


def configured() -> str | None:
    """The Netlify site's name, when the website should go on Netlify (NETLIFY_SITE and NETLIFY_TOKEN set)."""
    if turned_off() or not os.getenv("NETLIFY_TOKEN", "").strip():
        return None
    return site_name(os.getenv("NETLIFY_SITE"))


def needs_setup() -> bool:
    """Not set up and not turned off: the bot's window offers to set it up."""
    return configured() is None and not turned_off()


# ── Netlify ──

class NetlifyError(Exception):
    def __init__(self, message: str, status: int = 0, wait: float = 0):
        super().__init__(message)
        self.status = status
        self.wait = wait  # seconds until Netlify takes another upload (status 429)


BAD_TOKEN = ("Netlify didn't accept the access token (it may have expired or been deleted). "
             f"Make a new one at {TOKEN_PAGE}, remove the NETLIFY_TOKEN line from the .env file "
             "and restart the bot: it asks for the new one.")


class Netlify:
    """The few Netlify API calls the bot needs (docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api)."""

    def __init__(self, token: str, http: aiohttp.ClientSession):
        self.http = http
        self.headers = {"Authorization": f"Bearer {token}", **HEADERS}

    async def call(self, method: str, path: str, *, json_body=None, data: bytes | None = None,
                   content_type: str | None = None):
        headers = dict(self.headers)
        if content_type:
            headers["Content-Type"] = content_type
        try:
            async with self.http.request(method, API + path, json=json_body, data=data, headers=headers) as r:
                try:
                    body = await r.json(content_type=None)
                except (ValueError, aiohttp.ContentTypeError):
                    body = None
                if r.status in (200, 201):
                    return body
                message = (body or {}).get("message") if isinstance(body, dict) else None
                if r.status == 401:
                    raise NetlifyError(BAD_TOKEN, 401)
                if r.status == 429:
                    try:
                        wait = max(1.0, float(r.headers.get("X-RateLimit-Reset", "0")) - time.time())
                    except ValueError:
                        wait = 60.0
                    raise NetlifyError("Netlify only takes a few uploads a minute.", 429, min(wait, 3600))
                raise NetlifyError(f"Netlify said: {message or r.reason or 'error'} ({r.status}).", r.status)
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            raise NetlifyError(f"Couldn't reach Netlify ({e.__class__.__name__}). Is the internet working?") from e

    async def user(self) -> dict:
        return await self.call("GET", "/user") or {}

    async def find_site(self, name: str) -> dict | None:
        try:
            return await self.call("GET", f"/sites/{name}.netlify.app")
        except NetlifyError as e:
            if e.status == 404:
                return None  # no such site in this account
            raise

    async def open_site(self, name: str) -> tuple[dict, bool]:
        """The site called `name` in this Netlify account, made first if it doesn't exist. (site, made_now)"""
        site = await self.find_site(name)
        if site:
            return site, False
        try:
            return await self.call("POST", "/sites", json_body={"name": name}), True
        except NetlifyError as e:
            if e.status == 422:
                raise NetlifyError(f"{name}.netlify.app is taken by someone else's site. Pick another name.", 422) from e
            raise

    async def deploy(self, site_id: str, zipped: bytes) -> dict:
        """Upload the website as a zip and wait until it's live."""
        d = await self.call("POST", f"/sites/{site_id}/deploys", data=zipped, content_type="application/zip") or {}
        deadline = time.monotonic() + 180
        while d.get("state") not in ("ready", "error") and time.monotonic() < deadline:
            await asyncio.sleep(POLL_SECONDS)
            d = await self.call("GET", f"/deploys/{d.get('id')}") or {}
        if d.get("state") == "error":
            raise NetlifyError(f"Netlify couldn't publish the upload: {d.get('error_message') or 'no reason given'}.")
        if d.get("state") != "ready":
            raise NetlifyError("Netlify is still publishing the upload. It goes live by itself when it's done.")
        return d


async def check_setup(token: str, name: str | None = None) -> tuple[dict, dict | None, bool]:
    """For the bot's window: (Netlify account, site, made_now). Raises NetlifyError."""
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as http:
        nf = Netlify(token, http)
        user = await nf.user()
        if not name:
            return user, None, False
        site, made = await nf.open_site(name)
        return user, site, made


# ── what goes on Netlify ──

def redirects_file(tunnel: str) -> str:
    lines = ["# Made by the bot each time it starts (dashboard/netlify.py): the address changes every start.",
             "# Logins and the dashboard's data go to the bot on your PC. Everything else is a file here."]
    for path in PROXIED:
        lines.append(f"{path}  {tunnel}{path.replace('*', ':splat')}  200!")
    return "\n".join(lines) + "\n"


def headers_file(csp: str) -> str:
    """The same safety headers the bot sends (Netlify sends these with the files; the bot's answers keep its own)."""
    return ("/*\n"
            "  X-Content-Type-Options: nosniff\n"
            "  X-Frame-Options: DENY\n"
            "  Referrer-Policy: same-origin\n"
            f"  Content-Security-Policy: {csp}\n")


def build_zip(tunnel: str, csp: str, snapshot: dict | None = None, folder: Path | None = None) -> bytes:
    """
    The website as Netlify gets it: index.html and favicon.ico at the top, every file of the Website
    folder under static/ (the same addresses the bot uses), the rules, and site-info.json (what the
    home page shows while the bot is off).
    """
    folder = folder or WEBSITE
    buf = io.BytesIO()

    def put(name: str, data: bytes):
        info = zipfile.ZipInfo(name, date_time=(2024, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        z.writestr(info, data)

    with zipfile.ZipFile(buf, "w") as z:
        for f in sorted(folder.rglob("*")):
            rel = f.relative_to(folder)
            if not f.is_file() or any(p.startswith(".") for p in rel.parts) or f.name.lower() in SKIP_FILES:
                continue
            put("static/" + rel.as_posix(), f.read_bytes())
        put("index.html", (folder / "index.html").read_bytes())
        if (folder / "favicon.ico").is_file():
            put("favicon.ico", (folder / "favicon.ico").read_bytes())
        if snapshot:
            put("site-info.json", json.dumps(snapshot, separators=(",", ":")).encode())
        put("_redirects", redirects_file(tunnel).encode())
        put("_headers", headers_file(csp).encode())
    return buf.getvalue()


# ── Cloudflare's tunnel program ──

class TunnelError(Exception):
    pass


def asset_name() -> str | None:
    """Which file of Cloudflare's releases runs on this computer."""
    machine = platform.machine().lower()
    if sys.platform == "win32":
        return "cloudflared-windows-386.exe" if machine in ("x86", "i386", "i686") else "cloudflared-windows-amd64.exe"
    if sys.platform == "darwin":
        return "cloudflared-darwin-arm64.tgz" if machine in ("arm64", "aarch64") else "cloudflared-darwin-amd64.tgz"
    if sys.platform.startswith("linux"):
        return {
            "x86_64": "cloudflared-linux-amd64", "amd64": "cloudflared-linux-amd64",
            "aarch64": "cloudflared-linux-arm64", "arm64": "cloudflared-linux-arm64",
            "armv7l": "cloudflared-linux-arm", "armv6l": "cloudflared-linux-arm",
            "i386": "cloudflared-linux-386", "i686": "cloudflared-linux-386",
        }.get(machine)
    return None


def program_file() -> Path:
    return TOOLS / ("cloudflared.exe" if sys.platform == "win32" else "cloudflared")


def find_cloudflared() -> str | None:
    """CLOUDFLARED_PATH from .env, the copy in the tools folder, or one that's already installed."""
    custom = os.getenv("CLOUDFLARED_PATH", "").strip().strip('"')
    if custom:
        return custom if Path(custom).is_file() else None
    ours = program_file()
    if ours.is_file():
        return str(ours)
    return shutil.which("cloudflared")


async def download_cloudflared(http: aiohttp.ClientSession) -> tuple[str, bool]:
    """
    Download cloudflared from Cloudflare's GitHub releases into the tools folder.
    Returns (path, checked): checked = it matched the SHA-256 fingerprint GitHub lists for that file.
    """
    name = asset_name()
    if not name:
        raise TunnelError(f"Cloudflare has no tunnel program for this computer ({sys.platform}, {platform.machine()}).")
    url, expected = LATEST + name, None
    try:
        async with http.get(RELEASES, headers={**HEADERS, "Accept": "application/vnd.github+json"}) as r:
            release = await r.json(content_type=None) if r.status == 200 else {}
        for asset in release.get("assets") or []:
            if asset.get("name") == name:
                if str(asset.get("browser_download_url") or "").startswith(DOWNLOADS):
                    url = asset["browser_download_url"]
                digest = str(asset.get("digest") or "")
                if re.match(r"^sha256:[0-9a-f]{64}$", digest):
                    expected = digest[7:]
        if not expected:  # older releases: the fingerprints are listed in the release notes
            m = re.search(rf"^\s*{re.escape(name)}\s*:\s*([0-9a-f]{{64}})\s*$", release.get("body") or "", re.M)
            expected = m.group(1) if m else None
    except (aiohttp.ClientError, asyncio.TimeoutError, ValueError, AttributeError):
        pass  # GitHub's list didn't load: download the latest one anyway (it can't be checked)

    TOOLS.mkdir(exist_ok=True)
    part = TOOLS / (name + ".part")
    sha = hashlib.sha256()
    try:
        async with http.get(url, headers=HEADERS, timeout=aiohttp.ClientTimeout(total=600, sock_read=60)) as r:
            if r.status != 200:
                raise TunnelError(f"Couldn't download Cloudflare's tunnel program (GitHub answered {r.status}).")
            with open(part, "wb") as f:
                async for chunk in r.content.iter_chunked(1 << 16):
                    sha.update(chunk)
                    f.write(chunk)
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        part.unlink(missing_ok=True)
        raise TunnelError(f"Couldn't download Cloudflare's tunnel program ({e.__class__.__name__}). Is the internet working?") from e
    if expected and sha.hexdigest() != expected:
        part.unlink(missing_ok=True)
        raise TunnelError("The downloaded tunnel program didn't match the fingerprint Cloudflare published, so it was "
                          "deleted. Restart the bot to download it again.")

    final = program_file()
    if name.endswith(".tgz"):  # macOS: the program is inside an archive
        try:
            with tarfile.open(part) as tar:
                member = next((m for m in tar.getmembers() if m.isfile() and Path(m.name).name == "cloudflared"), None)
                data = tar.extractfile(member).read() if member else None
        finally:
            part.unlink(missing_ok=True)
        if not data:
            raise TunnelError("Cloudflare's download didn't have the tunnel program in it.")
        final.write_bytes(data)
    else:
        os.replace(part, final)
    if sys.platform != "win32":
        final.chmod(0o755)
    return str(final), bool(expected)


def _no_console() -> bool:
    """Windows, and the bot has no window of its own."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        return not ctypes.windll.kernel32.GetConsoleWindow()
    except Exception:
        return False


class Tunnel:
    """Runs cloudflared and starts it again if it stops. Calls on_address(url) with every new address."""

    def __init__(self, program: str, origin: str, on_address):
        self.program, self.origin, self.on_address = program, origin, on_address
        self.proc: subprocess.Popen | None = None
        self.address: str | None = None
        self.stopped = False
        self.tasks: set[asyncio.Task] = set()
        atexit.register(self.kill)  # don't leave it running after the bot closes

    async def run(self):
        failures = 0
        while not self.stopped:
            started = time.monotonic()
            found = await self._run_once()
            if self.stopped:
                return
            # ran for a good while: start again soon. Kept failing: wait longer each time (up to 5 minutes)
            failures = 0 if found and time.monotonic() - started > 300 else failures + 1
            wait = min(300, 5 * 2 ** min(failures - 1, 6)) if failures else 5
            say(f"The tunnel to Cloudflare closed. Opening a new one in {wait} seconds...")
            await asyncio.sleep(wait)

    async def _run_once(self) -> bool:
        """Run cloudflared once, until it stops. True if it gave an address."""
        loop = asyncio.get_running_loop()
        try:
            # Shares the bot's window (without printing in it), so closing the window or Ctrl+C closes it too.
            # A bot running without a window (pythonw, a service) doesn't get a new window for it either.
            self.proc = subprocess.Popen(
                [self.program, "tunnel", "--no-autoupdate", "--url", self.origin],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if _no_console() else 0)
        except OSError as e:
            say(f"Couldn't start Cloudflare's tunnel program ({self.program}): {e}")
            return False
        proc, done = self.proc, loop.create_future()
        state = {"found": False, "tail": []}

        def new_address(url: str):
            self.address = url
            task = loop.create_task(self.on_address(url))
            self.tasks.add(task)  # keep a hold of it until it's done
            task.add_done_callback(self.tasks.discard)

        def read():
            # Its output is read all the time (a full pipe would stall it), in a thread so this works
            # with any event loop
            try:
                for raw in iter(proc.stderr.readline, b""):
                    text = raw.decode("utf-8", "replace").rstrip()
                    state["tail"] = (state["tail"] + [text])[-15:]
                    m = None if state["found"] else TUNNEL_ADDRESS.search(text)
                    if m:
                        state["found"] = True
                        loop.call_soon_threadsafe(new_address, m.group(0))
                proc.wait()
            finally:
                try:
                    loop.call_soon_threadsafe(lambda: done.done() or done.set_result(None))
                except RuntimeError:
                    pass  # the bot already stopped

        threading.Thread(target=read, name="cloudflared-output", daemon=True).start()
        await done
        if not state["found"] and not self.stopped:
            tail = state["tail"]
            errors = [t for t in tail if " ERR " in t or "error" in t.lower()][-3:] or tail[-2:]
            say("Cloudflare's tunnel didn't start" + (":" if errors else "."))
            for t in errors:
                say(f"    {t}")
        return state["found"]

    def kill(self):
        p = self.proc
        if p is None or p.poll() is not None:
            return
        try:
            p.kill()
        except Exception:
            try:
                os.kill(p.pid, signal.SIGTERM)
            except Exception:
                pass

    def stop(self):
        self.stopped = True
        self.kill()


# ── putting it together ──

class Link:
    """
    Keeps https://<site>.netlify.app connected to this PC while the bot runs: opens the tunnel and
    uploads the website pointing at it, again whenever the tunnel's address changes.
    """

    def __init__(self, runner, access, name: str, token: str, origin: str, csp: str, give_up=None):
        self.runner, self.access = runner, access
        self.name, self.token, self.origin, self.csp = name, token, origin, csp
        self.url = site_url(name)
        self.give_up = give_up  # called when it can't work at all (logins go back to this PC's own address)
        self.tunnel: Tunnel | None = None
        self.site: dict | None = None
        self.deploys: list[float] = []
        self.lock = asyncio.Lock()
        self.published: str | None = None  # the tunnel address the live upload points at
        self.task: asyncio.Task | None = None
        self.first = True

    def start(self) -> asyncio.Task:
        self.task = asyncio.get_running_loop().create_task(self._main())
        return self.task

    async def _main(self):
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as http:
                self.http = http
                self.nf = Netlify(self.token, http)
                if not await self._open_site():
                    return self._give_up()
                program = find_cloudflared()
                if not program:
                    say("Getting Cloudflare's free tunnel program (only this once)...")
                    try:
                        program, checked = await download_cloudflared(http)
                    except TunnelError as e:
                        say(str(e))
                        return self._give_up()
                    say(f"Saved it in the tools folder{' (fingerprint checked)' if checked else ''}.")
                say("Connecting this PC to the website through Cloudflare...")
                self.tunnel = Tunnel(program, self.origin, self._new_address)
                await self.tunnel.run()
        except asyncio.CancelledError:
            raise
        except Exception as e:  # never take the bot down over the website
            say(f"Stopped connecting to Netlify: {e.__class__.__name__}: {e}")
        finally:
            if self.tunnel:
                self.tunnel.stop()

    def _give_up(self):
        if self.give_up:
            self.give_up()

    async def _open_site(self) -> bool:
        """Find the Netlify site (or make it). Waits for the internet if it isn't up yet."""
        wait = 10
        while True:
            try:
                self.site, made = await self.nf.open_site(self.name)
                if made:
                    say(f"Made your Netlify site: {self.url}")
                return True
            except NetlifyError as e:
                if e.status in (401, 403, 422):
                    say(str(e))
                    return False
                say(f"{e} Trying again in {wait} seconds.")
                await asyncio.sleep(wait)
                wait = min(wait * 2, 300)

    async def _new_address(self, tunnel: str):
        async with self.lock:
            if self.tunnel and tunnel != self.tunnel.address:
                return  # an even newer address came in while waiting: that one gets uploaded
            try:
                if self.first:
                    await self._wait_for_bot()
                await self._publish(tunnel)
                if self.first and self.published == tunnel:
                    self.first = False
                    await self._check_live()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # never take the bot down over the website
                if not (self.tunnel and self.tunnel.stopped):
                    say(f"Couldn't upload the website: {e}")

    async def _wait_for_bot(self):
        """The first upload carries the bot's name, picture and commands, so give it a moment to log in."""
        for _ in range(60):
            if getattr(self.runner, "state", "") == "online":
                return
            await asyncio.sleep(1)

    async def _snapshot(self) -> dict | None:
        """What the home page shows while the bot is off: the live info, or the last upload's if the bot isn't online."""
        if getattr(self.runner, "state", "") == "online":
            try:
                return {**self.access.public_info(), "online": False, "saved_at": int(time.time())}
            except Exception:
                pass
        try:
            async with self.http.get(self.url + "/site-info.json", headers=HEADERS) as r:
                if r.status == 200:
                    old = await r.json(content_type=None)
                    if isinstance(old, dict) and old.get("figs") is not None:
                        return old
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
            pass
        try:
            return {**self.access.public_info(), "online": False, "saved_at": int(time.time())}
        except Exception:
            return None

    async def _publish(self, tunnel: str):
        snapshot = await self._snapshot()
        zipped = await asyncio.get_running_loop().run_in_executor(None, build_zip, tunnel, self.csp, snapshot)
        for attempt in range(6):
            # Netlify takes 3 uploads a minute: wait for a free spot
            now = time.monotonic()
            self.deploys = [t for t in self.deploys if now - t < 60]
            if len(self.deploys) >= DEPLOYS_PER_MINUTE:
                await asyncio.sleep(60 - (now - self.deploys[0]) + 1)
            if self.tunnel and tunnel != self.tunnel.address:
                return  # outdated while waiting
            self.deploys.append(time.monotonic())
            try:
                await self.nf.deploy(self.site.get("id") or f"{self.name}.netlify.app", zipped)
                self.published = tunnel
                say(f"Uploaded the website to {self.url}")
                return
            except NetlifyError as e:
                if e.status == 429:
                    self.deploys.pop()  # refused, so it doesn't count
                    wait = max(1, round(e.wait))
                    say(f"{e} Uploading in {wait} second{'s' if wait != 1 else ''}.")
                    await asyncio.sleep(wait)
                elif e.status in (401, 403, 404, 422) or attempt == 5:
                    raise
                else:
                    say(f"{e} Trying again in 15 seconds.")
                    await asyncio.sleep(15)

    async def _check_live(self):
        """Open the Netlify address like a visitor would, to say whether it reaches the bot."""
        for _ in range(12):
            try:
                async with self.http.get(self.url + "/api/public", headers=HEADERS,
                                         timeout=aiohttp.ClientTimeout(total=20)) as r:
                    if r.status == 200 and "figs" in (await r.json(content_type=None) or {}):
                        say(f"The website is live and connected to this PC: {self.url}")
                        return True
            except (aiohttp.ClientError, asyncio.TimeoutError, ValueError, TypeError):
                pass
            await asyncio.sleep(5)
        say(f"Uploaded, but {self.url} can't reach this PC yet. Cloudflare's tunnel sometimes needs a few "
            "minutes. If it stays like this, restart the bot.")
        return False

    def stop(self):
        if self.tunnel:
            self.tunnel.stop()
        if self.task:
            self.task.cancel()
