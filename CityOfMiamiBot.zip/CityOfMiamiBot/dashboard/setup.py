"""
Checking a bot token with Discord (when the console asks for it), the invite link, and the
bot's status for the website. The token is never typed into the website.
"""

import asyncio
import base64
import re

import aiohttp

DISCORD_API = "https://discord.com/api/v10"
TOKEN_SHAPE = re.compile(r"^[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}$")

# Permissions the invite link asks for (everything the bot's features use)
INVITE_PERMISSIONS = (
    (1 << 1)      # Kick Members (honeypot)
    | (1 << 2)    # Ban Members (honeypot)
    | (1 << 4)    # Manage Channels (tickets)
    | (1 << 6)    # Add Reactions
    | (1 << 10)   # View Channels
    | (1 << 11)   # Send Messages
    | (1 << 13)   # Manage Messages (word filter)
    | (1 << 14)   # Embed Links
    | (1 << 15)   # Attach Files
    | (1 << 16)   # Read Message History
    | (1 << 18)   # Use External Emojis
    | (1 << 20)   # Connect (join-to-create voice channels)
    | (1 << 22)   # Mute Members (/voice mute)
    | (1 << 24)   # Move Members (join-to-create voice channels, /voice move)
    | (1 << 27)   # Manage Nicknames (Roblox nicknames)
    | (1 << 28)   # Manage Roles (whitelist, priority and reaction roles)
    | (1 << 40)   # Timeout Members (honeypot, auto-mod, /timeout)
    | (1 << 43)   # Create Expressions (/steal)
    | (1 << 49)   # Create Polls
)


class TokenError(Exception):
    def __init__(self, message: str, wrong_token: bool = False):
        super().__init__(message)
        self.wrong_token = wrong_token  # only real wrong tokens count toward the lockout


def clean_token(raw) -> str:
    token = str(raw or "").strip().strip('"').strip("'")
    if token.lower().startswith("bot "):
        token = token[4:].strip()
    return token


def bot_id_from_token(token: str) -> str | None:
    """The first part of a bot token is the bot's user ID."""
    try:
        first = token.split(".", 1)[0]
        text = base64.urlsafe_b64decode(first + "=" * (-len(first) % 4)).decode()
        return text if text.isdigit() else None
    except (ValueError, UnicodeDecodeError):
        return None


async def check_token(token: str) -> dict:
    """Ask Discord whether the token works. Returns the bot's id and name."""
    headers = {"Authorization": f"Bot {token}", "User-Agent": "DiscordBot (CityOfMiamiBot, 1.0)"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as http:
            async with http.get(f"{DISCORD_API}/users/@me", headers=headers) as r:
                if r.status == 401:
                    raise TokenError("Discord didn't accept that token. Copy it again, or reset it in the Developer Portal and paste the new one.", True)
                if r.status == 429:
                    raise TokenError("Discord is rate limiting this computer. Wait a minute and try again.")
                if r.status != 200:
                    raise TokenError(f"Discord answered with an error ({r.status}). Try again in a moment.")
                user = await r.json()
    except (aiohttp.ClientError, asyncio.TimeoutError):
        raise TokenError("Couldn't reach Discord. Check the internet connection on the computer running the bot.")
    return {"id": str(user["id"]), "name": user.get("username", "your bot")}


def invite_url(bot) -> str | None:
    if bot is None or bot.user is None:
        return None
    app_id = bot.application_id or bot.user.id
    return (f"https://discord.com/oauth2/authorize?client_id={app_id}"
            f"&scope=bot%20applications.commands&permissions={INVITE_PERMISSIONS}")


def bot_status(runner) -> dict:
    """The bot's state for the website (safe to show before logging in)."""
    bot = runner.bot
    user = bot.user if bot is not None else None
    online = runner.state == "online" and bot is not None
    return {
        "state": runner.state,  # starting, online or offline
        "error": runner.error if runner.state == "offline" else None,
        "name": user.name if user else None,
        "avatar": user.display_avatar.url if user else None,
        "servers": len(bot.guilds) if online else 0,
    }
