"""
Everything the dashboard can read or do. server.py turns these into web routes.

Handlers get a Req (who is logged in + the JSON they sent) and return a dict that is
sent back as JSON. Raise ApiError to send back an error message instead.

Every route here belongs to one server: server.py checks the person may manage it, then
calls use_guild() so `config` and need_guild() mean that server while the handler runs.
"""

import datetime
import json
import math
import os
import time
import traceback

import discord

from commands.Staff.wl_embed import config, save_config, DEFAULTS, current_config
from commands.Staff.figs import figs_for_client, enabled_tabs, enabled_features, COMMAND_FEATURES
from .schema import FIELDS, config_to_client, clean_patch
from .setup import bot_status, invite_url

AUDIT_DIR = os.path.join("data", "audit")

# Friendly names for the activity log
LABELS = {
    "server_name": "server name", "accent_color": "accent color", "city_emoji": "server emoji",
    "thumbnail_url": "thumbnail", "banner_url": "banner", "support_url": "support link",
    "website_url": "website link", "log_channel_id": "log channel",
    "wl_enabled": "whitelist mode", "whitelist_channel_id": "whitelist channel",
    "whitelist_role_id": "whitelist role", "unverified_role_id": "unverified role",
    "wl_panel_title": "WL panel title", "wl_panel_subtitle": "WL panel subtitle",
    "wl_panel_sections": "WL panel text", "wl_panel_footer": "WL panel footer",
    "welcome_enabled": "welcome messages", "welcome_channel_id": "welcome channel",
    "welcome_title": "welcome title", "welcome_message": "welcome text",
    "welcome_links": "welcome channel links", "welcome_footer": "welcome footer",
    "priority_roles": "priority roles",
    "filtered_words": "filtered words", "allowed_words": "allowed words",
    "filter_whitelist_users": "filter whitelist", "filter_message": "filter warning",
    "honeypot_channel_id": "honeypot trap channel", "honeypot_log_channel_id": "honeypot log channel",
    "honeypot_action": "honeypot action", "honeypot_message": "honeypot DM",
    "react_channel_ids": "👍/👎 channels",
    "female_role_id": "/verify-female role", "female_log_channel_id": "/verify-female log channel",
    "disabled_commands": "turned off commands", "dashboard_role_ids": "dashboard access roles",
    "ticket_log_channel_id": "ticket log channel", "ticket_max_open": "tickets per member",
    "ticket_claim": "ticket claim button", "ticket_dm_transcript": "ticket transcript DMs",
    "ticket_types": "ticket types", "figs": "figs", "dashboard_user_ids": "dashboard access people",
    "roblox_verified_role_id": "Roblox verified role", "roblox_unverified_role_id": "Roblox unverified role",
    "roblox_nickname": "Roblox nicknames", "roblox_auto_verify": "Roblox auto-verify",
    "roblox_log_channel_id": "Roblox log channel", "roblox_panel_title": "Roblox panel title",
    "roblox_panel_text": "Roblox panel text", "roblox_group_id": "Roblox group",
    "roblox_group_member_role_id": "Roblox group member role", "roblox_rank_roles": "Roblox rank roles",
    "rbx_min_age_days": "minimum Roblox account age", "rbx_blacklist_groups": "blocked Roblox groups",
    "rbx_auto_update_hours": "Roblox auto-update", "rbx_badge_roles": "badge roles", "rbx_pass_roles": "game pass roles",
    "rbx_place_id": "Roblox game", "rbx_stats_channel_id": "game stats channel", "rbx_shout_channel_id": "group shout channel",
    "sess_channel_id": "session channel", "sess_ping_role_id": "session ping role", "sess_host_role_ids": "session hosts",
    "sess_link": "session join link", "sess_types": "session types",
    "join_role_ids": "join roles", "join_bot_role_ids": "bot join roles", "welcome_dm": "welcome DM",
    "goodbye_enabled": "goodbye messages", "goodbye_channel_id": "goodbye channel", "goodbye_message": "goodbye text",
    "am_invites": "invite blocking", "am_links": "link blocking", "am_allowed_links": "allowed links", "am_spam": "spam blocking",
    "am_spam_count": "spam limit", "am_spam_seconds": "spam window", "am_mentions": "mention limit", "am_caps": "caps blocking",
    "am_action": "auto-mod action", "am_warn": "auto-mod warnings", "am_ignored_role_ids": "auto-mod ignored roles",
    "am_ignored_channel_ids": "auto-mod ignored channels", "am_log_channel_id": "auto-mod log channel",
    "mod_log_channel_id": "moderation log channel", "mod_dm": "moderation DMs", "mod_warn_timeout": "warnings before a timeout",
    "mod_timeout_minutes": "warning timeout length", "mod_warn_kick": "warnings before a kick", "mod_warn_ban": "warnings before a ban",
    "logs_channel_id": "log channel", "logs_message_channel_id": "message log channel", "logs_events": "logged events",
    "logs_ignored_channel_ids": "channels not logged",
    "lvl_enabled": "leveling", "lvl_xp_min": "XP per message", "lvl_xp_max": "XP per message", "lvl_cooldown": "XP cooldown",
    "lvl_announce": "level-up messages", "lvl_channel_id": "level-up channel", "lvl_message": "level-up text",
    "lvl_roles": "level roles", "lvl_stack": "keeping level roles", "lvl_no_xp_channel_ids": "no-XP channels",
    "lvl_no_xp_role_ids": "no-XP roles",
    "sug_channel_id": "suggestion channel", "sug_anonymous": "anonymous suggestions", "sug_staff_role_ids": "suggestion staff",
    "sug_dm_result": "suggestion result DMs",
    "star_channel_id": "starboard channel", "star_emoji": "starboard emoji", "star_threshold": "stars needed",
    "star_self": "self-stars", "star_ignored_channel_ids": "starboard ignored channels",
    "bday_channel_id": "birthday channel", "bday_role_id": "birthday role", "bday_message": "birthday text", "bday_hour": "birthday time",
    "ar_rules": "auto-responses", "ar_cooldown": "auto-response cooldown", "ann_messages": "timed messages",
    "tv_hub_channel_id": "join-to-create channel", "tv_category_id": "voice category", "tv_name": "voice channel name",
    "tv_limit": "voice channel limit", "sticky_messages": "sticky messages", "stat_channels": "stat channels",
    "count_channel_id": "counting channel", "count_reset_on_fail": "counting resets",
    "ticket_autoclose_hours": "ticket auto-close", "ticket_rating": "ticket ratings", "ticket_snippets": "ticket snippets",
    "ticket_hours_on": "support hours", "ticket_hours_start": "support hours", "ticket_hours_end": "support hours",
    "ticket_utc_offset": "support hours time zone", "ticket_offline_message": "outside-hours message",
    "ticket_dm_open": "DM to open a ticket",
    "app_forms": "applications", "app_panel_title": "application panel title", "app_panel_text": "application panel text",
    "faq_entries": "FAQ", "faq_title": "FAQ title", "faq_text": "FAQ text",
    "status_channel_id": "status channel", "status_components": "status parts", "status_note": "status note",
    "rev_channel_id": "review channel", "rev_role_id": "reviewer role",
    "util_snipe": "/snipe", "util_afk": "/afk", "util_afk_nick": "AFK nicknames",
    "prefix": "command prefix", "prefix_enabled": "prefix commands",
}

# Feature → the cog that gives its dashboard data (dashboard_info) and buttons (DASH_ACTIONS)
FEATURE_COGS = {
    "automod": "AutoModPlus", "moderation": "ModTools", "leveling": "Leveling", "suggestions": "Suggestions",
    "starboard": "Starboard", "birthdays": "Birthdays", "announcements": "Announcements", "tempvoice": "TempVoice",
    "channeltools": "ChannelTools", "applications": "Applications", "faq": "Faq", "status": "StatusPage",
    "reviews": "Reviews", "roblox-game": "RobloxGame", "roblox-sessions": "Sessions", "tickets": "TicketExtras",
    "utility": "Utility",
}

# Changing any of these redraws the honeypot warning message
HONEYPOT_LOOK = {"honeypot_action", "accent_color", "city_emoji", "thumbnail_url"}
# Changing any of these redraws the posted ticket panels
PANEL_LOOK = {"ticket_types", "accent_color", "thumbnail_url", "server_name"}


class ApiError(Exception):
    def __init__(self, status: int, message: str, extra: dict | None = None):
        super().__init__(message)
        self.status, self.message, self.extra = status, message, extra or {}


class Req:
    def __init__(self, user: dict, body: dict | None = None, params: dict | None = None, query: dict | None = None):
        self.user = user or {}
        self.body = body or {}
        self.params = params or {}
        self.query = query or {}


def _load_audit(guild_id: int) -> list:
    try:
        with open(os.path.join(AUDIT_DIR, f"{guild_id}.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except (FileNotFoundError, json.JSONDecodeError):
        return []


IMAGE_TYPES = ("image/png", "image/jpeg", "image/gif", "image/webp")


def _image_data(value, label: str) -> str:
    """Check a picture sent from the dashboard (a data: link). Returns it for Discord."""
    import base64
    import re as _re
    m = _re.match(r"^data:(image/[a-z+]+);base64,([A-Za-z0-9+/=\s]+)$", str(value or ""))
    if not m or m.group(1) not in IMAGE_TYPES:
        raise ApiError(400, f"The {label} has to be a PNG, JPG, GIF or WebP image.")
    try:
        size = len(base64.b64decode(m.group(2), validate=False))
    except ValueError:
        raise ApiError(400, f"That {label} file is damaged. Try another one.")
    if size > 10 * 1024 * 1024:
        raise ApiError(400, f"The {label} is too big. Discord takes images up to 10 MB.")
    return f"data:{m.group(1)};base64,{''.join(m.group(2).split())}"


def _member_image(guild_id, user_id, kind: str, image_hash, size: int) -> str | None:
    if not image_hash:
        return None
    ext = "gif" if str(image_hash).startswith("a_") else "png"
    return f"https://cdn.discordapp.com/guilds/{guild_id}/users/{user_id}/{kind}/{image_hash}.{ext}?size={size}"


def _int(value, what="ID") -> int:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        raise ApiError(400, f"That {what} isn't valid.")


def _avatar(member) -> str | None:
    try:
        return member.display_avatar.url
    except AttributeError:
        return None


class Api:
    ROUTES = [
        ("GET", "/state", "state"),
        ("GET", "/server-info", "server_live"),
        ("PATCH", "/config", "patch_config"),
        ("GET", "/members", "search_members"),
        ("POST", "/actions/wl-panel", "post_wl_panel"),
        ("POST", "/actions/welcome-test", "welcome_test"),
        ("POST", "/actions/honeypot-repost", "honeypot_repost"),
        ("POST", "/actions/honeypot-reset", "honeypot_reset"),
        ("POST", "/polls", "create_poll"),
        ("POST", "/giveaways", "create_giveaway"),
        ("POST", "/giveaways/{id}/end", "end_giveaway"),
        ("POST", "/giveaways/{id}/reroll", "reroll_giveaway"),
        ("DELETE", "/giveaways/{id}", "delete_giveaway"),
        ("POST", "/reaction-roles", "create_reaction_panel"),
        ("DELETE", "/reaction-roles/{id}", "delete_reaction_panel"),
        ("POST", "/tickets/panels", "create_ticket_panel"),
        ("POST", "/tickets/panels/{id}", "update_ticket_panel"),
        ("DELETE", "/tickets/panels/{id}", "delete_ticket_panel"),
        ("POST", "/tickets/{id}/close", "close_ticket"),
        ("POST", "/tickets/{id}/reopen", "reopen_ticket"),
        ("POST", "/tickets/{id}/transcript", "transcript_ticket"),
        ("DELETE", "/tickets/{id}", "delete_ticket"),
        ("POST", "/roblox/panel", "post_roblox_panel"),
        ("GET", "/roblox/group", "roblox_group"),
        ("POST", "/roblox/update-all", "roblox_update_all"),
        ("POST", "/do/{feature}/{action}", "feature_action"),
        ("POST", "/profile", "update_profile"),
    ]

    def __init__(self, runner):
        self.runner = runner
        self.audits: dict[int, list] = {}
        self._live: dict[int, tuple[float, dict]] = {}  # server id -> (when, online count etc.)

    @property
    def bot(self):
        """The running bot (None until a token has been entered)."""
        return self.runner.bot

    # ──────────────────────────── helpers ───────────────────────────────────

    def need_guild(self):
        """The server this request is for (picked by server.py before the handler runs)."""
        bot = self.bot
        g = bot.get_guild(current_config().guild_id) if bot is not None and bot.is_ready() else None
        if g is None:
            raise ApiError(404, "The bot isn't in that server, or isn't connected yet.")
        return g

    def audit(self, guild_id: int) -> list:
        if guild_id not in self.audits:
            self.audits[guild_id] = _load_audit(guild_id)
        return self.audits[guild_id]

    def log(self, user: dict, text: str, guild_id: int | None = None):
        gid = guild_id or current_config().guild_id
        entries = self.audit(gid)
        entries.append({"t": int(time.time()), "user": user.get("name", "Someone"), "avatar": user.get("avatar"), "text": text})
        del entries[:-200]
        try:
            os.makedirs(AUDIT_DIR, exist_ok=True)
            with open(os.path.join(AUDIT_DIR, f"{gid}.json"), "w", encoding="utf-8") as f:
                json.dump(entries, f, indent=1, ensure_ascii=False)
        except OSError:
            pass

    def text_channel(self, g, cid):
        ch = g.get_channel(_int(cid, "channel"))
        if ch is None or ch.type.name not in ("text", "news"):
            raise ApiError(400, "Pick a text channel.")
        perms = ch.permissions_for(g.me)
        if not (perms.view_channel and perms.send_messages):
            raise ApiError(400, f"I can't send messages in #{ch.name}. Give my role View Channel and Send Messages there.")
        return ch

    def cog(self, name: str):
        cog = self.bot.get_cog(name)
        if cog is None:
            raise ApiError(500, f"The {name} feature didn't load. Check the bot console for errors.")
        return cog

    @staticmethod
    async def discord_call(coro, failed: str):
        try:
            return await coro
        except discord.Forbidden:
            raise ApiError(403, f"{failed} Discord says I'm missing a permission.")
        except discord.HTTPException as e:
            raise ApiError(502, f"{failed} Discord said: {e}")

    # ──────────────────────────── reading ───────────────────────────────────

    def guild_info(self, g) -> dict:
        channels = []
        for category, chans in g.by_category():
            if category is not None:
                channels.append({"id": str(category.id), "name": category.name, "type": "category", "parent_id": None})
            for ch in chans:
                channels.append({
                    "id": str(ch.id), "name": ch.name, "type": ch.type.name,
                    "parent_id": str(category.id) if category else None,
                })

        roles = [
            {
                "id": str(r.id), "name": r.name,
                "color": f"#{r.color.value:06x}" if r.color.value else None,
                "managed": r.managed, "assignable": r.is_assignable(),
                "members": len(r.members),
            }
            for r in sorted(g.roles, key=lambda r: r.position, reverse=True)
            if not r.is_default()
        ]
        perms = g.me.guild_permissions if g.me else None
        wanted = ["administrator", "manage_roles", "manage_channels", "manage_messages", "ban_members", "kick_members",
                  "moderate_members", "add_reactions", "send_messages", "manage_nicknames"]
        return {
            "id": str(g.id),
            "name": g.name,
            "icon": g.icon.url if g.icon else None,
            "member_count": g.member_count or len(g.members),
            "channels": channels,
            "roles": roles,
            "emojis": [{"id": str(e.id), "name": e.name, "animated": e.animated} for e in g.emojis],
            "bot_perms": {p: bool(getattr(perms, p, False)) for p in wanted} if perms else {},
        }

    VERIFICATION = {
        "none": "None", "low": "Low: a verified email",
        "medium": "Medium: a verified email, on Discord for 5 minutes",
        "high": "High: on Discord 5 minutes, in the server 10 minutes",
        "highest": "Highest: a verified phone number",
    }
    BADGES = (("VERIFIED", "Verified"), ("PARTNERED", "Partnered"), ("COMMUNITY", "Community"), ("DISCOVERABLE", "In Discovery"))

    def server_info(self, g) -> dict:
        """Facts about the server for the Overview page. All from the bot's cache, so it's instant."""
        members = list(g.members)
        total = g.member_count or len(members)
        # bots and new members can only be counted once Discord has sent the whole member list
        counted = bool(members) and bool(getattr(g, "chunked", True))
        bots = sum(1 for m in members if m.bot) if counted else None
        week = time.time() - 7 * 86400
        joined_week = sum(1 for m in members if not m.bot and getattr(m, "joined_at", None)
                          and m.joined_at.timestamp() >= week) if counted else None
        kinds: dict[str, int] = {}
        for ch in g.channels:
            name = getattr(getattr(ch, "type", None), "name", "other")
            kinds[name] = kinds.get(name, 0) + 1
        owner = getattr(g, "owner", None)
        me = g.me
        created = getattr(g, "created_at", None)
        verification = getattr(getattr(g, "verification_level", None), "name", None)
        locale = getattr(g, "preferred_locale", None)
        return {
            "id": str(g.id),
            "description": getattr(g, "description", None) or None,
            "banner": g.banner.url if getattr(g, "banner", None) else None,
            "created": created.timestamp() if created else None,
            "owner": self.person(owner) if owner else {"id": str(g.owner_id) if g.owner_id else None},
            "members": total,
            "bots": bots,
            "humans": total - bots if bots is not None else None,
            "joined_week": joined_week,
            "bot_joined": me.joined_at.timestamp() if me is not None and getattr(me, "joined_at", None) else None,
            "channels": {
                "text": kinds.get("text", 0), "announcement": kinds.get("news", 0), "voice": kinds.get("voice", 0),
                "stage": kinds.get("stage_voice", 0), "forum": kinds.get("forum", 0) + kinds.get("media", 0),
                "categories": kinds.get("category", 0),
            },
            "roles": max(0, len(g.roles) - 1),  # not counting @everyone
            "emojis": len(g.emojis), "emoji_limit": getattr(g, "emoji_limit", None),
            "stickers": len(getattr(g, "stickers", ()) or ()), "sticker_limit": getattr(g, "sticker_limit", None),
            "boosts": getattr(g, "premium_subscription_count", 0) or 0,
            "boost_level": getattr(g, "premium_tier", 0) or 0,
            "verification": self.VERIFICATION.get(verification, verification),
            "locale": str(getattr(locale, "value", locale)) if locale else None,
            "vanity": getattr(g, "vanity_url_code", None),
            "badges": [label for flag, label in self.BADGES if flag in (getattr(g, "features", None) or [])],
        }

    @staticmethod
    def person(member) -> dict:
        return {
            "id": str(member.id), "name": member.name,
            "display": getattr(member, "display_name", None) or getattr(member, "global_name", None) or member.name,
            "avatar": member.display_avatar.url if getattr(member, "display_avatar", None) else None,
        }

    async def server_live(self, req: Req) -> dict:
        """What the cache can't say: how many members are online right now (Discord's count). Kept a minute."""
        import asyncio
        g = self.need_guild()
        at, cached = self._live.get(g.id, (0.0, None))
        if cached is not None and time.time() - at < 60:
            return cached
        out = {"online": None, "members": None, "owner": None}
        try:
            fresh = await asyncio.wait_for(self.bot.fetch_guild(g.id, with_counts=True), timeout=6)
            out["online"] = getattr(fresh, "approximate_presence_count", None)
            out["members"] = getattr(fresh, "approximate_member_count", None)
        except Exception:
            pass  # Discord didn't answer: the page shows a dash
        if getattr(g, "owner", None) is None and g.owner_id:
            try:  # owner not in the bot's member list yet
                out["owner"] = self.person(await asyncio.wait_for(self.bot.fetch_user(g.owner_id), timeout=6))
            except Exception:
                pass
        self._live[g.id] = (time.time(), out)
        return out

    def commands_info(self) -> list:
        disabled = set(config.get("disabled_commands", []))
        out = []
        for cmd in sorted(self.bot.tree.get_commands(), key=lambda c: c.name):
            perms = getattr(cmd, "default_permissions", None)
            needs = [name.replace("_", " ").title() for name, on in perms if on] if perms else []
            cog = getattr(cmd, "binding", None)
            out.append({
                "name": cmd.name,
                "description": getattr(cmd, "description", ""),
                "needs": needs,
                "group": type(cog).__name__ if cog else "",
                # a command group (/role add, /role remove...) lists its subcommands as its options
                "options": [
                    {"name": s.name, "required": True, "description": s.description}
                    for s in getattr(cmd, "commands", [])
                ] or [
                    {"name": p.name, "required": p.required, "description": p.description}
                    for p in getattr(cmd, "parameters", [])
                ],
                "enabled": cmd.name not in disabled,
                "feature": COMMAND_FEATURES.get(cmd.name),
            })
        return out

    def giveaways_info(self, g) -> list:
        cog = self.bot.get_cog("Giveaway")
        if not cog:
            return []
        out = []
        for mid, gw in cog.giveaways.items():
            if gw.get("guild_id") != g.id:
                continue
            ch = g.get_channel(gw["channel_id"])
            out.append({
                "id": mid, "prize": gw["prize"], "channel_id": str(gw["channel_id"]),
                "channel": ch.name if ch else "deleted-channel",
                "end": gw["end"], "ended": gw["ended"], "winners": gw["winners"],
                "entries": len(gw["entrants"]), "host_id": str(gw["host_id"]),
                "winner_ids": [str(w) for w in gw.get("winner_ids", [])],
                "url": f"https://discord.com/channels/{g.id}/{gw['channel_id']}/{mid}",
            })
        out.sort(key=lambda x: (x["ended"], -x["end"] if x["ended"] else x["end"]))
        return out

    def panels_info(self, g) -> list:
        cog = self.bot.get_cog("ReactionRoles")
        if not cog:
            return []
        out = []
        for mid, panel in cog.panels.items():
            cid = panel.get("channel_id")
            ch = g.get_channel(cid) if cid else None
            if cid and ch is None and self.bot.get_channel(cid) is not None:
                continue  # belongs to another server
            out.append({
                "id": mid,
                "title": panel.get("title") or "Reaction Roles",
                "channel_id": str(cid) if cid else None,
                "channel": ch.name if ch else None,
                "rows": [
                    {"emoji": panel.get("emojis", {}).get(key, key), "role_id": str(rid)}
                    for key, rid in panel["roles"].items()
                ],
                "url": f"https://discord.com/channels/{g.id}/{cid}/{mid}" if cid else None,
            })
        return sorted(out, key=lambda p: int(p["id"]), reverse=True)

    def user_info(self, g, uid) -> dict:
        m = g.get_member(int(uid))
        if m is None:
            return {"id": str(uid), "name": "Not in the server", "username": "", "avatar": None, "missing": True}
        return {"id": str(m.id), "name": m.display_name, "username": m.name, "avatar": _avatar(m), "bot": m.bot}

    def stats(self, g) -> dict:
        wl_role = g.get_role(config.get("whitelist_role_id") or 0)
        cog_g = self.bot.get_cog("Giveaway")
        return {
            "whitelisted": len(wl_role.members) if wl_role else None,
            "honeypot_catches": int(config.get("honeypot_catches", 0)),
            "giveaways_live": sum(1 for x in (cog_g.giveaways.values() if cog_g else [])
                                  if not x["ended"] and x.get("guild_id") == g.id),
            "reaction_panels": len(self.panels_info(g)),
        }

    async def state(self, req: Req) -> dict:
        bot = self.bot
        info = bot_status(self.runner)
        if bot is not None and bot.user is not None:
            latency = bot.latency
            info.update({
                "id": str(bot.user.id),
                "latency_ms": round(latency * 1000) if isinstance(latency, float) and math.isfinite(latency) else None,
                "started": int(getattr(bot, "start_time", time.time())),
                "invite_url": invite_url(bot),
            })
        out = {"user": req.user, "ready": False, "bot": info}
        try:
            g = self.need_guild()
        except ApiError:
            return out

        out.update({
            "ready": True,
            "guild": self.guild_info(g),
            "server": self.server_info(g),
            "config": config_to_client(config),
            "defaults": config_to_client(DEFAULTS),
            "stats": self.stats(g),
            "commands": self.commands_info(),
            "giveaways": self.giveaways_info(g),
            "reaction_panels": self.panels_info(g),
            "users": [self.user_info(g, u) for u in
                      dict.fromkeys([*config.get("filter_whitelist_users", []), *config.get("dashboard_user_ids", [])])],
            "activity": list(reversed(self.audit(g.id)[-40:])),
            "tickets": self.bot.get_cog("Tickets").dashboard_info(g) if self.bot.get_cog("Tickets") else None,
            "roblox": self.bot.get_cog("Roblox").dashboard_info(g) if self.bot.get_cog("Roblox") else None,
            "extras": self.extras(g),
            "figs": figs_for_client(),
            "tabs": enabled_tabs(config),
            "features": sorted(enabled_features(config)),
            "you": {"owner": req.user.get("id") == str(g.owner_id), "bot_owner": bool(req.user.get("bot_owner"))},
            "profile": self.profile_info(g),
        })
        return out

    def extras(self, g) -> dict:
        """Data for the pages of features that are on (leaderboards, suggestions, cases…)."""
        out, on = {}, enabled_features(config)
        for feature, name in FEATURE_COGS.items():
            cog = self.bot.get_cog(name)
            if feature in on and cog is not None and hasattr(cog, "dashboard_info"):
                try:
                    out[feature] = cog.dashboard_info(g)
                except Exception:
                    traceback.print_exc()
        return out

    async def feature_action(self, req: Req) -> dict:
        """A button on a feature's page: post a panel, approve a suggestion, start a session…"""
        from commands.Staff.kit import DashError
        g = self.need_guild()
        feature, action = req.params.get("feature"), req.params.get("action")
        if feature not in FEATURE_COGS:
            raise ApiError(404, "That feature doesn't exist.")
        if feature not in enabled_features(config):
            raise ApiError(400, "Turn on a fig with this feature first (Figs page).")
        cog = self.cog(FEATURE_COGS[feature])
        method = getattr(cog, "DASH_ACTIONS", {}).get(action)
        if not method:
            raise ApiError(404, "That action doesn't exist.")
        try:
            res = await getattr(cog, method)(g, req.body or {}, req.user) or {}
        except DashError as e:
            raise ApiError(400, str(e))
        except discord.Forbidden:
            raise ApiError(403, "Discord says I'm missing a permission for that.")
        except discord.HTTPException as e:
            raise ApiError(502, f"Discord said: {e}")
        if res.get("log"):
            self.log(req.user, res.pop("log"))
        if hasattr(cog, "dashboard_info"):
            res.setdefault("info", cog.dashboard_info(g))
        return {"ok": True, **res}

    async def search_members(self, req: Req) -> dict:
        g = self.need_guild()
        q = str(req.query.get("q", "")).strip().lower()
        if not q:
            return {"members": []}
        found = []
        for m in g.members:
            names = (m.name.lower(), m.display_name.lower(), (m.global_name or "").lower())
            if any(q in n for n in names) or str(m.id) == q:
                found.append(m)
            if len(found) >= 20:
                break
        return {"members": [self.user_info(g, m.id) for m in found]}

    # ──────────────────────────── saving settings ───────────────────────────

    async def patch_config(self, req: Req) -> dict:
        g = self.need_guild()
        changes = req.body.get("changes")
        if not isinstance(changes, dict) or not changes:
            raise ApiError(400, "Nothing to save.")

        cleaned, errors = clean_patch(changes, g)
        if errors:
            raise ApiError(400, "Some settings need fixing before they can be saved.", {"fields": errors})

        before = {k: config.get(k) for k in cleaned}
        changed = [k for k, v in cleaned.items() if before[k] != v]
        for key in changed:
            config[key] = cleaned[key]
        if changed:
            save_config()
            self.log(req.user, "Changed " + ", ".join(LABELS.get(k, k) for k in changed))

        notes = await self.after_change(g, changed, before)
        return {"config": config_to_client(config), "changed": changed, "notes": notes}

    async def after_change(self, g, changed: list, before: dict) -> list:
        """Things that should happen in Discord right after a setting changes."""
        notes = []
        for name in set(FEATURE_COGS.values()):  # FAQ, application and status messages redraw themselves
            cog = self.bot.get_cog(name)
            if cog is not None and hasattr(cog, "settings_changed") and changed:
                try:
                    notes += await cog.settings_changed(g, changed, before) or []
                except Exception:
                    traceback.print_exc()
        tickets = self.bot.get_cog("Tickets")
        if tickets and PANEL_LOOK & set(changed) and tickets.data["panels"]:
            await tickets.refresh_all_panels(g.id)
            notes.append("Updated the ticket panels in Discord.")

        honeypot = self.bot.get_cog("Honeypot")
        if not honeypot:
            return notes

        if "honeypot_channel_id" in changed and config.get("honeypot_channel_id"):
            trap = g.get_channel(config["honeypot_channel_id"])
            if trap is not None:
                if await honeypot.post_warning(trap):
                    notes.append(f"Posted the warning in #{trap.name}.")
                else:
                    notes.append(f"Couldn't post the warning in #{trap.name}. Check my permissions there.")
        elif HONEYPOT_LOOK & set(changed):
            await honeypot.update_warning(g)
        return notes

    # ──────────────────────────── actions ───────────────────────────────────

    async def post_wl_panel(self, req: Req) -> dict:
        from commands.Staff.wl_embed import send_wl_embed
        g = self.need_guild()
        ch = self.text_channel(g, req.body.get("channel_id"))
        msg = await self.discord_call(send_wl_embed(ch), "Couldn't post the WL panel.")
        self.log(req.user, f"Posted the WL panel in #{ch.name}")
        return {"ok": True, "url": msg.jump_url, "message": f"Posted the WL panel in #{ch.name}."}

    async def welcome_test(self, req: Req) -> dict:
        from commands.Staff.welcome import send_welcome
        g = self.need_guild()
        cid = req.body.get("channel_id") or config.get("welcome_channel_id")
        if not cid:
            raise ApiError(400, "Pick a welcome channel first.")
        ch = self.text_channel(g, cid)
        member = g.get_member(int(req.user["id"])) if req.user.get("id") else None
        msg = await self.discord_call(send_welcome(member or g.me, ch), "Couldn't send the test welcome.")
        self.log(req.user, f"Sent a test welcome in #{ch.name}")
        return {"ok": True, "url": msg.jump_url, "message": f"Sent a test welcome in #{ch.name}."}

    async def honeypot_repost(self, req: Req) -> dict:
        g = self.need_guild()
        trap = g.get_channel(config.get("honeypot_channel_id") or 0)
        if trap is None:
            raise ApiError(400, "Pick a trap channel first.")
        if not await self.cog("Honeypot").post_warning(trap):
            raise ApiError(403, f"Couldn't post in #{trap.name}. Check my permissions there.")
        self.log(req.user, f"Reposted the honeypot warning in #{trap.name}")
        return {"ok": True, "message": f"Posted the warning in #{trap.name}."}

    async def honeypot_reset(self, req: Req) -> dict:
        g = self.need_guild()
        config["honeypot_catches"] = 0
        save_config()
        await self.cog("Honeypot").update_warning(g)
        self.log(req.user, "Reset the honeypot catch count")
        return {"ok": True, "message": "Catch count reset to 0."}

    async def create_poll(self, req: Req) -> dict:
        g = self.need_guild()
        b = req.body
        ch = self.text_channel(g, b.get("channel_id"))
        question = str(b.get("question", "")).strip()
        answers = [str(a).strip() for a in b.get("answers", []) if str(a).strip()]
        hours = _int(b.get("hours", 24), "length")
        if not 1 <= len(question) <= 300:
            raise ApiError(400, "The question has to be 1–300 characters.")
        if not 2 <= len(answers) <= 10:
            raise ApiError(400, "Add between 2 and 10 answers.")
        if any(len(a) > 55 for a in answers):
            raise ApiError(400, "Each answer has to be 55 characters or less.")
        if not 1 <= hours <= 768:
            raise ApiError(400, "Polls can run from 1 to 768 hours.")

        poll = discord.Poll(question=question, duration=datetime.timedelta(hours=hours), multiple=bool(b.get("multiple")))
        for a in answers:
            poll.add_answer(text=a)
        msg = await self.discord_call(ch.send(poll=poll), "Couldn't post the poll.")
        self.log(req.user, f"Started a poll in #{ch.name}: {question[:60]}")
        return {"ok": True, "url": msg.jump_url, "message": f"Poll posted in #{ch.name}."}

    # ── giveaways ──

    async def create_giveaway(self, req: Req) -> dict:
        from commands.Staff.giveaway import _parse_duration
        g = self.need_guild()
        b = req.body
        ch = self.text_channel(g, b.get("channel_id"))
        prize = str(b.get("prize", "")).strip()
        seconds = _parse_duration(str(b.get("duration", "")))
        winners = _int(b.get("winners", 1), "winner count")
        if not 1 <= len(prize) <= 200:
            raise ApiError(400, "The prize has to be 1–200 characters.")
        if not seconds or not 10 <= seconds <= 60 * 86400:
            raise ApiError(400, "Use a length like 30m, 2h, 1d or 1d12h (between 10 seconds and 60 days).")
        if not 1 <= winners <= 50:
            raise ApiError(400, "Pick 1–50 winners.")

        host = int(req.user["id"]) if req.user.get("id") else g.me.id
        cog = self.cog("Giveaway")
        await self.discord_call(cog.create(ch, prize, seconds, winners, host), "Couldn't post the giveaway.")
        self.log(req.user, f"Started a giveaway in #{ch.name}: {prize[:60]}")
        return {"ok": True, "message": f"Giveaway started in #{ch.name}.", "giveaways": self.giveaways_info(g)}

    def _giveaway(self, req: Req):
        cog = self.cog("Giveaway")
        mid = str(req.params.get("id"))
        if mid not in cog.giveaways:
            raise ApiError(404, "That giveaway doesn't exist anymore.")
        return cog, mid

    async def end_giveaway(self, req: Req) -> dict:
        g = self.need_guild()
        cog, mid = self._giveaway(req)
        await cog.end_now(mid)
        self.log(req.user, f"Ended the giveaway for {cog.giveaways[mid]['prize'][:60]}")
        return {"ok": True, "message": "Giveaway ended and winners picked.", "giveaways": self.giveaways_info(g)}

    async def reroll_giveaway(self, req: Req) -> dict:
        g = self.need_guild()
        cog, mid = self._giveaway(req)
        if not cog.giveaways[mid]["ended"]:
            raise ApiError(400, "End the giveaway before rerolling it.")
        new = await cog.reroll(mid)
        if not new:
            raise ApiError(400, "There's nobody left to pick. Everyone who entered has already won.")
        self.log(req.user, f"Rerolled the giveaway for {cog.giveaways[mid]['prize'][:60]}")
        return {"ok": True, "message": "Picked new winners.", "giveaways": self.giveaways_info(g)}

    async def delete_giveaway(self, req: Req) -> dict:
        g = self.need_guild()
        cog, mid = self._giveaway(req)
        prize = cog.giveaways[mid]["prize"]
        await cog.delete(mid)
        self.log(req.user, f"Deleted the giveaway for {prize[:60]}")
        return {"ok": True, "message": "Giveaway deleted.", "giveaways": self.giveaways_info(g)}

    # ── tickets ──

    def _panel_body(self, b: dict) -> dict:
        from commands.Staff.tickets import get_type
        title = str(b.get("title") or "").strip()
        description = str(b.get("description") or "").strip()
        type_ids = [str(t) for t in (b.get("type_ids") or []) if get_type(str(t))]
        style = "dropdown" if b.get("style") == "dropdown" else "buttons"
        if not 1 <= len(title) <= 200:
            raise ApiError(400, "Give the panel a title (up to 200 characters).")
        if len(description) > 2000:
            raise ApiError(400, "Keep the description under 2000 characters.")
        if not type_ids:
            raise ApiError(400, "Pick at least one saved ticket type for the panel.")
        if len(type_ids) > 25:
            raise ApiError(400, "A panel can show up to 25 ticket types.")
        return {"title": title, "description": description, "type_ids": type_ids, "style": style}

    def _tickets(self):
        return self.cog("Tickets")

    async def create_ticket_panel(self, req: Req) -> dict:
        g = self.need_guild()
        ch = self.text_channel(g, req.body.get("channel_id"))
        panel = self._panel_body(req.body)
        cog = self._tickets()
        await self.discord_call(cog.post_panel(ch, panel), "Couldn't post the panel.")
        self.log(req.user, f"Posted a ticket panel in #{ch.name}")
        return {"ok": True, "message": f"Ticket panel posted in #{ch.name}.", "tickets": cog.dashboard_info(g)}

    async def update_ticket_panel(self, req: Req) -> dict:
        g = self.need_guild()
        cog = self._tickets()
        mid = str(req.params.get("id"))
        if mid not in cog.data["panels"]:
            raise ApiError(404, "That panel doesn't exist anymore.")
        cog.data["panels"][mid].update(self._panel_body(req.body))
        cog.save()
        if not await cog.refresh_panel(mid):
            raise ApiError(404, "The panel's message was deleted in Discord, so it was removed here too.", {"tickets": cog.dashboard_info(g)})
        self.log(req.user, "Updated a ticket panel")
        return {"ok": True, "message": "Panel updated in Discord.", "tickets": cog.dashboard_info(g)}

    async def delete_ticket_panel(self, req: Req) -> dict:
        g = self.need_guild()
        cog = self._tickets()
        mid = str(req.params.get("id"))
        if mid not in cog.data["panels"]:
            raise ApiError(404, "That panel doesn't exist anymore.")
        await cog.delete_panel(mid)
        self.log(req.user, "Deleted a ticket panel")
        return {"ok": True, "message": "Panel deleted.", "tickets": cog.dashboard_info(g)}

    def _ticket_channel(self, g, req: Req):
        cog = self._tickets()
        cid = str(req.params.get("id"))
        if cog.ticket(cid) is None:
            raise ApiError(404, "That ticket doesn't exist anymore.")
        ch = g.get_channel(int(cid))
        if ch is None:
            cog.data["tickets"].pop(cid, None)
            cog.save()
            raise ApiError(404, "That ticket's channel was deleted.", {"tickets": cog.dashboard_info(g)})
        return cog, ch

    def _acting_member(self, g, req: Req):
        """Who the bot says did it in Discord: the logged-in member, or the bot itself."""
        return (g.get_member(int(req.user["id"])) if req.user.get("id") else None) or g.me

    async def close_ticket(self, req: Req) -> dict:
        g = self.need_guild()
        cog, ch = self._ticket_channel(g, req)
        error = await cog.close_ticket(ch, self._acting_member(g, req), str(req.body.get("reason") or "").strip()[:300] or None)
        if error:
            raise ApiError(400, error)
        self.log(req.user, f"Closed ticket #{ch.name}")
        return {"ok": True, "message": f"Closed #{ch.name}.", "tickets": cog.dashboard_info(g)}

    async def reopen_ticket(self, req: Req) -> dict:
        g = self.need_guild()
        cog, ch = self._ticket_channel(g, req)
        error = await cog.reopen_ticket(ch, self._acting_member(g, req))
        if error:
            raise ApiError(400, error)
        self.log(req.user, f"Reopened ticket #{ch.name}")
        return {"ok": True, "message": f"Reopened #{ch.name}.", "tickets": cog.dashboard_info(g)}

    async def transcript_ticket(self, req: Req) -> dict:
        g = self.need_guild()
        cog, ch = self._ticket_channel(g, req)
        record, error = await cog.save_transcript(ch, self._acting_member(g, req))
        if error:
            raise ApiError(400, error)
        self.log(req.user, f"Saved a transcript of #{ch.name}")
        return {"ok": True, "message": f"Transcript of #{ch.name} saved.", "tickets": cog.dashboard_info(g)}

    async def delete_ticket(self, req: Req) -> dict:
        g = self.need_guild()
        cog, ch = self._ticket_channel(g, req)
        name = ch.name
        error = await cog.delete_ticket(ch, self._acting_member(g, req), delay=0)
        if error:
            raise ApiError(400, error, {"tickets": cog.dashboard_info(g)})
        self.log(req.user, f"Deleted ticket #{name}")
        return {"ok": True, "message": f"Deleted #{name}. The transcript was saved.", "tickets": cog.dashboard_info(g)}

    # ── Roblox ──

    async def post_roblox_panel(self, req: Req) -> dict:
        g = self.need_guild()
        ch = self.text_channel(g, req.body.get("channel_id"))
        msg = await self.discord_call(self.cog("Roblox").post_panel(ch), "Couldn't post the verify panel.")
        self.log(req.user, f"Posted the Roblox verify panel in #{ch.name}")
        return {"ok": True, "url": msg.jump_url, "message": f"Posted the verify panel in #{ch.name}."}

    async def roblox_group(self, req: Req) -> dict:
        from commands.Staff.roblox import get_group, RobloxError
        self.need_guild()
        gid = str(req.query.get("id", "")).strip()
        if not gid.isdigit():
            raise ApiError(400, "Type the group ID: the number in your group's link, like roblox.com/groups/1234567.")
        try:
            group = await get_group(int(gid))
        except RobloxError as e:
            raise ApiError(502, str(e))
        if not group:
            raise ApiError(404, f"There's no Roblox group with the ID {gid}.")
        return {"group": {
            "id": str(group["id"]), "name": group.get("name", ""), "members": group.get("memberCount", 0),
            "roles": [{"name": r["name"], "rank": r["rank"], "members": r.get("memberCount", 0)} for r in group["roles"] if r["rank"] > 0],
        }}

    # ── the bot's look in this server (server owner only) ──

    def profile_info(self, g, member: dict | None = None) -> dict:
        """The bot's name, picture and banner in this server. `member` is Discord's answer right after a change."""
        me, user = g.me, self.bot.user
        if member is not None:
            nick, avatar, banner = member.get("nick"), member.get("avatar"), member.get("banner")
            avatar_url = _member_image(g.id, user.id, "avatars", avatar, 256)
            banner_url = _member_image(g.id, user.id, "banners", banner, 600)
        else:
            nick = getattr(me, "nick", None)
            guild_avatar, guild_banner = getattr(me, "guild_avatar", None), getattr(me, "guild_banner", None)
            avatar_url = guild_avatar.url if guild_avatar else None
            banner_url = guild_banner.url if guild_banner else None
        user_banner = getattr(user, "banner", None)
        return {
            "nick": nick or "", "name": user.name, "global_name": getattr(user, "global_name", None) or user.name,
            "avatar": avatar_url, "banner": banner_url,
            "default_avatar": user.display_avatar.url if user else None,
            "default_banner": user_banner.url if user_banner else None,
        }

    async def update_profile(self, req: Req) -> dict:
        g = self.need_guild()
        if req.user.get("id") != str(g.owner_id):
            raise ApiError(403, "Only the server owner can change the bot's name, picture and banner in this server.")
        b, payload, changed = req.body, {}, []
        if "nick" in b:
            nick = str(b.get("nick") or "").strip()
            if len(nick) > 32:
                raise ApiError(400, "Discord names can be up to 32 characters.")
            payload["nick"] = nick or None
            changed.append("name")
        for key, label in (("avatar", "picture"), ("banner", "banner")):
            if key in b:
                payload[key] = _image_data(b.get(key), label) if b.get(key) else None
                changed.append(label)
        if not payload:
            raise ApiError(400, "Nothing to change.")
        import asyncio
        from discord.http import Route
        too_fast = "Discord only lets bots change their profile a few times in a while. Try again in a few minutes."
        try:
            # discord.py waits out rate limits by itself, which can take minutes, so stop waiting after 25 seconds
            member = await asyncio.wait_for(self.bot.http.request(
                Route("PATCH", "/guilds/{guild_id}/members/@me", guild_id=g.id),
                json=payload, reason=f"Changed on the dashboard by {req.user.get('name')}"), timeout=25)
        except asyncio.TimeoutError:
            raise ApiError(429, too_fast)
        except discord.Forbidden:
            raise ApiError(403, "Discord says I'm not allowed. For the name, my role needs the Change Nickname permission.")
        except discord.HTTPException as e:
            text = str(getattr(e, "text", "") or e)
            if getattr(e, "status", None) == 429 or "too fast" in text.lower():
                raise ApiError(429, too_fast)
            raise ApiError(400, f"Discord didn't accept that: {text}")
        self.log(req.user, "Changed the bot's " + " and ".join(changed) + " in this server")
        return {"ok": True, "message": "Saved. It can take a minute to show up everywhere in Discord.",
                "profile": self.profile_info(g, member if isinstance(member, dict) else None)}

    async def roblox_update_all(self, req: Req) -> dict:
        import asyncio
        g = self.need_guild()
        cog = self.cog("Roblox")
        count = sum(1 for m in g.members if cog.link_of(m.id) and not m.bot)
        if not count:
            raise ApiError(400, "Nobody in this server has linked a Roblox account yet.")
        asyncio.create_task(cog.update_everyone(g))
        self.log(req.user, "Started updating everyone's Roblox roles")
        return {"ok": True, "message": f"Updating {count} linked {'member' if count == 1 else 'members'} in the background."}

    # ── reaction roles ──

    async def create_reaction_panel(self, req: Req) -> dict:
        g = self.need_guild()
        b = req.body
        ch = self.text_channel(g, b.get("channel_id"))
        title = str(b.get("title") or "Reaction Roles").strip()[:200]
        rows = b.get("rows") or []
        if not isinstance(rows, list) or len(rows) > 20:
            raise ApiError(400, "A panel can have up to 20 roles.")

        raw = []
        for row in rows:
            rid = row.get("role_id")
            role = g.get_role(_int(rid, "role")) if rid else None
            if rid and role is None:
                raise ApiError(400, "One of those roles isn't in the server anymore.")
            raw.append((role, str(row.get("emoji") or "").strip() or None))

        cog = self.cog("ReactionRoles")
        pairs, error = cog.check_pairs(raw, mention=False)
        if error:
            raise ApiError(400, error)

        msg, failed = await self.discord_call(cog.post_panel(ch, title, pairs), "Couldn't post the panel.")
        self.log(req.user, f"Posted a reaction role panel in #{ch.name}")
        note = f" These emojis didn't work: {' '.join(failed)}" if failed else ""
        return {"ok": True, "url": msg.jump_url, "message": f"Panel posted in #{ch.name}.{note}",
                "reaction_panels": self.panels_info(g)}

    async def delete_reaction_panel(self, req: Req) -> dict:
        g = self.need_guild()
        cog = self.cog("ReactionRoles")
        mid = str(req.params.get("id"))
        if mid not in cog.panels:
            raise ApiError(404, "That panel doesn't exist anymore.")
        keep = bool(req.query.get("keep_message") in ("1", "true"))
        await cog.delete_panel(mid, delete_message=not keep)
        self.log(req.user, "Deleted a reaction role panel")
        return {"ok": True, "message": "Panel deleted.", "reaction_panels": self.panels_info(g)}


# Make sure every route points at a real handler (catches typos at startup)
for _m, _p, _h in Api.ROUTES:
    assert not _p.startswith("/api/"), _p
    assert hasattr(Api, _h), _h
assert set(FIELDS) <= set(LABELS), set(FIELDS) - set(LABELS)
