"""
Server logs: deleted and edited messages, joins and leaves, role and nickname changes, bans,
voice channel moves and channels being made or deleted. Pick what's logged on the dashboard.
"""

import discord
from discord.ext import commands

from .wl_embed import config, use_guild, simple_view
from .figs import feature_on


def _quote(text: str, limit: int = 900) -> str:
    text = (text or "").replace("```", "'''").strip()
    return f"```{text[:limit]}```" if text else "-# (no text)"


class ServerLogs(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def wants(self, guild, event: str) -> bool:
        use_guild(guild)
        return feature_on(config, "logs") and bool(config.get("logs_channel_id")) and event in config.get("logs_events", [])

    async def post(self, guild, *lines: str, messages: bool = False):
        cid = (config.get("logs_message_channel_id") if messages else None) or config.get("logs_channel_id")
        channel = guild.get_channel(cid or 0)
        if channel is None:
            return
        try:
            await channel.send(view=simple_view(*lines[:3]), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass

    def skip_channel(self, channel) -> bool:
        ids = {config.get("logs_channel_id"), config.get("logs_message_channel_id"), *config.get("logs_ignored_channel_ids", [])}
        return getattr(channel, "id", None) in ids

    # ── messages ──

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if message.guild is None or message.author.bot or not self.wants(message.guild, "message_delete"):
            return
        if self.skip_channel(message.channel):
            return
        files = len(getattr(message, "attachments", []) or [])
        await self.post(message.guild, f"### 🗑️ Message deleted in {message.channel.mention}",
                        f"By {message.author.mention} ({message.author})" + (f", with {files} file{'s' if files != 1 else ''}" if files else ""),
                        _quote(message.content), messages=True)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if after.guild is None or after.author.bot or before.content == after.content:
            return
        if not self.wants(after.guild, "message_edit") or self.skip_channel(after.channel):
            return
        await self.post(after.guild, f"### ✏️ Message edited in {after.channel.mention}",
                        f"By {after.author.mention} ([jump to it]({after.jump_url}))\n**Before**",
                        _quote(before.content, 700) + "\n**After**\n" + _quote(after.content, 700), messages=True)

    # ── members ──

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not self.wants(member.guild, "member_join"):
            return
        created = getattr(member, "created_at", None)
        age = f"Account made <t:{int(created.timestamp())}:R>" if created else ""
        await self.post(member.guild, "### 📥 Member joined",
                        f"{member.mention} ({member}){' 🤖' if member.bot else ''}",
                        f"{age}\n-# Member #{member.guild.member_count}".strip())

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if not self.wants(member.guild, "member_leave"):
            return
        roles = [r.mention for r in getattr(member, "roles", []) if not r.is_default()]
        await self.post(member.guild, "### 📤 Member left", f"{member.mention} ({member})",
                        ("Roles: " + " ".join(roles[:20])) if roles else "-# No roles")

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        guild = after.guild
        added = [r for r in after.roles if r not in before.roles]
        removed = [r for r in before.roles if r not in after.roles]
        if (added or removed) and self.wants(guild, "member_roles"):
            parts = []
            if added:
                parts.append("Added " + " ".join(r.mention for r in added))
            if removed:
                parts.append("Removed " + " ".join(r.mention for r in removed))
            await self.post(guild, "### 🏷️ Roles changed", f"{after.mention} ({after})", "\n".join(parts))
        if getattr(before, "nick", None) != getattr(after, "nick", None) and self.wants(guild, "member_nick"):
            await self.post(guild, "### 📝 Nickname changed", f"{after.mention} ({after})",
                            f"**{before.nick or before.name}** → **{after.nick or after.name}**")

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user):
        if self.wants(guild, "member_ban"):
            await self.post(guild, "### 🔨 Member banned", f"<@{user.id}> ({user})")

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user):
        if self.wants(guild, "member_unban"):
            await self.post(guild, "### 🕊️ Member unbanned", f"<@{user.id}> ({user})")

    # ── voice and channels ──

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel or not self.wants(member.guild, "voice"):
            return
        if before.channel is None:
            line = f"joined 🔊 {after.channel.mention}"
        elif after.channel is None:
            line = f"left 🔊 {before.channel.mention}"
        else:
            line = f"moved from 🔊 {before.channel.mention} to 🔊 {after.channel.mention}"
        await self.post(member.guild, "### 🎙️ Voice", f"{member.mention} {line}")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        if self.wants(channel.guild, "channels"):
            await self.post(channel.guild, "### ➕ Channel made", f"{channel.mention} (#{channel.name})")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        if self.wants(channel.guild, "channels"):
            await self.post(channel.guild, "### ➖ Channel deleted", f"#{channel.name}")


async def setup(bot: commands.Bot):
    await bot.add_cog(ServerLogs(bot))
