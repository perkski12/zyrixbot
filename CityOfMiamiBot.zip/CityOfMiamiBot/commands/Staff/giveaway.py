import asyncio
import json
import random
import re
import time

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, city_emoji, accent, use_guild

DATA_FILE = "giveaways.json"           # saved so giveaways survive restarts
JOIN_ID = "cityofmiami:giveaway:join"  # the Join button's ID (handled in on_interaction)

UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def _parse_duration(text: str) -> int | None:
    """'30m', '2h', '1d12h', '1w' → seconds. None if it can't be read."""
    parts = re.findall(r"(\d+)\s*([smhdw])", text.lower())
    if not parts or re.sub(r"[\d\s smhdw]", "", text.lower()):
        return None
    return sum(int(n) * UNITS[u] for n, u in parts)


def _load() -> dict:
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


class Giveaway(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.giveaways = _load()  # {message_id: {...}}
        self._pending_updates: set[str] = set()

    async def cog_load(self):
        self.check_giveaways.start()

    async def cog_unload(self):
        self.check_giveaways.cancel()

    def _save(self):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(self.giveaways, f, indent=2)

    # ──────────────────────────── the giveaway message ──────────────────────

    def _view(self, g: dict) -> ui.LayoutView:
        use_guild(g["guild_id"])  # draw it with that server's emoji and colors
        ended = g["ended"]
        end = int(g["end"])
        entries = len(g["entrants"])

        if ended:
            winners = g.get("winner_ids", [])
            winner_text = ", ".join(f"<@{w}>" for w in winners) if winners else "No valid entries"
            details = (
                f"**Winners:** {winner_text}\n"
                f"**Ended:** <t:{end}:R>\n"
                f"**Hosted By:** <@{g['host_id']}>\n"
                f"**Entries:** **{entries}**"
            )
        else:
            details = (
                f"**Winners:** {g['winners']}\n"
                f"**Ends:** <t:{end}:R> (<t:{end}:f>)\n"
                f"**Hosted By:** <@{g['host_id']}>\n"
                f"**Entries:** **{entries}**"
            )

        title = ui.TextDisplay(f"## {city_emoji()} {'Giveaway Ended' if ended else 'Giveaway'}")
        prize = ui.TextDisplay(f"### {g['prize']}")
        thumb = config.get("thumbnail_url", "")

        children = []
        if thumb and str(thumb).startswith("http"):
            children.append(ui.Section(title, prize, accessory=ui.Thumbnail(
                media=discord.UnfurledMediaItem(url=thumb), description="Server thumbnail")))
        else:
            children += [title, prize]

        children += [
            ui.Separator(),
            ui.TextDisplay(details),
            ui.Separator(visible=False),
            ui.ActionRow(ui.Button(
                label="Giveaway Ended" if ended else "Join Giveaway",
                style=discord.ButtonStyle.secondary if ended else discord.ButtonStyle.primary,
                emoji=city_emoji(),
                custom_id=JOIN_ID,
                disabled=ended
            )),
            ui.TextDisplay(f"-# {config.get('server_name', 'City Of Miami')}"),
        ]

        view = ui.LayoutView()
        view.add_item(ui.Container(*children, accent_color=accent()))
        return view

    async def _refresh(self, mid: str):
        g = self.giveaways.get(mid)
        channel = self.bot.get_channel(g["channel_id"]) if g else None
        if not channel:
            return
        try:
            await channel.get_partial_message(int(mid)).edit(
                view=self._view(g), allowed_mentions=discord.AllowedMentions.none()
            )
        except discord.HTTPException:
            pass

    def _schedule_refresh(self, mid: str):
        """Update the entry count at most once every 2 seconds (avoids rate limits)."""
        if mid in self._pending_updates:
            return
        self._pending_updates.add(mid)

        async def run():
            await asyncio.sleep(2)
            self._pending_updates.discard(mid)
            await self._refresh(mid)

        asyncio.create_task(run())

    # ──────────────────────────── /giveaway ─────────────────────────────────

    @app_commands.command(name="giveaway", description="Start a giveaway")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(
        prize="What they win",
        duration="How long it runs, like 30m, 2h, 1d or 1d12h",
        winners="How many winners (default 1)"
    )
    async def giveaway(
        self,
        interaction: discord.Interaction,
        prize: app_commands.Range[str, 1, 200],
        duration: str,
        winners: app_commands.Range[int, 1, 50] = 1
    ):
        seconds = _parse_duration(duration)
        if not seconds or seconds < 10 or seconds > 60 * 86400:
            await interaction.response.send_message(
                "Use a time like `30m`, `2h`, `1d` or `1d12h` (between 10 seconds and 60 days).",
                ephemeral=True
            )
            return

        try:
            await self.create(interaction.channel, prize, seconds, winners, interaction.user.id)
        except discord.HTTPException:
            await interaction.response.send_message("I can't send messages in this channel.", ephemeral=True)
            return

        await interaction.response.send_message("Giveaway started!", ephemeral=True)

    # ──────────────────────────── shared with the dashboard ─────────────────

    async def create(self, channel, prize: str, seconds: int, winners: int, host_id: int) -> str:
        """Post a giveaway in `channel` and start tracking it. Returns the message ID."""
        g = {
            "guild_id": channel.guild.id,
            "channel_id": channel.id,
            "prize": prize,
            "winners": winners,
            "end": int(time.time()) + seconds,
            "host_id": host_id,
            "entrants": [],
            "ended": False,
        }
        message = await channel.send(view=self._view(g), allowed_mentions=discord.AllowedMentions.none())
        self.giveaways[str(message.id)] = g
        self._save()
        return str(message.id)

    async def end_now(self, mid: str):
        """End a running giveaway early and pick the winners."""
        g = self.giveaways.get(mid)
        if g and not g["ended"]:
            await self._end(mid)

    async def reroll(self, mid: str) -> list[int]:
        """Pick new winners for an ended giveaway (people who already won are skipped)."""
        g = self.giveaways.get(mid)
        if not g or not g["ended"]:
            return []
        guild = self.bot.get_guild(g["guild_id"])
        old = set(g.get("winner_ids", []))
        valid = [uid for uid in g["entrants"] if uid not in old and guild and guild.get_member(uid)]
        new = random.sample(valid, min(g["winners"], len(valid)))
        if not new:
            return []

        g["winner_ids"] = new
        self._save()
        await self._refresh(mid)

        channel = self.bot.get_channel(g["channel_id"])
        if channel:
            mentions = ", ".join(f"<@{w}>" for w in new)
            try:
                await channel.send(
                    f"{city_emoji()} Reroll! Congratulations {mentions}, you won **{g['prize']}**!",
                    reference=channel.get_partial_message(int(mid)),
                    mention_author=False,
                    allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False)
                )
            except discord.HTTPException:
                pass
        return new

    async def delete(self, mid: str):
        """Stop tracking a giveaway and delete its message."""
        g = self.giveaways.pop(mid, None)
        self._save()
        channel = self.bot.get_channel(g["channel_id"]) if g else None
        if channel:
            try:
                await channel.get_partial_message(int(mid)).delete()
            except discord.HTTPException:
                pass

    # ──────────────────────────── Join button ───────────────────────────────

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return
        if (interaction.data or {}).get("custom_id") != JOIN_ID or not interaction.message:
            return

        mid = str(interaction.message.id)
        g = self.giveaways.get(mid)
        use_guild(interaction.guild)

        if not g or g["ended"]:
            await interaction.response.send_message("This giveaway has ended.", ephemeral=True)
            return

        uid = interaction.user.id
        if uid in g["entrants"]:
            g["entrants"].remove(uid)
            text = "You left the giveaway."
        else:
            g["entrants"].append(uid)
            text = f"{city_emoji()} You're entered! Good luck. Click again to leave."

        self._save()
        await interaction.response.send_message(text, ephemeral=True)
        self._schedule_refresh(mid)

    # ──────────────────────────── ending ────────────────────────────────────

    async def _end(self, mid: str):
        g = self.giveaways[mid]
        guild = self.bot.get_guild(g["guild_id"])
        use_guild(g["guild_id"])

        # Only people still in the server can win
        valid = [uid for uid in g["entrants"] if guild and guild.get_member(uid)]
        winner_ids = random.sample(valid, min(g["winners"], len(valid)))

        g["ended"] = True
        g["winner_ids"] = winner_ids
        self._save()
        await self._refresh(mid)

        channel = self.bot.get_channel(g["channel_id"])
        if not channel:
            return

        if winner_ids:
            mentions = ", ".join(f"<@{w}>" for w in winner_ids)
            text = f"{city_emoji()} Congratulations {mentions}! You won **{g['prize']}**!"
        else:
            text = f"No one entered the giveaway for **{g['prize']}**."

        try:
            await channel.send(
                text,
                reference=channel.get_partial_message(int(mid)),
                mention_author=False,
                allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False)
            )
        except discord.HTTPException:
            pass

    @tasks.loop(seconds=15)
    async def check_giveaways(self):
        now = time.time()
        for mid, g in list(self.giveaways.items()):
            if not g["ended"] and g["end"] <= now:
                await self._end(mid)

    @check_giveaways.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()


async def setup(bot: commands.Bot):
    await bot.add_cog(Giveaway(bot))
