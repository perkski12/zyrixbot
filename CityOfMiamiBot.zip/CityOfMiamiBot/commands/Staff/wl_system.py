import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import send_wl_embed, config, save_config, accent, use_guild
from .figs import feature_on


def _thumbnail_url() -> str:
    return config.get("thumbnail_url", "")


def _make_container(*text_lines: str, accent_color: int | None = None, thumbnail: bool = True) -> ui.Container:
    """Helper: build a simple labelled Container, optionally with a thumbnail section."""
    url = _thumbnail_url()
    children = []

    if thumbnail and url and str(url).startswith("http"):
        children.append(
            ui.Section(
                *[ui.TextDisplay(line) for line in text_lines],
                accessory=ui.Thumbnail(
                    media=discord.UnfurledMediaItem(url=url),
                    description="Server thumbnail"
                )
            )
        )
    else:
        for line in text_lines:
            children.append(ui.TextDisplay(line))

    return ui.Container(*children, accent_color=accent_color if accent_color is not None else accent())


class WLSystem(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @property
    def wl_enabled(self) -> bool:
        # Read live from config so the dashboard and /turnonwl /turnoffwl always agree
        return bool(config.get("wl_enabled", True))

    # ──────────────────────────── slash commands ────────────────────────────

    def _set_mode(self, enabled: bool, channel: discord.abc.GuildChannel):
        """Switch WL/vouch mode, make this the whitelist channel, and remember both."""
        config["wl_enabled"] = enabled
        config["whitelist_channel_id"] = channel.id
        save_config()

    @app_commands.command(name="turnonwl", description="Enable direct WL mode")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(channel="The whitelist channel (default: the channel you run this in)")
    async def turnonwl(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None):
        channel = channel or interaction.channel
        self._set_mode(True, channel)

        class ModeView(ui.LayoutView):
            def __init__(self):
                super().__init__()
                self.add_item(_make_container(
                    "## WL Mode Enabled",
                    f"Type `wl` in {channel.mention} to get whitelisted."
                ))

        await interaction.response.send_message(view=ModeView(), ephemeral=True)

    @app_commands.command(name="turnoffwl", description="Enable Vouch Mode")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(channel="The whitelist channel (default: the channel you run this in)")
    async def turnoffwl(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None):
        channel = channel or interaction.channel
        self._set_mode(False, channel)

        class ModeView(ui.LayoutView):
            def __init__(self):
                super().__init__()
                self.add_item(_make_container(
                    "## Vouch Mode Enabled",
                    f"Only whitelisted users can vouch with `vouch @user` in {channel.mention}."
                ))

        await interaction.response.send_message(view=ModeView(), ephemeral=True)

    # ──────────────────────────── listeners ─────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        use_guild(message.guild)
        if not feature_on(config, "whitelist"):
            return

        if message.channel.id != config.get("whitelist_channel_id"):
            return

        content = message.content.lower().strip()

        if self.wl_enabled and content == "wl":
            await self.process_whitelist(message)
        elif not self.wl_enabled and content.startswith("vouch"):
            await self.process_vouch(message)

    # ──────────────────────────── wl logic ──────────────────────────────────

    async def _give_role(self, member: discord.Member, role: discord.Role, channel) -> bool:
        """Give the whitelist role. If it fails, say why in the channel instead of failing silently."""
        try:
            await member.add_roles(role, reason="Whitelisted")
            return True
        except discord.Forbidden:
            problem = (
                f"I can't give {role.mention}. Make sure I have **Manage Roles** and that "
                f"my role is **above** {role.mention} in Server Settings → Roles."
            )
        except discord.HTTPException as e:
            problem = f"Discord returned an error while giving {role.mention}: `{e}`"

        print(f"[WL] Failed to give {role.name} to {member}: {problem}")

        class ErrorView(ui.LayoutView):
            def __init__(self):
                super().__init__()
                self.add_item(_make_container("## Whitelist Failed", problem))

        try:
            await channel.send(view=ErrorView(), allowed_mentions=discord.AllowedMentions.none(), delete_after=30)
        except discord.HTTPException:
            pass
        return False

    async def process_whitelist(self, message: discord.Message):
        """Handle direct 'wl' command"""
        role = message.guild.get_role(config.get("whitelist_role_id") or 0)
        if not role:
            await message.channel.send("The whitelist role isn't set. Pick it on the dashboard (Whitelist page).", delete_after=10)
            return

        if not await self._give_role(message.author, role, message.channel):
            return

        # Remove the unverified role if configured and the member has it
        unverified_role = message.guild.get_role(config.get("unverified_role_id") or 0)
        if unverified_role and unverified_role in message.author.roles:
            try:
                await message.author.remove_roles(unverified_role)
            except Exception:
                pass

        class SuccessView(ui.LayoutView):
            def __init__(self):
                super().__init__()
                self.add_item(_make_container(
                    "## Whitelisted Successfully",
                    f"{message.author.mention} has been whitelisted!"
                ))

        await message.channel.send(view=SuccessView())
        await self.send_log(message.guild, message.author, "Direct WL")

    async def process_vouch(self, message: discord.Message):
        """Handle 'vouch @user' command"""
        whitelist_role = message.guild.get_role(config.get("whitelist_role_id") or 0)
        if not whitelist_role:
            await message.channel.send("Whitelist role not found.", delete_after=10)
            return

        if whitelist_role not in message.author.roles:
            class NoPermView(ui.LayoutView):
                def __init__(self):
                    super().__init__()
                    self.add_item(_make_container(
                        "## No Permission",
                        "Only whitelisted users can vouch others."
                    ))

            await message.channel.send(view=NoPermView(), delete_after=10)
            return

        if not message.mentions:
            await message.channel.send("Please mention a user: `vouch @user`", delete_after=10)
            return

        target = message.mentions[0]
        if not await self._give_role(target, whitelist_role, message.channel):
            return

        # Remove the unverified role if configured and the member has it
        unverified_role = message.guild.get_role(config.get("unverified_role_id") or 0)
        if unverified_role and unverified_role in target.roles:
            try:
                await target.remove_roles(unverified_role)
            except Exception:
                pass

        class VouchView(ui.LayoutView):
            def __init__(self):
                super().__init__()
                self.add_item(_make_container(
                    "## Vouch Successful",
                    f"{target.mention} has been whitelisted by {message.author.mention}!"
                ))

        await message.channel.send(view=VouchView())
        await self.send_log(message.guild, target, f"Vouched by {message.author}")

    async def send_log(self, guild: discord.Guild, user: discord.Member, method: str):
        log_channel_id = config.get("log_channel_id")
        if not log_channel_id:
            return

        log_channel = guild.get_channel(log_channel_id)
        if not log_channel:
            return

        ts = int(discord.utils.utcnow().timestamp())
        url = _thumbnail_url()

        class LogView(ui.LayoutView):
            def __init__(self):
                super().__init__()

                children = []

                if url and str(url).startswith("http"):
                    children.append(ui.Section(
                        ui.TextDisplay("## Whitelist Log"),
                        ui.TextDisplay(f"{user.mention} has been whitelisted"),
                        accessory=ui.Thumbnail(
                            media=discord.UnfurledMediaItem(url=url),
                            description="Server thumbnail"
                        )
                    ))
                else:
                    children.append(ui.TextDisplay("## Whitelist Log"))
                    children.append(ui.TextDisplay(f"{user.mention} has been whitelisted"))

                children.append(ui.Separator())
                children.append(ui.TextDisplay(f"**Method:** {method}"))
                children.append(ui.TextDisplay(f"**User ID:** `{user.id}`"))
                children.append(ui.TextDisplay(f"**Time:** <t:{ts}:F>"))
                children.append(ui.Separator(visible=False))
                children.append(ui.TextDisplay(f"-# {guild.name}"))

                self.add_item(ui.Container(*children, accent_color=accent()))

        try:
            await log_channel.send(view=LogView())
        except Exception:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(WLSystem(bot))
