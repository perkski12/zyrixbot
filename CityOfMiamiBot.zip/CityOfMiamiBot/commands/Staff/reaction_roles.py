import json

import discord
from discord import app_commands
from discord.ext import commands

from .wl_embed import config, simple_view, use_guild
from .figs import feature_on

# Saved panels live here so reaction roles keep working after a restart
DATA_FILE = "reaction_roles.json"


def _load() -> dict:
    """{message_id: {"channel_id", "title", "roles": {emoji_key: role_id}, "emojis": {emoji_key: emoji_text}}}"""
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

    # Older saves were just {message_id: {emoji_key: role_id}}; upgrade them in place
    for mid, panel in list(data.items()):
        if "roles" not in panel:
            data[mid] = {"channel_id": None, "title": "Reaction Roles", "roles": panel, "emojis": {}}
    return data


def _save(data: dict):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _emoji_key(emoji: discord.PartialEmoji) -> str:
    """Custom emojis match by ID, normal emojis match by the character itself."""
    return str(emoji.id) if emoji.id else emoji.name


def _panel_view(title: str, pairs: list[tuple[discord.Role, discord.PartialEmoji]]):
    server_name = config.get("server_name", "City Of Miami")
    role_list = "\n".join(f"{emoji} → {role.mention}" for role, emoji in pairs)
    return simple_view(
        f"## {title}",
        f"**{server_name}** React to the certain emoji to receive the certain role",
        role_list
    )


class ReactionRoles(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.panels = _load()

    # ──────────────────────────── shared with the dashboard ─────────────────

    @staticmethod
    def check_pairs(raw: list[tuple[discord.Role | None, str | None]], mention: bool = True):
        """Turn (role, emoji text) pairs into (role, PartialEmoji). Returns (pairs, error_text)."""
        pairs: list[tuple[discord.Role, discord.PartialEmoji]] = []
        for i, (role, emoji) in enumerate(raw, start=1):
            if role is None and not emoji:
                continue
            if role is None or not emoji:
                return [], f"Role {i} and emoji {i} have to be filled in together."
            if not role.is_assignable():
                who = role.mention if mention else f"@{role.name}"
                return [], f"{who} is above my role. Move my role higher in Server Settings → Roles."
            pairs.append((role, discord.PartialEmoji.from_str(emoji.strip())))

        if not pairs:
            return [], "Add at least one role and emoji."
        keys = [_emoji_key(e) for _, e in pairs]
        if len(keys) != len(set(keys)):
            return [], "Each role needs its own emoji."
        return pairs, None

    async def attach(self, message: discord.Message, title: str, pairs) -> list[str]:
        """React on a posted panel and start tracking it. Returns emojis that couldn't be added."""
        roles, emojis, failed = {}, {}, []
        for role, emoji in pairs:
            try:
                await message.add_reaction(emoji)
                roles[_emoji_key(emoji)] = role.id
                emojis[_emoji_key(emoji)] = str(emoji)
            except discord.HTTPException:
                failed.append(str(emoji))

        if roles:
            self.panels[str(message.id)] = {
                "channel_id": message.channel.id,
                "title": title,
                "roles": roles,
                "emojis": emojis,
            }
            _save(self.panels)
        return failed

    async def post_panel(self, channel: discord.TextChannel, title: str, pairs) -> tuple[discord.Message, list[str]]:
        """Post a new panel in `channel` (used by the dashboard)."""
        message = await channel.send(view=_panel_view(title, pairs), allowed_mentions=discord.AllowedMentions.none())
        failed = await self.attach(message, title, pairs)
        return message, failed

    async def delete_panel(self, message_id: str, delete_message: bool = True):
        panel = self.panels.pop(str(message_id), None)
        _save(self.panels)
        if panel and delete_message and panel.get("channel_id"):
            channel = self.bot.get_channel(panel["channel_id"])
            if channel:
                try:
                    await channel.get_partial_message(int(message_id)).delete()
                except discord.HTTPException:
                    pass

    # ──────────────────────────── /reactionrole ─────────────────────────────

    @app_commands.command(name="reactionrole", description="Post a reaction role panel")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(
        role1="First role", emoji1="Emoji for the first role",
        role2="Second role", emoji2="Emoji for the second role",
        role3="Third role", emoji3="Emoji for the third role",
        role4="Fourth role", emoji4="Emoji for the fourth role",
        role5="Fifth role", emoji5="Emoji for the fifth role",
        title="Title at the top of the panel"
    )
    async def reactionrole(
        self,
        interaction: discord.Interaction,
        role1: discord.Role, emoji1: str,
        role2: discord.Role | None = None, emoji2: str | None = None,
        role3: discord.Role | None = None, emoji3: str | None = None,
        role4: discord.Role | None = None, emoji4: str | None = None,
        role5: discord.Role | None = None, emoji5: str | None = None,
        title: str = "Reaction Roles"
    ):
        raw = [(role1, emoji1), (role2, emoji2), (role3, emoji3), (role4, emoji4), (role5, emoji5)]
        pairs, error = self.check_pairs(raw)
        if error:
            await interaction.response.send_message(
                view=simple_view("## Can't Post That Panel", error),
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none()
            )
            return

        await interaction.response.send_message(
            view=_panel_view(title, pairs),
            allowed_mentions=discord.AllowedMentions.none()  # don't ping the roles
        )
        message = await interaction.original_response()

        # Add each reaction so members can click it
        failed = await self.attach(message, title, pairs)

        if failed:
            await interaction.followup.send(
                view=simple_view(
                    "## Some Emojis Didn't Work",
                    f"I couldn't react with: {' '.join(failed)}",
                    "-# Use a normal emoji, or a custom emoji from a server I'm in."
                ),
                ephemeral=True
            )

    # ──────────────────────────── listeners ─────────────────────────────────

    async def _handle(self, payload: discord.RawReactionActionEvent, add: bool):
        if payload.guild_id is None or payload.user_id == self.bot.user.id:
            return

        panel = self.panels.get(str(payload.message_id))
        role_id = panel["roles"].get(_emoji_key(payload.emoji)) if panel else None
        if not role_id:
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        use_guild(guild)
        if not feature_on(config, "reaction-roles"):
            return

        member = payload.member or guild.get_member(payload.user_id)
        role = guild.get_role(role_id)
        if not member or member.bot or not role:
            return

        try:
            if add:
                await member.add_roles(role, reason="Reaction role")
            else:
                await member.remove_roles(role, reason="Reaction role removed")
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        await self._handle(payload, add=True)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        await self._handle(payload, add=False)

    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload: discord.RawMessageDeleteEvent):
        # Forget panels that get deleted
        if self.panels.pop(str(payload.message_id), None) is not None:
            _save(self.panels)


async def setup(bot: commands.Bot):
    await bot.add_cog(ReactionRoles(bot))
