"""
Prefix commands: every slash command also works as ,ban @someone spam (the prefix is set on the
dashboard's Commands page, "," by default). It runs the very same code as the slash command, so the
two never drift apart.

  ,ban @bob spamming            the last text option takes the rest of the line
  ,tempban @bob 3d spam
  ,role add @bob VIP            command groups: ,role add / ,role remove / ,reminder set ...
  ,softban @bob spam days=3     options after the text go as name=value
  ,timeout @bob 10m             minutes and seconds can be written as 10m, 2h, 30s
  ,help  /  ,help ban           what you can use here, and how

Mentioning the bot works as a prefix too (@zyrix help). Replies are visible to everyone, because a
normal message can't have a "only you can see this" answer. Commands that open a form (/announce,
/apply...) answer that they only work as slash commands.
"""

import inspect
import re
import sys
import traceback

import discord
from discord.ext import commands

from .wl_embed import config, use_guild, accent
from .figs import COMMAND_FEATURES, FEATURES, feature_on
from .kit import box, parse_duration

ALIASES = {
    "mute": "timeout", "unmute": "untimeout", "clear": "purge", "warns": "warnings", "w": "warn",
    "ui": "userinfo", "whois": "userinfo", "si": "serverinfo", "av": "avatar", "pfp": "avatar", "mc": "membercount",
    "remind": "reminder set", "reminders": "reminder list", "tb": "tempban", "sb": "softban", "nickname": "nick",
}
TOKEN = re.compile(r'"([^"]*)"|“([^”]*)”|(\S+)')
KEYWORD = re.compile(r"^([A-Za-z_][\w-]*)[=:](.+)$", re.S)
MENTION_USER = re.compile(r"^<@!?(\d{15,22})>$")
MENTION_ROLE = re.compile(r"^<@&(\d{15,22})>$")
MENTION_CHANNEL = re.compile(r"^<#(\d{15,22})>$")
SNOWFLAKE = re.compile(r"^\d{15,22}$")
YES = {"yes", "y", "true", "on", "1", "enable", "enabled"}
NO = {"no", "n", "false", "off", "0", "disable", "disabled"}


class Bad(Exception):
    """A typed option that doesn't fit. The message is shown to the person."""


class FormNeeded(Exception):
    pass


def kind(param) -> str:
    """'string', 'integer', 'boolean', 'user', 'channel', 'role', 'number', 'attachment'..."""
    t = getattr(param, "type", None)
    return getattr(t, "name", str(t)).lower()


def tokens(text: str) -> list[tuple[str, int, int]]:
    """Words (and "quoted words") with where they start and end in the text."""
    out = []
    for m in TOKEN.finditer(text):
        value = next(g for g in m.groups() if g is not None)
        out.append((value, m.start(), m.end()))
    return out


# ── the stand-in for a slash command interaction ──

class _Response:
    def __init__(self, it):
        self.it, self._done = it, False

    def is_done(self) -> bool:
        return self._done

    async def send_message(self, content=None, *, ephemeral=False, **kw):
        self._done = True
        await self.it.send(content, **kw)

    async def defer(self, *, ephemeral=False, thinking=False):
        self._done = True
        try:
            await self.it.channel.typing()
        except Exception:
            pass

    async def edit_message(self, **kw):
        self._done = True
        if self.it.sent:
            await self.it.sent[-1].edit(**kw)

    async def send_modal(self, modal):
        raise FormNeeded()


class _Followup:
    def __init__(self, it):
        self.it = it

    async def send(self, content=None, *, ephemeral=False, wait=False, **kw):
        return await self.it.send(content, **kw)


class PrefixInteraction:
    """Looks enough like a slash command interaction for the commands' code. Answers go in the channel."""

    type = discord.InteractionType.application_command

    def __init__(self, bot, message, name: str):
        self.client = bot
        self.guild, self.user, self.channel = message.guild, message.author, message.channel
        self.guild_id, self.channel_id = message.guild.id, message.channel.id
        self.data = {"name": name, "prefix": True}
        self.message = None
        self.created_at = getattr(message, "created_at", None)
        self.extras = {}
        self.response, self.followup = _Response(self), _Followup(self)
        self.source = message
        self.sent = []

    @property
    def permissions(self):
        return self.channel.permissions_for(self.user)

    @property
    def app_permissions(self):
        return self.channel.permissions_for(self.guild.me)

    async def send(self, content=None, *, view=None, embed=None, embeds=None, file=None, files=None, poll=None,
                   allowed_mentions=None, delete_after=None, **_):
        kw = {k: v for k, v in dict(view=view, embed=embed, embeds=embeds, file=file, files=files, poll=poll,
                                    allowed_mentions=allowed_mentions, delete_after=delete_after).items() if v is not None}
        if not self.sent:  # the first answer replies to the command (still works if the command was deleted)
            try:
                kw["reference"] = self.source.to_reference(fail_if_not_exists=False)
                kw["mention_author"] = False
            except AttributeError:
                pass
        msg = await self.channel.send(content, **kw)
        self.sent.append(msg)
        return msg

    async def original_response(self):
        return self.sent[0] if self.sent else None

    async def edit_original_response(self, **kw):
        if self.sent:
            return await self.sent[0].edit(**kw)

    async def delete_original_response(self):
        if self.sent:
            await self.sent[0].delete()


class Prefix(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── finding the command ──

    def prefixes(self, guild) -> list[str]:
        out = []
        if config.get("prefix_enabled", True) and (config.get("prefix") or "").strip():
            out.append(config["prefix"].strip())
        if self.bot.user is not None:
            out += [f"<@{self.bot.user.id}> ", f"<@!{self.bot.user.id}> "]
        return out

    def find(self, words: list[str]):
        """(top-level command, the command to run, how it's written, how many typed words that took)."""
        first = words[0].lower()
        target = ALIASES[first].split() if self.bot.tree.get_command(first) is None and first in ALIASES else [first]
        top = self.bot.tree.get_command(target[0])
        if top is None:
            return None
        if not getattr(top, "commands", None):
            return top, top, top.name, 1
        typed = 1
        sub_name = target[1] if len(target) > 1 else None
        if sub_name is None and len(words) > 1:
            sub_name, typed = words[1].lower(), 2
        sub = top.get_command(sub_name) if sub_name else None
        if sub is None:
            return top, None, top.name, 1
        return top, sub, f"{top.name} {sub.name}", typed

    # ── reading the options ──

    def annotation(self, cmd, name: str):
        try:
            return inspect.signature(cmd.callback).parameters[name].annotation
        except (KeyError, ValueError, TypeError):
            return None

    def wants_member(self, cmd, name: str) -> bool:
        """discord.Member (has to be in the server) rather than discord.User (anyone)."""
        ann = self.annotation(cmd, name)
        return "Member" in str(ann) and "User" not in str(ann)

    def find_member(self, guild, token: str, by_name: bool):
        m = MENTION_USER.match(token)
        uid = int(m.group(1)) if m else (int(token) if SNOWFLAKE.match(token) else None)
        if uid:
            return guild.get_member(uid), uid
        if by_name:
            low = token.lower().lstrip("@")
            for mem in guild.members:
                if low in {str(getattr(mem, a, "") or "").lower() for a in ("name", "display_name", "global_name")}:
                    return mem, mem.id
        return None, None

    async def convert(self, guild, cmd, param, token: str, attachments: list, required: bool, by_name: bool | None = None):
        """Turn a typed word into the option's value. Raises Bad when it doesn't fit."""
        k, name = kind(param), param.name
        by_name = required if by_name is None else by_name
        choices = getattr(param, "choices", None) or []
        if choices:
            for c in choices:
                if token.lower() in (str(c.name).lower(), str(c.value).lower()):
                    return c.value
            raise Bad(f"`{name}` has to be one of: " + ", ".join(str(c.name) for c in choices))
        if k == "string":
            lo, hi = getattr(param, "min_value", None), getattr(param, "max_value", None)
            if lo is not None and len(token) < lo:
                raise Bad(f"`{name}` needs at least {lo} characters.")
            if hi is not None and len(token) > hi:
                raise Bad(f"`{name}` can be at most {hi} characters.")
            return token
        if k in ("integer", "number"):
            try:
                value = int(token) if k == "integer" else float(token)
            except ValueError:
                seconds = parse_duration(token) if name.endswith(("minutes", "seconds")) else None
                if seconds is None:
                    raise Bad(f"`{name}` has to be a number.")
                value = seconds // 60 if name.endswith("minutes") else seconds
            lo, hi = getattr(param, "min_value", None), getattr(param, "max_value", None)
            if (lo is not None and value < lo) or (hi is not None and value > hi):
                raise Bad(f"`{name}` has to be between {lo} and {hi}.")
            return value
        if k == "boolean":
            if token.lower() in YES:
                return True
            if token.lower() in NO:
                return False
            raise Bad(f"`{name}` has to be yes or no.")
        if k == "user":
            member, uid = self.find_member(guild, token, by_name=by_name)
            if member is not None:
                return member
            if uid and not self.wants_member(cmd, name):
                user = self.bot.get_user(uid)
                if user is None:
                    try:
                        user = await self.bot.fetch_user(uid)
                    except discord.HTTPException:
                        raise Bad(f"There's no Discord account with the ID {uid}.")
                return user
            raise Bad(f"I couldn't find the member `{token}` here. Mention them or paste their user ID.")
        if k == "role":
            m = MENTION_ROLE.match(token)
            rid = int(m.group(1)) if m else (int(token) if SNOWFLAKE.match(token) else None)
            role = guild.get_role(rid) if rid else None
            if role is None and by_name:
                low = token.lower().lstrip("@")
                role = next((r for r in guild.roles if r.name.lower() == low), None)
            if role is None:
                raise Bad(f"I couldn't find the role `{token}`. Mention it, paste its ID or type its exact name.")
            return role
        if k == "channel":
            m = MENTION_CHANNEL.match(token)
            cid = int(m.group(1)) if m else (int(token) if SNOWFLAKE.match(token) else None)
            ch = guild.get_channel(cid) if cid else None
            if ch is None and by_name:
                low = token.lower().lstrip("#")
                ch = next((c for c in getattr(guild, "channels", []) if getattr(c, "name", "").lower() == low), None)
            types = getattr(param, "channel_types", None) or []
            if ch is None or (types and ch.type not in types):
                raise Bad(f"I couldn't find the channel `{token}`. Mention it, like #general.")
            return ch
        if k == "attachment":
            if not attachments:
                raise Bad(f"Attach a file for `{name}`.")
            return attachments.pop(0)
        return token

    async def options(self, guild, cmd, text: str, attachments: list) -> dict:
        params = list(getattr(cmd, "parameters", []))
        by_name = {p.name.lower().replace("-", "_"): p for p in params}
        values: dict = {}

        # name=value anywhere (they're cut out of the text first)
        rest, keep = "", 0
        for word, start, end in tokens(text):
            m = KEYWORD.match(word)
            key = m.group(1).lower().replace("-", "_") if m else None
            if key in by_name:
                p = by_name[key]
                values[p.name] = await self.convert(guild, cmd, p, m.group(2).strip('"'), attachments, True)
                rest += text[keep:start]
                keep = end
        rest += text[keep:]

        todo = [p for p in params if p.name not in values]
        strings = [p for p in todo if kind(p) == "string" and not getattr(p, "choices", None)]
        greedy = strings[-1] if strings else None  # the last text option takes the rest of the line
        words = tokens(rest)
        i, skipped = 0, None
        for n, p in enumerate(todo):
            if i >= len(words):
                break
            later = todo[n + 1:]
            whole = rest[words[i][1]:].strip() if len(words) - i > 1 else words[i][0]  # the rest of the line
            if p is greedy and not any(q.required for q in later):
                values[p.name] = await self.convert(guild, cmd, p, whole, attachments, p.required)
                i = len(words)
                break
            # names (not just mentions) count for a member, role or channel unless a text option comes later
            by_name = p.required or not any(q is greedy for q in later)
            try:
                values[p.name] = await self.convert(guild, cmd, p, words[i][0], attachments, p.required, by_name)
                i += 1
            except Bad:
                if kind(p) in ("user", "role", "channel") and not later and len(words) - i > 1:
                    # the last option: a name with spaces in it, like Server Booster
                    values[p.name] = await self.convert(guild, cmd, p, whole, attachments, p.required, True)
                    i = len(words)
                    break
                if p.required:
                    raise
                # an optional option this word isn't for: leave it out and try the word on the next one
                skipped = sys.exc_info()[1]
        if i < len(words) and skipped is not None:
            raise skipped  # a word was left over because it didn't fit anything: say why
        for p in params:  # files attached to the message fill file options
            if kind(p) == "attachment" and p.name not in values and attachments:
                values[p.name] = attachments.pop(0)
        missing = [p.name for p in params if p.required and p.name not in values]
        if missing:
            raise Bad("Missing: " + ", ".join(f"`{n}`" for n in missing) + ".")
        return values

    # ── help text ──

    def usage(self, prefix: str, written: str, cmd) -> str:
        params = list(getattr(cmd, "parameters", []))
        strings = [p for p in params if kind(p) == "string" and not getattr(p, "choices", None)]
        greedy = strings[-1] if strings else None
        parts, after = [], False
        for p in params:
            label = p.name
            if getattr(p, "choices", None):
                label = "|".join(str(c.name).lower() for c in p.choices)
            if after:
                parts.append(f"[{p.name}=…]")
            else:
                parts.append(f"<{label}>" if p.required else f"[{label}]")
            if p is greedy:
                after = True
        return f"{prefix}{written} " + " ".join(parts) if parts else f"{prefix}{written}"

    def can_use(self, member, top) -> bool:
        perms = getattr(top, "default_permissions", None)
        if not perms:
            return True
        mine = member.guild_permissions
        return getattr(mine, "administrator", False) or all(getattr(mine, n, False) for n, on in perms if on)

    def needs(self, top) -> str:
        perms = getattr(top, "default_permissions", None)
        names = [n.replace("_", " ").title() for n, on in perms if on] if perms else []
        return ", ".join(names)

    async def help(self, message, prefix: str, words: list[str]):
        guild, user = message.guild, message.author
        disabled = set(config.get("disabled_commands", []))
        if words:
            found = self.find(words)
            if not found:
                return await message.channel.send(view=box(f"## No command called `{words[0]}`", f"See them all with `{prefix}help`."),
                                                  reference=message.to_reference(fail_if_not_exists=False), mention_author=False)
            top, cmd, written, _ = found
            lines = []
            for c in ([cmd] if cmd else getattr(top, "commands", [])):
                w = written if cmd else f"{top.name} {c.name}"
                lines.append(f"`{self.usage(prefix, w, c)}`\n{c.description}")
            extra = f"-# Needs {self.needs(top)}  ·  Also works as `/{written}`" if self.needs(top) else f"-# Also works as `/{written}`"
            return await message.channel.send(view=box(f"## {prefix}{written}", "\n\n".join(lines)[:3800], extra),
                                              reference=message.to_reference(fail_if_not_exists=False), mention_author=False)
        groups: dict[str, list[str]] = {}
        for top in sorted(self.bot.tree.get_commands(), key=lambda c: c.name):
            feature = COMMAND_FEATURES.get(top.name)
            if top.name in disabled or (feature and not feature_on(config, feature)) or not self.can_use(user, top):
                continue
            name = FEATURES[feature][0] if feature in FEATURES else "General"
            subs = getattr(top, "commands", None)
            groups.setdefault(name, []).extend([f"`{top.name} {s.name}`" for s in subs] if subs else [f"`{top.name}`"])
        parts = [f"**{name}**\n" + " ".join(cmds) for name, cmds in sorted(groups.items())]
        chunks, cur = [], ""
        for p in parts:
            if len(cur) + len(p) > 3500:
                chunks.append(cur)
                cur = ""
            cur += ("\n\n" if cur else "") + p
        if cur:
            chunks.append(cur)
        await message.channel.send(
            view=box(f"## Commands you can use here", *chunks[:6],
                     f"-# Type `{prefix}` before any of them, like `{prefix}ban @someone spam`, or use / instead. "
                     f"`{prefix}help ban` shows how one works."),
            reference=message.to_reference(fail_if_not_exists=False), mention_author=False,
            allowed_mentions=discord.AllowedMentions.none())

    # ── running it ──

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or message.author.bot or not message.content:
            return
        use_guild(message.guild)
        content = message.content
        prefix = next((p for p in self.prefixes(message.guild) if content.startswith(p)), None)
        if prefix is None:
            return
        body = content[len(prefix):]
        words = [w for w, _, _ in tokens(body)]
        if not words or body[:1].isspace() and not prefix.endswith(" "):
            return  # just the prefix, or ", hello" in a sentence
        shown = prefix if not prefix.startswith("<@") else "@" + (self.bot.user.name if self.bot.user else "bot") + " "
        if words[0].lower() in ("help", "commands"):
            return await self.help(message, shown, words[1:])
        found = self.find(words)
        if found is None:
            return  # not a command: probably just a message that starts with the prefix
        top, cmd, written, used = found
        if cmd is None:
            subs = ", ".join(f"`{shown}{top.name} {s.name}`" for s in top.commands)
            return await message.channel.send(view=box(f"## {shown}{top.name} needs one more word", subs),
                                              reference=message.to_reference(fail_if_not_exists=False), mention_author=False)
        it = PrefixInteraction(self.bot, message, top.name)
        if not await self.bot.tree.interaction_check(it):
            return  # turned off, or part of a fig that's off (it already said so)
        if not self.can_use(message.author, top):
            return await it.send(view=box("## You can't use that", f"`{shown}{written}` needs **{self.needs(top)}**."))
        # the text after the command name, with its original spacing and new lines
        spans = tokens(body)
        start = spans[used][1] if len(spans) > used else len(body)
        attachments = list(getattr(message, "attachments", []))
        try:
            values = await self.options(message.guild, cmd, body[start:], attachments)
        except Bad as e:
            return await it.send(view=box(f"## {e}", f"`{self.usage(shown, written, cmd)}`",
                                          f"-# `{shown}help {written}` shows more"))
        try:
            if cmd.binding is not None:
                await cmd.callback(cmd.binding, it, **values)
            else:
                await cmd.callback(it, **values)
        except FormNeeded:
            await it.send(view=box(f"## Use /{written} for this one", "It opens a form, and forms only work with slash commands."))
        except Exception as e:
            traceback.print_exc()
            try:
                await it.send(view=box("## Something broke", f"`{shown}{written}` hit an error on the bot's side: {e}"[:1500]))
            except discord.HTTPException:
                pass


async def setup(bot: commands.Bot):
    await bot.add_cog(Prefix(bot))
