"""
FAQ panel: a message with a dropdown of common questions. Picking one shows the answer privately.
/faq answers a question in the channel. Posted panels update when you save new questions.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, use_guild, fill
from .figs import feature_on
from .kit import Store, box, reply, text_channel


def entries() -> list[dict]:
    return [e for e in config.get("faq_entries", []) if e.get("question") and e.get("answer")]


def panel_view(guild) -> ui.LayoutView:
    items = entries()
    parts = [f"## {config.get('faq_title') or 'FAQ'}"]
    if config.get("faq_text"):
        parts.append(fill(config["faq_text"], guild))
    if items:
        parts.append(ui.ActionRow(ui.Select(custom_id="faq:pick", placeholder="Pick a question", options=[
            discord.SelectOption(label=e["question"][:100], value=e["question"][:100], emoji=e.get("emoji") or None)
            for e in items[:25]])))
    else:
        parts.append("-# No questions yet.")
    return box(*parts)


class Faq(commands.Cog):
    DASH_ACTIONS = {"panel": "dash_panel"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("faq_panels.json")  # server → [[channel id, message id]]

    def find(self, question: str) -> dict | None:
        q = question.strip().lower()
        return next((e for e in entries() if e["question"][:100].lower() == q), None)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component or interaction.guild is None:
            return
        data = interaction.data or {}
        if data.get("custom_id") != "faq:pick":
            return
        use_guild(interaction.guild)
        found = self.find((data.get("values") or [""])[0]) if feature_on(config, "faq") else None
        if found is None:
            return await reply(interaction, "## That question was removed")
        await interaction.response.send_message(view=box(f"### {found.get('emoji') or '❔'} {found['question']}",
                                                         fill(found["answer"], interaction.guild, interaction.user)), ephemeral=True)

    @app_commands.command(name="faq", description="Answer a common question")
    @app_commands.describe(question="Which question")
    async def faq(self, interaction: discord.Interaction, question: str):
        found = self.find(question)
        if found is None:
            return await reply(interaction, "## No question like that", "Pick one from the list.")
        await interaction.response.send_message(view=box(f"### {found.get('emoji') or '❔'} {found['question']}",
                                                         fill(found["answer"], interaction.guild)))

    @faq.autocomplete("question")
    async def _questions(self, interaction: discord.Interaction, current: str):
        use_guild(interaction.guild)
        return [app_commands.Choice(name=e["question"][:100], value=e["question"][:100]) for e in entries()
                if current.lower() in e["question"].lower()][:25]

    async def settings_changed(self, guild, changed: list, before: dict) -> list[str]:
        if not {"faq_entries", "faq_title", "faq_text"} & set(changed):
            return []
        kept, updated = [], 0
        for cid, mid in self.store.guild(guild, list):
            channel = guild.get_channel(cid)
            if channel is None:
                continue
            try:
                await channel.get_partial_message(mid).edit(view=panel_view(guild))
                kept.append([cid, mid])
                updated += 1
            except discord.NotFound:
                pass
            except discord.HTTPException:
                kept.append([cid, mid])
        self.store.data[str(guild.id)] = kept
        self.store.save()
        return [f"Updated {updated} FAQ panel{'s' if updated != 1 else ''} in Discord."] if updated else []

    async def dash_panel(self, guild, body: dict, user: dict) -> dict:
        channel = text_channel(guild, body.get("channel_id"))
        msg = await channel.send(view=panel_view(guild))
        self.store.guild(guild, list).append([channel.id, msg.id])
        self.store.save()
        return {"message": f"Posted the FAQ in #{channel.name}.", "url": msg.jump_url, "log": f"Posted the FAQ panel in #{channel.name}"}


async def setup(bot: commands.Bot):
    await bot.add_cog(Faq(bot))
