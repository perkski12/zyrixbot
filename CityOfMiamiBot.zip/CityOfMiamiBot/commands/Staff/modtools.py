"""
Moderation: /warn, /warnings, /delwarn, /clearwarns, /timeout, /untimeout, /kick, /ban, /tempban,
/softban, /unban, /nick, /modlogs, /case, /purge, /slowmode, /lock, /unlock, /lockdown, /hide, /unhide,
/nuke and /voice. Every action is saved as a numbered case (data/mod_cases.json) and logged. Enough
warnings can time out, kick or ban someone automatically (dashboard → Moderation). Temporary bans
end by themselves (data/tempbans.json).
"""

import datetime
from typing import Optional

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, use_guild, simple_view, server_name
from .kit import Store, send_log, reply, now, person, DashError, parse_duration, duration_text, box

ACTIONS = {
    "warn": ("⚠️", "Warning", "You were warned"),
    "timeout": ("⏳", "Timeout", "You were timed out"),
    "untimeout": ("✅", "Timeout removed", None),
    "kick": ("👢", "Kick", "You were kicked"),
    "ban": ("🔨", "Ban", "You were banned"),
    "tempban": ("⏱️", "Temporary ban", "You were banned"),
    "softban": ("🧽", "Softban", "You were kicked and your recent messages were deleted"),
    "unban": ("🕊️", "Unban", None),
}
MAX_TEMPBAN = 365 * 86400


def _span(minutes: int) -> str:
    if minutes % 1440 == 0:
        return f"{minutes // 1440} day{'s' if minutes != 1440 else ''}"
    if minutes % 60 == 0:
        return f"{minutes // 60} hour{'s' if minutes != 60 else ''}"
    return f"{minutes} minute{'s' if minutes != 1 else ''}"


class _Someone:
    """A user who isn't in the server (for unban cases), or the dashboard as the moderator."""

    def __init__(self, uid: int, name: str | None = None):
        self.id, self.name = uid, name

    def __str__(self):
        return self.name or f"User {self.id}"


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'s' if n != 1 else ''}"


class ModTools(commands.Cog):
    DASH_ACTIONS = {"delete-case": "dash_delete_case", "clear-warnings": "dash_clear_warnings", "end-tempban": "dash_end_tempban"}

    case_group = app_commands.Group(name="case", description="Look up a moderation case or change its reason",
                                    default_permissions=discord.Permissions(moderate_members=True))
    lockdown_group = app_commands.Group(name="lockdown", description="Lock or unlock every channel at once",
                                        default_permissions=discord.Permissions(manage_channels=True))
    voice_group = app_commands.Group(name="voice", description="Disconnect, move or mute someone in voice",
                                     default_permissions=discord.Permissions(move_members=True))

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("mod_cases.json")
        self.tempbans = Store("tempbans.json")
        self.lockdowns = Store("lockdowns.json")

    async def cog_load(self):
        self.tempban_loop.start()

    async def cog_unload(self):
        self.tempban_loop.cancel()

    # ── cases ──

    def book(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"next": 1, "cases": []})

    def warnings_of(self, guild, user_id: int) -> list[dict]:
        return [c for c in self.book(guild)["cases"] if c["action"] == "warn" and c["user_id"] == user_id]

    def find_case(self, guild, number: int) -> dict | None:
        return next((c for c in self.book(guild)["cases"] if c["id"] == number), None)

    async def add_case(self, guild, user, mod, action: str, reason: str = "", extra: dict | None = None) -> dict:
        use_guild(guild)
        book = self.book(guild)
        case = {"id": book["next"], "action": action, "user_id": user.id, "user": str(user),
                "mod_id": mod.id, "mod": str(mod), "reason": reason or "", "t": now(), **(extra or {})}
        book["next"] += 1
        book["cases"].append(case)
        del book["cases"][:-2000]
        self.store.save()
        emoji, name, _ = ACTIONS[action]
        detail = f" for {_span(case['minutes'])}" if case.get("minutes") else ""
        await send_log(guild, "mod_log_channel_id", f"## {emoji} Case {case['id']}: {name}{detail}",
                       f"<@{user.id}> ({user}) by <@{mod.id}>", f"Reason: {reason}" if reason else "-# No reason given")
        if action == "warn":
            await self.after_warning(guild, user)
        return case

    async def after_warning(self, guild, user):
        """Enough warnings → timeout, kick or ban (set on the dashboard)."""
        member = guild.get_member(user.id)
        if member is None:
            return
        count = len(self.warnings_of(guild, user.id))
        reason = f"Reached {count} warnings"
        me = guild.me
        if count == int(config.get("mod_warn_ban", 0) or 0):
            if not self.above(me, member):
                await self.dm(guild, member, "ban", reason)
                try:
                    await guild.ban(member, reason=reason)
                    await self.add_case(guild, member, me, "ban", reason)
                except discord.HTTPException:
                    pass
        elif count == int(config.get("mod_warn_kick", 0) or 0):
            if not self.above(me, member):
                await self.dm(guild, member, "kick", reason)
                try:
                    await member.kick(reason=reason)
                    await self.add_case(guild, member, me, "kick", reason)
                except discord.HTTPException:
                    pass
        elif count == int(config.get("mod_warn_timeout", 0) or 0):
            minutes = int(config.get("mod_timeout_minutes", 60))
            try:
                await member.timeout(datetime.timedelta(minutes=minutes), reason=reason)
                await self.dm(guild, member, "timeout", reason, f" for {_span(minutes)}")
                await self.add_case(guild, member, me, "timeout", reason, {"minutes": minutes})
            except (discord.HTTPException, AttributeError):
                pass

    async def dm(self, guild, user, action: str, reason: str, extra: str = ""):
        text = ACTIONS[action][2]
        if not text or not config.get("mod_dm", True):
            return
        try:
            await user.send(view=simple_view(f"## {text} in {server_name(guild)}{extra}",
                                             f"Reason: {reason}" if reason else "No reason was given."))
        except (discord.HTTPException, AttributeError):
            pass

    # ── who can act on whom ──

    @staticmethod
    def above(actor, target) -> bool:
        """True if the target's highest role is the same as or above the actor's (so the actor can't act)."""
        if getattr(target, "top_role", None) is None or getattr(actor, "top_role", None) is None:
            return False
        if actor.id == actor.guild.owner_id:
            return False
        return target.top_role.position >= actor.top_role.position

    def problem(self, interaction, target, allow_self: bool = False) -> str | None:
        guild = interaction.guild
        if target.id == interaction.user.id and not allow_self:
            return "You can't do that to yourself."
        if target.id == guild.owner_id:
            return "That's the server owner."
        if target.id == guild.me.id:
            return "I can't do that to myself."
        if isinstance(target, discord.Member) or guild.get_member(target.id):
            member = guild.get_member(target.id) or target
            if target.id != interaction.user.id and self.above(interaction.user, member):
                return "Their highest role is the same as or above yours."
            if self.above(guild.me, member):
                return "Their highest role is above mine, so Discord won't let me. Drag my role higher in Server Settings → Roles."
        return None

    async def done(self, interaction, case: dict, line: str):
        emoji, name, _ = ACTIONS[case["action"]]
        await reply(interaction, f"## {emoji} {name} (case {case['id']})", line,
                    f"Reason: {case['reason']}" if case["reason"] else "-# No reason given")

    # ── warnings ──

    @app_commands.command(name="warn", description="Warn a member")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(member="Who to warn", reason="Why (they'll see this)")
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str):
        if member.bot or (error := self.problem(interaction, member)):
            return await reply(interaction, "## Can't warn them", error or "Bots can't be warned.")
        await self.dm(interaction.guild, member, "warn", reason)
        case = await self.add_case(interaction.guild, member, interaction.user, "warn", reason)
        count = len(self.warnings_of(interaction.guild, member.id))
        await self.done(interaction, case, f"{member.mention} now has **{count}** warning{'s' if count != 1 else ''}.")

    @app_commands.command(name="warnings", description="See a member's warnings")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(member="Whose warnings to see")
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        warns = self.warnings_of(interaction.guild, member.id)
        if not warns:
            return await reply(interaction, f"## {member.display_name} has no warnings")
        lines = "\n".join(f"**#{c['id']}** <t:{c['t']}:d> by {c['mod']}: {c['reason'] or 'No reason'}" for c in warns[-10:])
        await reply(interaction, f"## {member.display_name}: {len(warns)} warning{'s' if len(warns) != 1 else ''}", lines[:3900])

    @app_commands.command(name="delwarn", description="Remove one warning by its case number")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(case="The case number, from /warnings")
    async def delwarn(self, interaction: discord.Interaction, case: int):
        book = self.book(interaction.guild)
        found = next((c for c in book["cases"] if c["id"] == case and c["action"] == "warn"), None)
        if not found:
            return await reply(interaction, "## No such warning", f"There's no warning with case number {case}.")
        book["cases"].remove(found)
        self.store.save()
        await reply(interaction, "## Warning removed", f"Case {case} for <@{found['user_id']}> is gone.")

    @app_commands.command(name="clearwarns", description="Remove all of a member's warnings")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(member="Whose warnings to clear")
    async def clearwarns(self, interaction: discord.Interaction, member: discord.Member):
        n = self.clear(interaction.guild, member.id)
        await reply(interaction, "## Warnings cleared", f"Removed {n} warning{'s' if n != 1 else ''} from {member.mention}.")

    def clear(self, guild, user_id: int) -> int:
        book = self.book(guild)
        before = len(book["cases"])
        book["cases"] = [c for c in book["cases"] if not (c["action"] == "warn" and c["user_id"] == user_id)]
        self.store.save()
        return before - len(book["cases"])

    # ── case history ──

    @app_commands.command(name="modlogs", description="See every moderation case for someone")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(user="Whose cases to see (people who left work too)")
    async def modlogs(self, interaction: discord.Interaction, user: discord.User):
        cases = [c for c in self.book(interaction.guild)["cases"] if c["user_id"] == user.id]
        if not cases:
            return await reply(interaction, f"## {user} has a clean record", "No warnings, timeouts, kicks or bans.")
        counts: dict[str, int] = {}
        for c in cases:
            counts[c["action"]] = counts.get(c["action"], 0) + 1
        summary = ", ".join(f"{n} {ACTIONS[a][1].lower()}{'s' if n != 1 and not ACTIONS[a][1].endswith('removed') else ''}"
                            for a, n in counts.items() if a in ACTIONS)
        lines = "\n".join(
            f"**#{c['id']}** {ACTIONS.get(c['action'], ('', c['action'], None))[0]} {ACTIONS.get(c['action'], ('', c['action'], None))[1]}"
            + (f" ({_span(c['minutes'])})" if c.get("minutes") else "")
            + f" <t:{c['t']}:d> by {c['mod']}: {c['reason'] or 'No reason'}"
            for c in reversed(cases[-15:]))
        await reply(interaction, f"## {user}: {_plural(len(cases), 'case')}", summary, lines[:3800])

    @case_group.command(name="view", description="See one moderation case")
    @app_commands.describe(number="The case number")
    async def case_view(self, interaction: discord.Interaction, number: int):
        c = self.find_case(interaction.guild, number)
        if not c:
            return await reply(interaction, "## No such case", f"There's no case number {number}.")
        emoji, name, _ = ACTIONS.get(c["action"], ("", c["action"], None))
        detail = f" for {_span(c['minutes'])}" if c.get("minutes") else ""
        await reply(interaction, f"## {emoji} Case {c['id']}: {name}{detail}",
                    f"**Who:** <@{c['user_id']}> ({c['user']})\n**By:** <@{c['mod_id']}> ({c['mod']})\n**When:** <t:{c['t']}:f>",
                    f"Reason: {c['reason']}" if c["reason"] else "-# No reason given")

    @case_group.command(name="reason", description="Change the reason on a moderation case")
    @app_commands.describe(number="The case number", reason="The new reason")
    async def case_reason(self, interaction: discord.Interaction, number: int, reason: app_commands.Range[str, 1, 500]):
        c = self.find_case(interaction.guild, number)
        if not c:
            return await reply(interaction, "## No such case", f"There's no case number {number}.")
        c["reason"] = reason
        self.store.save()
        await send_log(interaction.guild, "mod_log_channel_id", f"## ✏️ Case {number}: reason changed",
                       f"By {interaction.user.mention}", f"Reason: {reason}")
        await reply(interaction, f"## Case {number} updated", f"Reason: {reason}")

    # ── punishments ──

    @app_commands.command(name="timeout", description="Time a member out")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(member="Who to time out", minutes="How long, in minutes (max 40320 = 4 weeks)", reason="Why")
    async def timeout(self, interaction: discord.Interaction, member: discord.Member,
                      minutes: app_commands.Range[int, 1, 40320], reason: str | None = None):
        if error := self.problem(interaction, member):
            return await reply(interaction, "## Can't time them out", error)
        try:
            await member.timeout(datetime.timedelta(minutes=minutes), reason=reason)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't time them out", "I need the **Timeout Members** permission.")
        await self.dm(interaction.guild, member, "timeout", reason or "", f" for {_span(minutes)}")
        case = await self.add_case(interaction.guild, member, interaction.user, "timeout", reason or "", {"minutes": minutes})
        await self.done(interaction, case, f"{member.mention} is timed out for {_span(minutes)}.")

    @app_commands.command(name="untimeout", description="Remove a member's timeout")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(member="Whose timeout to remove")
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member):
        try:
            await member.timeout(None)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't remove it", "I need the **Timeout Members** permission.")
        case = await self.add_case(interaction.guild, member, interaction.user, "untimeout")
        await self.done(interaction, case, f"{member.mention} can talk again.")

    @app_commands.command(name="kick", description="Kick a member")
    @app_commands.default_permissions(kick_members=True)
    @app_commands.describe(member="Who to kick", reason="Why")
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str | None = None):
        if error := self.problem(interaction, member):
            return await reply(interaction, "## Can't kick them", error)
        await self.dm(interaction.guild, member, "kick", reason or "")
        try:
            await member.kick(reason=reason)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't kick them", "I need the **Kick Members** permission.")
        case = await self.add_case(interaction.guild, member, interaction.user, "kick", reason or "")
        await self.done(interaction, case, f"**{member}** was kicked.")

    @app_commands.command(name="ban", description="Ban someone, even if they aren't in the server")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.describe(user="Who to ban (pick them, or paste their user ID)", reason="Why",
                           delete_messages="Also delete their messages from the last day")
    async def ban(self, interaction: discord.Interaction, user: discord.User, reason: str | None = None,
                  delete_messages: bool = False):
        if error := self.problem(interaction, user):
            return await reply(interaction, "## Can't ban them", error)
        await self.dm(interaction.guild, user, "ban", reason or "")
        try:
            await interaction.guild.ban(user, reason=reason, delete_message_seconds=86400 if delete_messages else 0)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't ban them", "I need the **Ban Members** permission.")
        self.forget_tempban(interaction.guild, user.id)  # a normal ban doesn't end by itself
        case = await self.add_case(interaction.guild, user, interaction.user, "ban", reason or "")
        await self.done(interaction, case, f"**{user}** was banned.")

    @app_commands.command(name="tempban", description="Ban someone for a while. They're unbanned by themselves")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.describe(user="Who to ban (pick them, or paste their user ID)", duration="How long, like 30m, 12h, 3d or 2w",
                           reason="Why", delete_messages="Also delete their messages from the last day")
    async def tempban(self, interaction: discord.Interaction, user: discord.User, duration: str,
                      reason: str | None = None, delete_messages: bool = False):
        seconds = parse_duration(duration)
        if not seconds or seconds < 60 or seconds > MAX_TEMPBAN:
            return await reply(interaction, "## That isn't a length I can use", "Use something like `30m`, `12h`, `3d` or `2w` (1 minute to 1 year).")
        if error := self.problem(interaction, user):
            return await reply(interaction, "## Can't ban them", error)
        minutes = max(1, seconds // 60)
        await self.dm(interaction.guild, user, "tempban", reason or "", f" for {duration_text(seconds)}")
        try:
            await interaction.guild.ban(user, reason=f"{reason or 'No reason'} (for {duration_text(seconds)})",
                                        delete_message_seconds=86400 if delete_messages else 0)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't ban them", "I need the **Ban Members** permission.")
        until = now() + seconds
        entries = self.tempbans.guild(interaction.guild, list)
        entries[:] = [e for e in entries if e["user_id"] != user.id] + [{"user_id": user.id, "user": str(user), "until": until}]
        self.tempbans.save()
        case = await self.add_case(interaction.guild, user, interaction.user, "tempban", reason or "",
                                   {"minutes": minutes, "until": until})
        await self.done(interaction, case, f"**{user}** is banned until <t:{until}:f> (<t:{until}:R>).")

    @app_commands.command(name="softban", description="Kick someone and delete their recent messages (they can rejoin)")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.describe(member="Who to softban", reason="Why", days="How many days of their messages to delete (1-7)")
    async def softban(self, interaction: discord.Interaction, member: discord.Member, reason: str | None = None,
                      days: app_commands.Range[int, 1, 7] = 1):
        if error := self.problem(interaction, member):
            return await reply(interaction, "## Can't softban them", error)
        await self.dm(interaction.guild, member, "softban", reason or "")
        try:
            await interaction.guild.ban(member, reason=f"Softban: {reason or 'No reason'}", delete_message_seconds=days * 86400)
            await interaction.guild.unban(member, reason="Softban (unbanned right away)")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't softban them", "I need the **Ban Members** permission.")
        case = await self.add_case(interaction.guild, member, interaction.user, "softban", reason or "")
        await self.done(interaction, case, f"**{member}** was kicked and their messages from the last {_plural(days, 'day')} were deleted. They can join again.")

    @app_commands.command(name="unban", description="Unban someone by their user ID")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.describe(user_id="Their Discord user ID", reason="Why")
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str | None = None):
        if not user_id.strip().isdigit():
            return await reply(interaction, "## That isn't a user ID", "Right-click them → Copy User ID (needs Developer Mode).")
        uid = int(user_id.strip())
        try:
            await interaction.guild.unban(discord.Object(id=uid), reason=reason)
        except discord.NotFound:
            self.forget_tempban(interaction.guild, uid)
            return await reply(interaction, "## Not banned", "That user isn't banned here.")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't unban them", "I need the **Ban Members** permission.")
        self.forget_tempban(interaction.guild, uid)
        case = await self.add_case(interaction.guild, _Someone(uid), interaction.user, "unban", reason or "")
        await self.done(interaction, case, f"<@{uid}> can join again.")

    # ── temporary bans end by themselves ──

    def forget_tempban(self, guild, user_id: int):
        entries = self.tempbans.data.get(str(guild.id))
        if entries and any(e["user_id"] == user_id for e in entries):
            entries[:] = [e for e in entries if e["user_id"] != user_id]
            self.tempbans.save()

    @tasks.loop(minutes=1)
    async def tempban_loop(self):
        await self.end_tempbans()

    @tempban_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def end_tempbans(self, at: int | None = None) -> int:
        """Unban everyone whose temporary ban is over. Returns how many."""
        at, ended = at or now(), 0
        for gid, entries in list(self.tempbans.data.items()):
            guild = self.bot.get_guild(int(gid))
            if guild is None:
                continue
            for e in [e for e in entries if e["until"] <= at]:
                try:
                    await guild.unban(discord.Object(id=e["user_id"]), reason="Temporary ban ended")
                except discord.NotFound:
                    pass  # someone unbanned them already
                except discord.HTTPException:
                    if at - e["until"] < 7 * 86400:
                        continue  # no permission right now: try again next minute (for up to a week)
                entries.remove(e)
                ended += 1
                await self.add_case(guild, _Someone(e["user_id"]), guild.me, "unban", "Temporary ban ended")
            self.tempbans.save()
        return ended

    # ── nicknames ──

    @app_commands.command(name="nick", description="Change or reset someone's nickname")
    @app_commands.default_permissions(manage_nicknames=True)
    @app_commands.describe(member="Whose nickname to change", nickname="The new nickname (leave it out to reset it)")
    async def nick(self, interaction: discord.Interaction, member: discord.Member,
                   nickname: Optional[app_commands.Range[str, 1, 32]] = None):
        if error := self.problem(interaction, member, allow_self=True):
            return await reply(interaction, "## Can't change their nickname", error)
        old = member.display_name
        try:
            await member.edit(nick=nickname, reason=f"/nick by {interaction.user}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't change it", "I need the **Manage Nicknames** permission.")
        line = f"{member.mention}: **{old}** → **{nickname}**" if nickname else f"{member.mention}'s nickname was reset."
        await send_log(interaction.guild, "mod_log_channel_id", "## ✏️ Nickname changed", line, f"By {interaction.user.mention}")
        await reply(interaction, "## ✏️ Nickname changed" if nickname else "## ✏️ Nickname reset", line)

    # ── channels ──

    @app_commands.command(name="purge", description="Delete recent messages in this channel")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.describe(amount="How many messages to check (1-100)", member="Only delete this member's messages",
                           bots="Only delete messages from bots", contains="Only delete messages with this text in them")
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100],
                    member: discord.Member | None = None, bots: bool = False, contains: str | None = None):
        await interaction.response.defer(ephemeral=True, thinking=True)
        needle = (contains or "").lower()

        def wanted(m) -> bool:
            if member and m.author.id != member.id:
                return False
            if bots and not m.author.bot:
                return False
            if needle and needle not in (m.content or "").lower():
                return False
            return True
        try:
            deleted = await interaction.channel.purge(limit=amount, check=wanted if (member or bots or needle) else None)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't delete messages", "I need **Manage Messages** and **Read Message History** here.")
        await reply(interaction, "## 🧹 Done", f"Deleted {_plural(len(deleted), 'message')}.")
        what = [f"from {member.mention}" if member else "", "from bots" if bots else "", f'containing "{contains}"' if needle else ""]
        await send_log(interaction.guild, "mod_log_channel_id", "## 🧹 Purge",
                       f"{interaction.user.mention} deleted {len(deleted)} messages in {interaction.channel.mention} "
                       + " ".join(w for w in what if w))

    @app_commands.command(name="slowmode", description="Set slowmode for this channel")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.describe(seconds="Seconds between messages (0 turns it off, max 21600)")
    async def slowmode(self, interaction: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]):
        try:
            await interaction.channel.edit(slowmode_delay=seconds)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't change it", "I need **Manage Channels** here.")
        await reply(interaction, "## 🐢 Slowmode " + ("off" if not seconds else f"set to {seconds}s"))

    async def _everyone(self, interaction, channel, reason: str | None, **change) -> bool:
        """Change what @everyone may do in a channel. False (and a reply) when it can't."""
        everyone = interaction.guild.default_role
        overwrite = channel.overwrites_for(everyone)
        for k, v in change.items():
            setattr(overwrite, k, v)
        try:
            await channel.set_permissions(everyone, overwrite=overwrite, reason=reason or f"By {interaction.user}")
        except discord.HTTPException:
            await reply(interaction, "## Couldn't change it", f"I need **Manage Channels** and **Manage Roles** in {channel.mention}.")
            return False
        return True

    async def _lock(self, interaction, locked: bool, reason: str | None):
        if not await self._everyone(interaction, interaction.channel, reason, send_messages=False if locked else None):
            return
        await interaction.response.send_message(view=simple_view(
            "## 🔒 Channel locked" if locked else "## 🔓 Channel unlocked",
            *([f"Reason: {reason}"] if reason else [])))

    @app_commands.command(name="lock", description="Stop members from talking in this channel")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.describe(reason="Why (shown in the channel)")
    async def lock(self, interaction: discord.Interaction, reason: str | None = None):
        await self._lock(interaction, True, reason)

    @app_commands.command(name="unlock", description="Let members talk in this channel again")
    @app_commands.default_permissions(manage_channels=True)
    async def unlock(self, interaction: discord.Interaction):
        await self._lock(interaction, False, None)

    @app_commands.command(name="hide", description="Hide a channel from everyone (staff roles still see it)")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.describe(channel="Which channel (this one if you leave it out)")
    async def hide(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None):
        channel = channel or interaction.channel
        if await self._everyone(interaction, channel, f"Hidden by {interaction.user}", view_channel=False):
            await reply(interaction, "## 🙈 Channel hidden", f"{channel.mention} is hidden from @everyone. Bring it back with `/unhide`.")

    @app_commands.command(name="unhide", description="Show a hidden channel to everyone again")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.describe(channel="Which channel (this one if you leave it out)")
    async def unhide(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None):
        channel = channel or interaction.channel
        if await self._everyone(interaction, channel, f"Shown again by {interaction.user}", view_channel=None):
            await reply(interaction, "## 👀 Channel visible again", f"Everyone can see {channel.mention} again.")

    @lockdown_group.command(name="start", description="Stop members from talking in every channel")
    @app_commands.describe(reason="Why (shown where you run it)")
    async def lockdown_start(self, interaction: discord.Interaction, reason: str | None = None):
        guild, everyone = interaction.guild, interaction.guild.default_role
        record = self.lockdowns.guild(guild)
        if record.get("channels"):
            return await reply(interaction, "## Already locked down", f"Since <t:{record['t']}:R>. End it with `/lockdown end`.")
        await interaction.response.defer(thinking=True)
        locked, skipped = [], 0
        for channel in guild.text_channels:
            overwrite = channel.overwrites_for(everyone)
            if overwrite.send_messages is False or overwrite.view_channel is False:
                continue  # already locked, or hidden from everyone anyway
            was = overwrite.send_messages
            overwrite.send_messages = False
            try:
                await channel.set_permissions(everyone, overwrite=overwrite, reason=f"Lockdown by {interaction.user}")
            except discord.HTTPException:
                skipped += 1
                continue
            locked.append({"id": channel.id, "was": was})
        record.update({"channels": locked, "t": now(), "by": interaction.user.id, "reason": reason or ""})
        self.lockdowns.save()
        await send_log(guild, "mod_log_channel_id", "## 🔒 Lockdown started",
                       f"{interaction.user.mention} locked {_plural(len(locked), 'channel')}", f"Reason: {reason}" if reason else "-# No reason given")
        await reply(interaction, "## 🔒 Server locked down",
                    f"Locked {_plural(len(locked), 'channel')}." + (f" Couldn't lock {skipped} (I need Manage Channels there)." if skipped else "")
                    + "\n-# Roles that are allowed to talk in a channel can still talk there. End it with `/lockdown end`.",
                    f"Reason: {reason}" if reason else "", ephemeral=False)

    @lockdown_group.command(name="end", description="Let members talk again in the channels the lockdown locked")
    async def lockdown_end(self, interaction: discord.Interaction):
        guild, everyone = interaction.guild, interaction.guild.default_role
        record = self.lockdowns.guild(guild)
        if not record.get("channels"):
            return await reply(interaction, "## No lockdown", "The server isn't locked down. Start one with `/lockdown start`.")
        await interaction.response.defer(thinking=True)
        opened = 0
        for item in record["channels"]:
            channel = guild.get_channel(item["id"])
            if channel is None:
                continue
            overwrite = channel.overwrites_for(everyone)
            overwrite.send_messages = item.get("was")
            try:
                await channel.set_permissions(everyone, overwrite=overwrite, reason=f"Lockdown ended by {interaction.user}")
                opened += 1
            except discord.HTTPException:
                pass
        record.clear()
        self.lockdowns.save()
        await send_log(guild, "mod_log_channel_id", "## 🔓 Lockdown ended", f"{interaction.user.mention} unlocked {_plural(opened, 'channel')}")
        await reply(interaction, "## 🔓 Lockdown over", f"Unlocked {_plural(opened, 'channel')}.", ephemeral=False)

    @app_commands.command(name="nuke", description="Delete this channel and make a fresh copy (wipes every message)")
    @app_commands.default_permissions(manage_channels=True)
    async def nuke(self, interaction: discord.Interaction):
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            return await reply(interaction, "## Can't nuke this", "It only works in text channels.")
        yes = ui.Button(label=f"Nuke #{channel.name}"[:80], emoji="💥", style=discord.ButtonStyle.danger)
        no = ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        view = box(f"## 💥 Nuke #{channel.name}?",
                   "The channel is deleted and a copy with the same name, settings and permissions takes its place. "
                   "**Every message in it is gone for good.**", ui.ActionRow(yes, no))
        view.timeout = 60

        async def go(click: discord.Interaction):
            use_guild(click.guild)  # a button press doesn't come with the server's settings by itself
            if click.user.id != interaction.user.id:
                return await reply(click, "## Not yours", "Only the person who ran /nuke can confirm it.")
            await click.response.edit_message(view=simple_view("## 💥 Nuking..."))
            await self.do_nuke(channel, interaction.user)

        async def cancel(click: discord.Interaction):
            await click.response.edit_message(view=simple_view("## Cancelled", "Nothing was deleted."))

        yes.callback, no.callback = go, cancel
        await interaction.response.send_message(view=view, ephemeral=True)

    async def do_nuke(self, channel, user):
        guild = channel.guild
        try:
            fresh = await channel.clone(reason=f"Nuked by {user}")
            await fresh.edit(position=channel.position)
        except discord.HTTPException:
            return
        try:
            await channel.delete(reason=f"Nuked by {user}")
        except discord.HTTPException:
            # Discord keeps some channels (the rules or updates channel of a Community server): undo the copy
            try:
                await fresh.delete(reason="Couldn't delete the original")
            except discord.HTTPException:
                pass
            try:
                await channel.send(view=simple_view("## Couldn't nuke this channel",
                                                    "Discord won't let me delete it. It may be the server's rules or updates channel."))
            except discord.HTTPException:
                pass
            return
        try:
            await fresh.send(view=simple_view("## 💥 Channel nuked", f"-# By {user.mention}"),
                             allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass
        await send_log(guild, "mod_log_channel_id", "## 💥 Channel nuked", f"#{channel.name} by {user.mention}")
        return fresh

    # ── voice ──

    async def _voice_target(self, interaction, member) -> str | None:
        if error := self.problem(interaction, member, allow_self=True):
            return error
        if getattr(member, "voice", None) is None or member.voice.channel is None:
            return f"{member.display_name} isn't in a voice channel."
        return None

    @voice_group.command(name="kick", description="Disconnect someone from voice")
    @app_commands.describe(member="Who to disconnect")
    async def voice_kick(self, interaction: discord.Interaction, member: discord.Member):
        if error := await self._voice_target(interaction, member):
            return await reply(interaction, "## Can't do that", error)
        try:
            await member.move_to(None, reason=f"Disconnected by {interaction.user}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't disconnect them", "I need the **Move Members** permission.")
        await reply(interaction, "## 🔌 Disconnected", f"{member.mention} was disconnected from voice.")

    @voice_group.command(name="move", description="Move someone to another voice channel")
    @app_commands.describe(member="Who to move", channel="Where to")
    async def voice_move(self, interaction: discord.Interaction, member: discord.Member, channel: discord.VoiceChannel):
        if error := await self._voice_target(interaction, member):
            return await reply(interaction, "## Can't do that", error)
        try:
            await member.move_to(channel, reason=f"Moved by {interaction.user}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't move them", f"I need **Move Members** and **Connect** in {channel.mention}.")
        await reply(interaction, "## 🔀 Moved", f"{member.mention} is now in {channel.mention}.")

    async def _voice_mute(self, interaction, member, muted: bool):
        perms = interaction.user.guild_permissions
        if not (perms.administrator or perms.mute_members):
            return await reply(interaction, "## You can't do that", "Muting in voice needs the **Mute Members** permission.")
        if error := await self._voice_target(interaction, member):
            return await reply(interaction, "## Can't do that", error)
        try:
            await member.edit(mute=muted, reason=f"{'Muted' if muted else 'Unmuted'} by {interaction.user}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't change it", "I need the **Mute Members** permission.")
        await reply(interaction, "## 🔇 Muted in voice" if muted else "## 🔊 Unmuted in voice",
                    f"{member.mention} {'can no longer' if muted else 'can'} talk in voice channels.")

    @voice_group.command(name="mute", description="Server-mute someone in voice")
    @app_commands.describe(member="Who to mute")
    async def voice_mute(self, interaction: discord.Interaction, member: discord.Member):
        await self._voice_mute(interaction, member, True)

    @voice_group.command(name="unmute", description="Remove someone's server mute in voice")
    @app_commands.describe(member="Who to unmute")
    async def voice_unmute(self, interaction: discord.Interaction, member: discord.Member):
        await self._voice_mute(interaction, member, False)

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        cases = self.book(guild)["cases"]
        warned: dict[int, int] = {}
        for c in cases:
            if c["action"] == "warn":
                warned[c["user_id"]] = warned.get(c["user_id"], 0) + 1
        top = sorted(warned.items(), key=lambda kv: -kv[1])[:15]
        lock = self.lockdowns.data.get(str(guild.id)) or {}
        return {
            "cases": [{**c, "user_id": str(c["user_id"]), "mod_id": str(c["mod_id"])} for c in reversed(cases[-150:])],
            "warned": [{**(person(guild, uid) or {}), "count": n, "user": next(c["user"] for c in cases if c["user_id"] == uid)}
                       for uid, n in top],
            "total": len(cases),
            "tempbans": [{"user_id": str(e["user_id"]), "user": e.get("user") or f"User {e['user_id']}", "until": e["until"]}
                         for e in sorted(self.tempbans.data.get(str(guild.id)) or [], key=lambda e: e["until"])],
            "lockdown": {"channels": len(lock.get("channels") or []), "t": lock.get("t")} if lock.get("channels") else None,
        }

    async def dash_delete_case(self, guild, body: dict, user: dict) -> dict:
        book = self.book(guild)
        try:
            cid = int(body.get("case"))
        except (TypeError, ValueError):
            raise DashError("That isn't a case number.")
        found = next((c for c in book["cases"] if c["id"] == cid), None)
        if not found:
            raise DashError("That case doesn't exist anymore.")
        book["cases"].remove(found)
        self.store.save()
        return {"message": f"Deleted case {cid}.", "log": f"Deleted moderation case {cid}"}

    async def dash_clear_warnings(self, guild, body: dict, user: dict) -> dict:
        try:
            uid = int(body.get("user_id"))
        except (TypeError, ValueError):
            raise DashError("Pick a member.")
        n = self.clear(guild, uid)
        return {"message": f"Removed {n} warning{'s' if n != 1 else ''}.", "log": f"Cleared the warnings of <@{uid}>"}

    async def dash_end_tempban(self, guild, body: dict, user: dict) -> dict:
        try:
            uid = int(body.get("user_id"))
        except (TypeError, ValueError):
            raise DashError("Pick someone.")
        entries = self.tempbans.data.get(str(guild.id)) or []
        entry = next((e for e in entries if e["user_id"] == uid), None)
        if entry is None:
            raise DashError("Their ban already ended.")
        try:
            await guild.unban(discord.Object(id=uid), reason=f"Temporary ban ended early on the dashboard by {user.get('name')}")
        except discord.NotFound:
            pass
        except discord.HTTPException:
            raise DashError("I need the Ban Members permission to unban them.")
        self.forget_tempban(guild, uid)
        await self.add_case(guild, _Someone(uid), _Someone(int(user.get("id") or 0), f"{user.get('name')} (dashboard)"),
                            "unban", "Temporary ban ended early")
        return {"message": f"Unbanned {entry.get('user') or uid}.", "log": f"Ended the temporary ban of <@{uid}> early"}


async def setup(bot: commands.Bot):
    await bot.add_cog(ModTools(bot))
