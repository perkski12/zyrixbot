"""
Suggestions: /suggest (or the button on a suggestion panel) posts a suggestion with 👍 / 👎 vote
buttons. Staff approve, deny or mark it as being considered (with a reason) from Discord or the
dashboard, and the author gets a DM. Saved in data/suggestions.json.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, use_guild, simple_view, server_name
from .figs import feature_on
from .kit import Store, box, reply, is_staff, text_channel, jump, now, person, DashError

STATUSES = {
    "open": ("💡", "Open for votes"),
    "considering": ("🤔", "Being considered"),
    "approved": ("✅", "Approved"),
    "implemented": ("🚀", "Added"),
    "denied": ("❌", "Denied"),
}


def suggestion_view(s: dict) -> ui.LayoutView:
    emoji, label = STATUSES[s["status"]]
    by = "-# Sent anonymously" if s.get("anonymous") else f"-# Suggested by <@{s['author_id']}>"
    status = f"**{emoji} {label}**" + (f"\n> {s['reason']}" if s.get("reason") else "")
    voting = s["status"] in ("open", "considering")
    return box(
        f"## Suggestion #{s['number']}",
        s["text"],
        by,
        ui.Separator(),
        status,
        ui.ActionRow(
            ui.Button(label=str(len(s["up"])), emoji="👍", custom_id="sug:up", style=discord.ButtonStyle.success, disabled=not voting),
            ui.Button(label=str(len(s["down"])), emoji="👎", custom_id="sug:down", style=discord.ButtonStyle.danger, disabled=not voting),
            ui.Button(label="Staff", emoji="⚙️", custom_id="sug:manage", style=discord.ButtonStyle.secondary),
        ),
    )


def panel_view() -> ui.LayoutView:
    return box("## 💡 Suggestions", "Have an idea for the server? Press the button and tell us.",
               ui.ActionRow(ui.Button(label="Make a suggestion", emoji="💡", custom_id="sug:new", style=discord.ButtonStyle.primary)))


def manage_view(mid: int) -> ui.LayoutView:
    return box("### What should happen with it?", ui.ActionRow(*[
        ui.Button(label=label, emoji=emoji, custom_id=f"sug:set:{mid}:{key}", style=discord.ButtonStyle.secondary)
        for key, (emoji, label) in STATUSES.items() if key != "open"
    ]))


class SuggestForm(ui.Modal):
    def __init__(self, cog: "Suggestions"):
        super().__init__(title="Make a suggestion", custom_id="sug:form")
        self.cog = cog
        self.text = ui.TextInput(label="Your idea", style=discord.TextStyle.paragraph, max_length=1500, required=True,
                                 placeholder="What should we add or change?")
        self.add_item(self.text)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        await self.cog.submit(interaction, str(self.text.value))


class ReasonForm(ui.Modal):
    def __init__(self, cog: "Suggestions", mid: int, status: str):
        super().__init__(title=f"Mark as {STATUSES[status][1].lower()}"[:45], custom_id=f"sug:reason:{mid}:{status}")
        self.cog, self.mid, self.status = cog, mid, status
        self.reason = ui.TextInput(label="Reason (optional, everyone sees it)", style=discord.TextStyle.paragraph,
                                   max_length=500, required=False)
        self.add_item(self.reason)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        error = await self.cog.set_status(interaction.guild, self.mid, self.status, str(self.reason.value or ""), interaction.user)
        await reply(interaction, *(("## Couldn't update it", error) if error else ("## Updated", f"Marked as {STATUSES[self.status][1].lower()}.")))


class Suggestions(commands.Cog):
    DASH_ACTIONS = {"set-status": "dash_set_status", "panel": "dash_panel"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("suggestions.json")

    def book(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"next": 1, "items": {}})

    def staff(self, member) -> bool:
        return is_staff(member, "manage_guild", config.get("sug_staff_role_ids", []))

    # ── posting ──

    async def post(self, guild, author, text: str):
        """Post a suggestion. Returns (message, None) or (None, error)."""
        use_guild(guild)
        channel = guild.get_channel(config.get("sug_channel_id") or 0)
        if channel is None:
            return None, "Suggestions aren't set up yet. Staff can pick a channel on the dashboard."
        book = self.book(guild)
        s = {"number": book["next"], "author_id": author.id, "author": str(author), "text": text.strip()[:1500],
             "status": "open", "reason": "", "up": [], "down": [], "t": now(), "channel_id": channel.id,
             "anonymous": bool(config.get("sug_anonymous"))}
        try:
            msg = await channel.send(view=suggestion_view(s), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            return None, f"I can't post in #{channel.name}. Ask staff to check my permissions there."
        book["next"] += 1
        book["items"][str(msg.id)] = s
        self.store.save()
        return msg, None

    async def submit(self, interaction: discord.Interaction, text: str):
        if not feature_on(config, "suggestions"):
            return await reply(interaction, "## Suggestions are off")
        msg, error = await self.post(interaction.guild, interaction.user, text)
        if error:
            return await reply(interaction, "## Couldn't post it", error)
        await reply(interaction, "## 💡 Suggestion posted", f"Thanks! It's here: {msg.jump_url}")

    @app_commands.command(name="suggest", description="Suggest something for the server")
    @app_commands.describe(idea="Your idea")
    async def suggest(self, interaction: discord.Interaction, idea: str):
        await self.submit(interaction, idea)

    # ── votes and staff decisions ──

    async def set_status(self, guild, mid, status: str, reason: str, by) -> str | None:
        use_guild(guild)
        s = self.book(guild)["items"].get(str(mid))
        if s is None:
            return "That suggestion doesn't exist anymore."
        if status not in STATUSES:
            return "That isn't a status."
        s.update(status=status, reason=reason.strip()[:500], decided_by=str(by), decided_at=now())
        self.store.save()
        channel = guild.get_channel(s["channel_id"])
        if channel is not None:
            try:
                await channel.get_partial_message(int(mid)).edit(view=suggestion_view(s))
            except discord.HTTPException:
                pass
        if config.get("sug_dm_result", True) and status != "open":
            author = guild.get_member(s["author_id"])
            emoji, label = STATUSES[status]
            if author is not None:
                try:
                    await author.send(view=simple_view(f"## {emoji} Your suggestion in {server_name(guild)}: {label.lower()}",
                                                       s["text"][:1000], f"Reason: {s['reason']}" if s["reason"] else "-# No reason given"))
                except (discord.HTTPException, AttributeError):
                    pass
        return None

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component or interaction.guild is None:
            return
        custom_id = (interaction.data or {}).get("custom_id", "")
        if not custom_id.startswith("sug:"):
            return
        use_guild(interaction.guild)
        if not feature_on(config, "suggestions"):
            return await reply(interaction, "## Suggestions are off")
        parts = custom_id.split(":")
        action = parts[1]

        if action == "new":
            return await interaction.response.send_modal(SuggestForm(self))

        if action == "set":
            if not self.staff(interaction.user):
                return await reply(interaction, "## Staff only")
            return await interaction.response.send_modal(ReasonForm(self, int(parts[2]), parts[3]))

        mid = interaction.message.id
        s = self.book(interaction.guild)["items"].get(str(mid))
        if s is None:
            return await reply(interaction, "## This suggestion is gone")

        if action == "manage":
            if not self.staff(interaction.user):
                return await reply(interaction, "## Staff only", "Only staff can approve or deny suggestions.")
            return await interaction.response.send_message(view=manage_view(mid), ephemeral=True)

        if action in ("up", "down"):
            uid, mine, other = interaction.user.id, s[action], s["down" if action == "up" else "up"]
            if uid in mine:
                mine.remove(uid)
            else:
                mine.append(uid)
                if uid in other:
                    other.remove(uid)
            self.store.save()
            await interaction.response.edit_message(view=suggestion_view(s))

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        items = []
        for mid, s in self.book(guild)["items"].items():
            items.append({"id": mid, "number": s["number"], "text": s["text"], "status": s["status"], "reason": s.get("reason", ""),
                          "up": len(s["up"]), "down": len(s["down"]), "t": s["t"],
                          "author": person(guild, s["author_id"]) or {"name": s.get("author", "")},
                          "url": jump(guild.id, s["channel_id"], mid)})
        items.sort(key=lambda x: -x["number"])
        return {"items": items[:200], "statuses": {k: v[1] for k, v in STATUSES.items()}}

    async def dash_set_status(self, guild, body: dict, user: dict) -> dict:
        status = str(body.get("status") or "")
        mid = str(body.get("id") or "")
        by = type("Dashboard", (), {"__str__": lambda self: user.get("name", "Dashboard")})()
        error = await self.set_status(guild, mid, status, str(body.get("reason") or ""), by)
        if error:
            raise DashError(error)
        s = self.book(guild)["items"][mid]
        return {"message": f"Suggestion #{s['number']} is {STATUSES[status][1].lower()}.",
                "log": f"Marked suggestion #{s['number']} as {STATUSES[status][1].lower()}"}

    async def dash_panel(self, guild, body: dict, user: dict) -> dict:
        channel = text_channel(guild, body.get("channel_id"))
        msg = await channel.send(view=panel_view())
        return {"message": f"Posted the suggestion panel in #{channel.name}.", "url": msg.jump_url,
                "log": f"Posted the suggestion panel in #{channel.name}"}


async def setup(bot: commands.Bot):
    await bot.add_cog(Suggestions(bot))
