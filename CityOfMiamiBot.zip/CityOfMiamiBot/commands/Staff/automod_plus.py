"""
Auto-mod: deletes spam, Discord invites, links, mass mentions and ALL CAPS messages.
Settings: dashboard → Auto-mod. Staff with Manage Messages are never caught.
"""

import datetime
import re
import time
from collections import defaultdict, deque

import discord
from discord.ext import commands

from .wl_embed import config, use_guild
from .figs import feature_on
from .kit import send_log, now

INVITE = re.compile(r"(discord\.gg|discord(?:app)?\.com/invite|dsc\.gg)/\S+", re.I)
LINK = re.compile(r"https?://([^\s/<>]+)", re.I)

RULES = {
    "spam": ("Spam", "slow down, you're sending messages too fast."),
    "invites": ("Discord invite", "invite links to other servers aren't allowed here."),
    "links": ("Link", "links aren't allowed here."),
    "mentions": ("Mass mention", "don't mention that many people at once."),
    "caps": ("All caps", "please don't type in all caps."),
}


class AutoModPlus(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.recent: dict[tuple, deque] = defaultdict(deque)          # (server, member) → message times
        self.history: dict[int, deque] = defaultdict(lambda: deque(maxlen=30))  # server → recent catches

    # ── rules ──

    def broken_rule(self, message) -> str | None:
        """The first rule a message breaks, or None."""
        text = message.content or ""

        if config.get("am_spam", True):  # every message counts toward the spam limit
            q = self.recent[(message.guild.id, message.author.id)]
            t = time.monotonic()
            q.append(t)
            while q and t - q[0] > int(config.get("am_spam_seconds", 5)):
                q.popleft()
            if len(q) >= int(config.get("am_spam_count", 6)):
                q.clear()
                return "spam"

        if config.get("am_invites", True) and INVITE.search(text):
            return "invites"

        if config.get("am_links"):
            allowed = [a.lower().removeprefix("www.") for a in config.get("am_allowed_links", [])]
            for host in LINK.findall(text):
                host = host.lower().split(":")[0].removeprefix("www.")
                if not any(host == a or host.endswith("." + a) for a in allowed):
                    return "links"

        limit = int(config.get("am_mentions", 6) or 0)
        mentioned = len({m.id for m in getattr(message, "mentions", [])}) + len(getattr(message, "role_mentions", []))
        if limit and mentioned >= limit:
            return "mentions"

        letters = [c for c in text if c.isalpha()]
        if config.get("am_caps") and len(letters) >= 12 and sum(c.isupper() for c in letters) / len(letters) >= 0.75:
            return "caps"
        return None

    def exempt(self, message) -> bool:
        member = message.author
        perms = getattr(member, "guild_permissions", None)
        if perms is not None and (perms.administrator or perms.manage_messages):
            return True
        if message.channel.id in config.get("am_ignored_channel_ids", []):
            return True
        ignored = set(config.get("am_ignored_role_ids", []))
        return any(r.id in ignored for r in getattr(member, "roles", []))

    # ── catching ──

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or message.author.bot:
            return
        use_guild(message.guild)
        if not feature_on(config, "automod") or self.exempt(message):
            return
        rule = self.broken_rule(message)
        if rule:
            await self.punish(message, rule)

    async def punish(self, message, rule: str):
        member, guild = message.author, message.guild
        name, why = RULES[rule]
        try:
            await message.delete()
        except discord.HTTPException:
            pass

        done = "Message deleted"
        action = config.get("am_action", "delete")
        if action.startswith("timeout_"):
            minutes = int(action.split("_")[1])
            try:
                await member.timeout(datetime.timedelta(minutes=minutes), reason=f"Auto-mod: {name}")
                done += f", timed out for {minutes // 60} h" if minutes >= 60 else f", timed out for {minutes} min"
            except (discord.HTTPException, AttributeError):
                done += " (couldn't time them out)"

        try:
            await message.channel.send(f"{member.mention}, {why}", delete_after=8,
                                       allowed_mentions=discord.AllowedMentions(users=True))
        except discord.HTTPException:
            pass

        if config.get("am_warn"):
            mod = self.bot.get_cog("ModTools")
            if mod is not None:
                await mod.add_case(guild, member, guild.me, "warn", f"Auto-mod: {name}")

        self.history[guild.id].appendleft({"t": now(), "user": member.display_name, "user_id": str(member.id),
                                           "rule": name, "channel": getattr(message.channel, "name", ""),
                                           "text": (message.content or "")[:200]})
        snippet = (message.content or "").replace("```", "'''")[:300]
        await send_log(guild, "am_log_channel_id", f"## 🛡️ Auto-mod: {name}",
                       f"{member.mention} in {message.channel.mention}. {done}.",
                       f"```{snippet}```" if snippet else "-# (no text)")

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        return {"recent": list(self.history[guild.id])}


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoModPlus(bot))
