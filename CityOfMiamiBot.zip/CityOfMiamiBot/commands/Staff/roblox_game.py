"""
Roblox game and group:
  • /game shows your game's live player count, visits and favorites.
  • A live stats message in a channel, updated every 5 minutes.
  • Group shouts are posted to a channel when they change.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, use_guild
from .figs import feature_on
from .kit import Store, box, reply, text_channel, now, DashError
from . import roblox as rbx


def game_url(place_id) -> str:
    return f"https://www.roblox.com/games/{int(place_id)}"


def stats_view(game: dict, group: dict | None = None) -> ui.LayoutView:
    lines = [f"**{game['playing']:,}** playing now", f"**{game['visits']:,}** visits", f"**{game['favorites']:,}** favorites"]
    if group:
        lines.append(f"**{group.get('memberCount', 0):,}** members in {group.get('name', 'the group')}")
    return box(f"## 🎮 {game['name']}", "\n".join(lines), f"-# Updated <t:{now()}:R>",
               ui.ActionRow(ui.Button(label="Play", emoji="▶️", url=game_url(game["place_id"]), style=discord.ButtonStyle.link)))


class RobloxGame(commands.Cog):
    DASH_ACTIONS = {"lookup": "dash_lookup", "post-stats": "dash_post_stats"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("roblox_game.json")
        self.cache: dict[int, dict] = {}  # server → latest game stats

    def state(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"stats_msg": None, "stats_channel": None, "shout": None})

    async def cog_load(self):
        self.game_loop.start()

    async def cog_unload(self):
        self.game_loop.cancel()

    @tasks.loop(minutes=5)
    async def game_loop(self):
        for guild in list(self.bot.guilds):
            use_guild(guild)
            if feature_on(config, "roblox-game"):
                try:
                    await self.refresh(guild)
                except rbx.RobloxError:
                    pass

    @game_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def refresh(self, guild):
        """Update the live stats message and post a new group shout, if there is one."""
        await self.update_stats_message(guild)
        await self.check_shout(guild)

    async def update_stats_message(self, guild, force_new: bool = False):
        place, cid = config.get("rbx_place_id"), config.get("rbx_stats_channel_id")
        if not place or not cid:
            return None
        channel = guild.get_channel(cid)
        if channel is None:
            return None
        game = await rbx.get_game(place)
        if not game:
            return None
        self.cache[guild.id] = {**game, "checked": now()}
        group = await rbx.get_group(config["roblox_group_id"]) if config.get("roblox_group_id") else None
        state, view = self.state(guild), stats_view(game, group)
        if state["stats_msg"] and state["stats_channel"] == channel.id and not force_new:
            try:
                await channel.get_partial_message(state["stats_msg"]).edit(view=view)
                return state["stats_msg"]
            except discord.HTTPException:
                pass  # deleted: post a new one
        msg = await channel.send(view=view)
        state.update(stats_msg=msg.id, stats_channel=channel.id)
        self.store.save()
        return msg

    async def check_shout(self, guild):
        group_id, channel = config.get("roblox_group_id"), guild.get_channel(config.get("rbx_shout_channel_id") or 0)
        if not group_id or channel is None:
            return False
        group = await rbx.get_group(group_id)
        shout = (group or {}).get("shout") or {}
        stamp = shout.get("updated") or ""
        state = self.state(guild)
        if not shout.get("body") or stamp == state["shout"]:
            return False
        first = state["shout"] is None
        state["shout"] = stamp
        self.store.save()
        if first:
            return False  # don't repost an old shout the moment this is turned on
        poster = (shout.get("poster") or {}).get("displayName") or (shout.get("poster") or {}).get("username") or "someone"
        try:
            await channel.send(view=box(f"## 📣 {group.get('name', 'Group')} shout", shout["body"][:3500], f"-# Posted by {poster}"),
                               allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            return False
        return True

    @app_commands.command(name="game", description="Live stats for the server's Roblox game")
    async def game(self, interaction: discord.Interaction):
        place = config.get("rbx_place_id")
        if not place:
            return await reply(interaction, "## No game set", "Staff can add the game on the dashboard (Game & group).")
        await interaction.response.defer(thinking=True)
        try:
            game = await rbx.get_game(place)
        except rbx.RobloxError as e:
            return await interaction.followup.send(view=box("## Roblox didn't answer", str(e)))
        if not game:
            return await interaction.followup.send(view=box("## Game not found", "The place ID on the dashboard doesn't match a game."))
        self.cache[interaction.guild.id] = {**game, "checked": now()}
        await interaction.followup.send(view=stats_view(game))

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        state = self.state(guild)
        return {"game": self.cache.get(guild.id), "stats_posted": bool(state["stats_msg"])}

    async def dash_lookup(self, guild, body: dict, user: dict) -> dict:
        place = str(body.get("place_id") or "").strip()
        if not place.isdigit():
            raise DashError("Type the place ID: the number in your game's link, like roblox.com/games/1234567.")
        try:
            game = await rbx.get_game(int(place))
        except rbx.RobloxError as e:
            raise DashError(str(e))
        if not game:
            raise DashError(f"There's no Roblox game with the place ID {place}.")
        self.cache[guild.id] = {**game, "checked": now()}
        return {"game": game}

    async def dash_post_stats(self, guild, body: dict, user: dict) -> dict:
        if not config.get("rbx_place_id"):
            raise DashError("Add your game's place ID and save first.")
        text_channel(guild, config.get("rbx_stats_channel_id"))
        try:
            result = await self.update_stats_message(guild, force_new=bool(body.get("new")))
        except rbx.RobloxError as e:
            raise DashError(str(e))
        if result is None:
            raise DashError("Couldn't find the game. Check the place ID.")
        return {"message": "The live stats message is up to date.", "log": "Posted the live game stats"}


async def setup(bot: commands.Bot):
    await bot.add_cog(RobloxGame(bot))
