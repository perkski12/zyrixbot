import discord
from discord import app_commands
from discord.ext import commands

from .wl_embed import config, save_config, simple_view, use_guild
from .figs import feature_on


class ReactChannel(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ──────────────────────────── /reactchannel ─────────────────────────────

    @app_commands.command(name="reactchannel", description="Connect or disconnect a 👍/👎 channel")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(channel="Every message here gets 👍 and 👎 (run again to turn it off)")
    async def reactchannel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        channels = config.setdefault("react_channel_ids", [])

        if channel.id in channels:
            channels.remove(channel.id)
            title, text = "## Channel Disconnected", f"{channel.mention} won't get reactions anymore."
        else:
            channels.append(channel.id)
            title, text = "## Channel Connected", f"Every message in {channel.mention} will get 👍 and 👎."

        save_config()
        await interaction.response.send_message(view=simple_view(title, text), ephemeral=True)

    # ──────────────────────────── listener ──────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        use_guild(message.guild)
        if not feature_on(config, "react") or message.channel.id not in config.get("react_channel_ids", []):
            return

        try:
            await message.add_reaction("👍")
            await message.add_reaction("👎")
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(ReactChannel(bot))
