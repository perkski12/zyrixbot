import datetime
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

Answer = app_commands.Range[str, 1, 55]  # Discord's limit for a poll answer


class Polls(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ──────────────────────────── /polls ────────────────────────────────────

    @app_commands.command(name="polls", description="Start a Discord poll")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(
        question="What you're asking",
        option1="First answer",
        option2="Second answer",
        option3="Third answer",
        option4="Fourth answer",
        option5="Fifth answer",
        hours="How long the poll stays open (default 24, max 768)",
        multiple="Let people pick more than one answer"
    )
    async def polls(
        self,
        interaction: discord.Interaction,
        question: app_commands.Range[str, 1, 300],
        option1: Answer,
        option2: Answer,
        option3: Optional[Answer] = None,
        option4: Optional[Answer] = None,
        option5: Optional[Answer] = None,
        hours: app_commands.Range[int, 1, 768] = 24,
        multiple: bool = False
    ):
        poll = discord.Poll(
            question=question,
            duration=datetime.timedelta(hours=hours),
            multiple=multiple
        )
        for answer in (option1, option2, option3, option4, option5):
            if answer:
                poll.add_answer(text=answer)

        await interaction.response.send_message(poll=poll)


async def setup(bot: commands.Bot):
    await bot.add_cog(Polls(bot))
