"""
Figs: server types a server can turn on (any mix) on the dashboard.

Each fig switches on a set of features. A feature can belong to several figs, so a server
gets every tab that's useful for the figs it picked. Features of figs that are off don't
run in that server, their slash commands answer with a hint, and their tabs are hidden.
"""

# feature id: (name, dashboard tabs)
FEATURES = {
    "whitelist": ("Whitelist", ["whitelist"]),
    "priority": ("Priority roles", ["priority"]),
    "fivem-tools": ("Sneak peeks + female verification", []),
    "welcome": ("Welcome, goodbye and join roles", ["welcome"]),
    "filter": ("Word filter", ["filter"]),
    "honeypot": ("Honeypot", ["honeypot"]),
    "automod": ("Auto-mod (spam, invites, links, caps)", ["automod"]),
    "moderation": ("Moderation and warnings", ["moderation"]),
    "logs": ("Server logs", ["logs"]),
    "react": ("React channels", ["react"]),
    "reaction-roles": ("Reaction roles", ["reaction-roles"]),
    "giveaways": ("Giveaways", ["giveaways"]),
    "polls": ("Polls", ["polls"]),
    "leveling": ("Leveling and XP", ["leveling"]),
    "suggestions": ("Suggestions", ["suggestions"]),
    "starboard": ("Starboard", ["starboard"]),
    "birthdays": ("Birthdays", ["birthdays"]),
    "autoresponses": ("Auto-responses", ["autoresponses"]),
    "announcements": ("Announcements and timed messages", ["announcements"]),
    "tempvoice": ("Join-to-create voice channels", ["tempvoice"]),
    "channeltools": ("Sticky messages, counting and stat channels", ["channeltools"]),
    "tickets": ("Tickets", ["tickets", "ticket-types", "ticket-panels"]),
    "applications": ("Applications", ["applications"]),
    "faq": ("FAQ panel", ["faq"]),
    "status": ("Status page", ["status"]),
    "reviews": ("Reviews", ["reviews"]),
    "roblox-verify": ("Roblox verification", ["roblox"]),
    "roblox-ranks": ("Roblox role binds (ranks, badges, passes)", ["roblox-ranks"]),
    "roblox-game": ("Roblox game stats and group shouts", ["roblox-game"]),
    "roblox-sessions": ("Sessions", ["roblox-sessions"]),
    "utility": ("Utility (info, reminders, AFK, snipe)", ["utility"]),
}

# Every server needs these, whatever kind it is
SAFETY = ["automod", "moderation", "logs", "filter", "honeypot", "utility"]

FIGS = {
    "fivem": {
        "name": "FiveM Server",
        "blurb": "Whitelisting, queue priority, sneak peeks and everything an RP city needs.",
        "features": ["whitelist", "priority", "fivem-tools", "welcome", "tickets", "applications", "announcements",
                     "giveaways", "polls", "reaction-roles", *SAFETY],
    },
    "roblox": {
        "name": "Roblox Server",
        "blurb": "Roblox verification, rank, badge and game pass roles, live game stats, group shouts and sessions.",
        "features": ["roblox-verify", "roblox-ranks", "roblox-game", "roblox-sessions", "welcome", "leveling",
                     "suggestions", "applications", "tickets", "giveaways", "polls", "reaction-roles", "autoresponses",
                     "announcements", "tempvoice", "channeltools", *SAFETY],
    },
    "community": {
        "name": "Community Server",
        "blurb": "Leveling, suggestions, starboard, birthdays, self roles, giveaways, voice channels and more.",
        "features": ["welcome", "leveling", "suggestions", "starboard", "birthdays", "reaction-roles", "giveaways",
                     "polls", "react", "autoresponses", "announcements", "tempvoice", "channeltools", "applications",
                     "faq", "tickets", *SAFETY],
    },
    "support": {
        "name": "Support Server",
        "blurb": "Tickets with ratings and auto-close, an FAQ panel, a status page, applications and reviews.",
        "features": ["tickets", "faq", "status", "reviews", "applications", "suggestions", "autoresponses",
                     "announcements", "channeltools", "welcome", "reaction-roles", "polls", *SAFETY],
    },
}

# slash command: feature it belongs to (commands not listed always work)
COMMAND_FEATURES = {
    "turnonwl": "whitelist", "turnoffwl": "whitelist",
    "give-prio": "priority", "removeall-prio": "priority",
    "sneakpeek": "fivem-tools", "verify-female": "fivem-tools",
    "filter-add": "filter", "filter-remove": "filter", "filter-allow": "filter",
    "filter-list": "filter", "wlfilter": "filter",
    "honeypot": "honeypot",
    "giveaway": "giveaways",
    "polls": "polls",
    "reactionrole": "reaction-roles",
    "reactchannel": "react",
    "ticket-add": "tickets", "ticket-remove": "tickets", "ticket-close": "tickets",
    "ticket-claim": "tickets", "ticket-rename": "tickets", "snippet": "tickets",
    "verify": "roblox-verify", "roblox-update": "roblox-verify", "roblox-unlink": "roblox-verify",
    "roblox-whois": "roblox-verify", "roblox-profile": "roblox-verify",
    "game": "roblox-game", "session-start": "roblox-sessions", "session-end": "roblox-sessions",
    "warn": "moderation", "warnings": "moderation", "delwarn": "moderation", "clearwarns": "moderation",
    "timeout": "moderation", "untimeout": "moderation", "kick": "moderation", "ban": "moderation",
    "unban": "moderation", "purge": "moderation", "slowmode": "moderation", "lock": "moderation", "unlock": "moderation",
    "tempban": "moderation", "softban": "moderation", "nick": "moderation", "modlogs": "moderation", "case": "moderation",
    "lockdown": "moderation", "hide": "moderation", "unhide": "moderation", "nuke": "moderation", "voice": "moderation",
    "role": "moderation", "autorole": "welcome",
    "userinfo": "utility", "serverinfo": "utility", "avatar": "utility", "banner": "utility", "membercount": "utility",
    "ping": "utility", "botinfo": "utility", "say": "utility", "reminder": "utility", "afk": "utility",
    "snipe": "utility", "steal": "utility",
    "rank": "leveling", "leaderboard": "leveling", "xp-give": "leveling", "xp-reset": "leveling",
    "suggest": "suggestions",
    "birthday-set": "birthdays", "birthday-remove": "birthdays", "birthdays": "birthdays",
    "vc-limit": "tempvoice", "vc-rename": "tempvoice", "vc-lock": "tempvoice", "vc-unlock": "tempvoice",
    "announce": "announcements",
    "faq": "faq", "status": "status", "status-set": "status",
    "apply": "applications", "review": "reviews",
}

# Tabs every server has, whatever figs are on
CORE_TABS = ["overview", "figs", "general", "profile", "commands", "access"]


def enabled_features(conf) -> set:
    out = set()
    for fig in conf.get("figs", []):
        out.update(FIGS.get(fig, {}).get("features", []))
    return out


def feature_on(conf, feature: str) -> bool:
    return feature in enabled_features(conf)


def figs_with(feature: str) -> list[str]:
    """Names of the figs that include a feature, for 'turn on ...' hints."""
    return [f["name"] for f in FIGS.values() if feature in f["features"]]


def enabled_tabs(conf) -> list[str]:
    tabs = list(CORE_TABS)
    for feature in enabled_features(conf):
        tabs += FEATURES[feature][1]
    return tabs


def figs_for_client() -> dict:
    return {
        "figs": [
            {"id": fid, "name": f["name"], "blurb": f["blurb"],
             "features": [{"id": x, "name": FEATURES[x][0], "tabs": FEATURES[x][1]} for x in f["features"]]}
            for fid, f in FIGS.items()
        ],
        "core_tabs": CORE_TABS,
    }
