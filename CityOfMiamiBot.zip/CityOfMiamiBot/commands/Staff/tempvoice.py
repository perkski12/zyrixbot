"""
Join-to-create voice channels: joining the "join to create" channel makes a voice channel just for
you, and it's deleted when everyone leaves. Owners can use /vc-limit, /vc-rename, /vc-lock, /vc-unlock.
"""

import discord
from discord import app_commands
from discord.ext import commands

from .wl_embed import config, use_guild
from .figs import feature_on
from .kit import Store, reply


class TempVoice(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("temp_voice.json")  # server → {channel id: owner id}

    def owned(self, guild) -> dict:
        return self.store.guild(guild)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        guild = member.guild
        use_guild(guild)
        if after.channel is not None and after.channel.id == config.get("tv_hub_channel_id") and feature_on(config, "tempvoice"):
            await self.create(member, after.channel)
        if before.channel is not None and str(before.channel.id) in self.owned(guild) and not before.channel.members:
            await self.remove(before.channel)

    async def create(self, member, hub):
        guild = member.guild
        category = guild.get_channel(config.get("tv_category_id") or 0) or hub.category
        name = (config.get("tv_name") or "{user}'s channel").replace("{user}", member.display_name)[:100]
        overwrites = {member: discord.PermissionOverwrite(connect=True, manage_channels=True, move_members=True)}
        try:
            channel = await guild.create_voice_channel(name, category=category, overwrites=overwrites,
                                                       user_limit=int(config.get("tv_limit", 0) or 0),
                                                       reason=f"Join-to-create for {member}")
        except discord.HTTPException as e:
            print(f"[TempVoice] Couldn't make a channel: {e}")
            return None
        self.owned(guild)[str(channel.id)] = member.id
        self.store.save()
        try:
            await member.move_to(channel)
        except discord.HTTPException:
            pass
        return channel

    async def remove(self, channel):
        self.owned(channel.guild).pop(str(channel.id), None)
        self.store.save()
        try:
            await channel.delete(reason="Everyone left")
        except discord.HTTPException:
            pass

    async def mine(self, interaction):
        voice = getattr(interaction.user, "voice", None)
        channel = voice.channel if voice else None
        if channel is None or self.owned(interaction.guild).get(str(channel.id)) != interaction.user.id:
            await reply(interaction, "## Not your channel", "Join the channel you made with join-to-create first.")
            return None
        return channel

    @app_commands.command(name="vc-limit", description="Set how many people can join your voice channel")
    @app_commands.describe(people="0 means no limit")
    async def vc_limit(self, interaction: discord.Interaction, people: app_commands.Range[int, 0, 99]):
        if channel := await self.mine(interaction):
            await channel.edit(user_limit=people)
            await reply(interaction, "## 👥 Limit " + ("removed" if not people else f"set to {people}"))

    @app_commands.command(name="vc-rename", description="Rename your voice channel")
    @app_commands.describe(name="The new name")
    async def vc_rename(self, interaction: discord.Interaction, name: str):
        if channel := await self.mine(interaction):
            try:
                await channel.edit(name=name[:100])
            except discord.HTTPException:
                return await reply(interaction, "## Slow down", "Discord allows 2 renames every 10 minutes.")
            await reply(interaction, "## ✏️ Renamed", f"Your channel is now **{name[:100]}**.")

    @app_commands.command(name="vc-lock", description="Stop new people from joining your voice channel")
    async def vc_lock(self, interaction: discord.Interaction):
        if channel := await self.mine(interaction):
            await channel.set_permissions(interaction.guild.default_role, connect=False)
            await reply(interaction, "## 🔒 Locked", "People already inside can stay.")

    @app_commands.command(name="vc-unlock", description="Let people join your voice channel again")
    async def vc_unlock(self, interaction: discord.Interaction):
        if channel := await self.mine(interaction):
            await channel.set_permissions(interaction.guild.default_role, connect=None)
            await reply(interaction, "## 🔓 Unlocked")

    def dashboard_info(self, guild) -> dict:
        live = [cid for cid in self.owned(guild) if guild.get_channel(int(cid))]
        return {"active": len(live)}


async def setup(bot: commands.Bot):
    await bot.add_cog(TempVoice(bot))
