"""
Roles: /role add, remove, temp, info and members, and /autorole add, remove and list.

/autorole changes the same join roles as the dashboard's Welcome page (join_role_ids for members,
join_bot_role_ids for bots). Temporary roles come off by themselves (data/temp_roles.json).
"""

import discord
from discord import app_commands
from discord.ext import commands, tasks

from .wl_embed import config, save_config
from .kit import Store, reply, send_log, now, parse_duration, duration_text

MAX_TEMP = 365 * 86400
MAX_JOIN_ROLES = 10
KEY_PERMS = [("administrator", "Administrator"), ("manage_guild", "Manage Server"), ("manage_roles", "Manage Roles"),
             ("manage_channels", "Manage Channels"), ("manage_messages", "Manage Messages"), ("kick_members", "Kick Members"),
             ("ban_members", "Ban Members"), ("moderate_members", "Timeout Members"), ("mention_everyone", "Mention Everyone"),
             ("manage_nicknames", "Manage Nicknames"), ("manage_webhooks", "Manage Webhooks")]


def role_problem(interaction, role) -> str | None:
    """Why the person (or the bot) can't give or take this role, or None."""
    guild, actor = interaction.guild, interaction.user
    if role.is_default():
        return "@everyone isn't a role you can give or take."
    if role.managed:
        return f"{role.mention} belongs to a bot or an integration, so Discord handles it."
    if not role.is_assignable():
        return f"{role.mention} is above my highest role. Drag my role above it in Server Settings → Roles."
    if actor.id != guild.owner_id and role.position >= actor.top_role.position:
        return f"{role.mention} is the same as or above your highest role."
    return None


class Roles(commands.Cog):
    role_group = app_commands.Group(name="role", description="Give, take or look up roles",
                                    default_permissions=discord.Permissions(manage_roles=True))
    autorole_group = app_commands.Group(name="autorole", description="Roles everyone gets when they join",
                                        default_permissions=discord.Permissions(manage_guild=True))

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.temp = Store("temp_roles.json")

    async def cog_load(self):
        self.temp_loop.start()

    async def cog_unload(self):
        self.temp_loop.cancel()

    # ── /role ──

    @role_group.command(name="add", description="Give someone a role")
    @app_commands.describe(member="Who gets it", role="Which role")
    async def role_add(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if error := role_problem(interaction, role):
            return await reply(interaction, "## Can't give that role", error)
        if role in member.roles:
            return await reply(interaction, "## Already has it", f"{member.mention} already has {role.mention}.")
        try:
            await member.add_roles(role, reason=f"/role add by {interaction.user}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't give it", "I need the **Manage Roles** permission.")
        await self.log(interaction, "➕ Role given", f"{role.mention} → {member.mention}")
        await reply(interaction, "## ➕ Role given", f"{member.mention} now has {role.mention}.")

    @role_group.command(name="remove", description="Take a role away from someone")
    @app_commands.describe(member="Who loses it", role="Which role")
    async def role_remove(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if error := role_problem(interaction, role):
            return await reply(interaction, "## Can't take that role", error)
        if role not in member.roles:
            return await reply(interaction, "## Doesn't have it", f"{member.mention} doesn't have {role.mention}.")
        try:
            await member.remove_roles(role, reason=f"/role remove by {interaction.user}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't take it", "I need the **Manage Roles** permission.")
        self.forget(interaction.guild, member.id, role.id)
        await self.log(interaction, "➖ Role taken", f"{role.mention} from {member.mention}")
        await reply(interaction, "## ➖ Role taken", f"{member.mention} no longer has {role.mention}.")

    @role_group.command(name="temp", description="Give someone a role for a while. It comes off by itself")
    @app_commands.describe(member="Who gets it", role="Which role", duration="How long, like 30m, 12h, 3d or 2w")
    async def role_temp(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role, duration: str):
        seconds = parse_duration(duration)
        if not seconds or seconds < 60 or seconds > MAX_TEMP:
            return await reply(interaction, "## That isn't a length I can use", "Use something like `30m`, `12h`, `3d` or `2w` (1 minute to 1 year).")
        if error := role_problem(interaction, role):
            return await reply(interaction, "## Can't give that role", error)
        try:
            if role not in member.roles:
                await member.add_roles(role, reason=f"/role temp by {interaction.user} for {duration_text(seconds)}")
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't give it", "I need the **Manage Roles** permission.")
        until = now() + seconds
        entries = self.temp.guild(interaction.guild, list)
        entries[:] = [e for e in entries if not (e["user_id"] == member.id and e["role_id"] == role.id)]
        entries.append({"user_id": member.id, "role_id": role.id, "until": until})
        self.temp.save()
        await self.log(interaction, "⏱️ Temporary role given", f"{role.mention} → {member.mention} until <t:{until}:f>")
        await reply(interaction, "## ⏱️ Temporary role given", f"{member.mention} has {role.mention} until <t:{until}:f> (<t:{until}:R>).")

    @role_group.command(name="info", description="See a role's details")
    @app_commands.describe(role="Which role")
    async def role_info(self, interaction: discord.Interaction, role: discord.Role):
        perms = [name for key, name in KEY_PERMS if getattr(role.permissions, key, False)]
        color = f"#{role.color.value:06x}" if role.color.value else "None"
        created = int(role.created_at.timestamp()) if getattr(role, "created_at", None) else None
        lines = [
            f"**ID:** `{role.id}`",
            f"**Members:** {len(role.members)}",
            f"**Color:** {color}",
            f"**Position:** {role.position} of {len(interaction.guild.roles) - 1}",
            f"**Shown separately:** {'Yes' if getattr(role, 'hoist', False) else 'No'}  ·  **Mentionable:** {'Yes' if getattr(role, 'mentionable', False) else 'No'}",
        ]
        if created:
            lines.append(f"**Made:** <t:{created}:D> (<t:{created}:R>)")
        if role.managed:
            lines.append("-# Handled by a bot or integration")
        await reply(interaction, f"## {role.name}", "\n".join(lines),
                    "**Key permissions:** " + (", ".join(perms) if perms else "None"))

    @role_group.command(name="members", description="See who has a role")
    @app_commands.describe(role="Which role")
    async def role_members(self, interaction: discord.Interaction, role: discord.Role):
        members = sorted(role.members, key=lambda m: m.display_name.lower())
        if not members:
            return await reply(interaction, f"## Nobody has {role.name}")
        shown = ", ".join(m.mention for m in members[:60])
        more = f"\n-# and {len(members) - 60} more" if len(members) > 60 else ""
        await reply(interaction, f"## {role.name}: {len(members)} member{'s' if len(members) != 1 else ''}", (shown + more)[:3900])

    async def log(self, interaction, title: str, line: str):
        await send_log(interaction.guild, "mod_log_channel_id", f"## {title}", line, f"By {interaction.user.mention}")

    # ── temporary roles come off by themselves ──

    def forget(self, guild, user_id: int, role_id: int):
        entries = self.temp.data.get(str(guild.id))
        if entries and any(e["user_id"] == user_id and e["role_id"] == role_id for e in entries):
            entries[:] = [e for e in entries if not (e["user_id"] == user_id and e["role_id"] == role_id)]
            self.temp.save()

    @tasks.loop(minutes=1)
    async def temp_loop(self):
        await self.end_temp_roles()

    @temp_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def end_temp_roles(self, at: int | None = None) -> int:
        at, ended = at or now(), 0
        for gid, entries in list(self.temp.data.items()):
            guild = self.bot.get_guild(int(gid))
            if guild is None:
                continue
            for e in [e for e in entries if e["until"] <= at]:
                member, role = guild.get_member(e["user_id"]), guild.get_role(e["role_id"])
                if member is not None and role is not None and role in member.roles:
                    try:
                        await member.remove_roles(role, reason="Temporary role ended")
                    except discord.HTTPException:
                        if at - e["until"] < 7 * 86400:
                            continue  # try again next minute (for up to a week)
                entries.remove(e)
                ended += 1
            self.temp.save()
        return ended

    # ── /autorole (the Welcome page's join roles) ──

    @autorole_group.command(name="add", description="Give a role to everyone who joins from now on")
    @app_commands.describe(role="Which role", who="Members or bots (members if you leave it out)")
    @app_commands.choices(who=[app_commands.Choice(name="Members", value="members"),
                               app_commands.Choice(name="Bots", value="bots")])
    async def autorole_add(self, interaction: discord.Interaction, role: discord.Role, who: str = "members"):
        if error := role_problem(interaction, role):
            return await reply(interaction, "## Can't use that role", error)
        key = "join_bot_role_ids" if who == "bots" else "join_role_ids"
        ids = list(config.get(key) or [])
        if role.id in ids:
            return await reply(interaction, "## Already on the list", f"{'Bots' if who == 'bots' else 'New members'} already get {role.mention}.")
        if len(ids) >= MAX_JOIN_ROLES:
            return await reply(interaction, "## That's the most", f"You can have up to {MAX_JOIN_ROLES} join roles. Remove one first.")
        config[key] = ids + [role.id]
        save_config()
        await reply(interaction, "## ✅ Autorole added",
                    f"{'Bots' if who == 'bots' else 'Everyone'} who joins from now on gets {role.mention}.",
                    "-# To give it to people already here, use `/roleall`.")

    @autorole_group.command(name="remove", description="Stop giving a role to people who join")
    @app_commands.describe(role="Which role")
    async def autorole_remove(self, interaction: discord.Interaction, role: discord.Role):
        removed = False
        for key in ("join_role_ids", "join_bot_role_ids"):
            ids = list(config.get(key) or [])
            if role.id in ids:
                config[key] = [i for i in ids if i != role.id]
                removed = True
        if not removed:
            return await reply(interaction, "## Not an autorole", f"{role.mention} isn't given to people who join.")
        save_config()
        await reply(interaction, "## Autorole removed", f"People who join no longer get {role.mention}.")

    @autorole_group.command(name="list", description="See which roles people get when they join")
    async def autorole_list(self, interaction: discord.Interaction):
        guild = interaction.guild

        def names(key):
            roles = [guild.get_role(i) for i in config.get(key) or []]
            return ", ".join(r.mention for r in roles if r) or "None"
        await reply(interaction, "## Autoroles", f"**Members:** {names('join_role_ids')}\n**Bots:** {names('join_bot_role_ids')}",
                    "-# Add with `/autorole add`, or on the dashboard's Welcome page.")


async def setup(bot: commands.Bot):
    await bot.add_cog(Roles(bot))
