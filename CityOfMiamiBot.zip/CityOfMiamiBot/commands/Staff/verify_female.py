import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, city_emoji, accent


def _thumbnail_url() -> str:
    return config.get("thumbnail_url", "")


def _make_container(*text_lines: str, accent_color: int | None = None) -> ui.Container:
    url = _thumbnail_url()
    children = []

    if url and str(url).startswith("http"):
        children.append(
            ui.Section(
                *[ui.TextDisplay(line) for line in text_lines],
                accessory=ui.Thumbnail(
                    media=discord.UnfurledMediaItem(url=url),
                    description="Server thumbnail"
                )
            )
        )
    else:
        for line in text_lines:
            children.append(ui.TextDisplay(line))

    return ui.Container(*children, accent_color=accent_color if accent_color is not None else accent())


class VerifyFemale(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ──────────────────────────── /verify-female ────────────────────────────

    @app_commands.command(
        name="verify-female",
        description="Verify a female user, give them a role, and log it"
    )
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.describe(
        user="The user being verified",
        role="The role to give (default: the one set on the dashboard)",
        userverifier="The staff member who is verifying (default: you)",
        logchannel="The channel to log it in (default: the one set on the dashboard)"
    )
    async def verify_female(
        self,
        interaction: discord.Interaction,
        user: discord.Member,
        role: discord.Role | None = None,
        userverifier: discord.Member | None = None,
        logchannel: discord.TextChannel | None = None
    ):
        # Empty options fall back to the dashboard defaults
        role = role or interaction.guild.get_role(config.get("female_role_id") or 0)
        userverifier = userverifier or interaction.user
        logchannel = logchannel or interaction.guild.get_channel(config.get("female_log_channel_id") or 0)

        if role is None or logchannel is None:
            missing = "role" if role is None else "log channel"
            class MissingView(ui.LayoutView):
                def __init__(self_inner):
                    super().__init__()
                    self_inner.add_item(_make_container(
                        f"## {city_emoji()} Missing {missing.title()}",
                        f"Pick a {missing} in the command, or set a default on the dashboard (Commands page)."
                    ))
            await interaction.response.send_message(view=MissingView(), ephemeral=True)
            return

        # Give the role
        try:
            await user.add_roles(role, reason=f"Female verified by {userverifier}")
        except discord.Forbidden:
            class ErrView(ui.LayoutView):
                def __init__(self_inner):
                    super().__init__()
                    self_inner.add_item(_make_container(
                        f"## {city_emoji()} Permission Denied",
                        "I don't have permission to manage roles. Check my role hierarchy."
                    ))
            await interaction.response.send_message(view=ErrView(), ephemeral=True)
            return
        except Exception as e:
            class ErrView(ui.LayoutView):
                def __init__(self_inner):
                    super().__init__()
                    self_inner.add_item(_make_container(f"## {city_emoji()} Error", str(e)))
            await interaction.response.send_message(view=ErrView(), ephemeral=True)
            return

        ts = int(discord.utils.utcnow().timestamp())
        url = _thumbnail_url()

        # ── Log embed sent to the chosen log channel ──
        class LogView(ui.LayoutView):
            def __init__(self_inner):
                super().__init__()

                children = []

                if url and str(url).startswith("http"):
                    children.append(ui.Section(
                        ui.TextDisplay(f"## {city_emoji()} Female Verification"),
                        accessory=ui.Thumbnail(
                            media=discord.UnfurledMediaItem(url=url),
                            description="Server thumbnail"
                        )
                    ))
                else:
                    children.append(ui.TextDisplay(f"## {city_emoji()} Female Verification"))

                children.append(ui.Separator())
                children.append(ui.TextDisplay(f"**User:** {user.mention} (`{user}`)"))
                children.append(ui.TextDisplay(f"**Role Gave:** {role.mention}"))
                children.append(ui.TextDisplay(f"**User Who Verified:** {userverifier.mention}"))
                children.append(ui.Separator(visible=False))
                children.append(ui.TextDisplay(f"<t:{ts}:F>"))
                children.append(ui.Separator(visible=False))
                children.append(ui.TextDisplay(f"-# {interaction.guild.name}"))

                self_inner.add_item(ui.Container(*children, accent_color=accent()))

        try:
            await logchannel.send(view=LogView())
        except discord.HTTPException:
            pass

        # ── Confirmation in the command channel ──
        class ConfirmView(ui.LayoutView):
            def __init__(self_inner):
                super().__init__()
                self_inner.add_item(_make_container(
                    f"## {city_emoji()} Verified",
                    f"{user.mention} has been given {role.mention}.",
                    f"Logged to {logchannel.mention}."
                ))

        await interaction.response.send_message(view=ConfirmView())


async def setup(bot: commands.Bot):
    await bot.add_cog(VerifyFemale(bot))
