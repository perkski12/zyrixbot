"""
Status page: a message showing whether each part of your service is working (like a website
status page). Update it from the dashboard or with /status-set; the message updates by itself.
/status shows it to anyone. Changes are kept in data/status_page.json.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, use_guild, save_config
from .figs import feature_on
from .kit import Store, box, reply, is_staff, text_channel, now, DashError

STATES = {
    "operational": ("🟢", "Operational"),
    "maintenance": ("🔧", "Maintenance"),
    "degraded": ("🟡", "Degraded performance"),
    "partial": ("🟠", "Partial outage"),
    "major": ("🔴", "Major outage"),
}
ORDER = list(STATES)  # worst last


def overall(parts: list[dict]) -> str:
    states = [p.get("state", "operational") for p in parts] or ["operational"]
    return max(states, key=ORDER.index)


def status_view() -> ui.LayoutView:
    parts = [p for p in config.get("status_components", []) if p.get("name")]
    worst = overall(parts)
    emoji, label = STATES[worst]
    head = f"## {emoji} All systems operational" if worst == "operational" else f"## {emoji} {label}"
    lines = "\n".join(f"{STATES[p['state']][0]} **{p['name']}**: {STATES[p['state']][1]}" for p in parts) or "-# Nothing added yet."
    children = [head, lines]
    if config.get("status_note"):
        children.append(f"> {config['status_note']}")
    children.append(f"-# Updated <t:{now()}:R>")
    return box(*children)


class StatusPage(commands.Cog):
    DASH_ACTIONS = {"post": "dash_post"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("status_page.json")

    def state(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"msg": None, "channel": None, "history": []})

    async def update_message(self, guild, force_new: bool = False):
        use_guild(guild)
        channel = guild.get_channel(config.get("status_channel_id") or 0)
        if channel is None:
            return None
        state = self.state(guild)
        if state["msg"] and state["channel"] == channel.id and not force_new:
            try:
                await channel.get_partial_message(state["msg"]).edit(view=status_view())
                return state["msg"]
            except discord.HTTPException:
                pass
        msg = await channel.send(view=status_view())
        state.update(msg=msg.id, channel=channel.id)
        self.store.save()
        return msg

    def remember(self, guild, before: list, after: list, by: str):
        old = {p["name"]: p["state"] for p in before or []}
        history = self.state(guild)["history"]
        for p in after:
            if old.get(p["name"]) != p["state"]:
                history.insert(0, {"t": now(), "name": p["name"], "state": p["state"], "by": by})
        del history[50:]
        self.store.save()

    async def settings_changed(self, guild, changed: list, before: dict) -> list[str]:
        if not {"status_components", "status_note", "status_channel_id"} & set(changed):
            return []
        if "status_components" in changed:
            self.remember(guild, before.get("status_components"), config.get("status_components", []), "Dashboard")
        if self.state(guild)["msg"] or "status_channel_id" in changed:
            try:
                if await self.update_message(guild):
                    return ["Updated the status message in Discord."]
            except discord.HTTPException:
                return ["Couldn't update the status message. Check my permissions in the status channel."]
        return []

    @app_commands.command(name="status", description="See whether everything is working")
    async def status(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=status_view(), ephemeral=True)

    @app_commands.command(name="status-set", description="Change the status of one part")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(part="Which part", state="Its status now")
    async def status_set(self, interaction: discord.Interaction, part: str, state: str):
        parts = [dict(p) for p in config.get("status_components", [])]
        target = next((p for p in parts if p["name"].lower() == part.lower()), None)
        key = next((k for k, (_, label) in STATES.items() if state.lower() in (k, label.lower())), None)
        if target is None or key is None:
            return await reply(interaction, "## Pick from the list", "Choose a part and a status from the suggestions.")
        before = [dict(p) for p in parts]
        target["state"] = key
        config["status_components"] = parts
        save_config()
        self.remember(interaction.guild, before, parts, str(interaction.user))
        try:
            await self.update_message(interaction.guild)
        except discord.HTTPException:
            pass
        await reply(interaction, f"## {STATES[key][0]} {target['name']}: {STATES[key][1]}")

    @status_set.autocomplete("part")
    async def _parts(self, interaction: discord.Interaction, current: str):
        use_guild(interaction.guild)
        return [app_commands.Choice(name=p["name"], value=p["name"]) for p in config.get("status_components", [])
                if current.lower() in p["name"].lower()][:25]

    @status_set.autocomplete("state")
    async def _states(self, interaction: discord.Interaction, current: str):
        return [app_commands.Choice(name=f"{e} {label}", value=key) for key, (e, label) in STATES.items()
                if current.lower() in label.lower()]

    def dashboard_info(self, guild) -> dict:
        state = self.state(guild)
        return {"posted": bool(state["msg"]), "history": state["history"][:25],
                "overall": overall(config.get("status_components", [])),
                "url": f"https://discord.com/channels/{guild.id}/{state['channel']}/{state['msg']}" if state["msg"] else None}

    async def dash_post(self, guild, body: dict, user: dict) -> dict:
        text_channel(guild, config.get("status_channel_id"))
        msg = await self.update_message(guild, force_new=bool(body.get("new")))
        url = msg.jump_url if hasattr(msg, "jump_url") else None
        return {"message": "The status message is up to date.", "url": url, "log": "Posted the status message"}


async def setup(bot: commands.Bot):
    await bot.add_cog(StatusPage(bot))
