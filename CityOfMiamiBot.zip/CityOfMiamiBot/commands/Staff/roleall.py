import time

import discord
from discord import app_commands
from discord.ext import commands

from .wl_embed import simple_view


class RoleAll(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.running: set[int] = set()  # guild IDs with a /roleall in progress

    # ──────────────────────────── /roleall ──────────────────────────────────

    @app_commands.command(name="roleall", description="Give (or remove) a role for everyone in the server")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(
        role="The role to give or remove",
        action="Give or remove the role (default: give)",
        members="Who to include (default: everyone)"
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="Give", value="give"),
            app_commands.Choice(name="Remove", value="remove"),
        ],
        members=[
            app_commands.Choice(name="Everyone", value="all"),
            app_commands.Choice(name="Humans only", value="humans"),
            app_commands.Choice(name="Bots only", value="bots"),
        ]
    )
    async def roleall(
        self,
        interaction: discord.Interaction,
        role: discord.Role,
        action: str = "give",
        members: str = "all"
    ):
        guild = interaction.guild
        none = discord.AllowedMentions.none()

        if role.is_default() or not role.is_assignable():
            await interaction.response.send_message(
                view=simple_view("## Can't Use That Role", f"{role.mention} is above my role or can't be given out. Move my role higher in Server Settings → Roles."),
                ephemeral=True, allowed_mentions=none
            )
            return

        if guild.id in self.running:
            await interaction.response.send_message(
                view=simple_view("## Already Running", "Wait for the current `/roleall` to finish."),
                ephemeral=True
            )
            return

        if not guild.chunked:
            await guild.chunk()

        give = action == "give"
        targets = [
            m for m in guild.members
            if (members == "all" or (members == "bots") == m.bot)
            and ((role not in m.roles) if give else (role in m.roles))
        ]

        if not targets:
            await interaction.response.send_message(
                view=simple_view("## Nothing To Do", f"Everyone {'already has' if give else 'is already without'} {role.mention}."),
                ephemeral=True, allowed_mentions=none
            )
            return

        verb, done_verb = ("Giving", "Gave") if give else ("Removing", "Removed")
        to_from = "to" if give else "from"
        total = len(targets)

        await interaction.response.send_message(
            view=simple_view("## Role All Started", f"{verb} {role.mention} {to_from} **{total}** members. Progress is posted in this channel."),
            ephemeral=True, allowed_mentions=none
        )

        # Public progress message (keeps updating even past Discord's 15 minute interaction limit)
        try:
            progress = await interaction.channel.send(
                view=simple_view("## Role All", f"{verb} {role.mention} {to_from} **{total}** members...", f"-# 0/{total} done"),
                allowed_mentions=none
            )
        except discord.HTTPException:
            progress = None

        self.running.add(guild.id)
        done = failed = 0
        last_edit = time.monotonic()
        reason = f"/roleall by {interaction.user}"

        try:
            for member in targets:
                try:
                    if give:
                        await member.add_roles(role, reason=reason)
                    else:
                        await member.remove_roles(role, reason=reason)
                    done += 1
                except discord.HTTPException:
                    failed += 1

                # Update progress every 5 seconds (discord.py waits out rate limits on its own)
                if progress and time.monotonic() - last_edit >= 5:
                    last_edit = time.monotonic()
                    try:
                        await progress.edit(view=simple_view(
                            "## Role All", f"{verb} {role.mention} {to_from} **{total}** members...",
                            f"-# {done + failed}/{total} done"
                        ), allowed_mentions=none)
                    except discord.HTTPException:
                        pass
        finally:
            self.running.discard(guild.id)

        final = simple_view(
            "## Role All Finished",
            f"{done_verb} {role.mention} {to_from} **{done}** members.",
            f"-# {failed} failed" if failed else f"-# Done by {interaction.user}"
        )
        try:
            if progress:
                await progress.edit(view=final, allowed_mentions=none)
            else:
                await interaction.channel.send(view=final, allowed_mentions=none)
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(RoleAll(bot))
