"""
Channel tools:
  • Sticky messages stay at the bottom of a channel (reposted after new messages).
  • Stat channels show live numbers in their name, like "Members: 1,204" (updated every 10 minutes).
  • A counting channel where members count up one by one.
"""

import asyncio
import re
import time

import discord
from discord.ext import commands, tasks

from .wl_embed import config, use_guild
from .figs import feature_on
from .kit import Store, box

NUMBER = re.compile(r"^\s*(\d{1,9})\b")


def stat_values(guild) -> dict:
    members = guild.member_count or len(guild.members)
    bots = sum(1 for m in guild.members if m.bot)
    return {"members": members, "humans": max(0, members - bots), "bots": bots,
            "boosts": getattr(guild, "premium_subscription_count", 0) or 0,
            "channels": len(guild.channels), "roles": len(guild.roles)}


def stat_name(template: str, guild) -> str:
    values = stat_values(guild)
    return re.sub(r"\{(\w+)\}", lambda m: f"{values[m.group(1)]:,}" if m.group(1) in values else m.group(0), template)[:100]


class ChannelTools(commands.Cog):
    DASH_ACTIONS = {"refresh-stats": "dash_refresh", "reset-count": "dash_reset_count"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("channel_tools.json")
        self.sticky_at: dict[int, float] = {}
        self.sticky_lock: dict[int, asyncio.Lock] = {}

    def state(self, guild) -> dict:
        data = self.store.guild(guild, lambda: {"sticky": {}, "count": {"n": 0, "last": None, "best": 0}})
        data.setdefault("sticky", {})
        data.setdefault("count", {"n": 0, "last": None, "best": 0})
        return data

    async def cog_load(self):
        self.stats_loop.start()

    async def cog_unload(self):
        self.stats_loop.cancel()

    # ── sticky messages and counting ──

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or (self.bot.user and message.author.id == self.bot.user.id):
            return
        use_guild(message.guild)
        if not feature_on(config, "channeltools"):
            return
        if message.channel.id == config.get("count_channel_id") and not message.author.bot:
            await self.count(message)
        sticky = next((s for s in config.get("sticky_messages", []) if s.get("channel_id") == message.channel.id), None)
        if sticky:
            await self.restick(message.channel, sticky["text"])

    async def restick(self, channel, text: str, wait: float = 3):
        lock = self.sticky_lock.setdefault(channel.id, asyncio.Lock())
        if lock.locked():
            return  # a repost is already coming
        async with lock:
            await asyncio.sleep(max(0.0, wait - (time.monotonic() - self.sticky_at.get(channel.id, 0))))
            stuck = self.state(channel.guild)["sticky"]
            old = stuck.get(str(channel.id))
            if old:
                try:
                    await channel.get_partial_message(old).delete()
                except discord.HTTPException:
                    pass
            try:
                msg = await channel.send(view=box(f"📌 {text}"), allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                return
            stuck[str(channel.id)] = msg.id
            self.sticky_at[channel.id] = time.monotonic()
            self.store.save()

    async def count(self, message):
        match = NUMBER.match(message.content or "")
        if not match:
            return
        state = self.state(message.guild)["count"]
        number, expected = int(match.group(1)), state["n"] + 1
        ok = number == expected and state["last"] != message.author.id
        if ok:
            state.update(n=number, last=message.author.id, best=max(state["best"], number))
            emoji = "✅" if number % 100 else "💯"
        else:
            emoji, reached = "❌", state["n"]
            why = "You can't count twice in a row." if state["last"] == message.author.id and number == expected else f"The next number was **{expected}**."
            if config.get("count_reset_on_fail", True):
                state.update(n=0, last=None)
                why += " Start again from **1**."
            try:
                await message.channel.send(f"{message.author.mention} ruined it at **{reached}**! {why}",
                                           allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                pass
        self.store.save()
        try:
            await message.add_reaction(emoji)
        except discord.HTTPException:
            pass

    # ── stat channels ──

    @tasks.loop(minutes=10)
    async def stats_loop(self):
        for guild in list(self.bot.guilds):
            use_guild(guild)
            if feature_on(config, "channeltools"):
                await self.update_stats(guild)

    @stats_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def update_stats(self, guild) -> int:
        changed = 0
        for row in config.get("stat_channels", []):
            channel = guild.get_channel(row.get("channel_id") or 0)
            if channel is None:
                continue
            name = stat_name(row["template"], guild)
            if channel.name != name:
                try:
                    await channel.edit(name=name, reason="Stat channel")
                    changed += 1
                except discord.HTTPException:
                    pass
        return changed

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        count = self.state(guild)["count"]
        return {"count": count["n"], "best": count["best"], "values": stat_values(guild)}

    async def dash_refresh(self, guild, body: dict, user: dict) -> dict:
        n = await self.update_stats(guild)
        return {"message": f"Updated {n} channel name{'s' if n != 1 else ''}." if n else "Every stat channel is up to date."}

    async def dash_reset_count(self, guild, body: dict, user: dict) -> dict:
        self.state(guild)["count"].update(n=0, last=None)
        self.store.save()
        return {"message": "Counting starts again from 1.", "log": "Reset the counting channel"}


async def setup(bot: commands.Bot):
    await bot.add_cog(ChannelTools(bot))
