"""
Roblox verification + group rank roles (the Roblox Server fig).

Verifying:
  1. A member clicks "Verify with Roblox" on the panel (or uses /verify) and types their Roblox username.
  2. The bot gives them a few words to paste into the About section of their Roblox profile.
  3. They press Done, the bot reads their profile, and if the words are there they're linked.
Linked members get the verified role, their Roblox name as nickname, and roles for their rank
in your Roblox group. A link works in every server that uses the bot, so joining another
server with auto-verify on sets them up straight away.

Commands: /verify, /roblox-update, /roblox-unlink, /roblox-whois
"""

import asyncio
import json
import os
import secrets
import time

import aiohttp
import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, simple_view, accent, use_guild, server_name
from .figs import feature_on

LINKS_FILE = os.path.join("data", "roblox_links.json")
CODE_MINUTES = 15
WORDS = (
    "apple ocean tiger maple rocket candle river sunset pencil garden silver forest planet "
    "window bridge castle dragon falcon harbor island jungle lantern meadow orange panda "
    "pepper quartz rabbit saddle tomato violet walnut yellow zebra anchor basket cactus "
    "dolphin engine feather glacier hammer igloo jacket kettle lemon marble needle orbit "
    "parrot ribbon shadow thunder tulip velvet wagon"
).split()
NICKNAMES = {
    "": "Don't change nicknames",
    "{display}": "Roblox display name",
    "{roblox}": "Roblox username",
    "{display} (@{roblox})": "Display name (@username)",
}


class RobloxError(Exception):
    pass


# ──────────────────────────── Roblox web API ────────────────────────────────
# Public endpoints, no API key needed.

async def _request(method: str, url: str, **kw):
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=12)) as http:
            async with http.request(method, url, **kw) as r:
                if r.status == 429:
                    raise RobloxError("Roblox is busy right now. Try again in a minute.")
                if r.status == 400 or r.status == 404:
                    return None
                if r.status != 200:
                    raise RobloxError(f"Roblox answered with an error ({r.status}). Try again in a minute.")
                return await r.json()
    except (aiohttp.ClientError, asyncio.TimeoutError):
        raise RobloxError("Couldn't reach Roblox. Try again in a minute.")


async def find_user(username: str) -> dict | None:
    """{'id', 'name', 'displayName'} for a username, or None."""
    data = await _request("POST", "https://users.roblox.com/v1/usernames/users",
                          json={"usernames": [username], "excludeBannedUsers": True})
    users = (data or {}).get("data") or []
    return users[0] if users else None


async def get_user(user_id: int) -> dict | None:
    """{'id', 'name', 'displayName', 'description'} or None."""
    return await _request("GET", f"https://users.roblox.com/v1/users/{int(user_id)}")


async def get_group_rank(user_id: int, group_id: int) -> dict | None:
    """The member's role in a group: {'rank', 'name'}, or None if they're not in it."""
    data = await _request("GET", f"https://groups.roblox.com/v2/users/{int(user_id)}/groups/roles")
    for entry in (data or {}).get("data") or []:
        if int(entry["group"]["id"]) == int(group_id):
            return {"rank": int(entry["role"]["rank"]), "name": entry["role"]["name"]}
    return None


async def get_group(group_id: int) -> dict | None:
    """{'id', 'name', 'memberCount', 'roles': [{'name', 'rank', 'memberCount'}]} or None."""
    info = await _request("GET", f"https://groups.roblox.com/v1/groups/{int(group_id)}")
    if not info:
        return None
    roles = await _request("GET", f"https://groups.roblox.com/v1/groups/{int(group_id)}/roles")
    info["roles"] = sorted((roles or {}).get("roles") or [], key=lambda r: r["rank"], reverse=True)
    return info


async def get_headshot(user_id: int) -> str | None:
    data = await _request("GET", "https://thumbnails.roblox.com/v1/users/avatar-headshot",
                          params={"userIds": str(int(user_id)), "size": "150x150", "format": "Png"})
    items = (data or {}).get("data") or []
    return items[0].get("imageUrl") if items else None


async def get_user_groups(user_id: int) -> list[int]:
    """IDs of every group a Roblox user is in."""
    data = await _request("GET", f"https://groups.roblox.com/v2/users/{int(user_id)}/groups/roles")
    return [int(e["group"]["id"]) for e in (data or {}).get("data") or []]


async def owned_badges(user_id: int, badge_ids: list[int]) -> set[int]:
    """Which of these badges the user has."""
    if not badge_ids:
        return set()
    data = await _request("GET", f"https://badges.roblox.com/v1/users/{int(user_id)}/badges/awarded-dates",
                          params={"badgeIds": ",".join(str(int(b)) for b in badge_ids)})
    return {int(e["badgeId"]) for e in (data or {}).get("data") or []}


async def owns_pass(user_id: int, pass_id: int) -> bool:
    data = await _request("GET", f"https://inventory.roblox.com/v1/users/{int(user_id)}/items/GamePass/{int(pass_id)}/is-owned")
    return data is True


async def get_game(place_id: int) -> dict | None:
    """A game's live stats from its place ID (the number in the game's link)."""
    uni = await _request("GET", f"https://apis.roblox.com/universes/v1/places/{int(place_id)}/universe")
    universe = (uni or {}).get("universeId")
    if not universe:
        return None
    data = await _request("GET", "https://games.roblox.com/v1/games", params={"universeIds": str(universe)})
    games = (data or {}).get("data") or []
    if not games:
        return None
    g = games[0]
    return {"name": g.get("name", "Game"), "playing": g.get("playing", 0), "visits": g.get("visits", 0),
            "favorites": g.get("favoritedCount", 0), "max_players": g.get("maxPlayers", 0),
            "creator": (g.get("creator") or {}).get("name", ""), "place_id": int(place_id), "universe_id": universe,
            "updated": g.get("updated", "")}


def account_age_days(profile: dict) -> int | None:
    """How many days old a Roblox account is (Roblox sends "created" like 2006-02-27T21:06:40.3Z)."""
    import datetime
    try:
        when = datetime.datetime.strptime(str((profile or {}).get("created") or "")[:19], "%Y-%m-%dT%H:%M:%S")
    except ValueError:
        return None
    return (datetime.datetime.now(datetime.timezone.utc) - when.replace(tzinfo=datetime.timezone.utc)).days


def profile_url(user_id) -> str:
    return f"https://www.roblox.com/users/{int(user_id)}/profile"


# ──────────────────────────── layouts ───────────────────────────────────────

def _box(*children) -> ui.LayoutView:
    view = ui.LayoutView()
    view.add_item(ui.Container(*children, accent_color=accent()))
    return view


def panel_view() -> ui.LayoutView:
    """The message members click to verify."""
    return _box(
        ui.TextDisplay(f"## {config.get('roblox_panel_title') or 'Verify with Roblox'}"),
        ui.TextDisplay(config.get("roblox_panel_text") or "Link your Roblox account to get access."),
        ui.Separator(),
        ui.ActionRow(ui.Button(label="Verify with Roblox", emoji="✅", custom_id="roblox:start", style=discord.ButtonStyle.success)),
    )


def code_view(pending: dict) -> ui.LayoutView:
    return _box(
        ui.TextDisplay("## Prove it's your account"),
        ui.TextDisplay(
            f"1. Open your Roblox profile: **{pending['name']}**\n"
            "2. Click the pencil next to **About** and paste these words anywhere:\n"
            f"```{pending['code']}```\n"
            "3. Save, come back here and press **Done**."
        ),
        ui.TextDisplay(f"-# The words work for {CODE_MINUTES} minutes. You can remove them after."),
        ui.ActionRow(
            ui.Button(label="Done", emoji="✅", custom_id="roblox:check", style=discord.ButtonStyle.success),
            ui.Button(label="Open profile", url=profile_url(pending["id"]), style=discord.ButtonStyle.link),
            ui.Button(label="Cancel", custom_id="roblox:cancel", style=discord.ButtonStyle.secondary),
        ),
    )


def linked_view(link: dict) -> ui.LayoutView:
    return _box(
        ui.TextDisplay("## You already linked a Roblox account"),
        ui.TextDisplay(f"**{link['display']}** (@{link['name']})"),
        ui.ActionRow(
            ui.Button(label="Use this account", custom_id="roblox:use", style=discord.ButtonStyle.success),
            ui.Button(label="Link a different one", custom_id="roblox:new", style=discord.ButtonStyle.secondary),
        ),
    )


class UsernameForm(ui.Modal):
    def __init__(self, cog: "Roblox"):
        super().__init__(title="Verify with Roblox", custom_id="roblox:form")
        self.cog = cog
        self.username = ui.TextInput(label="Your Roblox username", placeholder="Not your display name", max_length=20, min_length=3)
        self.add_item(self.username)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        await self.cog.begin(interaction, str(self.username.value).strip())


# ──────────────────────────── the cog ───────────────────────────────────────

class Roblox(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.links = self._load()
        self.pending: dict[int, dict] = {}  # discord user id → code waiting to be checked
        self.auto_last: dict[int, float] = {}  # server → last automatic role update

    @staticmethod
    def _load() -> dict:
        try:
            with open(LINKS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _save(self):
        os.makedirs(os.path.dirname(LINKS_FILE), exist_ok=True)
        tmp = LINKS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.links, f, indent=2)
        os.replace(tmp, LINKS_FILE)

    def link_of(self, user_id: int) -> dict | None:
        return self.links.get(str(user_id))

    async def _reply(self, interaction: discord.Interaction, view: ui.LayoutView, edit: bool = False):
        if edit and not interaction.response.is_done():
            await interaction.response.edit_message(view=view)
        elif interaction.response.is_done():
            await interaction.followup.send(view=view, ephemeral=True)
        else:
            await interaction.response.send_message(view=view, ephemeral=True)

    # ── verifying ──

    async def start(self, interaction: discord.Interaction):
        link = self.link_of(interaction.user.id)
        if link:
            return await self._reply(interaction, linked_view(link))
        await interaction.response.send_modal(UsernameForm(self))

    async def begin(self, interaction: discord.Interaction, username: str):
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            user = await find_user(username)
        except RobloxError as e:
            return await self._reply(interaction, simple_view("## Roblox didn't answer", str(e)))
        if not user:
            return await self._reply(interaction, simple_view("## No Roblox account found",
                                                              f"Nobody on Roblox is called **{username}**. Check the spelling (use your username, not your display name)."))
        pending = {
            "id": int(user["id"]), "name": user["name"], "display": user.get("displayName") or user["name"],
            "code": " ".join(secrets.choice(WORDS) for _ in range(5)),
            "expires": time.time() + CODE_MINUTES * 60,
        }
        self.pending[interaction.user.id] = pending
        await self._reply(interaction, code_view(pending))

    async def check(self, interaction: discord.Interaction):
        pending = self.pending.get(interaction.user.id)
        if not pending or pending["expires"] < time.time():
            self.pending.pop(interaction.user.id, None)
            return await self._reply(interaction, simple_view("## That code expired", "Click **Verify with Roblox** again to get a new one."), edit=True)
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            profile = await get_user(pending["id"])
        except RobloxError as e:
            return await self._reply(interaction, simple_view("## Roblox didn't answer", str(e)))
        about = " ".join(str((profile or {}).get("description") or "").lower().split())
        if pending["code"] not in about:
            return await self._reply(interaction, simple_view(
                "## The words aren't on your profile yet",
                f"Make sure your About section has `{pending['code']}` and that you pressed Save, then press **Done** again. "
                "Roblox can take a minute to update."))

        problem = await self.screen(pending["id"], profile)
        if problem:
            self.pending.pop(interaction.user.id, None)
            await self.log(interaction.guild, f"⛔ {interaction.user.mention} tried to verify as **{pending['name']}**: {problem}")
            return await self._reply(interaction, simple_view("## Can't verify this account", problem))

        self.pending.pop(interaction.user.id, None)
        link = {"id": pending["id"], "name": profile.get("name", pending["name"]),
                "display": profile.get("displayName") or pending["display"], "verified_at": int(time.time())}
        self.links[str(interaction.user.id)] = link
        self._save()
        notes = await self.apply(interaction.user, link)
        await self._reply(interaction, simple_view(
            "## ✅ You're verified",
            f"Linked to **{link['display']}** (@{link['name']}). You can remove the words from your profile now.",
            *(["-# " + " ".join(notes)] if notes else [])))
        await self.log(interaction.guild, f"✅ {interaction.user.mention} verified as **{link['name']}** ({profile_url(link['id'])})")

    async def screen(self, roblox_id: int, profile: dict) -> str | None:
        """Reasons an account can't verify here: too new, or in a blocked group."""
        need = int(config.get("rbx_min_age_days", 0) or 0)
        if need:
            age = account_age_days(profile)
            if age is not None and age < need:
                return f"This Roblox account is {age} day{'s' if age != 1 else ''} old. Accounts have to be at least {need} days old to verify here."
        blocked = set(config.get("rbx_blacklist_groups", []))
        if blocked:
            try:
                groups = set(await get_user_groups(roblox_id))
            except RobloxError:
                return None  # don't lock people out because Roblox is down
            if groups & blocked:
                return "This Roblox account is in a group that isn't allowed here."
        return None

    # ── giving roles and nicknames ──

    async def apply(self, member: discord.Member, link: dict) -> list[str]:
        """Give the verified role, nickname and group rank roles in the member's server. Returns notes."""
        use_guild(member.guild)
        guild, notes = member.guild, []
        add, remove = set(), set()

        verified = guild.get_role(config.get("roblox_verified_role_id") or 0)
        unverified = guild.get_role(config.get("roblox_unverified_role_id") or 0)
        if verified:
            add.add(verified)
        if unverified:
            remove.add(unverified)

        group_id = config.get("roblox_group_id")
        if group_id and feature_on(config, "roblox-ranks"):
            try:
                rank = await get_group_rank(link["id"], group_id)
            except RobloxError:
                rank, notes = None, notes + ["Couldn't check your group rank right now."]
            member_role = guild.get_role(config.get("roblox_group_member_role_id") or 0)
            if member_role:
                (add if rank else remove).add(member_role)
            for bind in config.get("roblox_rank_roles", []):
                role = guild.get_role(bind.get("role_id") or 0)
                if role:
                    (add if rank and rank["rank"] == bind.get("rank") else remove).add(role)

        if feature_on(config, "roblox-ranks"):
            badges = [b for b in config.get("rbx_badge_roles", []) if b.get("badge_id") and b.get("role_id")]
            if badges:
                try:
                    owned = await owned_badges(link["id"], [b["badge_id"] for b in badges])
                except RobloxError:
                    owned, notes = None, notes + ["Couldn't check your badges right now."]
                if owned is not None:
                    for b in badges:
                        role = guild.get_role(b["role_id"])
                        if role:
                            (add if b["badge_id"] in owned else remove).add(role)
            for p in [p for p in config.get("rbx_pass_roles", []) if p.get("pass_id") and p.get("role_id")]:
                role = guild.get_role(p["role_id"])
                if role is None:
                    continue
                try:
                    (add if await owns_pass(link["id"], p["pass_id"]) else remove).add(role)
                except RobloxError:
                    notes.append("Couldn't check your game passes right now.")
                    break

        to_add = [r for r in add if r not in member.roles and r.is_assignable()]
        to_remove = [r for r in remove - add if r in member.roles and r.is_assignable()]
        try:
            if to_add:
                await member.add_roles(*to_add, reason="Roblox verification")
            if to_remove:
                await member.remove_roles(*to_remove, reason="Roblox verification")
        except discord.HTTPException:
            notes.append("I couldn't change some of your roles (my role needs to be higher).")
        if any(not r.is_assignable() for r in add | remove):
            notes.append("Some roles are above my role, so I skipped them.")

        fmt = config.get("roblox_nickname", "{display}")
        if fmt:
            nick = fmt.replace("{display}", link["display"]).replace("{roblox}", link["name"])[:32]
            if member.display_name != nick and member.id != guild.owner_id:
                try:
                    await member.edit(nick=nick, reason="Roblox verification")
                except discord.HTTPException:
                    notes.append("I couldn't change your nickname.")
        return notes

    async def unapply(self, member: discord.Member):
        use_guild(member.guild)
        guild = member.guild
        ids = [config.get("roblox_verified_role_id"), config.get("roblox_group_member_role_id")]
        ids += [b.get("role_id") for b in config.get("roblox_rank_roles", [])]
        ids += [b.get("role_id") for b in config.get("rbx_badge_roles", []) + config.get("rbx_pass_roles", [])]
        roles = [guild.get_role(i or 0) for i in ids]
        roles = [r for r in roles if r and r in member.roles and r.is_assignable()]
        try:
            if roles:
                await member.remove_roles(*roles, reason="Roblox account unlinked")
            unverified = guild.get_role(config.get("roblox_unverified_role_id") or 0)
            if unverified and unverified.is_assignable() and unverified not in member.roles:
                await member.add_roles(unverified, reason="Roblox account unlinked")
        except discord.HTTPException:
            pass

    async def update_everyone(self, guild) -> int:
        """Re-check everyone in the server who has a linked account. Returns how many."""
        done = 0
        for member in list(guild.members):
            link = self.link_of(member.id)
            if link and not member.bot:
                use_guild(guild)
                await self.apply(member, link)
                done += 1
                await asyncio.sleep(0.5)  # go easy on Roblox and Discord
        return done

    async def log(self, guild, text: str):
        use_guild(guild)
        channel = guild.get_channel(config.get("roblox_log_channel_id") or 0) or guild.get_channel(config.get("log_channel_id") or 0)
        if channel:
            try:
                await channel.send(view=simple_view("## Roblox", text), allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                pass

    # ── panel (posted from the dashboard) ──

    async def post_panel(self, channel) -> discord.Message:
        use_guild(channel.guild)
        return await channel.send(view=panel_view())

    # ── buttons ──

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component or interaction.guild is None:
            return
        custom_id = (interaction.data or {}).get("custom_id", "")
        if not custom_id.startswith("roblox:"):
            return
        use_guild(interaction.guild)
        action = custom_id.split(":", 1)[1]
        try:
            if not feature_on(config, "roblox-verify"):
                return await self._reply(interaction, simple_view("## Verification is off", "This server turned Roblox verification off."))
            if action == "start":
                await self.start(interaction)
            elif action == "new":
                await interaction.response.send_modal(UsernameForm(self))
            elif action == "use":
                await interaction.response.defer(ephemeral=True, thinking=True)
                link = self.link_of(interaction.user.id)
                notes = await self.apply(interaction.user, link) if link else ["Your link is gone. Verify again."]
                await self._reply(interaction, simple_view("## ✅ All set", f"Using **{link['display'] if link else '?'}**.", *(["-# " + " ".join(notes)] if notes else [])))
            elif action == "check":
                await self.check(interaction)
            elif action == "cancel":
                self.pending.pop(interaction.user.id, None)
                await self._reply(interaction, simple_view("Verification cancelled."), edit=True)
        except Exception as e:
            print(f"[Roblox] {custom_id} failed: {e}")
            try:
                await self._reply(interaction, simple_view("## Something went wrong", str(e)[:300]))
            except discord.HTTPException:
                pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return
        use_guild(member.guild)
        if not feature_on(config, "roblox-verify") or not config.get("roblox_auto_verify", True):
            return
        link = self.link_of(member.id)
        if link:
            await self.apply(member, link)
            await self.log(member.guild, f"✅ {member.mention} joined and was verified as **{link['name']}** automatically.")

    # ── commands ──

    @app_commands.command(name="verify", description="Link your Roblox account")
    async def verify(self, interaction: discord.Interaction):
        await self.start(interaction)

    @app_commands.command(name="roblox-update", description="Refresh Roblox roles and nickname")
    @app_commands.describe(member="Someone else to update (staff only)")
    async def roblox_update(self, interaction: discord.Interaction, member: discord.Member | None = None):
        target = member or interaction.user
        if member and not interaction.user.guild_permissions.manage_roles:
            return await self._reply(interaction, simple_view("## Staff only", "You need Manage Roles to update someone else."))
        link = self.link_of(target.id)
        if not link:
            return await self._reply(interaction, simple_view("## Not linked", f"{target.mention} hasn't linked a Roblox account. Use /verify."))
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            fresh = await get_user(link["id"])
            if fresh:
                link.update(name=fresh.get("name", link["name"]), display=fresh.get("displayName") or link["display"])
                self._save()
        except RobloxError:
            pass
        notes = await self.apply(target, link)
        await self._reply(interaction, simple_view("## Updated", f"{target.mention} is **{link['display']}** (@{link['name']}).",
                                                   *(["-# " + " ".join(notes)] if notes else [])))

    @app_commands.command(name="roblox-unlink", description="Unlink your Roblox account")
    async def roblox_unlink(self, interaction: discord.Interaction):
        if not self.links.pop(str(interaction.user.id), None):
            return await self._reply(interaction, simple_view("## Not linked", "You don't have a Roblox account linked."))
        self._save()
        await self.unapply(interaction.user)
        await self._reply(interaction, simple_view("## Unlinked", "Your Roblox account isn't linked anymore. Use /verify to link one again."))

    @app_commands.command(name="roblox-whois", description="See someone's linked Roblox account")
    @app_commands.describe(member="Who to look up")
    async def roblox_whois(self, interaction: discord.Interaction, member: discord.Member):
        link = self.link_of(member.id)
        if not link:
            return await self._reply(interaction, simple_view("## Not linked", f"{member.mention} hasn't linked a Roblox account."))
        await interaction.response.defer(ephemeral=True, thinking=True)
        lines = [f"## {link['display']}", f"@{link['name']}\n[Open Roblox profile]({profile_url(link['id'])})"]
        group_id = config.get("roblox_group_id")
        if group_id and feature_on(config, "roblox-ranks"):
            try:
                rank = await get_group_rank(link["id"], group_id)
                lines.append(f"Group rank: **{rank['name']}** ({rank['rank']})" if rank else "Not in the group")
            except RobloxError:
                pass
        await self._reply(interaction, simple_view(*lines[:3]))

    @app_commands.command(name="roblox-profile", description="Look up any Roblox account")
    @app_commands.describe(username="Their Roblox username")
    async def roblox_profile(self, interaction: discord.Interaction, username: str):
        await interaction.response.defer(thinking=True)
        try:
            found = await find_user(username.strip())
            profile = await get_user(found["id"]) if found else None
            face = await get_headshot(found["id"]) if found else None
        except RobloxError as e:
            return await interaction.followup.send(view=simple_view("## Roblox didn't answer", str(e)))
        if not profile:
            return await interaction.followup.send(view=simple_view("## No Roblox account found", f"Nobody on Roblox is called **{username}**."))
        age = account_age_days(profile)
        linked = next((uid for uid, l in self.links.items() if l["id"] == profile["id"] and interaction.guild.get_member(int(uid))), None)
        about = " ".join(str(profile.get("description") or "").split())[:300]
        lines = [f"## {profile.get('displayName') or profile['name']}",
                 f"@{profile['name']}\nID {profile['id']}" + (f"\nAccount is {age:,} days old" if age is not None else "")
                 + (f"\nLinked to <@{linked}>" if linked else ""),
                 f"> {about}" if about else "-# No About text"]
        texts = [ui.TextDisplay(t) for t in lines]
        children = [ui.Section(*texts, accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=face)))] if face else texts
        children.append(ui.ActionRow(ui.Button(label="Open profile", url=profile_url(profile["id"]), style=discord.ButtonStyle.link)))
        view = ui.LayoutView()
        view.add_item(ui.Container(*children, accent_color=accent()))
        await interaction.followup.send(view=view, allowed_mentions=discord.AllowedMentions.none())

    # ── keeping everyone's roles up to date ──

    async def cog_load(self):
        self.auto_update.start()

    async def cog_unload(self):
        self.auto_update.cancel()

    @tasks.loop(minutes=30)
    async def auto_update(self):
        await self.auto_tick()

    @auto_update.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def auto_tick(self, at: float | None = None) -> list[int]:
        """Servers that turned on auto-update get everyone re-checked every few hours."""
        at, done = at or time.time(), []
        for guild in list(self.bot.guilds):
            use_guild(guild)
            hours = int(config.get("rbx_auto_update_hours", 0) or 0)
            if not hours or not feature_on(config, "roblox-verify"):
                continue
            last = self.auto_last.setdefault(guild.id, at)  # first check: start counting from now
            if at - last >= hours * 3600:
                self.auto_last[guild.id] = at
                await self.update_everyone(guild)
                done.append(guild.id)
        return done

    # ── for the dashboard ──

    def dashboard_info(self, guild) -> dict:
        linked = [m for m in guild.members if str(m.id) in self.links and not m.bot]
        return {
            "linked": len(linked),
            "recent": [
                {"id": str(m.id), "name": m.display_name, "avatar": m.display_avatar.url,
                 "roblox": self.links[str(m.id)]["name"], "roblox_id": str(self.links[str(m.id)]["id"]),
                 "at": self.links[str(m.id)].get("verified_at", 0)}
                for m in sorted(linked, key=lambda m: self.links[str(m.id)].get("verified_at", 0), reverse=True)[:20]
            ],
            "nicknames": NICKNAMES,
        }


async def setup(bot: commands.Bot):
    await bot.add_cog(Roblox(bot))
