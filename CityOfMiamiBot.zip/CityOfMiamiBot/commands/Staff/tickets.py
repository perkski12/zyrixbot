"""
Tickets, like Ticket Tool.

  • Panels: a message with a button per ticket type (or a dropdown). Made on the dashboard.
  • Clicking opens a private channel only the member and that type's staff roles can see,
    after an optional form with up to 5 questions.
  • In the ticket: Close / Claim buttons. Once closed: Save transcript / Reopen / Delete.
  • Deleting saves an HTML transcript to the log channel (and DMs it to the member).
  • Staff commands: /ticket-add, /ticket-remove, /ticket-close, /ticket-claim, /ticket-rename

Settings live in config.json (edited on the dashboard). Open tickets, panels and the
transcript list live in tickets.json; transcript files go in the transcripts/ folder.
"""

import asyncio
import html
import json
import os
import re
import time

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, simple_view, accent, fill, use_guild
from .figs import feature_on

DATA_FILE = "tickets.json"
TRANSCRIPT_DIR = "transcripts"
MEMBER_PERMS = dict(view_channel=True, send_messages=True, read_message_history=True, attach_files=True, embed_links=True)
PINGS = discord.AllowedMentions(everyone=False, users=True, roles=True)


# ──────────────────────────── settings helpers ──────────────────────────────

def ticket_types() -> list[dict]:
    return [t for t in config.get("ticket_types", []) if t.get("id")]


def get_type(type_id: str) -> dict | None:
    return next((t for t in ticket_types() if t["id"] == type_id), None)


def channel_name(fmt: str, number: int, user: discord.abc.User, ttype: dict) -> str:
    name = (fmt or "ticket-{number}").replace("{number}", f"{number:04d}")
    name = name.replace("{user}", user.name).replace("{type}", ttype.get("name", "ticket"))
    name = re.sub(r"[^a-z0-9_-]+", "-", name.lower()).strip("-")[:90]
    return name or f"ticket-{number:04d}"


def fill_ticket(text: str, guild, user, ttype: dict, number: int) -> str:
    text = fill(text or "", guild, user)
    return text.replace("{type}", ttype.get("name", "")).replace("{number}", f"{number:04d}")


# ──────────────────────────── message layouts ───────────────────────────────

def _container(*children) -> ui.Container:
    return ui.Container(*children, accent_color=accent())


def panel_view(panel: dict) -> ui.LayoutView:
    """The message members click to open a ticket."""
    types = [t for t in (get_type(i) for i in panel.get("type_ids", [])) if t]
    header = [ui.TextDisplay(f"## {fill(panel.get('title') or 'Open a ticket')}")]
    if panel.get("description"):
        header.append(ui.TextDisplay(fill(panel["description"])))

    thumb = config.get("thumbnail_url", "")
    children = []
    if thumb and str(thumb).startswith("http"):
        children.append(ui.Section(*header, accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=thumb))))
    else:
        children.extend(header)

    if types:
        children.append(ui.Separator())
        if panel.get("style") == "dropdown":
            options = [
                discord.SelectOption(
                    label=t["name"][:100], value=t["id"],
                    description=(t.get("description") or "")[:100] or None,
                    emoji=t.get("emoji") or None,
                )
                for t in types[:25]
            ]
            children.append(ui.ActionRow(ui.Select(custom_id="ticket:select", placeholder="Pick a ticket type", options=options)))
        else:
            for i in range(0, min(len(types), 25), 5):
                children.append(ui.ActionRow(*[
                    ui.Button(label=t["name"][:80], emoji=t.get("emoji") or None,
                              custom_id=f"ticket:open:{t['id']}", style=discord.ButtonStyle.secondary)
                    for t in types[i:i + 5]
                ]))
    else:
        children.append(ui.TextDisplay("-# No ticket types are picked for this panel yet."))

    view = ui.LayoutView()
    view.add_item(_container(*children))
    return view


def ticket_view(ticket: dict, ttype: dict, guild, opener, answers) -> ui.LayoutView:
    """First message in a new ticket."""
    pings = [opener.mention]
    if ttype.get("ping_support"):
        pings += [f"<@&{rid}>" for rid in ttype.get("support_role_ids", [])]

    number = ticket["number"]
    emoji = f"{ttype['emoji']} " if ttype.get("emoji") else ""
    children = [ui.TextDisplay(f"## {emoji}{ttype['name']} ticket")]
    welcome = fill_ticket(ttype.get("welcome_message", ""), guild, opener, ttype, number)
    if welcome.strip():
        children.append(ui.TextDisplay(welcome))
    if answers:
        children.append(ui.Separator())
        children.append(ui.TextDisplay("\n\n".join(f"**{q}**\n{a.strip() or '-# No answer'}" for q, a in answers)[:3900]))
    children.append(ui.Separator())
    buttons = [ui.Button(label="Close", emoji="🔒", custom_id="ticket:close", style=discord.ButtonStyle.danger)]
    if config.get("ticket_claim", True):
        buttons.append(ui.Button(label="Claim", emoji="🙋", custom_id="ticket:claim", style=discord.ButtonStyle.secondary))
    children.append(ui.ActionRow(*buttons))
    children.append(ui.TextDisplay(f"-# Ticket {number:04d}"))

    view = ui.LayoutView()
    view.add_item(ui.TextDisplay(" ".join(pings)))
    view.add_item(_container(*children))
    return view


def closed_view(by, reason: str | None = None) -> ui.LayoutView:
    lines = [ui.TextDisplay("## 🔒 Ticket closed"), ui.TextDisplay(f"Closed by {by.mention}" + (f"\n**Reason:** {reason}" if reason else ""))]
    view = ui.LayoutView()
    view.add_item(_container(
        *lines,
        ui.Separator(),
        ui.ActionRow(
            ui.Button(label="Save transcript", emoji="📄", custom_id="ticket:transcript", style=discord.ButtonStyle.secondary),
            ui.Button(label="Reopen", emoji="🔓", custom_id="ticket:reopen", style=discord.ButtonStyle.secondary),
            ui.Button(label="Delete", emoji="⛔", custom_id="ticket:delete", style=discord.ButtonStyle.danger),
        ),
        ui.TextDisplay("-# Only staff can use these."),
    ))
    return view


def confirm_close_view() -> ui.LayoutView:
    view = ui.LayoutView()
    view.add_item(_container(
        ui.TextDisplay("## Close this ticket?"),
        ui.TextDisplay("The member won't see the channel anymore. Staff can reopen it."),
        ui.ActionRow(
            ui.Button(label="Close ticket", emoji="🔒", custom_id="ticket:close-yes", style=discord.ButtonStyle.danger),
            ui.Button(label="Keep it open", custom_id="ticket:close-no", style=discord.ButtonStyle.secondary),
        ),
    ))
    return view


class TicketForm(ui.Modal):
    """The questions asked before a ticket opens."""

    def __init__(self, cog: "Tickets", ttype: dict):
        super().__init__(title=f"{ttype['name']} ticket"[:45], custom_id=f"ticket:form:{ttype['id']}")
        self.cog, self.ttype, self.fields = cog, ttype, []
        for q in ttype.get("questions", [])[:5]:
            box = ui.TextInput(
                label=q["label"][:45],
                style=discord.TextStyle.paragraph if q.get("long") else discord.TextStyle.short,
                required=bool(q.get("required", True)),
                max_length=1000 if q.get("long") else 200,
            )
            self.add_item(box)
            self.fields.append((q["label"], box))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        answers = [(label, str(box.value or "")) for label, box in self.fields]
        await self.cog.open_from_interaction(interaction, self.ttype, answers)


# ──────────────────────────── transcripts ───────────────────────────────────

def _message_text(m) -> str:
    """Everything readable in a message: text, embeds and Components V2 text."""
    parts = [m.content] if m.content else []
    for e in m.embeds:
        for piece in (e.title, e.description):
            if piece:
                parts.append(piece)
        for f in e.fields:
            parts.append(f"{f.name}\n{f.value}")

    def walk(c):
        content = getattr(c, "content", None)
        if isinstance(content, str) and content:
            parts.append(content)
        for child in getattr(c, "children", None) or []:
            walk(child)
        for child in getattr(c, "components", None) or []:
            walk(child)
        label = getattr(c, "label", None)
        if isinstance(label, str) and getattr(c, "custom_id", None):
            parts.append(f"[{label}]")
    for comp in getattr(m, "components", None) or []:
        walk(comp)
    return "\n".join(parts)


def _render_text(text: str, guild) -> str:
    out = html.escape(text)

    def user(mt):
        member = guild.get_member(int(mt.group(1)))
        return f'<span class="mention">@{html.escape(member.display_name) if member else "unknown"}</span>'

    def role(mt):
        r = guild.get_role(int(mt.group(1)))
        return f'<span class="mention">@{html.escape(r.name) if r else "deleted-role"}</span>'

    def chan(mt):
        c = guild.get_channel(int(mt.group(1)))
        return f'<span class="mention">#{html.escape(c.name) if c else "deleted-channel"}</span>'

    out = re.sub(r"&lt;@&amp;(\d+)&gt;", role, out)
    out = re.sub(r"&lt;@!?(\d+)&gt;", user, out)
    out = re.sub(r"&lt;#(\d+)&gt;", chan, out)
    out = re.sub(r"&lt;a?:(\w+):\d+&gt;", r":\1:", out)
    out = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", out)
    out = re.sub(r"^#{1,3} (.+)$", r"<b>\1</b>", out, flags=re.M)
    out = re.sub(r"^-# (.+)$", r'<small>\1</small>', out, flags=re.M)
    return out


TRANSCRIPT_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
:root {{ color-scheme: dark; }}
body {{ margin: 0; background: #000; color: #e9e9e9; font: 15px/1.5 "Helvetica Neue", Arial, sans-serif; }}
header {{ padding: 32px 24px 22px; border-bottom: 1px solid #262626; max-width: 900px; margin: 0 auto; }}
h1 {{ margin: 0 0 10px; font-size: 32px; letter-spacing: -0.02em; }}
.facts {{ display: flex; flex-wrap: wrap; gap: 6px 22px; color: #9a9a9a; font-size: 14px; }}
.facts b {{ color: #fff; }}
main {{ max-width: 900px; margin: 0 auto; padding: 10px 24px 60px; }}
.msg {{ display: grid; grid-template-columns: 40px 1fr; gap: 14px; padding: 12px 0; border-bottom: 1px solid #141414; }}
.av {{ width: 40px; height: 40px; border-radius: 50%; background: #222; filter: grayscale(1); }}
.head {{ display: flex; gap: 8px; align-items: baseline; flex-wrap: wrap; }}
.head b {{ color: #fff; }}
.bot {{ font-size: 10px; font-weight: 700; border: 1px solid #777; border-radius: 4px; padding: 0 4px; color: #ccc; }}
time {{ color: #777; font-size: 12px; }}
.body {{ white-space: pre-wrap; word-wrap: break-word; }}
.mention {{ background: #262626; border-radius: 4px; padding: 0 3px; }}
small {{ color: #8a8a8a; }}
.att {{ display: inline-block; margin-top: 6px; color: #fff; }}
.empty {{ color: #777; padding: 30px 0; }}
</style></head><body>
<header><h1>#{channel}</h1><div class="facts">{facts}</div></header>
<main>{rows}</main>
</body></html>
"""


def render_transcript(guild, channel_name_: str, ticket: dict, type_name: str, messages) -> str:
    rows = []
    for m in messages:
        text = _message_text(m)
        attachments = "".join(
            f'<div><a class="att" href="{html.escape(a.url)}">📎 {html.escape(a.filename)}</a></div>' for a in m.attachments
        )
        if not text and not attachments:
            continue
        avatar = html.escape(str(m.author.display_avatar.url))
        bot = '<span class="bot">BOT</span>' if m.author.bot else ""
        rows.append(
            f'<div class="msg"><img class="av" src="{avatar}" alt=""><div>'
            f'<div class="head"><b>{html.escape(m.author.display_name)}</b>{bot}'
            f'<time>{m.created_at.strftime("%Y-%m-%d %H:%M")} UTC</time></div>'
            f'<div class="body">{_render_text(text, guild)}</div>{attachments}</div></div>'
        )
    opener = guild.get_member(ticket["opener_id"])
    facts = [
        f"<span>Ticket <b>{ticket['number']:04d}</b></span>",
        f"<span>Type <b>{html.escape(type_name)}</b></span>",
        f"<span>Opened by <b>{html.escape(opener.display_name if opener else ticket.get('opener_name', 'unknown'))}</b></span>",
        f"<span>Opened <b>{time.strftime('%Y-%m-%d %H:%M', time.gmtime(ticket['created']))} UTC</b></span>",
        f"<span><b>{len(rows)}</b> messages</span>",
    ]
    return TRANSCRIPT_PAGE.format(
        title=html.escape(f"Transcript #{channel_name_}"), channel=html.escape(channel_name_),
        facts="".join(facts), rows="".join(rows) or '<p class="empty">No messages.</p>',
    )


# ──────────────────────────── the cog ───────────────────────────────────────

class Tickets(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.data = self._load()
        self.lock = asyncio.Lock()

    # ── storage ──

    @staticmethod
    def _load() -> dict:
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            data = {}
        data.setdefault("counters", {})
        data.setdefault("tickets", {})
        data.setdefault("panels", {})
        data.setdefault("transcripts", [])
        # Older saves were for one server: tag their transcripts with that server
        guilds = {t["guild_id"] for t in data["tickets"].values()} | {p.get("guild_id") for p in data["panels"].values()}
        guilds.discard(None)
        if len(guilds) == 1:
            only = next(iter(guilds))
            for t in data["transcripts"]:
                t.setdefault("guild_id", only)
            if "counter" in data:
                data["counters"].setdefault(str(only), data.pop("counter"))
        return data

    def next_number(self, guild_id: int) -> int:
        """Ticket numbers count up separately in every server."""
        key = str(guild_id)
        if key not in self.data["counters"]:
            used = [t["number"] for t in self.data["tickets"].values() if t["guild_id"] == guild_id]
            used += [t["number"] for t in self.data["transcripts"] if t.get("guild_id") == guild_id]
            self.data["counters"][key] = max(used, default=0)
        return self.data["counters"][key] + 1

    def save(self):
        tmp = DATA_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, DATA_FILE)

    # ── lookups ──

    def ticket(self, channel_id) -> dict | None:
        return self.data["tickets"].get(str(channel_id))

    def open_tickets_of(self, guild, user_id: int) -> list[int]:
        return [
            int(cid) for cid, t in self.data["tickets"].items()
            if t["opener_id"] == user_id and t["status"] == "open" and t["guild_id"] == guild.id and guild.get_channel(int(cid))
        ]

    def is_staff(self, member, ticket: dict | None) -> bool:
        perms = member.guild_permissions
        if perms.administrator or perms.manage_channels:
            return True
        ttype = get_type(ticket["type_id"]) if ticket else None
        roles = set(ttype.get("support_role_ids", [])) if ttype else set()
        if not ttype:  # type was deleted: any staff role of any type counts
            for t in ticket_types():
                roles.update(t.get("support_role_ids", []))
        return any(r.id in roles for r in member.roles)

    def find_transcript(self, tid: str, guild_id: int | None = None) -> dict | None:
        return next((t for t in self.data["transcripts"]
                     if t["id"] == tid and (guild_id is None or t.get("guild_id") == guild_id)), None)

    async def log(self, guild, *lines: str, file_path: str | None = None, file_name: str | None = None):
        channel = guild.get_channel(config.get("ticket_log_channel_id") or 0) or guild.get_channel(config.get("log_channel_id") or 0)
        if channel is None:
            return
        try:
            await channel.send(view=simple_view(*lines[:3]), allowed_mentions=discord.AllowedMentions.none())
            if file_path:
                await channel.send(f"📄 Transcript: `{file_name}`", file=discord.File(file_path, filename=file_name))
        except (discord.HTTPException, OSError):
            pass

    # ── opening ──

    async def open_from_interaction(self, interaction: discord.Interaction, ttype: dict, answers=()):
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=True, thinking=True)
        channel, error = await self.open_ticket(interaction.guild, interaction.user, ttype, answers)
        if error:
            await interaction.followup.send(view=simple_view("## Couldn't open a ticket", error), ephemeral=True)
        else:
            await interaction.followup.send(view=simple_view("## Ticket opened", f"Here it is: {channel.mention}"), ephemeral=True)

    async def open_ticket(self, guild, user, ttype: dict, answers=()):
        """Make the ticket channel. Returns (channel, None) or (None, error message)."""
        async with self.lock:  # so a double click can't open two tickets
            limit = int(config.get("ticket_max_open", 1) or 0)
            mine = self.open_tickets_of(guild, user.id)
            if limit and len(mine) >= limit:
                return None, f"You already have an open ticket: <#{mine[0]}>" if limit == 1 else f"You already have {len(mine)} open tickets. Close one first."

            number = self.next_number(guild.id)
            category = guild.get_channel(ttype.get("category_id") or 0)
            if category is not None and category.type != discord.ChannelType.category:
                category = None

            overwrites = {
                guild.default_role: discord.PermissionOverwrite(view_channel=False),
                guild.me: discord.PermissionOverwrite(**MEMBER_PERMS),
                user: discord.PermissionOverwrite(**MEMBER_PERMS),
            }
            for rid in ttype.get("support_role_ids", []):
                role = guild.get_role(rid)
                if role is not None:
                    overwrites[role] = discord.PermissionOverwrite(**MEMBER_PERMS)

            try:
                channel = await guild.create_text_channel(
                    channel_name(ttype.get("name_format"), number, user, ttype),
                    category=category, overwrites=overwrites,
                    topic=f"Ticket {number:04d} ({ttype['name']}) opened by {user} ({user.id})",
                    reason=f"Ticket opened by {user}",
                )
            except discord.Forbidden:
                return None, "I'm not allowed to make channels here. Give my role **Manage Channels** and **Manage Roles**."
            except discord.HTTPException as e:
                return None, f"Discord wouldn't make the ticket channel: {getattr(e, 'text', '') or e}"

            ticket = {
                "number": number, "guild_id": guild.id, "type_id": ttype["id"], "opener_id": user.id,
                "opener_name": str(user), "status": "open", "created": int(time.time()),
                "claimed_by": None, "closed_by": None, "added": [],
                "answers": [[q, a] for q, a in answers],
            }
            self.data["counters"][str(guild.id)] = number
            self.data["tickets"][str(channel.id)] = ticket
            self.save()

        try:
            await channel.send(view=ticket_view(ticket, ttype, guild, user, answers), allowed_mentions=PINGS)
        except discord.HTTPException:
            pass
        await self.log(guild, "## 🎫 Ticket opened", f"{channel.mention} ({ttype['name']}) opened by {user.mention}")
        self.bot.dispatch("ticket_opened", channel, ticket)  # ticket_extras.py: support hours
        return channel, None

    # ── closing, reopening, claiming, deleting ──

    async def _set_member_access(self, channel, ticket: dict, allow: bool):
        for uid in [ticket["opener_id"], *ticket.get("added", [])]:
            member = channel.guild.get_member(uid)
            if member is None:
                continue
            try:
                if allow:
                    await channel.set_permissions(member, **MEMBER_PERMS)
                else:
                    await channel.set_permissions(member, view_channel=False, send_messages=False)
            except discord.HTTPException:
                pass

    async def close_ticket(self, channel, by, reason: str | None = None) -> str | None:
        ticket = self.ticket(channel.id)
        if ticket is None:
            return "This isn't a ticket channel."
        if ticket["status"] == "closed":
            return "This ticket is already closed."
        await self._set_member_access(channel, ticket, allow=False)
        ticket.update(status="closed", closed_by=by.id, closed_at=int(time.time()), reason=reason)
        self.save()
        try:
            await channel.send(view=closed_view(by, reason), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass
        await self.log(channel.guild, "## 🔒 Ticket closed", f"{channel.mention} closed by {by.mention}" + (f"\n**Reason:** {reason}" if reason else ""))
        self.bot.dispatch("ticket_closed", channel, ticket, by)  # ticket_extras.py: ratings
        return None

    async def reopen_ticket(self, channel, by) -> str | None:
        ticket = self.ticket(channel.id)
        if ticket is None:
            return "This isn't a ticket channel."
        if ticket["status"] == "open":
            return "This ticket is already open."
        await self._set_member_access(channel, ticket, allow=True)
        ticket.update(status="open", closed_by=None, closed_at=None, reason=None)
        self.save()
        try:
            await channel.send(view=simple_view("## 🔓 Ticket reopened", f"Reopened by {by.mention}"), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass
        await self.log(channel.guild, "## 🔓 Ticket reopened", f"{channel.mention} reopened by {by.mention}")
        return None

    async def claim_ticket(self, channel, by) -> str | None:
        ticket = self.ticket(channel.id)
        if ticket is None:
            return "This isn't a ticket channel."
        if ticket.get("claimed_by") == by.id:
            return "You already claimed this ticket."
        if ticket.get("claimed_by"):
            return f"<@{ticket['claimed_by']}> already claimed this ticket."
        ticket["claimed_by"] = by.id
        self.save()
        try:
            await channel.send(view=simple_view("## 🙋 Ticket claimed", f"{by.mention} will help you with this ticket."), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass
        await self.log(channel.guild, "## 🙋 Ticket claimed", f"{channel.mention} claimed by {by.mention}")
        return None

    async def make_transcript(self, channel, ticket: dict, by=None) -> dict:
        """Save the channel's messages as an HTML page. Returns its record."""
        messages = [m async for m in channel.history(limit=5000, oldest_first=True)]
        ttype = get_type(ticket["type_id"])
        type_name = ttype["name"] if ttype else "Deleted type"
        page = render_transcript(channel.guild, channel.name, ticket, type_name, messages)

        os.makedirs(TRANSCRIPT_DIR, exist_ok=True)
        tid = f"{ticket['number']:04d}-{int(time.time())}"
        safe = re.sub(r"[^a-z0-9_-]", "", channel.name.lower()) or "ticket"
        file_name = f"{safe}-{tid}.html"
        with open(os.path.join(TRANSCRIPT_DIR, file_name), "w", encoding="utf-8") as f:
            f.write(page)

        record = {
            "id": tid, "guild_id": channel.guild.id, "file": file_name, "number": ticket["number"], "channel": channel.name,
            "type": type_name, "opener_id": ticket["opener_id"], "opener_name": ticket.get("opener_name", ""),
            "saved_by": str(by) if by else None, "created": ticket["created"], "saved": int(time.time()),
            "messages": page.count('class="msg"'),
        }
        self.data["transcripts"].append(record)
        self.data["transcripts"] = self.data["transcripts"][-1000:]
        self.save()
        return record

    async def save_transcript(self, channel, by) -> tuple[dict | None, str | None]:
        ticket = self.ticket(channel.id)
        if ticket is None:
            return None, "This isn't a ticket channel."
        record = await self.make_transcript(channel, ticket, by)
        path = os.path.join(TRANSCRIPT_DIR, record["file"])
        try:
            await channel.send(f"📄 Transcript saved by {by.mention}", file=discord.File(path, filename=record["file"]),
                               allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass
        await self.log(channel.guild, "## 📄 Transcript saved", f"{channel.mention} by {by.mention}", file_path=path, file_name=record["file"])
        return record, None

    async def delete_ticket(self, channel, by, delay: int = 5) -> str | None:
        ticket = self.ticket(channel.id)
        if ticket is None:
            return "This isn't a ticket channel."
        record = None
        try:
            record = await self.make_transcript(channel, ticket, by)
        except (discord.HTTPException, OSError) as e:
            print(f"[Tickets] Couldn't save a transcript for #{channel.name}: {e}")

        path = os.path.join(TRANSCRIPT_DIR, record["file"]) if record else None
        await self.log(channel.guild, "## ⛔ Ticket deleted", f"#{channel.name} deleted by {by.mention}", file_path=path,
                       file_name=record["file"] if record else None)

        if record and config.get("ticket_dm_transcript", True):
            opener = channel.guild.get_member(ticket["opener_id"])
            if opener is not None:
                try:
                    server = config.get("server_name") or channel.guild.name
                    await opener.send(f"Your ticket in **{server}** was closed. Here's a copy of the conversation.",
                                      file=discord.File(path, filename=record["file"]))
                except (discord.HTTPException, OSError):
                    pass

        if delay:
            try:
                await channel.send(view=simple_view("## ⛔ Deleting ticket", f"This channel will be deleted in {delay} seconds."))
            except discord.HTTPException:
                pass
            await asyncio.sleep(delay)

        self.data["tickets"].pop(str(channel.id), None)
        self.save()
        try:
            await channel.delete(reason=f"Ticket deleted by {by}")
        except discord.HTTPException as e:
            return f"Saved the transcript, but Discord wouldn't delete the channel: {e}"
        return None

    # ── panels (made on the dashboard) ──

    async def post_panel(self, channel, panel: dict) -> dict:
        message = await channel.send(view=panel_view(panel), allowed_mentions=discord.AllowedMentions.none())
        record = {**panel, "channel_id": channel.id, "guild_id": channel.guild.id, "created": int(time.time())}
        self.data["panels"][str(message.id)] = record
        self.save()
        return record

    async def refresh_panel(self, message_id: str) -> bool:
        panel = self.data["panels"].get(str(message_id))
        channel = self.bot.get_channel(panel["channel_id"]) if panel else None
        if channel is None:
            return False
        use_guild(channel.guild)
        try:
            await channel.get_partial_message(int(message_id)).edit(view=panel_view(panel))
            return True
        except discord.NotFound:
            self.data["panels"].pop(str(message_id), None)
            self.save()
            return False
        except discord.HTTPException:
            return False

    async def refresh_all_panels(self, guild_id: int):
        """Redraw one server's panels (after its ticket types change)."""
        for mid, panel in list(self.data["panels"].items()):
            if panel.get("guild_id") == guild_id:
                await self.refresh_panel(mid)

    async def delete_panel(self, message_id: str):
        panel = self.data["panels"].pop(str(message_id), None)
        self.save()
        channel = self.bot.get_channel(panel["channel_id"]) if panel else None
        if channel is not None:
            try:
                await channel.get_partial_message(int(message_id)).delete()
            except discord.HTTPException:
                pass

    # ── buttons, dropdowns ──

    async def _reply(self, interaction: discord.Interaction, *lines: str):
        view = simple_view(*lines)
        if interaction.response.is_done():
            await interaction.followup.send(view=view, ephemeral=True)
        else:
            await interaction.response.send_message(view=view, ephemeral=True)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component or interaction.guild is None:
            return
        data = interaction.data or {}
        custom_id = data.get("custom_id", "")
        if not custom_id.startswith("ticket:"):
            return
        use_guild(interaction.guild)
        action = custom_id.split(":")[1]
        try:
            await self._handle(interaction, action, custom_id, data)
        except Exception as e:
            print(f"[Tickets] {custom_id} failed: {e}")
            try:
                await self._reply(interaction, "## Something went wrong", str(e)[:300])
            except discord.HTTPException:
                pass

    async def _handle(self, interaction, action: str, custom_id: str, data: dict):
        channel, user = interaction.channel, interaction.user

        if action in ("open", "select"):
            type_id = custom_id.split(":", 2)[2] if action == "open" else (data.get("values") or [""])[0]
            ttype = get_type(type_id)
            if ttype is None or not feature_on(config, "tickets"):
                return await self._reply(interaction, "## Ticket type removed", "This kind of ticket isn't available anymore.")
            limit = int(config.get("ticket_max_open", 1) or 0)
            mine = self.open_tickets_of(interaction.guild, user.id)
            if limit and len(mine) >= limit:
                return await self._reply(interaction, "## You already have a ticket", f"Here it is: <#{mine[0]}>")
            if ttype.get("questions"):
                return await interaction.response.send_modal(TicketForm(self, ttype))
            return await self.open_from_interaction(interaction, ttype)

        ticket = self.ticket(channel.id)
        if ticket is None:
            return await self._reply(interaction, "## Not a ticket", "This channel isn't a ticket anymore.")
        staff = self.is_staff(user, ticket)

        if action == "close":
            if not (staff or user.id == ticket["opener_id"]):
                return await self._reply(interaction, "## Not allowed", "Only staff or the person who opened this ticket can close it.")
            return await interaction.response.send_message(view=confirm_close_view(), ephemeral=True)

        if action == "close-no":
            return await interaction.response.edit_message(view=simple_view("The ticket stays open."))

        if action == "close-yes":
            if not (staff or user.id == ticket["opener_id"]):
                return await self._reply(interaction, "## Not allowed", "Only staff or the person who opened this ticket can close it.")
            await interaction.response.edit_message(view=simple_view("Closing the ticket…"))
            error = await self.close_ticket(channel, user)
            if error:
                await self._reply(interaction, "## Couldn't close it", error)
            return

        if not staff:
            return await self._reply(interaction, "## Staff only", "Only staff can do that.")

        if action == "claim":
            error = await self.claim_ticket(channel, user)
            if error:
                return await self._reply(interaction, "## Couldn't claim it", error)
            return await self._reply(interaction, "## Claimed", "You're handling this ticket now.")

        if action == "reopen":
            await interaction.response.defer(ephemeral=True)
            error = await self.reopen_ticket(channel, user)
            return await self._reply(interaction, *(("## Couldn't reopen it", error) if error else ("## Reopened",)))

        if action == "transcript":
            await interaction.response.defer(ephemeral=True, thinking=True)
            _, error = await self.save_transcript(channel, user)
            return await self._reply(interaction, *(("## Couldn't save it", error) if error else ("## Transcript saved",)))

        if action == "delete":
            await interaction.response.defer(ephemeral=True)
            error = await self.delete_ticket(channel, user)
            if error:
                await self._reply(interaction, "## Couldn't delete it", error)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        if self.data["tickets"].pop(str(channel.id), None) is not None:
            self.save()

    # ── staff commands ──

    async def _ticket_here(self, interaction: discord.Interaction, staff_only: bool = True):
        ticket = self.ticket(interaction.channel.id)
        if ticket is None:
            await self._reply(interaction, "## Not a ticket", "Use this inside a ticket channel.")
            return None
        if staff_only and not self.is_staff(interaction.user, ticket):
            await self._reply(interaction, "## Staff only", "Only staff can do that.")
            return None
        return ticket

    @app_commands.command(name="ticket-add", description="Add someone to this ticket")
    @app_commands.describe(user="Who to add")
    async def ticket_add(self, interaction: discord.Interaction, user: discord.Member):
        ticket = await self._ticket_here(interaction)
        if ticket is None:
            return
        try:
            await interaction.channel.set_permissions(user, **MEMBER_PERMS)
        except discord.HTTPException:
            return await self._reply(interaction, "## Couldn't add them", "Give my role **Manage Roles** so I can change channel permissions.")
        if user.id not in ticket["added"] and user.id != ticket["opener_id"]:
            ticket["added"].append(user.id)
            self.save()
        await interaction.response.send_message(view=simple_view(f"➕ Added {user.mention} to this ticket."))

    @app_commands.command(name="ticket-remove", description="Remove someone from this ticket")
    @app_commands.describe(user="Who to remove")
    async def ticket_remove(self, interaction: discord.Interaction, user: discord.Member):
        ticket = await self._ticket_here(interaction)
        if ticket is None:
            return
        if user.id == ticket["opener_id"]:
            return await self._reply(interaction, "## Can't remove them", "That's who opened the ticket. Close it instead.")
        try:
            await interaction.channel.set_permissions(user, overwrite=None)
        except discord.HTTPException:
            return await self._reply(interaction, "## Couldn't remove them", "Give my role **Manage Roles** so I can change channel permissions.")
        if user.id in ticket["added"]:
            ticket["added"].remove(user.id)
            self.save()
        await interaction.response.send_message(view=simple_view(f"➖ Removed {user.mention} from this ticket."))

    @app_commands.command(name="ticket-close", description="Close this ticket")
    @app_commands.describe(reason="Why it's being closed (optional)")
    async def ticket_close(self, interaction: discord.Interaction, reason: str | None = None):
        ticket = await self._ticket_here(interaction, staff_only=False)
        if ticket is None:
            return
        if not (self.is_staff(interaction.user, ticket) or interaction.user.id == ticket["opener_id"]):
            return await self._reply(interaction, "## Not allowed", "Only staff or the person who opened this ticket can close it.")
        await interaction.response.defer(ephemeral=True)
        error = await self.close_ticket(interaction.channel, interaction.user, reason)
        await self._reply(interaction, *(("## Couldn't close it", error) if error else ("## Ticket closed",)))

    @app_commands.command(name="ticket-claim", description="Claim this ticket so members know you're handling it")
    async def ticket_claim(self, interaction: discord.Interaction):
        if await self._ticket_here(interaction) is None:
            return
        error = await self.claim_ticket(interaction.channel, interaction.user)
        await self._reply(interaction, *(("## Couldn't claim it", error) if error else ("## Claimed", "You're handling this ticket now.")))

    @app_commands.command(name="ticket-rename", description="Rename this ticket channel")
    @app_commands.describe(name="The new channel name")
    async def ticket_rename(self, interaction: discord.Interaction, name: str):
        if await self._ticket_here(interaction) is None:
            return
        new = re.sub(r"[^a-z0-9_-]+", "-", name.lower()).strip("-")[:90]
        if not new:
            return await self._reply(interaction, "## That name won't work", "Use letters, numbers and dashes.")
        await interaction.response.defer(ephemeral=True)
        try:
            await asyncio.wait_for(interaction.channel.edit(name=new), timeout=10)
        except asyncio.TimeoutError:
            return await self._reply(interaction, "## Slow down", "Discord only allows 2 renames every 10 minutes. Try again later.")
        except discord.HTTPException as e:
            return await self._reply(interaction, "## Couldn't rename it", str(e)[:200])
        await self._reply(interaction, "## Renamed", f"This ticket is now #{new}.")

    # ── for the dashboard ──

    def dashboard_info(self, guild) -> dict:
        def person(uid):
            if not uid:
                return None
            m = guild.get_member(int(uid))
            return {"id": str(uid), "name": m.display_name if m else "Left the server",
                    "avatar": m.display_avatar.url if m else None}

        tickets = []
        for cid, t in self.data["tickets"].items():
            if t["guild_id"] != guild.id:
                continue
            ch = guild.get_channel(int(cid))
            ttype = get_type(t["type_id"])
            tickets.append({
                "id": cid, "name": ch.name if ch else f"ticket-{t['number']:04d}", "number": t["number"],
                "type": ttype["name"] if ttype else "Deleted type", "status": t["status"],
                "opener": person(t["opener_id"]) or {"name": t.get("opener_name", "")},
                "claimed_by": person(t.get("claimed_by")), "created": t["created"],
                "answers": t.get("answers", []),
                "url": f"https://discord.com/channels/{guild.id}/{cid}",
            })
        tickets.sort(key=lambda x: (x["status"] != "open", -x["created"]))

        panels = []
        for mid, p in self.data["panels"].items():
            if p.get("guild_id") != guild.id:
                continue
            ch = guild.get_channel(p["channel_id"])
            panels.append({
                "id": mid, "title": p.get("title", ""), "description": p.get("description", ""),
                "style": p.get("style", "buttons"), "type_ids": p.get("type_ids", []),
                "channel_id": str(p["channel_id"]), "channel": ch.name if ch else None,
                "url": f"https://discord.com/channels/{guild.id}/{p['channel_id']}/{mid}",
            })
        panels.sort(key=lambda p: int(p["id"]), reverse=True)

        transcripts = [
            {k: (str(v) if k in ("opener_id", "guild_id") else v) for k, v in t.items() if k != "file"}
            for t in reversed(self.data["transcripts"]) if t.get("guild_id") == guild.id
        ][:200]
        return {"tickets": tickets, "panels": panels, "transcripts": transcripts,
                "count": self.data["counters"].get(str(guild.id), 0)}


async def setup(bot: commands.Bot):
    await bot.add_cog(Tickets(bot))
