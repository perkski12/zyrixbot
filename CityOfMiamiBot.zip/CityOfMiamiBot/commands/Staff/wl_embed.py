"""
Shared settings + helpers for every command file.

Every server the bot is in has its own settings, saved in data/guilds/<server id>.json.

How the code picks the right server's settings:
  • Each entry point (a slash command, a button, an event like a new message, a dashboard
    request) calls use_guild(guild) first.
  • After that, `config` (imported below) IS that server's settings: config.get(...),
    config["x"] = y and save_config() all act on that server only.
  • If code forgets to call use_guild, using `config` raises an error instead of quietly
    touching another server's settings.
"""

import contextlib
import contextvars
import json
import os

import discord
from discord import ui

DATA_DIR = os.path.join("data", "guilds")
LEGACY_FILE = "config.json"  # the old single-server settings file (moved over automatically)

DEFAULT_FILTER_MESSAGE = "**{user} watch your language, that word isn't allowed here.**"
DEFAULT_HONEYPOT_MESSAGE = (
    "You were caught by the honeypot in **{server}**. "
    "That channel is a trap for spam bots and hacked accounts."
)

# Every setting, with the value a new server starts with.
DEFAULTS = {
    # Figs turned on for this server (see figs.py)
    "figs": [],

    # Branding (server_name empty = use the Discord server's name)
    "server_name": "",
    "accent_color": "#ffffff",
    "settings_version": 2,  # 2: the default accent color became white (was pink #e91e63)
    "city_emoji": "⭐",
    "thumbnail_url": "",
    "banner_url": "",
    "support_url": "",
    "website_url": "",
    "log_channel_id": None,

    # Whitelist
    "wl_enabled": True,
    "whitelist_channel_id": None,
    "whitelist_role_id": None,
    "unverified_role_id": None,
    "wl_panel_title": "WL System",
    "wl_panel_subtitle": "Get verified to access the server!",
    "wl_panel_sections": [
        "**To get whitelisted:**\n"
        "• Type `wl` to get whitelisted\n"
        "• Example: `wl`",
        "**To vouch someone:**\n"
        "• Type `vouch` and mention the user\n"
        "• **Requirement:** You must already be whitelisted to vouch others\n"
        "• Example: `vouch @user`",
        "**After verification:**\n"
        "• Access to all channels\n"
        "• Ability to participate in events\n"
        "• Join us in-game!",
    ],
    "wl_panel_footer": "Support Server | Website",

    # Welcome
    "welcome_enabled": True,
    "welcome_channel_id": None,
    "welcome_title": "Welcome To {server}",
    "welcome_message": "Welcome here {user}, make sure to read these below so you're ready to jump in!",
    "welcome_links": [],
    "welcome_footer": "Once read, have fun with us!",

    # Priority roles  {name: role_id}
    "priority_roles": {},

    # Word filter
    "filtered_words": [],
    "allowed_words": [],
    "filter_whitelist_users": [],
    "filter_message": DEFAULT_FILTER_MESSAGE,

    # Honeypot
    "honeypot_channel_id": None,
    "honeypot_log_channel_id": None,
    "honeypot_action": "softban",
    "honeypot_message": DEFAULT_HONEYPOT_MESSAGE,
    "honeypot_catches": 0,

    # 👍/👎 channels
    "react_channel_ids": [],

    # /verify-female defaults (used when the command options are left empty)
    "female_role_id": None,
    "female_log_channel_id": None,

    # Commands turned off on the dashboard
    "disabled_commands": [],

    # Who besides the owner / Administrator / Manage Server can open this server's dashboard
    "dashboard_role_ids": [],
    "dashboard_user_ids": [],

    # Tickets
    "ticket_log_channel_id": None,
    "ticket_max_open": 1,
    "ticket_claim": True,
    "ticket_dm_transcript": True,
    "ticket_types": [
        {
            "id": "support",
            "name": "Support",
            "emoji": "🎫",
            "description": "Questions or problems? Talk to staff.",
            "category_id": None,
            "support_role_ids": [],
            "ping_support": True,
            "name_format": "ticket-{number}",
            "welcome_message": (
                "Hey {user}, thanks for opening a ticket!\n"
                "Tell us what you need and staff will be with you soon."
            ),
            "questions": [],
        },
    ],

    # Roblox verification
    "roblox_verified_role_id": None,
    "roblox_unverified_role_id": None,
    "roblox_nickname": "{display}",
    "roblox_auto_verify": True,
    "roblox_log_channel_id": None,
    "roblox_panel_title": "Verify with Roblox",
    "roblox_panel_text": "Link your Roblox account to get access to the server. It takes about a minute.",

    # Roblox group ranks
    "roblox_group_id": None,
    "roblox_group_member_role_id": None,
    "roblox_rank_roles": [],

    # Roblox extras: who may verify, badge / game pass roles, game, sessions
    "rbx_min_age_days": 0,
    "rbx_blacklist_groups": [],
    "rbx_auto_update_hours": 0,
    "rbx_badge_roles": [],       # [{badge_id, role_id, name}]
    "rbx_pass_roles": [],        # [{pass_id, role_id, name}]
    "rbx_place_id": None,
    "rbx_stats_channel_id": None,
    "rbx_shout_channel_id": None,
    "sess_channel_id": None,
    "sess_ping_role_id": None,
    "sess_host_role_ids": [],
    "sess_link": "",
    "sess_types": [
        {"name": "Training", "emoji": "🎯"},
        {"name": "Shift", "emoji": "🕒"},
        {"name": "Event", "emoji": "🎉"},
    ],

    # Welcome extras
    "join_role_ids": [],
    "join_bot_role_ids": [],
    "welcome_dm": "",
    "goodbye_enabled": False,
    "goodbye_channel_id": None,
    "goodbye_message": "**{username}** left the server. We're now {member_count} members.",

    # Auto-mod
    "am_invites": True,
    "am_links": False,
    "am_allowed_links": ["youtube.com", "youtu.be", "tenor.com", "giphy.com", "roblox.com"],
    "am_spam": True,
    "am_spam_count": 6,
    "am_spam_seconds": 5,
    "am_mentions": 6,
    "am_caps": False,
    "am_action": "delete",
    "am_warn": False,
    "am_ignored_role_ids": [],
    "am_ignored_channel_ids": [],
    "am_log_channel_id": None,

    # Moderation
    "mod_log_channel_id": None,
    "mod_dm": True,
    "mod_warn_timeout": 3,
    "mod_timeout_minutes": 60,
    "mod_warn_kick": 0,
    "mod_warn_ban": 0,

    # Prefix commands (,ban @someone ...): every slash command works with the prefix too
    "prefix": ",",
    "prefix_enabled": True,

    # Utility
    "util_snipe": True,
    "util_afk": True,
    "util_afk_nick": True,

    # Server logs
    "logs_channel_id": None,
    "logs_message_channel_id": None,
    "logs_events": ["message_delete", "message_edit", "member_join", "member_leave", "member_roles",
                    "member_nick", "member_ban", "member_unban", "channels"],
    "logs_ignored_channel_ids": [],

    # Leveling
    "lvl_enabled": True,
    "lvl_xp_min": 15,
    "lvl_xp_max": 25,
    "lvl_cooldown": 60,
    "lvl_announce": "channel",
    "lvl_channel_id": None,
    "lvl_message": "GG {user}, you just reached **level {level}**!",
    "lvl_roles": [],             # [{level, role_id}]
    "lvl_stack": True,
    "lvl_no_xp_channel_ids": [],
    "lvl_no_xp_role_ids": [],

    # Suggestions
    "sug_channel_id": None,
    "sug_anonymous": False,
    "sug_staff_role_ids": [],
    "sug_dm_result": True,

    # Starboard
    "star_channel_id": None,
    "star_emoji": "⭐",
    "star_threshold": 3,
    "star_self": False,
    "star_ignored_channel_ids": [],

    # Birthdays
    "bday_channel_id": None,
    "bday_role_id": None,
    "bday_message": "Happy birthday {user}! 🎂 Have an amazing day!",
    "bday_hour": 14,

    # Auto-responses  [{trigger, match, response, reply, channel_ids}]
    "ar_rules": [],
    "ar_cooldown": 10,

    # Timed messages  [{id, name, channel_id, title, text, every_hours, ping_role_id, enabled}]
    "ann_messages": [],

    # Join-to-create voice channels
    "tv_hub_channel_id": None,
    "tv_category_id": None,
    "tv_name": "{user}'s channel",
    "tv_limit": 0,

    # Channel tools
    "sticky_messages": [],       # [{channel_id, text}]
    "stat_channels": [],         # [{channel_id, template}]
    "count_channel_id": None,
    "count_reset_on_fail": True,

    # Ticket extras
    "ticket_autoclose_hours": 0,
    "ticket_rating": False,
    "ticket_snippets": [],       # [{name, text}]
    "ticket_hours_on": False,
    "ticket_hours_start": 9,
    "ticket_hours_end": 21,
    "ticket_utc_offset": 0,
    "ticket_offline_message": "We're outside our support hours right now, so replies may take a little longer. We'll get back to you as soon as we can.",
    "ticket_dm_open": False,

    # Applications
    "app_forms": [],
    "app_panel_title": "Applications",
    "app_panel_text": "Pick what you'd like to apply for. You'll answer a few questions, then staff will get back to you.",

    # FAQ
    "faq_entries": [],           # [{question, answer, emoji}]
    "faq_title": "Frequently asked questions",
    "faq_text": "Pick a question to see the answer. Only you can see it.",

    # Status page
    "status_channel_id": None,
    "status_components": [],     # [{name, state}]
    "status_note": "",

    # Reviews
    "rev_channel_id": None,
    "rev_role_id": None,
}


def _fresh(value):
    return json.loads(json.dumps(value))  # deep copy so lists/dicts are never shared


class GuildConfig(dict):
    """One server's settings. save() writes them to data/guilds/<id>.json."""

    def __init__(self, guild_id: int, data: dict):
        super().__init__(data)
        self.guild_id = guild_id
        upgraded = self.upgrade()
        for key, value in DEFAULTS.items():
            self.setdefault(key, _fresh(value))
        if upgraded:
            try:
                self.save()
            except OSError:
                pass

    def upgrade(self) -> bool:
        """Bring settings saved by an older version up to date. True when something changed."""
        if self.get("settings_version", 1) >= 2:
            return False
        # The old default accent was pink. Servers still on it switch to the new default, white;
        # a color someone picked themselves stays.
        if str(self.get("accent_color") or "").lower() == "#e91e63":
            self["accent_color"] = "#ffffff"
        self["settings_version"] = 2
        return True

    @property
    def path(self) -> str:
        return os.path.join(DATA_DIR, f"{self.guild_id}.json")

    def save(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(dict(self), f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.path)


_cache: dict[int, GuildConfig] = {}
_current: contextvars.ContextVar = contextvars.ContextVar("current_guild_config", default=None)


def _guild_id(guild) -> int:
    return int(getattr(guild, "id", guild))


def get_config(guild) -> GuildConfig:
    """A server's settings (a guild, or its ID), loaded from disk the first time."""
    gid = _guild_id(guild)
    conf = _cache.get(gid)
    if conf is None:
        data = {}
        path = os.path.join(DATA_DIR, f"{gid}.json")
        try:
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                data = loaded if isinstance(loaded, dict) else {}
        except FileNotFoundError:
            pass
        except json.JSONDecodeError as e:
            print(f"[Config] {path} is broken ({e}), starting that server with default settings.")
        conf = _cache[gid] = GuildConfig(gid, data)
    return conf


def use_guild(guild) -> GuildConfig | None:
    """Make `config` mean this server's settings for the rest of this command / event."""
    if guild is None:
        _current.set(None)
        return None
    conf = get_config(guild)
    _current.set(conf)
    return conf


@contextlib.contextmanager
def guild_context(guild):
    """Use a server's settings inside a `with` block, then go back to what was there before."""
    token = _current.set(get_config(guild) if guild is not None else None)
    try:
        yield
    finally:
        _current.reset(token)


def current_config() -> GuildConfig:
    conf = _current.get()
    if conf is None:
        raise RuntimeError("No server picked for this settings lookup (use_guild was not called).")
    return conf


class _ConfigProxy:
    """Stands in for the current server's settings (see the note at the top)."""

    def __getattr__(self, name):
        return getattr(current_config(), name)

    def __getitem__(self, key):
        return current_config()[key]

    def __setitem__(self, key, value):
        current_config()[key] = value

    def __contains__(self, key):
        return key in current_config()

    def __iter__(self):
        return iter(current_config())

    def __len__(self):
        return len(current_config())

    def __repr__(self):
        conf = _current.get()
        return f"<settings for {conf.guild_id}>" if conf else "<settings: no server picked>"


config = _ConfigProxy()


def save_config():
    """Save the current server's settings."""
    current_config().save()


def known_guild_ids() -> list[int]:
    if not os.path.isdir(DATA_DIR):
        return []
    return [int(f[:-5]) for f in os.listdir(DATA_DIR) if f.endswith(".json") and f[:-5].isdigit()]


def migrate_legacy(bot) -> int | None:
    """Move the old single-server config.json onto the server it belongs to (runs once)."""
    if not os.path.exists(LEGACY_FILE):
        return None
    try:
        with open(LEGACY_FILE, "r", encoding="utf-8") as f:
            legacy = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(legacy, dict):
        return None

    target = None
    wanted = os.getenv("DASHBOARD_GUILD_ID", "").strip()
    if wanted.isdigit():
        target = bot.get_guild(int(wanted))
    if target is None:
        for key in ("whitelist_channel_id", "welcome_channel_id", "log_channel_id", "honeypot_channel_id"):
            ch = bot.get_channel(legacy.get(key) or 0)
            if ch is not None and getattr(ch, "guild", None) is not None:
                target = ch.guild
                break
    if target is None and len(bot.guilds) == 1:
        target = bot.guilds[0]
    if target is None:
        return None
    if os.path.exists(os.path.join(DATA_DIR, f"{target.id}.json")):
        return None

    # The old version was built for a FiveM community, so start with those figs on
    legacy.setdefault("figs", ["fivem", "community"])
    legacy.setdefault("city_emoji", "<:cityofmiami:1569162833445392394>")
    legacy.setdefault("server_name", "City Of Miami")
    # Channel links the old welcome message always showed (they were built in before)
    legacy.setdefault("welcome_links", [1569074209228062822, 1569165004085796974, 1569074416757772389, 1569074439793020979])
    _cache.pop(target.id, None)
    conf = GuildConfig(target.id, legacy)
    conf.save()
    _cache[target.id] = conf
    os.replace(LEGACY_FILE, LEGACY_FILE.replace(".json", ".old.json"))
    # The old dashboard change log becomes this server's log
    old_log, new_log = "dashboard_log.json", os.path.join("data", "audit", f"{target.id}.json")
    if os.path.exists(old_log) and not os.path.exists(new_log):
        try:
            os.makedirs(os.path.dirname(new_log), exist_ok=True)
            os.replace(old_log, new_log)
        except OSError:
            pass
    print(f"[Config] Moved config.json over to {target.name} ({target.id}). The old file is saved as config.old.json.")
    return target.id


# ──────────────────────────── branding helpers ──────────────────────────────
# These use the current server's settings.

FALLBACK_ACCENT = 0xffffff
FALLBACK_EMOJI = "⭐"
ACCENT = FALLBACK_ACCENT
CITY_EMOJI = FALLBACK_EMOJI


def _conf_or_none():
    return _current.get()


def _accent_value() -> int:
    conf = _conf_or_none()
    value = conf.get("accent_color", FALLBACK_ACCENT) if conf else FALLBACK_ACCENT
    try:
        if isinstance(value, int):
            return value
        return int(str(value).lstrip("#"), 16)
    except ValueError:
        return FALLBACK_ACCENT


accent = _accent_value


def city_emoji() -> str:
    """The server's emoji, used on buttons, titles and reactions."""
    conf = _conf_or_none()
    return (conf.get("city_emoji") if conf else None) or FALLBACK_EMOJI


def server_name(guild=None) -> str:
    conf = _conf_or_none()
    return (conf.get("server_name") if conf else "") or (guild.name if guild is not None else "")


def fill(text: str, guild: discord.Guild | None = None, member: discord.abc.User | None = None) -> str:
    """Swap {server}, {user}, {username} and {member_count} for real values."""
    text = text.replace("{server}", server_name(guild))
    if guild is not None:
        text = text.replace("{member_count}", str(guild.member_count or len(guild.members)))
    if member is not None:
        text = text.replace("{user}", member.mention).replace("{username}", member.display_name)
    return text


def _thumb() -> str:
    conf = _conf_or_none()
    url = conf.get("thumbnail_url", "") if conf else ""
    return url if url and str(url).startswith("http") else ""


def simple_view(*text_lines: str, accent: int | None = None) -> ui.LayoutView:
    """One-shot panel: up to 3 lines of text with the server thumbnail beside them. Empty lines are left out."""
    text_lines = [line for line in text_lines if line] or ["\u200b"]
    url = _thumb()
    children = []

    if url:
        children.append(ui.Section(
            *[ui.TextDisplay(line) for line in text_lines],
            accessory=ui.Thumbnail(
                media=discord.UnfurledMediaItem(url=url),
                description="Server thumbnail"
            )
        ))
    else:
        children.extend(ui.TextDisplay(line) for line in text_lines)

    view = ui.LayoutView()
    view.add_item(ui.Container(*children, accent_color=accent if accent is not None else _accent_value()))
    return view


# ──────────────────────────── WL panel ──────────────────────────────────────

def build_wl_view() -> ui.LayoutView:
    """The WL panel (text is edited on the dashboard, Whitelist page)."""
    thumbnail_url = _thumb()
    banner_url = config.get("banner_url", "")
    support_url = config.get("support_url", "")
    website_url = config.get("website_url", "")
    emoji = city_emoji()

    title = fill(config.get("wl_panel_title") or "WL System")
    subtitle = fill(config.get("wl_panel_subtitle") or "")
    header_lines = [ui.TextDisplay(f"# {title}")]
    if subtitle:
        header_lines.append(ui.TextDisplay(subtitle))

    view = ui.LayoutView(timeout=None)
    children = []

    if thumbnail_url:
        children.append(ui.Section(
            *header_lines,
            accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=thumbnail_url), description="Server thumbnail")
        ))
    else:
        children.extend(header_lines)
    children.append(ui.Separator())

    if banner_url and str(banner_url).startswith("http"):
        gallery = ui.MediaGallery()
        gallery.add_item(media=banner_url, description="Server banner")
        children.append(gallery)
        children.append(ui.Separator())

    sections = [s for s in config.get("wl_panel_sections", []) if str(s).strip()]
    for i, block in enumerate(sections):
        if i:
            children.append(ui.Separator(visible=False))
        children.append(ui.TextDisplay(fill(block)))

    if support_url or website_url:
        children.append(ui.Separator())
        buttons = []
        if support_url:
            buttons.append(ui.Button(label="Support Server", style=discord.ButtonStyle.gray, url=support_url, emoji=emoji))
        if website_url:
            buttons.append(ui.Button(label="Website", style=discord.ButtonStyle.gray, url=website_url, emoji=emoji))
        children.append(ui.ActionRow(*buttons))

    footer = config.get("wl_panel_footer", "")
    if footer:
        children.append(ui.Separator(visible=False))
        children.append(ui.TextDisplay(f"-# {fill(footer)}"))

    view.add_item(ui.Container(*children, accent_color=accent()))
    return view


async def send_wl_embed(channel) -> discord.Message:
    """Sends the WL panel (in the channel's server) using Components V2"""
    use_guild(channel.guild)
    return await channel.send(view=build_wl_view())


__all__ = [
    'send_wl_embed', 'build_wl_view', 'config', 'save_config', 'simple_view', 'fill', 'server_name',
    'accent', 'city_emoji', 'CITY_EMOJI', 'ACCENT', 'DEFAULTS', 'get_config', 'use_guild',
    'current_config', 'guild_context', 'migrate_legacy', 'known_guild_ids', 'GuildConfig',
    'DEFAULT_FILTER_MESSAGE', 'DEFAULT_HONEYPOT_MESSAGE',
]
