"""
Sessions: hosts announce trainings, shifts and events with /session-start (or from the dashboard).
The announcement pings a role, shows who's hosting and has a button to join the game.
/session-end marks it as over. Saved in data/sessions.json.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, use_guild
from .figs import feature_on
from .kit import Store, box, reply, is_staff, jump, now, ago_text, DashError

PINGS = discord.AllowedMentions(everyone=False, users=False, roles=True)


def join_link() -> str:
    if config.get("sess_link"):
        return config["sess_link"]
    return f"https://www.roblox.com/games/{config['rbx_place_id']}" if config.get("rbx_place_id") else ""


def session_view(s: dict) -> ui.LayoutView:
    emoji = s.get("emoji") or "📅"
    if s.get("ended"):
        head = f"## {emoji} {s['type']} has ended"
        body = f"Hosted by <@{s['host_id']}>\nLasted {ago_text(s['ended'] - s['started'])}"
    else:
        ping = f"<@&{s['ping_role_id']}>\n" if s.get("ping_role_id") else ""
        head = f"{ping}## {emoji} {s['type']} is starting!"
        body = f"Hosted by <@{s['host_id']}>\nStarted <t:{s['started']}:R>"
    parts = [head, body]
    if s.get("notes"):
        parts.append(f"> {s['notes']}")
    if s.get("link") and not s.get("ended"):
        parts.append(ui.ActionRow(ui.Button(label="Join the game", emoji="▶️", url=s["link"], style=discord.ButtonStyle.link)))
    return box(*parts)


class Sessions(commands.Cog):
    DASH_ACTIONS = {"start": "dash_start", "end": "dash_end"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("sessions.json")

    def book(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"active": {}, "history": []})

    def types(self) -> list[dict]:
        return [t for t in config.get("sess_types", []) if t.get("name")] or [{"name": "Session", "emoji": "📅"}]

    def can_host(self, member) -> bool:
        return is_staff(member, "manage_guild", config.get("sess_host_role_ids", []))

    async def start(self, guild, host, type_name: str, notes: str = ""):
        """Post the announcement. Returns (message, None) or (None, error)."""
        use_guild(guild)
        channel = guild.get_channel(config.get("sess_channel_id") or 0)
        if channel is None:
            return None, "Pick a session channel on the dashboard first."
        ttype = next((t for t in self.types() if t["name"].lower() == type_name.lower()), None)
        if ttype is None:
            return None, f"There's no session type called {type_name}."
        s = {"type": ttype["name"], "emoji": ttype.get("emoji", ""), "host_id": host.id, "host": str(host),
             "notes": notes.strip()[:500], "started": now(), "ended": None, "channel_id": channel.id,
             "ping_role_id": config.get("sess_ping_role_id"), "link": join_link()}
        try:
            msg = await channel.send(view=session_view(s), allowed_mentions=PINGS)
        except discord.HTTPException:
            return None, f"I can't post in #{channel.name}."
        self.book(guild)["active"][str(msg.id)] = s
        self.store.save()
        return msg, None

    async def end(self, guild, mid: str) -> dict | None:
        book = self.book(guild)
        s = book["active"].pop(str(mid), None)
        if s is None:
            return None
        s["ended"] = now()
        book["history"].insert(0, {**s, "id": str(mid)})
        del book["history"][50:]
        self.store.save()
        channel = guild.get_channel(s["channel_id"])
        if channel is not None:
            try:
                await channel.get_partial_message(int(mid)).edit(view=session_view(s))
            except discord.HTTPException:
                pass
        return s

    @app_commands.command(name="session-start", description="Announce a training, shift or event")
    @app_commands.describe(kind="What kind of session", notes="Anything people should know (optional)")
    async def session_start(self, interaction: discord.Interaction, kind: str, notes: str | None = None):
        if not self.can_host(interaction.user):
            return await reply(interaction, "## Hosts only", "You need a host role to start sessions.")
        msg, error = await self.start(interaction.guild, interaction.user, kind, notes or "")
        if error:
            return await reply(interaction, "## Couldn't start it", error)
        await reply(interaction, "## Session announced", f"{msg.jump_url}\nUse /session-end when it's over.")

    @session_start.autocomplete("kind")
    async def _kinds(self, interaction: discord.Interaction, current: str):
        use_guild(interaction.guild)
        return [app_commands.Choice(name=t["name"], value=t["name"]) for t in self.types()
                if current.lower() in t["name"].lower()][:25]

    @app_commands.command(name="session-end", description="Mark your session as over")
    async def session_end(self, interaction: discord.Interaction):
        active = self.book(interaction.guild)["active"]
        mine = [mid for mid, s in active.items() if s["host_id"] == interaction.user.id]
        if not mine and self.can_host(interaction.user) and active:
            mine = list(active)
        if not mine:
            return await reply(interaction, "## No session running", "You don't have a session to end.")
        s = await self.end(interaction.guild, mine[-1])
        await reply(interaction, f"## {s['type']} ended", f"It lasted {ago_text(s['ended'] - s['started'])}.")

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        book = self.book(guild)
        return {"active": [{**s, "id": mid, "host_id": str(s["host_id"]), "url": jump(guild.id, s["channel_id"], mid)}
                           for mid, s in book["active"].items()],
                "history": [{**s, "host_id": str(s["host_id"])} for s in book["history"][:25]],
                "types": [t["name"] for t in self.types()]}

    async def dash_start(self, guild, body: dict, user: dict) -> dict:
        host = guild.get_member(int(user["id"])) if user.get("id") else None
        msg, error = await self.start(guild, host or guild.me, str(body.get("type") or ""), str(body.get("notes") or ""))
        if error:
            raise DashError(error)
        s = self.book(guild)["active"][str(msg.id)]
        return {"message": f"{s['type']} announced.", "url": msg.jump_url, "log": f"Started a {s['type'].lower()} session"}

    async def dash_end(self, guild, body: dict, user: dict) -> dict:
        s = await self.end(guild, str(body.get("id") or ""))
        if s is None:
            raise DashError("That session isn't running anymore.")
        return {"message": f"{s['type']} ended.", "log": f"Ended a {s['type'].lower()} session"}


async def setup(bot: commands.Bot):
    await bot.add_cog(Sessions(bot))
