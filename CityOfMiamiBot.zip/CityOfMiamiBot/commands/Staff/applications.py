"""
Applications: staff applications, whitelist applications, partner requests... Members press a
button on the panel (or use /apply), answer up to 5 questions, and the answers go to a review
channel with Accept / Deny buttons. Accepting can give a role. The applicant gets a DM either way.
Saved in data/applications.json.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, use_guild, fill, simple_view, server_name
from .figs import feature_on
from .kit import Store, box, reply, is_staff, text_channel, jump, now, person, DashError

STATUS = {"pending": ("🕓", "Waiting for review"), "accepted": ("✅", "Accepted"), "denied": ("❌", "Denied")}


def forms(open_only: bool = False) -> list[dict]:
    return [f for f in config.get("app_forms", []) if not open_only or f.get("open", True)]


def get_form(form_id: str) -> dict | None:
    return next((f for f in forms() if f["id"] == form_id), None)


def panel_view(guild) -> ui.LayoutView:
    parts = [f"## {config.get('app_panel_title') or 'Applications'}"]
    if config.get("app_panel_text"):
        parts.append(fill(config["app_panel_text"], guild))
    open_forms = forms(open_only=True)
    if open_forms:
        lines = [f"{f.get('emoji') or '📝'} **{f['name']}**" + (f"\n-# {f['description']}" if f.get("description") else "") for f in open_forms]
        parts.append("\n".join(lines))
        buttons = [ui.Button(label=f["name"][:80], emoji=f.get("emoji") or "📝", custom_id=f"app:open:{f['id']}",
                             style=discord.ButtonStyle.primary) for f in open_forms[:10]]
        parts += [ui.ActionRow(*buttons[i:i + 5]) for i in range(0, len(buttons), 5)]
    else:
        parts.append("-# No applications are open right now.")
    return box(*parts)


def review_view(item: dict, form_name: str) -> ui.LayoutView:
    emoji, label = STATUS[item["status"]]
    answers = "\n".join(f"**{q}**\n> {a or '*No answer*'}" for q, a in item["answers"])[:3500]
    parts = [f"## 📝 {form_name} application #{item['number']}",
             f"From <@{item['user_id']}> ({item['user']})\n-# Joined Discord <t:{item.get('created', item['t'])}:R>",
             answers or "-# No answers", ui.Separator()]
    status = f"**{emoji} {label}**"
    if item.get("decided_by"):
        status += f" by {item['decided_by']}"
    if item.get("reason"):
        status += f"\n> {item['reason']}"
    parts.append(status)
    if item["status"] == "pending":
        parts.append(ui.ActionRow(
            ui.Button(label="Accept", emoji="✅", custom_id=f"app:acc:{item['number']}", style=discord.ButtonStyle.success),
            ui.Button(label="Deny", emoji="❌", custom_id=f"app:den:{item['number']}", style=discord.ButtonStyle.danger)))
    return box(*parts)


class ApplyForm(ui.Modal):
    def __init__(self, cog: "Applications", form: dict):
        super().__init__(title=f"{form['name']} application"[:45], custom_id=f"app:form:{form['id']}")
        self.cog, self.form, self.inputs = cog, form, []
        for q in form["questions"][:5]:
            field = ui.TextInput(label=q["label"][:45], required=q.get("required", True),
                                 style=discord.TextStyle.paragraph if q.get("long") else discord.TextStyle.short,
                                 max_length=1000 if q.get("long") else 200)
            self.inputs.append(field)
            self.add_item(field)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        answers = [(q["label"], str(f.value or "").strip()) for q, f in zip(self.form["questions"], self.inputs)]
        await self.cog.submit(interaction, self.form, answers)


class DenyForm(ui.Modal):
    def __init__(self, cog: "Applications", number: int):
        super().__init__(title="Deny this application", custom_id=f"app:deny:{number}")
        self.cog, self.number = cog, number
        self.reason = ui.TextInput(label="Reason (sent to them, optional)", style=discord.TextStyle.paragraph,
                                   max_length=500, required=False)
        self.add_item(self.reason)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        error = await self.cog.decide(interaction.guild, self.number, "denied", str(interaction.user), str(self.reason.value or ""))
        await reply(interaction, *(("## Couldn't deny it", error) if error else ("## Denied", "They've been told.")))


class Applications(commands.Cog):
    DASH_ACTIONS = {"panel": "dash_panel", "decide": "dash_decide"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("applications.json")

    def book(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"next": 1, "items": {}, "panels": []})

    def reviewer(self, member, form: dict | None) -> bool:
        return is_staff(member, "manage_guild", (form or {}).get("reviewer_role_ids", []))

    # ── applying ──

    async def start(self, interaction, form_id: str):
        form = get_form(form_id)
        if form is None or not form.get("open", True) or not feature_on(config, "applications"):
            return await reply(interaction, "## This application is closed")
        pending = [i for i in self.book(interaction.guild)["items"].values()
                   if i["user_id"] == interaction.user.id and i["form_id"] == form_id and i["status"] == "pending"]
        if pending:
            return await reply(interaction, "## You already applied", "Staff haven't looked at your last one yet. You'll get a DM.")
        await interaction.response.send_modal(ApplyForm(self, form))

    async def submit(self, interaction, form: dict, answers: list):
        guild, user = interaction.guild, interaction.user
        channel = guild.get_channel(form.get("review_channel_id") or 0)
        if channel is None:
            return await reply(interaction, "## Couldn't send it", "This application has no review channel. Tell staff.")
        book = self.book(guild)
        created = getattr(user, "created_at", None)
        item = {"number": book["next"], "form_id": form["id"], "user_id": user.id, "user": str(user), "answers": answers,
                "status": "pending", "t": now(), "created": int(created.timestamp()) if created else now(),
                "channel_id": channel.id}
        try:
            msg = await channel.send(view=review_view(item, form["name"]), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't send it", "I can't post in the review channel. Tell staff.")
        item["message_id"] = msg.id
        book["items"][str(item["number"])] = item
        book["next"] += 1
        self.store.save()
        await reply(interaction, "## 📨 Application sent", f"Thanks! Staff will review your {form['name'].lower()} application and DM you.")

    async def decide(self, guild, number: int, decision: str, by: str, reason: str = "") -> str | None:
        use_guild(guild)
        item = self.book(guild)["items"].get(str(number))
        if item is None:
            return "That application doesn't exist anymore."
        if item["status"] != "pending":
            return f"It was already {item['status']}."
        form = get_form(item["form_id"]) or {"name": "Deleted", "accept_role_id": None}
        item.update(status=decision, decided_by=by, reason=reason.strip()[:500], decided_at=now())
        self.store.save()
        member = guild.get_member(item["user_id"])
        if decision == "accepted" and member is not None and form.get("accept_role_id"):
            role = guild.get_role(form["accept_role_id"])
            if role is not None and role.is_assignable():
                try:
                    await member.add_roles(role, reason=f"{form['name']} application accepted")
                except discord.HTTPException:
                    pass
        if member is not None:
            emoji, label = STATUS[decision]
            try:
                await member.send(view=simple_view(f"## {emoji} Your {form['name'].lower()} application in {server_name(guild)} was {label.lower()}",
                                                   f"Reason: {item['reason']}" if item["reason"] else "-# No reason was given."))
            except (discord.HTTPException, AttributeError):
                pass
        channel = guild.get_channel(item["channel_id"])
        if channel is not None and item.get("message_id"):
            try:
                await channel.get_partial_message(item["message_id"]).edit(view=review_view(item, form["name"]))
            except discord.HTTPException:
                pass
        return None

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component or interaction.guild is None:
            return
        custom_id = (interaction.data or {}).get("custom_id", "")
        if not custom_id.startswith("app:"):
            return
        use_guild(interaction.guild)
        _, action, key = (custom_id.split(":") + ["", ""])[:3]
        if action == "open":
            return await self.start(interaction, key)
        item = self.book(interaction.guild)["items"].get(key)
        form = get_form(item["form_id"]) if item else None
        if item is None:
            return await reply(interaction, "## This application is gone")
        if not self.reviewer(interaction.user, form):
            return await reply(interaction, "## Reviewers only")
        if action == "acc":
            error = await self.decide(interaction.guild, int(key), "accepted", str(interaction.user))
            return await reply(interaction, *(("## Couldn't accept it", error) if error else ("## Accepted", "They've been told.")))
        if action == "den":
            return await interaction.response.send_modal(DenyForm(self, int(key)))

    @app_commands.command(name="apply", description="Apply for a role, staff team or more")
    @app_commands.describe(application="What to apply for")
    async def apply(self, interaction: discord.Interaction, application: str):
        form = next((f for f in forms(open_only=True) if f["name"].lower() == application.lower() or f["id"] == application), None)
        if form is None:
            return await reply(interaction, "## No open application like that", "Pick one from the list.")
        await self.start(interaction, form["id"])

    @apply.autocomplete("application")
    async def _forms(self, interaction: discord.Interaction, current: str):
        use_guild(interaction.guild)
        return [app_commands.Choice(name=f["name"], value=f["id"]) for f in forms(open_only=True)
                if current.lower() in f["name"].lower()][:25]

    # ── panels update when the forms change ──

    async def settings_changed(self, guild, changed: list, before: dict) -> list[str]:
        if not {"app_forms", "app_panel_title", "app_panel_text"} & set(changed):
            return []
        book, kept, updated = self.book(guild), [], 0
        for cid, mid in book["panels"]:
            channel = guild.get_channel(cid)
            if channel is None:
                continue
            try:
                await channel.get_partial_message(mid).edit(view=panel_view(guild))
                updated += 1
                kept.append([cid, mid])
            except discord.NotFound:
                pass
            except discord.HTTPException:
                kept.append([cid, mid])
        book["panels"] = kept
        self.store.save()
        return [f"Updated {updated} application panel{'s' if updated != 1 else ''} in Discord."] if updated else []

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        names = {f["id"]: f["name"] for f in forms()}
        items = sorted(self.book(guild)["items"].values(), key=lambda i: -i["number"])[:150]
        return {"items": [{"number": i["number"], "form": names.get(i["form_id"], "Deleted application"), "status": i["status"],
                           "answers": i["answers"], "t": i["t"], "reason": i.get("reason", ""), "decided_by": i.get("decided_by"),
                           "user": person(guild, i["user_id"]) or {"name": i["user"]},
                           "url": jump(guild.id, i["channel_id"], i.get("message_id"))} for i in items],
                "pending": sum(1 for i in self.book(guild)["items"].values() if i["status"] == "pending"),
                "panels": len(self.book(guild)["panels"])}

    async def dash_panel(self, guild, body: dict, user: dict) -> dict:
        if not forms():
            raise DashError("Add an application and save first.")
        channel = text_channel(guild, body.get("channel_id"))
        msg = await channel.send(view=panel_view(guild))
        self.book(guild)["panels"].append([channel.id, msg.id])
        self.store.save()
        return {"message": f"Posted the application panel in #{channel.name}.", "url": msg.jump_url,
                "log": f"Posted the application panel in #{channel.name}"}

    async def dash_decide(self, guild, body: dict, user: dict) -> dict:
        decision = body.get("decision")
        if decision not in ("accepted", "denied"):
            raise DashError("Pick accept or deny.")
        try:
            number = int(body.get("number"))
        except (TypeError, ValueError):
            raise DashError("That isn't an application number.")
        error = await self.decide(guild, number, decision, user.get("name", "Dashboard"), str(body.get("reason") or ""))
        if error:
            raise DashError(error)
        return {"message": f"Application #{number} {decision}.", "log": f"{decision.capitalize()} application #{number}"}


async def setup(bot: commands.Bot):
    await bot.add_cog(Applications(bot))
