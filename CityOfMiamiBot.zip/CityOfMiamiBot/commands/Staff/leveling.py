"""
Leveling: members earn XP for chatting (once a minute by default), level up, and earn roles at
the levels you pick. /rank, /leaderboard, /xp-give and /xp-reset. Saved in data/levels.json.
Same level curve as MEE6: going from level n to n+1 takes 5n² + 50n + 100 XP.
"""

import random
import time

import discord
from discord import app_commands
from discord.ext import commands

from .wl_embed import config, use_guild, fill, simple_view
from .figs import feature_on
from .kit import Store, reply, person, DashError


def xp_to_next(level: int) -> int:
    return 5 * level * level + 50 * level + 100


def level_of(xp: int) -> tuple[int, int]:
    """(level, XP into that level)"""
    level = 0
    while xp >= xp_to_next(level):
        xp -= xp_to_next(level)
        level += 1
    return level, xp


def bar(done: int, total: int, size: int = 12) -> str:
    filled = round(size * done / total) if total else 0
    return "█" * filled + "░" * (size - filled)


class Leveling(commands.Cog):
    DASH_ACTIONS = {"reset": "dash_reset", "give": "dash_give"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("levels.json")
        self.cooldowns: dict[tuple, float] = {}
        self.dirty, self.saved_at = False, 0.0

    # ── storage (saved at most every 30 seconds while people chat) ──

    def entry(self, guild, user_id) -> dict:
        return self.store.guild(guild).setdefault(str(user_id), {"xp": 0, "msgs": 0})

    def save_soon(self):
        self.dirty = True
        if time.time() - self.saved_at > 30:
            self.flush()

    def flush(self):
        if self.dirty:
            self.store.save()
            self.dirty, self.saved_at = False, time.time()

    async def cog_unload(self):
        self.flush()

    def ranking(self, guild) -> list[tuple[str, dict]]:
        return sorted(self.store.guild(guild).items(), key=lambda kv: -kv[1]["xp"])

    # ── earning XP ──

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or message.author.bot:
            return
        use_guild(message.guild)
        if not feature_on(config, "leveling") or not config.get("lvl_enabled", True):
            return
        if message.channel.id in config.get("lvl_no_xp_channel_ids", []):
            return
        blocked = set(config.get("lvl_no_xp_role_ids", []))
        if any(r.id in blocked for r in getattr(message.author, "roles", [])):
            return
        key = (message.guild.id, message.author.id)
        t = time.monotonic()
        if t - self.cooldowns.get(key, -1e9) < int(config.get("lvl_cooldown", 60)):
            return
        self.cooldowns[key] = t
        low, high = sorted((int(config.get("lvl_xp_min", 15)), int(config.get("lvl_xp_max", 25))))
        self.entry(message.guild, message.author.id)["msgs"] += 1
        await self.add_xp(message.author, random.randint(low, high), message.channel)

    async def add_xp(self, member, amount: int, channel=None) -> int:
        """Give (or take, if negative) XP. Levels up, gives roles and announces. Returns the new level."""
        data = self.entry(member.guild, member.id)
        before = level_of(data["xp"])[0]
        data["xp"] = max(0, data["xp"] + int(amount))
        after = level_of(data["xp"])[0]
        self.save_soon()
        if after != before:
            await self.sync_roles(member, after)
            if after > before:
                await self.announce(member, after, channel)
        return after

    async def sync_roles(self, member, level: int):
        binds = [b for b in config.get("lvl_roles", []) if b.get("role_id")]
        earned = [b for b in binds if b["level"] <= level]
        if earned and not config.get("lvl_stack", True):
            top = max(b["level"] for b in earned)
            earned = [b for b in earned if b["level"] == top]
        guild = member.guild
        want = {guild.get_role(b["role_id"]) for b in earned} - {None}
        every = {guild.get_role(b["role_id"]) for b in binds} - {None}
        add = [r for r in want if r not in member.roles and r.is_assignable()]
        remove = [r for r in every - want if r in member.roles and r.is_assignable()]
        try:
            if add:
                await member.add_roles(*add, reason=f"Reached level {level}")
            if remove:
                await member.remove_roles(*remove, reason=f"Now level {level}")
        except discord.HTTPException:
            pass

    async def announce(self, member, level: int, channel):
        mode = config.get("lvl_announce", "channel")
        if mode == "off":
            return
        text = fill((config.get("lvl_message") or "").replace("{level}", str(level)), member.guild, member)
        try:
            if mode == "dm":
                await member.send(text)
                return
            target = member.guild.get_channel(config.get("lvl_channel_id") or 0) if mode == "custom" else channel
            if target is not None:
                await target.send(text, allowed_mentions=discord.AllowedMentions(users=True))
        except (discord.HTTPException, AttributeError):
            pass

    # ── commands ──

    def card(self, guild, member) -> tuple[str, ...]:
        data = self.store.guild(guild).get(str(member.id), {"xp": 0, "msgs": 0})
        level, into = level_of(data["xp"])
        need = xp_to_next(level)
        ranking = [uid for uid, _ in self.ranking(guild)]
        place = ranking.index(str(member.id)) + 1 if str(member.id) in ranking else len(ranking) + 1
        return (f"## {member.display_name}",
                f"**Level {level}**, #{place} on the server\n`{bar(into, need)}` {into:,} / {need:,} XP to level {level + 1}",
                f"-# {data['xp']:,} XP total from {data['msgs']:,} messages")

    @app_commands.command(name="rank", description="See your level, or someone else's")
    @app_commands.describe(member="Whose level to see")
    async def rank(self, interaction: discord.Interaction, member: discord.Member | None = None):
        member = member or interaction.user
        await interaction.response.send_message(view=simple_view(*self.card(interaction.guild, member)))

    @app_commands.command(name="leaderboard", description="The most active members")
    async def leaderboard(self, interaction: discord.Interaction):
        top = self.ranking(interaction.guild)[:10]
        if not top:
            return await reply(interaction, "## No XP yet", "Chat a bit and check again.")
        medals = ["🥇", "🥈", "🥉"]
        lines = [f"{medals[i] if i < 3 else f'**{i + 1}.**'} <@{uid}>: level {level_of(d['xp'])[0]} ({d['xp']:,} XP)"
                 for i, (uid, d) in enumerate(top)]
        await interaction.response.send_message(view=simple_view("## 🏆 Leaderboard", "\n".join(lines)),
                                                allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="xp-give", description="Give or take XP (use a negative number to take)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(member="Who", amount="How much XP (negative takes XP away)")
    async def xp_give(self, interaction: discord.Interaction, member: discord.Member, amount: int):
        level = await self.add_xp(member, amount)
        self.flush()
        await reply(interaction, "## XP updated", f"{member.mention} is level {level} now.")

    @app_commands.command(name="xp-reset", description="Reset someone's XP to zero")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(member="Whose XP to reset")
    async def xp_reset(self, interaction: discord.Interaction, member: discord.Member):
        self.store.guild(interaction.guild).pop(str(member.id), None)
        self.dirty = True
        self.flush()
        await self.sync_roles(member, 0)
        await reply(interaction, "## XP reset", f"{member.mention} is back to level 0.")

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        rows = []
        for uid, d in self.ranking(guild)[:100]:
            level, into = level_of(d["xp"])
            rows.append({**(person(guild, uid) or {}), "xp": d["xp"], "msgs": d["msgs"], "level": level,
                         "into": into, "need": xp_to_next(level)})
        return {"top": rows, "members": len(self.store.guild(guild))}

    async def dash_reset(self, guild, body: dict, user: dict) -> dict:
        if body.get("all"):
            self.store.data[str(guild.id)] = {}
            self.dirty = True
            self.flush()
            return {"message": "Everyone's XP is back to zero. Level roles stay until people level again.",
                    "log": "Reset everyone's XP"}
        uid = str(body.get("user_id") or "")
        if uid not in self.store.guild(guild):
            raise DashError("That member has no XP.")
        self.store.guild(guild).pop(uid)
        self.dirty = True
        self.flush()
        member = guild.get_member(int(uid))
        if member is not None:
            await self.sync_roles(member, 0)
        return {"message": "Reset their XP.", "log": f"Reset the XP of <@{uid}>"}

    async def dash_give(self, guild, body: dict, user: dict) -> dict:
        try:
            member = guild.get_member(int(body.get("user_id")))
            amount = int(body.get("amount"))
        except (TypeError, ValueError):
            raise DashError("Pick a member and an amount.")
        if member is None:
            raise DashError("They're not in the server.")
        level = await self.add_xp(member, amount)
        self.flush()
        return {"message": f"{member.display_name} is level {level} now.", "log": f"Gave {amount} XP to {member}"}


async def setup(bot: commands.Bot):
    await bot.add_cog(Leveling(bot))
