import discord
from discord import app_commands
from discord.ext import commands

from .wl_embed import config, save_config, simple_view, use_guild
from .figs import feature_on

DEFAULT_FILTER_MESSAGE = "**{user} watch your language, that word isn't allowed here.**"


def _clean_list(key: str) -> list[str]:
    return [w.strip().lower() for w in config.get(key, []) if str(w).strip()]


class AutoMod(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ──────────────────────────── word filter ───────────────────────────────

    def _is_filtered(self, content: str) -> bool:
        """True if the message has a filtered word in it (even inside a longer word)."""
        filtered = _clean_list("filtered_words")
        if not filtered:
            return False

        text = content.lower()

        # Allowed words (/filter-allow) get blanked out first so they never trigger the filter
        for word in sorted(_clean_list("allowed_words"), key=len, reverse=True):
            text = text.replace(word, " ")

        return any(word in text for word in filtered)

    async def _check_filter(self, message: discord.Message):
        # People added with /wlfilter can say anything
        if message.author.id in config.get("filter_whitelist_users", []):
            return
        if not self._is_filtered(message.content):
            return

        try:
            await message.delete()
        except discord.HTTPException:
            pass

        text = config.get("filter_message", DEFAULT_FILTER_MESSAGE).replace("{user}", message.author.mention)
        await message.channel.send(text)

    # ──────────────────────────── listeners ─────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        use_guild(message.guild)
        if not feature_on(config, "filter"):
            return

        if message.channel.id == config.get("honeypot_channel_id"):
            return  # honeypot.py handles the trap channel

        await self._check_filter(message)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if after.author.bot or not after.guild or before.content == after.content:
            return
        use_guild(after.guild)
        if feature_on(config, "filter"):
            await self._check_filter(after)

    # ──────────────────────────── filter commands ───────────────────────────

    @app_commands.command(name="filter-add", description="Add a word to the filter")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(word="The word to block")
    async def filter_add(self, interaction: discord.Interaction, word: str):
        word = word.strip().lower()
        words = config.setdefault("filtered_words", [])
        if word in words:
            await interaction.response.send_message(view=simple_view("## Already Filtered", f"`{word}` is already on the list."), ephemeral=True)
            return
        words.append(word)
        save_config()
        await interaction.response.send_message(view=simple_view("## Word Added", f"`{word}` is now filtered."), ephemeral=True)

    @app_commands.command(name="filter-remove", description="Remove a word from the filter")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(word="The word to unblock")
    async def filter_remove(self, interaction: discord.Interaction, word: str):
        word = word.strip().lower()
        words = config.setdefault("filtered_words", [])
        if word not in words:
            await interaction.response.send_message(view=simple_view("## Not Found", f"`{word}` isn't on the list."), ephemeral=True)
            return
        words.remove(word)
        save_config()
        await interaction.response.send_message(view=simple_view("## Word Removed", f"`{word}` is no longer filtered."), ephemeral=True)

    @app_commands.command(name="wlfilter", description="Whitelist a person so the filter never deletes their messages")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(user="The person to whitelist (run again to remove them)")
    async def wlfilter(self, interaction: discord.Interaction, user: discord.Member):
        people = config.setdefault("filter_whitelist_users", [])
        if user.id in people:
            people.remove(user.id)
            title, text = "## Removed From Whitelist", f"{user.mention}'s messages will be filtered again."
        else:
            people.append(user.id)
            title, text = "## Whitelisted", f"{user.mention} can say filtered words without them being deleted."
        save_config()
        await interaction.response.send_message(view=simple_view(title, text), ephemeral=True)

    @app_commands.command(name="filter-allow", description="Allow a word so the filter never deletes it (run again to remove)")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(word="The word to allow, e.g. 'class' so it isn't caught by a filtered word inside it")
    async def filter_allow(self, interaction: discord.Interaction, word: str):
        word = word.strip().lower()
        allowed = config.setdefault("allowed_words", [])
        if word in allowed:
            allowed.remove(word)
            title, text = "## Allowed Word Removed", f"`{word}` can be filtered again."
        else:
            allowed.append(word)
            title, text = "## Word Allowed", f"`{word}` will never be deleted by the filter."
        save_config()
        await interaction.response.send_message(view=simple_view(title, text), ephemeral=True)

    @app_commands.command(name="filter-list", description="Show filtered words, allowed words and whitelisted people")
    @app_commands.default_permissions(administrator=True)
    async def filter_list(self, interaction: discord.Interaction):
        blocked = config.get("filtered_words", [])
        allowed = config.get("allowed_words", [])
        people = config.get("filter_whitelist_users", [])
        blocked_text = ", ".join(f"`{w}`" for w in blocked) if blocked else "None yet. Add some with `/filter-add`."
        allowed_text = ", ".join(f"`{w}`" for w in allowed) if allowed else "None. Add some with `/filter-allow`."
        people_text = ", ".join(f"<@{u}>" for u in people) if people else "None. Add someone with `/wlfilter`."
        await interaction.response.send_message(
            view=simple_view(
                "## Word Filter",
                f"**Filtered Words:** {blocked_text}"[:1800],
                (f"**Allowed Words:** {allowed_text}"[:900] + f"\n**Whitelisted People:** {people_text}"[:900])
            ),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none()
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoMod(bot))
