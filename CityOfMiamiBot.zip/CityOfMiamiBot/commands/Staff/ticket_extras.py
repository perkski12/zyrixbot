"""
Ticket extras:
  • Auto-close tickets nobody has written in for a while.
  • Ask members to rate the help they got (1-5 stars) when their ticket closes.
  • Saved replies staff send with /snippet.
  • Support hours: tickets opened outside them get a "we're away" note.
  • Members can DM the bot to open a ticket.
Ratings are saved in data/ticket_ratings.json.
"""

import datetime

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, use_guild, fill, simple_view, server_name
from .figs import feature_on
from .kit import Store, box, reply, now, person


def outside_hours(at: datetime.datetime | None = None) -> bool:
    if not config.get("ticket_hours_on"):
        return False
    at = at or datetime.datetime.now(datetime.timezone.utc)
    hour = (at.hour + int(config.get("ticket_utc_offset", 0) or 0)) % 24
    start, end = int(config.get("ticket_hours_start", 9)), int(config.get("ticket_hours_end", 21))
    if start == end:
        return False
    inside = start <= hour < end if start < end else (hour >= start or hour < end)
    return not inside


def rating_view(guild_id: int, channel_id: int, server: str) -> ui.LayoutView:
    return box("## How did we do?", f"Your ticket in **{server}** was closed. How was the help you got?",
               ui.ActionRow(*[ui.Button(label=str(n), emoji="⭐", custom_id=f"tkrate:{guild_id}:{channel_id}:{n}",
                                        style=discord.ButtonStyle.secondary) for n in range(1, 6)]))


class TicketExtras(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("ticket_ratings.json")
        self.saved_at = 0
        self.dm_last: dict[int, int] = {}
        self.pending_text: dict[int, str] = {}  # what someone DMed, kept until they pick a server

    @property
    def tickets(self):
        return self.bot.get_cog("Tickets")

    async def cog_load(self):
        self.autoclose_loop.start()

    async def cog_unload(self):
        self.autoclose_loop.cancel()

    # ── activity and auto-close ──

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return
        if message.guild is None:
            return await self.dm_open(message)
        cog = self.tickets
        ticket = cog.ticket(message.channel.id) if cog else None
        if ticket is not None:
            ticket["last"] = now()
            if now() - self.saved_at > 60:
                cog.save()
                self.saved_at = now()

    @tasks.loop(minutes=10)
    async def autoclose_loop(self):
        await self.autoclose()

    @autoclose_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def autoclose(self, at: int | None = None) -> int:
        cog, at, closed = self.tickets, at or now(), 0
        if cog is None:
            return 0
        for cid, t in list(cog.data["tickets"].items()):
            if t["status"] != "open":
                continue
            guild = self.bot.get_guild(t["guild_id"])
            if guild is None:
                continue
            use_guild(guild)
            hours = int(config.get("ticket_autoclose_hours", 0) or 0)
            if not hours or not feature_on(config, "tickets"):
                continue
            if at - (t.get("last") or t["created"]) >= hours * 3600:
                channel = guild.get_channel(int(cid))
                if channel is not None and not await cog.close_ticket(channel, guild.me, f"No messages for {hours} hours"):
                    closed += 1
        return closed

    # ── support hours ──

    @commands.Cog.listener()
    async def on_ticket_opened(self, channel, ticket: dict):
        use_guild(channel.guild)
        if outside_hours() and config.get("ticket_offline_message"):
            try:
                await channel.send(view=box(f"🌙 {fill(config['ticket_offline_message'], channel.guild)}"))
            except discord.HTTPException:
                pass

    # ── ratings ──

    @commands.Cog.listener()
    async def on_ticket_closed(self, channel, ticket: dict, by):
        use_guild(channel.guild)
        if not config.get("ticket_rating"):
            return
        opener = channel.guild.get_member(ticket["opener_id"])
        if opener is None or opener.bot:
            return
        try:
            await opener.send(view=rating_view(channel.guild.id, channel.id, server_name(channel.guild)))
        except (discord.HTTPException, AttributeError):
            pass

    def ratings(self, guild) -> list:
        return self.store.guild(guild, list)

    async def rate(self, guild, channel_id: int, user, stars: int) -> bool:
        use_guild(guild)
        cog = self.tickets
        ticket = (cog.ticket(channel_id) if cog else None) or {}
        if ticket and ticket.get("opener_id") != user.id:
            return False
        rows = self.ratings(guild)
        row = next((r for r in rows if r["channel_id"] == channel_id), None)
        if row is None:
            row = {"channel_id": channel_id, "number": ticket.get("number"), "opener_id": user.id,
                   "claimed_by": ticket.get("claimed_by"), "type_id": ticket.get("type_id")}
            rows.append(row)
            del rows[:-1000]
        row.update(stars=max(1, min(5, int(stars))), t=now())
        self.store.save()
        if cog:
            await cog.log(guild, f"## {'⭐' * row['stars']} Ticket rated {row['stars']}/5",
                          f"Ticket {row['number'] or ''} by <@{user.id}>".replace("  ", " "))
        return True

    # ── buttons in DMs ──

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return
        custom_id = (interaction.data or {}).get("custom_id", "")
        if custom_id.startswith("tkrate:"):
            _, gid, cid, stars = custom_id.split(":")
            guild = self.bot.get_guild(int(gid))
            if guild is None or not await self.rate(guild, int(cid), interaction.user, int(stars)):
                return await reply(interaction, "## Couldn't save that rating")
            await interaction.response.edit_message(view=box("## Thanks for the feedback!", f"You rated the help {'⭐' * int(stars)}"))
        elif custom_id.startswith("tkdm:"):
            guild = self.bot.get_guild(int(custom_id.split(":")[1]))
            member = guild.get_member(interaction.user.id) if guild else None
            if member is None:
                return await reply(interaction, "## You're not in that server anymore")
            await interaction.response.defer()
            await self.open_for(guild, member, "", interaction)

    # ── opening a ticket by DM ──

    def dm_servers(self, user) -> list:
        out = []
        for guild in self.bot.guilds:
            if guild.get_member(user.id) is None:
                continue
            use_guild(guild)
            if feature_on(config, "tickets") and config.get("ticket_dm_open") and config.get("ticket_types"):
                out.append(guild)
        return out

    async def dm_open(self, message):
        guilds = self.dm_servers(message.author)
        if not guilds or now() - self.dm_last.get(message.author.id, 0) < 20:
            return
        self.dm_last[message.author.id] = now()
        self.pending_text[message.author.id] = (message.content or "")[:1000]
        if len(guilds) == 1:
            return await self.open_for(guilds[0], guilds[0].get_member(message.author.id), message.content, None, message.channel)
        await message.channel.send(view=box("### Which server is this about?", ui.ActionRow(*[
            ui.Button(label=g.name[:80], custom_id=f"tkdm:{g.id}", style=discord.ButtonStyle.secondary) for g in guilds[:5]])))

    async def open_for(self, guild, member, text: str, interaction=None, dm_channel=None):
        use_guild(guild)
        from .tickets import ticket_types
        types = ticket_types()
        text = self.pending_text.pop(member.id, None) or text or ""
        answers = [("Their message", text[:1000])] if text.strip() else []
        channel, error = (None, "Tickets aren't set up yet.") if not types or not self.tickets else \
            await self.tickets.open_ticket(guild, member, types[0], answers)
        view = simple_view("## Couldn't open a ticket", error) if error else \
            simple_view("## 🎫 Ticket opened", f"Staff will answer you in {channel.mention} on **{guild.name}**.")
        target = interaction.followup if interaction else dm_channel
        try:
            await target.send(view=view)
        except discord.HTTPException:
            pass

    # ── saved replies ──

    @app_commands.command(name="snippet", description="Send a saved reply")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.describe(name="Which saved reply")
    async def snippet(self, interaction: discord.Interaction, name: str):
        found = next((s for s in config.get("ticket_snippets", []) if s["name"].lower() == name.lower()), None)
        if found is None:
            return await reply(interaction, "## No saved reply called that", "Add saved replies on the dashboard (Ticket types).")
        ticket = self.tickets.ticket(interaction.channel.id) if self.tickets else None
        opener = interaction.guild.get_member(ticket["opener_id"]) if ticket else None
        text = fill(found["text"], interaction.guild, opener)
        if opener is None:
            text = text.replace("{user}", "")
        await interaction.response.send_message(text, allowed_mentions=discord.AllowedMentions(users=True))

    @snippet.autocomplete("name")
    async def _snippet_names(self, interaction: discord.Interaction, current: str):
        use_guild(interaction.guild)
        return [app_commands.Choice(name=s["name"], value=s["name"]) for s in config.get("ticket_snippets", [])
                if current.lower() in s["name"].lower()][:25]

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        rows = [r for r in self.ratings(guild) if r.get("stars")]
        staff: dict[str, list] = {}
        for r in rows:
            if r.get("claimed_by"):
                staff.setdefault(str(r["claimed_by"]), []).append(r["stars"])
        return {
            "average": round(sum(r["stars"] for r in rows) / len(rows), 2) if rows else None,
            "count": len(rows),
            "spread": [sum(1 for r in rows if r["stars"] == n) for n in range(1, 6)],
            "recent": [{"stars": r["stars"], "number": r.get("number"), "t": r["t"], "opener": person(guild, r["opener_id"])}
                       for r in reversed(rows[-20:])],
            "staff": sorted([{**(person(guild, uid) or {}), "average": round(sum(v) / len(v), 2), "count": len(v)}
                             for uid, v in staff.items()], key=lambda x: -x["count"])[:15],
            "outside_hours": outside_hours(),
        }


async def setup(bot: commands.Bot):
    await bot.add_cog(TicketExtras(bot))
