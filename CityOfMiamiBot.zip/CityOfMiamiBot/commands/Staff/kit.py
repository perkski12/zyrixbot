"""
Small helpers shared by the feature files (this file isn't a feature itself).

  Store         a JSON file in data/ for a feature's records
  DashError     raised by a dashboard action, shown to the person on the dashboard
  box(...)      a message panel in the server's accent color
  reply(...)    answer an interaction privately, whether it was answered already or not
"""

import json
import os
import re
import time

import discord
from discord import ui

from .wl_embed import config, accent, simple_view


class DashError(Exception):
    """A dashboard action couldn't be done. The message is shown to the person on the dashboard."""


class Store:
    """A feature's records, kept in data/<name> and saved after every change."""

    def __init__(self, name: str, default=dict):
        self.path = os.path.join("data", name)
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                self.data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.data = default()

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=1, ensure_ascii=False)
        os.replace(tmp, self.path)

    def guild(self, guild, default=dict):
        """This server's part of the records (created if missing)."""
        key = str(getattr(guild, "id", guild))
        if key not in self.data:
            self.data[key] = default()
        return self.data[key]


def box(*children) -> ui.LayoutView:
    """Wrap text and components in one panel with the server's accent color."""
    view = ui.LayoutView(timeout=None)
    view.add_item(ui.Container(*[ui.TextDisplay(c) if isinstance(c, str) else c for c in children if c],
                               accent_color=accent()))
    return view


async def reply(interaction: discord.Interaction, *lines: str, view: ui.LayoutView | None = None, ephemeral: bool = True):
    view = view or simple_view(*lines[:3])
    if interaction.response.is_done():
        return await interaction.followup.send(view=view, ephemeral=ephemeral)
    return await interaction.response.send_message(view=view, ephemeral=ephemeral)


def is_staff(member, perm: str = "manage_guild", role_ids=()) -> bool:
    perms = getattr(member, "guild_permissions", None)
    if perms is not None and (perms.administrator or getattr(perms, perm, False)):
        return True
    wanted = {int(r) for r in role_ids or []}
    return any(r.id in wanted for r in getattr(member, "roles", []))


def text_channel(guild, cid):
    """A text channel the bot can post in, or DashError."""
    try:
        channel = guild.get_channel(int(cid or 0))
    except (TypeError, ValueError):
        channel = None
    if channel is None or channel.type.name not in ("text", "news"):
        raise DashError("Pick a text channel.")
    perms = channel.permissions_for(guild.me)
    if not (perms.view_channel and perms.send_messages):
        raise DashError(f"I can't send messages in #{channel.name}. Give my role View Channel and Send Messages there.")
    return channel


def channel_from(guild, key: str):
    """The channel saved in a setting, or the main log channel for log settings."""
    return guild.get_channel(config.get(key) or 0)


async def send_log(guild, key: str, *lines: str):
    """Post to the channel in setting `key`, or the main log channel when that's empty."""
    channel = guild.get_channel(config.get(key) or 0) or guild.get_channel(config.get("log_channel_id") or 0)
    if channel is None:
        return
    try:
        await channel.send(view=simple_view(*lines[:3]), allowed_mentions=discord.AllowedMentions.none())
    except discord.HTTPException:
        pass


def jump(guild_id, channel_id, message_id=None) -> str:
    return f"https://discord.com/channels/{guild_id}/{channel_id}" + (f"/{message_id}" if message_id else "")


def ago_text(seconds: float) -> str:
    seconds = max(0, int(seconds))
    for size, name in ((86400, "day"), (3600, "hour"), (60, "minute")):
        if seconds >= size:
            n = seconds // size
            return f"{n} {name}{'s' if n != 1 else ''}"
    return f"{seconds} seconds"


def person(guild, uid) -> dict | None:
    """A member as the dashboard shows them."""
    if not uid:
        return None
    m = guild.get_member(int(uid))
    return {"id": str(uid), "name": m.display_name if m else "Left the server",
            "avatar": m.display_avatar.url if m else None}


def now() -> int:
    return int(time.time())


UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_duration(text: str) -> int | None:
    """'30m', '2h', '1d12h', '1w', '2 days' → seconds. A plain number counts as minutes. None if it can't be read."""
    text = (text or "").strip().lower()
    if text.isdigit():
        return int(text) * 60
    text = re.sub(r"(\d)\s*(weeks?|wks?)\b", r"\1w", text)
    text = re.sub(r"(\d)\s*(days?)\b", r"\1d", text)
    text = re.sub(r"(\d)\s*(hours?|hrs?)\b", r"\1h", text)
    text = re.sub(r"(\d)\s*(minutes?|mins?)\b", r"\1m", text)
    text = re.sub(r"(\d)\s*(seconds?|secs?)\b", r"\1s", text)
    parts = re.findall(r"(\d+)\s*([smhdw])", text)
    if not parts or re.sub(r"[\d\s,smhdw]|and", "", text):
        return None
    return sum(int(n) * UNITS[u] for n, u in parts)


def duration_text(seconds: int) -> str:
    """90061 → '1 day 1 hour 1 minute' (the two biggest parts)."""
    seconds = max(0, int(seconds))
    out = []
    for size, name in ((604800, "week"), (86400, "day"), (3600, "hour"), (60, "minute"), (1, "second")):
        if seconds >= size:
            n, seconds = divmod(seconds, size)
            out.append(f"{n} {name}{'s' if n != 1 else ''}")
    return " ".join(out[:2]) or "0 seconds"
