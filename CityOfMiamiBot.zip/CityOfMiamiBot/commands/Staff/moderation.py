import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, city_emoji, accent


def _thumbnail_url() -> str:
    return config.get("thumbnail_url", "")


def _make_view(*text_lines: str, accent_color: int | None = None) -> ui.LayoutView:
    """Build a one-shot LayoutView with a Container (+ optional thumbnail Section)."""
    url = _thumbnail_url()
    children = []

    if url and str(url).startswith("http"):
        children.append(
            ui.Section(
                *[ui.TextDisplay(line) for line in text_lines],
                accessory=ui.Thumbnail(
                    media=discord.UnfurledMediaItem(url=url),
                    description="Server thumbnail"
                )
            )
        )
    else:
        for line in text_lines:
            children.append(ui.TextDisplay(line))

    view = ui.LayoutView()
    view.add_item(ui.Container(*children, accent_color=accent_color if accent_color is not None else accent()))
    return view


class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ──────────────────────────── /give-prio ────────────────────────────────

    @app_commands.command(name="give-prio", description="Give a priority role to a user")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(user="The member to give the role to", role="Select the priority role")
    async def give_prio(self, interaction: discord.Interaction, user: discord.Member, role: str):
        priority_roles = config.get("priority_roles", {})

        role_id = priority_roles.get(role)
        if not role_id:
            await interaction.response.send_message(
                view=_make_view("## Role Not Found", f"`{role}` isn't a priority role. Add it on the dashboard (Priority roles page)."),
                ephemeral=True
            )
            return

        discord_role = interaction.guild.get_role(int(role_id))
        if not discord_role:
            await interaction.response.send_message(
                view=_make_view("## Role Not Found", f"Role with ID `{role_id}` not found on server."),
                ephemeral=True
            )
            return

        try:
            await user.add_roles(discord_role)
            await interaction.response.send_message(
                view=_make_view(
                    "## Priority Role Given",
                    f"Successfully gave **{discord_role.name}** to {user.mention}"
                ),
                ephemeral=False
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                view=_make_view("## Permission Denied", "I don't have permission to manage roles."),
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                view=_make_view("## Error", str(e)),
                ephemeral=True
            )

    @give_prio.autocomplete("role")
    async def give_prio_role_autocomplete(self, interaction: discord.Interaction, current: str):
        names = list(config.get("priority_roles", {}).keys())
        return [
            app_commands.Choice(name=name, value=name)
            for name in names if current.lower() in name.lower()
        ][:25]

    # ──────────────────────────── /removeall-prio ───────────────────────────

    @app_commands.command(name="removeall-prio", description="Remove ALL priority roles from a user")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(user="The member to remove all priority roles from")
    async def removeall_prio(self, interaction: discord.Interaction, user: discord.Member):
        priority_roles = config.get("priority_roles", {})

        if not priority_roles:
            await interaction.response.send_message(
                view=_make_view("## No Roles", "No priority roles are set up yet. Add them on the dashboard (Priority roles page)."),
                ephemeral=True
            )
            return

        removed = []
        for role_name, role_id in priority_roles.items():
            discord_role = interaction.guild.get_role(int(role_id))
            if discord_role and discord_role in user.roles:
                try:
                    await user.remove_roles(discord_role)
                    removed.append(discord_role.name)
                except Exception:
                    pass

        if removed:
            await interaction.response.send_message(
                view=_make_view(
                    "## Priority Roles Removed",
                    f"Removed **{len(removed)}** priority roles from {user.mention}:",
                    f"`{', '.join(removed)}`"
                ),
                ephemeral=False
            )
        else:
            await interaction.response.send_message(
                view=_make_view(
                    "## No Roles Removed",
                    f"{user.mention} didn't have any priority roles from the config."
                ),
                ephemeral=False
            )

    # ──────────────────────────── /sneakpeek ────────────────────────────────

    @app_commands.command(name="sneakpeek", description="Post a sneak peek reaction goal")
    @app_commands.default_permissions(administrator=True)
    @app_commands.describe(
        amount="How many reactions are needed",
        title="The title shown at the top of the post",
        teaser_count="Which teaser number this unlocks"
    )
    async def sneakpeek(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1],
        title: str,
        teaser_count: app_commands.Range[int, 1]
    ):
        server_name = config.get("server_name", "City Of Miami")

        await interaction.response.send_message(
            view=_make_view(
                f"## {title}",
                f"Get us to **{amount}** reactions for teaser **#{teaser_count}**\n"
                f"For **{server_name}** to see what is being added to the server!"
            )
        )

        # Add the first reaction so members have something to click
        try:
            message = await interaction.original_response()
            await message.add_reaction(city_emoji())
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
