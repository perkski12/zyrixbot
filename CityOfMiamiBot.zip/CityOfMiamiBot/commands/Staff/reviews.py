"""
Reviews: members leave a 1-5 star review with /review. It's posted in the reviews channel, and the
dashboard shows the average. Good for shops, services and support teams. Saved in data/reviews.json.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, use_guild
from .kit import Store, box, reply, jump, now, person, DashError


def stars_text(n: int) -> str:
    return "⭐" * n + "☆" * (5 - n)


def review_view(r: dict) -> ui.LayoutView:
    return box(f"## {stars_text(r['stars'])}", r["text"], f"-# Review #{r['number']} by <@{r['user_id']}>")


class Reviews(commands.Cog):
    DASH_ACTIONS = {"delete": "dash_delete"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("reviews.json")

    def book(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"next": 1, "items": {}})

    @app_commands.command(name="review", description="Leave a review")
    @app_commands.describe(stars="How many stars (1-5)", review="What you thought")
    async def review(self, interaction: discord.Interaction, stars: app_commands.Range[int, 1, 5], review: str):
        guild, user = interaction.guild, interaction.user
        channel = guild.get_channel(config.get("rev_channel_id") or 0)
        if channel is None:
            return await reply(interaction, "## Reviews aren't set up", "Staff can pick a reviews channel on the dashboard.")
        need = guild.get_role(config.get("rev_role_id") or 0)
        if need is not None and need not in user.roles:
            return await reply(interaction, "## You can't review yet", f"You need the {need.mention} role to leave a review.")
        book = self.book(guild)
        recent = [r for r in book["items"].values() if r["user_id"] == user.id and now() - r["t"] < 86400]
        if recent:
            return await reply(interaction, "## One review a day", "You already left a review today.")
        r = {"number": book["next"], "stars": int(stars), "text": review.strip()[:1500], "user_id": user.id,
             "user": str(user), "t": now(), "channel_id": channel.id}
        try:
            msg = await channel.send(view=review_view(r), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't post it", "I can't post in the reviews channel.")
        r["message_id"] = msg.id
        book["items"][str(r["number"])] = r
        book["next"] += 1
        self.store.save()
        await reply(interaction, "## Thanks for the review!", stars_text(r["stars"]))

    def dashboard_info(self, guild) -> dict:
        items = sorted(self.book(guild)["items"].values(), key=lambda r: -r["number"])
        return {
            "average": round(sum(r["stars"] for r in items) / len(items), 2) if items else None,
            "count": len(items),
            "spread": [sum(1 for r in items if r["stars"] == n) for n in range(1, 6)],
            "items": [{"number": r["number"], "stars": r["stars"], "text": r["text"], "t": r["t"],
                       "user": person(guild, r["user_id"]) or {"name": r["user"]},
                       "url": jump(guild.id, r["channel_id"], r.get("message_id"))} for r in items[:100]],
        }

    async def dash_delete(self, guild, body: dict, user: dict) -> dict:
        r = self.book(guild)["items"].pop(str(body.get("number") or ""), None)
        if r is None:
            raise DashError("That review doesn't exist anymore.")
        self.store.save()
        channel = guild.get_channel(r["channel_id"])
        if channel is not None and r.get("message_id"):
            try:
                await channel.get_partial_message(r["message_id"]).delete()
            except discord.HTTPException:
                pass
        return {"message": f"Deleted review #{r['number']}.", "log": f"Deleted review #{r['number']}"}


async def setup(bot: commands.Bot):
    await bot.add_cog(Reviews(bot))
