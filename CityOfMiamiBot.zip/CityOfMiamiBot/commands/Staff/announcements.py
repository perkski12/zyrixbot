"""
Announcements: send a message as the bot from the dashboard or with /announce, and timed messages
that repeat every few hours (rules reminders, store links, server IP...). Last send times are kept
in data/timed_messages.json so a restart doesn't post twice.
"""

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, use_guild, fill
from .figs import feature_on
from .kit import Store, box, reply, text_channel, now, DashError

PINGS = discord.AllowedMentions(everyone=False, users=True, roles=True)


def message_view(guild, title: str, text: str, ping_role_id=None, image_url: str = "") -> ui.LayoutView:
    parts = []
    if ping_role_id:
        parts.append(f"<@&{ping_role_id}>")
    if title:
        parts.append(f"## {fill(title, guild)}")
    parts.append(fill(text, guild) or "​")
    children = ["\n".join(parts)]
    if image_url.startswith("http"):
        gallery = ui.MediaGallery()
        gallery.add_item(media=image_url)
        children.append(gallery)
    return box(*children)


class AnnounceForm(ui.Modal):
    def __init__(self, cog: "Announcements", channel, role):
        super().__init__(title=f"Announce in #{channel.name}"[:45], custom_id="ann:form")
        self.cog, self.channel, self.role = cog, channel, role
        self.heading = ui.TextInput(label="Title (optional)", max_length=200, required=False)
        self.body = ui.TextInput(label="Message", style=discord.TextStyle.paragraph, max_length=3500, required=True)
        self.add_item(self.heading)
        self.add_item(self.body)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)
        return True

    async def on_submit(self, interaction: discord.Interaction):
        try:
            msg = await self.channel.send(view=message_view(interaction.guild, str(self.heading.value or ""), str(self.body.value),
                                                            self.role.id if self.role else None), allowed_mentions=PINGS)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't post it", f"I can't send messages in {self.channel.mention}.")
        await reply(interaction, "## 📢 Posted", msg.jump_url)


class Announcements(commands.Cog):
    DASH_ACTIONS = {"send": "dash_send", "send-timed": "dash_send_timed"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("timed_messages.json")

    async def cog_load(self):
        self.timed_loop.start()

    async def cog_unload(self):
        self.timed_loop.cancel()

    @tasks.loop(minutes=1)
    async def timed_loop(self):
        await self.tick()

    @timed_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def tick(self, at: int | None = None) -> int:
        """Send every timed message that's due. Returns how many were sent."""
        at, sent = at or now(), 0
        for guild in list(self.bot.guilds):
            use_guild(guild)
            if not feature_on(config, "announcements"):
                continue
            last = self.store.guild(guild)
            for m in config.get("ann_messages", []):
                if not m.get("enabled", True) or not m.get("channel_id"):
                    continue
                if at - last.get(m["id"], 0) >= int(m.get("every_hours", 24)) * 3600:
                    last[m["id"]] = at
                    sent += await self.send_timed(guild, m)
            self.store.save()
        return sent

    async def send_timed(self, guild, m: dict) -> int:
        channel = guild.get_channel(m["channel_id"])
        if channel is None:
            return 0
        try:
            await channel.send(view=message_view(guild, m.get("title", ""), m["text"], m.get("ping_role_id")), allowed_mentions=PINGS)
            return 1
        except discord.HTTPException:
            return 0

    @app_commands.command(name="announce", description="Post an announcement as the bot")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(channel="Where to post it", ping="A role to ping (optional)")
    async def announce(self, interaction: discord.Interaction, channel: discord.TextChannel, ping: discord.Role | None = None):
        await interaction.response.send_modal(AnnounceForm(self, channel, ping))

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        return {"last_sent": dict(self.store.guild(guild))}

    async def dash_send(self, guild, body: dict, user: dict) -> dict:
        channel = text_channel(guild, body.get("channel_id"))
        text = str(body.get("text") or "").strip()
        if not text:
            raise DashError("Write the message first.")
        if len(text) > 3500:
            raise DashError("Keep the message under 3500 characters.")
        role = guild.get_role(int(body.get("ping_role_id") or 0)) if str(body.get("ping_role_id") or "").isdigit() else None
        image = str(body.get("image_url") or "").strip()
        msg = await channel.send(view=message_view(guild, str(body.get("title") or "")[:200], text, role.id if role else None, image),
                                 allowed_mentions=PINGS)
        return {"message": f"Posted in #{channel.name}.", "url": msg.jump_url, "log": f"Posted an announcement in #{channel.name}"}

    async def dash_send_timed(self, guild, body: dict, user: dict) -> dict:
        m = next((x for x in config.get("ann_messages", []) if x["id"] == body.get("id")), None)
        if m is None:
            raise DashError("Save the timed message first.")
        if not await self.send_timed(guild, m):
            raise DashError("I couldn't post it. Check the channel and my permissions there.")
        self.store.guild(guild)[m["id"]] = now()
        self.store.save()
        return {"message": "Sent it. The timer starts over from now."}


async def setup(bot: commands.Bot):
    await bot.add_cog(Announcements(bot))
