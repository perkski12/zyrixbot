"""
Birthdays: members save their birthday with /birthday-set. On the day, the bot wishes them a happy
birthday in the channel you pick and gives them the birthday role until the next day.
Saved in data/birthdays.json. The time of day is in UTC (picked on the dashboard).
"""

import datetime

import discord
from discord import app_commands
from discord.ext import commands, tasks

from .wl_embed import config, use_guild, fill, simple_view
from .figs import feature_on
from .kit import Store, reply, person, DashError

MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December"]


def pretty(md: str) -> str:
    month, day = md.split("-")
    return f"{MONTHS[int(month) - 1]} {int(day)}"


def days_until(md: str, today: datetime.date) -> int:
    month, day = map(int, md.split("-"))
    for year in (today.year, today.year + 1):
        try:
            d = datetime.date(year, month, day)
        except ValueError:  # Feb 29 in a normal year
            d = datetime.date(year, 2, 28)
        if d >= today:
            return (d - today).days
    return 366


class Birthdays(commands.Cog):
    DASH_ACTIONS = {"remove": "dash_remove", "check-now": "dash_check"}

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("birthdays.json")

    def book(self, guild) -> dict:
        return self.store.guild(guild, lambda: {"dates": {}, "announced": "", "holders": []})

    async def cog_load(self):
        self.birthday_loop.start()

    async def cog_unload(self):
        self.birthday_loop.cancel()

    @tasks.loop(minutes=10)
    async def birthday_loop(self):
        await self.tick()

    @birthday_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def tick(self, at: datetime.datetime | None = None, force: bool = False):
        at = at or datetime.datetime.now(datetime.timezone.utc)
        for guild in list(self.bot.guilds):
            use_guild(guild)
            if feature_on(config, "birthdays"):
                await self.check_guild(guild, at, force)

    async def check_guild(self, guild, at: datetime.datetime, force: bool = False) -> int:
        book = self.book(guild)
        key = at.strftime("%Y-%m-%d")
        if not force and (at.hour < int(config.get("bday_hour", 14)) or book["announced"] == key):
            return 0
        book["announced"] = key
        today = at.strftime("%m-%d")
        leap_day_today = today == "02-28" and not _is_leap(at.year)
        people = [guild.get_member(int(uid)) for uid, md in book["dates"].items()
                  if md == today or (leap_day_today and md == "02-29")]
        people = [m for m in people if m is not None]

        role = guild.get_role(config.get("bday_role_id") or 0)
        if role is not None and role.is_assignable():
            for uid in book["holders"]:
                m = guild.get_member(int(uid))
                if m is not None and m not in people and role in m.roles:
                    try:
                        await m.remove_roles(role, reason="Birthday is over")
                    except discord.HTTPException:
                        pass
            for m in people:
                try:
                    await m.add_roles(role, reason="Happy birthday!")
                except discord.HTTPException:
                    pass
        book["holders"] = [m.id for m in people]
        self.store.save()

        channel = guild.get_channel(config.get("bday_channel_id") or 0)
        if channel is not None and people:
            text = (config.get("bday_message") or "").replace("{user}", " ".join(m.mention for m in people))
            try:
                await channel.send(f"🎂 {fill(text, guild)}", allowed_mentions=discord.AllowedMentions(users=True))
            except discord.HTTPException:
                pass
        return len(people)

    # ── commands ──

    @app_commands.command(name="birthday-set", description="Save your birthday so the server can celebrate it")
    @app_commands.describe(month="Month (1-12)", day="Day of the month")
    async def birthday_set(self, interaction: discord.Interaction, month: app_commands.Range[int, 1, 12],
                           day: app_commands.Range[int, 1, 31]):
        try:
            datetime.date(2000, month, day)  # 2000 was a leap year, so Feb 29 is fine
        except ValueError:
            return await reply(interaction, "## That date doesn't exist", f"{MONTHS[month - 1]} doesn't have a day {day}.")
        md = f"{month:02d}-{day:02d}"
        self.book(interaction.guild)["dates"][str(interaction.user.id)] = md
        self.store.save()
        await reply(interaction, "## 🎂 Birthday saved", f"We'll celebrate on **{pretty(md)}**.")

    @app_commands.command(name="birthday-remove", description="Remove your saved birthday")
    async def birthday_remove(self, interaction: discord.Interaction):
        removed = self.book(interaction.guild)["dates"].pop(str(interaction.user.id), None)
        self.store.save()
        await reply(interaction, "## Birthday removed" if removed else "## You hadn't saved a birthday")

    @app_commands.command(name="birthdays", description="Upcoming birthdays")
    async def birthdays(self, interaction: discord.Interaction):
        rows = self.upcoming(interaction.guild)[:10]
        if not rows:
            return await reply(interaction, "## No birthdays saved yet", "Save yours with /birthday-set.")
        lines = "\n".join(f"**{pretty(md)}**: <@{uid}>" + (" 🎉 today!" if days == 0 else f" (in {days} days)")
                          for uid, md, days in rows)
        await interaction.response.send_message(view=simple_view("## 🎂 Upcoming birthdays", lines),
                                                allowed_mentions=discord.AllowedMentions.none())

    def upcoming(self, guild) -> list[tuple[str, str, int]]:
        today = datetime.datetime.now(datetime.timezone.utc).date()
        rows = [(uid, md, days_until(md, today)) for uid, md in self.book(guild)["dates"].items()
                if guild.get_member(int(uid)) is not None]
        return sorted(rows, key=lambda r: r[2])

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        return {"upcoming": [{**(person(guild, uid) or {}), "date": pretty(md), "days": days}
                             for uid, md, days in self.upcoming(guild)[:100]],
                "count": len(self.book(guild)["dates"])}

    async def dash_remove(self, guild, body: dict, user: dict) -> dict:
        if self.book(guild)["dates"].pop(str(body.get("user_id") or ""), None) is None:
            raise DashError("They don't have a birthday saved.")
        self.store.save()
        return {"message": "Removed their birthday.", "log": f"Removed the birthday of <@{body.get('user_id')}>"}

    async def dash_check(self, guild, body: dict, user: dict) -> dict:
        n = await self.check_guild(guild, datetime.datetime.now(datetime.timezone.utc), force=True)
        return {"message": f"Checked today's birthdays: {n} {'person' if n == 1 else 'people'} celebrating."}


def _is_leap(year: int) -> bool:
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


async def setup(bot: commands.Bot):
    await bot.add_cog(Birthdays(bot))
