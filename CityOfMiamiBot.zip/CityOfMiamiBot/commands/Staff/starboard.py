"""
Starboard: when a message gets enough ⭐ reactions (or the emoji you pick), the bot reposts it in
the starboard channel and keeps the count up to date. Saved in data/starboard.json.
"""

import discord
from discord import ui
from discord.ext import commands

from .wl_embed import config, use_guild, accent
from .figs import feature_on
from .kit import Store, now


def star_view(message, count: int, emoji: str) -> ui.LayoutView:
    author = message.author
    header = [ui.TextDisplay(f"{emoji} **{count}** in {message.channel.mention}"),
              ui.TextDisplay(f"**{getattr(author, 'display_name', author)}**")]
    avatar = getattr(getattr(author, "display_avatar", None), "url", None)
    children = [ui.Section(*header, accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=avatar)))
                if avatar else header[0]]
    if message.content:
        children.append(ui.TextDisplay(message.content[:3500]))
    images = [a.url for a in getattr(message, "attachments", []) or []
              if str(getattr(a, "content_type", "") or "").startswith("image/")]
    if images:
        gallery = ui.MediaGallery()
        for url in images[:4]:
            gallery.add_item(media=url)
        children.append(gallery)
    children.append(ui.ActionRow(ui.Button(label="Jump to message", url=message.jump_url, style=discord.ButtonStyle.link)))
    view = ui.LayoutView(timeout=None)
    view.add_item(ui.Container(*children, accent_color=accent()))
    return view


class Starboard(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.store = Store("starboard.json")

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        await self.update(payload)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload):
        await self.update(payload)

    async def update(self, payload):
        guild = self.bot.get_guild(payload.guild_id or 0)
        if guild is None:
            return
        use_guild(guild)
        if not feature_on(config, "starboard"):
            return
        board = guild.get_channel(config.get("star_channel_id") or 0)
        emoji = config.get("star_emoji") or "⭐"
        if board is None or str(payload.emoji) != emoji:
            return
        if payload.channel_id == board.id or payload.channel_id in config.get("star_ignored_channel_ids", []):
            return
        channel = guild.get_channel(payload.channel_id)
        if channel is None:
            return
        try:
            message = await channel.fetch_message(payload.message_id)
        except discord.HTTPException:
            return
        if message.author.bot:
            return
        count = await self.count(message, emoji)
        entries = self.store.guild(guild)
        entry = entries.get(str(message.id))
        if entry is None and count < int(config.get("star_threshold", 3)):
            return
        view = star_view(message, count, emoji)
        try:
            if entry is None:
                posted = await board.send(view=view, allowed_mentions=discord.AllowedMentions.none())
                entries[str(message.id)] = {"board": posted.id, "channel": channel.id, "author_id": message.author.id,
                                            "count": count, "t": now()}
            else:
                await board.get_partial_message(entry["board"]).edit(view=view)
                entry["count"] = count
        except discord.HTTPException:
            return
        self.store.save()

    async def count(self, message, emoji: str) -> int:
        for reaction in getattr(message, "reactions", []):
            if str(reaction.emoji) != emoji:
                continue
            n = reaction.count
            if not config.get("star_self"):
                try:
                    async for user in reaction.users():
                        if user.id == message.author.id:
                            n -= 1
                            break
                except discord.HTTPException:
                    pass
            return n
        return 0

    def dashboard_info(self, guild) -> dict:
        entries = self.store.guild(guild)
        top = sorted(entries.items(), key=lambda kv: -kv[1]["count"])[:10]
        return {"posted": len(entries), "top": [
            {"count": e["count"], "author_id": str(e["author_id"]),
             "url": f"https://discord.com/channels/{guild.id}/{e['channel']}/{mid}"} for mid, e in top]}


async def setup(bot: commands.Bot):
    await bot.add_cog(Starboard(bot))
