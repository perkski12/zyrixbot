"""
Auto-responses: when a message matches a trigger you set on the dashboard, the bot answers.
Good for "what's the IP?", "how do I join?" and other questions people ask a lot.
"""

import re
import time

import discord
from discord.ext import commands

from .wl_embed import config, use_guild, fill
from .figs import feature_on


def matches(rule: dict, text: str) -> bool:
    trigger = (rule.get("trigger") or "").lower().strip()
    if not trigger:
        return False
    how = rule.get("match", "contains")
    if how == "exact":
        return text.strip() == trigger
    if how == "starts":
        return text.startswith(trigger)
    if how == "word":
        return re.search(rf"(?<!\w){re.escape(trigger)}(?!\w)", text) is not None
    return trigger in text


class AutoResponder(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.last: dict[tuple, float] = {}

    def find(self, message) -> tuple[int, dict] | None:
        text = (message.content or "").lower()
        for i, rule in enumerate(config.get("ar_rules", [])):
            where = rule.get("channel_ids") or []
            if where and message.channel.id not in where:
                continue
            if matches(rule, text):
                return i, rule
        return None

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or message.author.bot or not message.content:
            return
        use_guild(message.guild)
        if not feature_on(config, "autoresponses"):
            return
        found = self.find(message)
        if found is None:
            return
        i, rule = found
        key = (message.guild.id, message.channel.id, i)
        t = time.monotonic()
        if t - self.last.get(key, -1e9) < int(config.get("ar_cooldown", 10)):
            return
        self.last[key] = t
        text = fill(rule["response"], message.guild, message.author)
        try:
            if rule.get("reply", True):
                await message.reply(text, mention_author=False, allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False))
            else:
                await message.channel.send(text, allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False))
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoResponder(bot))
