"""
Utility: /userinfo, /serverinfo, /avatar, /banner, /membercount, /ping, /botinfo, /say, /reminder,
/afk, /snipe and /steal.

/snipe only keeps the last deleted and the last edited message of each channel, in memory, for 10
minutes. Staff only, and it can be turned off on the dashboard (Utility page), like AFK.
"""

import asyncio
import os
import platform
import re
import time

import aiohttp
import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

from .wl_embed import config, simple_view, use_guild, accent
from .figs import feature_on
from .kit import Store, reply, send_log, now, parse_duration, duration_text

KEY_PERMS = [("administrator", "Administrator"), ("manage_guild", "Manage Server"), ("manage_roles", "Manage Roles"),
             ("manage_channels", "Manage Channels"), ("manage_messages", "Manage Messages"), ("kick_members", "Kick Members"),
             ("ban_members", "Ban Members"), ("moderate_members", "Timeout Members"), ("mention_everyone", "Mention Everyone")]
SNIPE_SECONDS = 600
MAX_REMINDERS = 25
MAX_REMIND = 365 * 86400
CUSTOM_EMOJI = re.compile(r"^<(a?):(\w{2,32}):(\d{15,22})>$")
EMOJI_NAME = re.compile(r"^\w{2,32}$")
AFK_TAG = "[AFK] "


def ts(dt) -> int | None:
    return int(dt.timestamp()) if dt else None


def card(title: str, lines: list[str], thumb: str | None = None, extra: list | None = None) -> ui.LayoutView:
    """A panel with a picture beside the title (a profile picture, a server icon)."""
    head = [ui.TextDisplay(title)] + ([ui.TextDisplay("\n".join(lines[:12])[:3900])] if lines else [])
    children = [ui.Section(*head, accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=thumb)))] if thumb else head
    view = ui.LayoutView()
    view.add_item(ui.Container(*children, *(extra or []), accent_color=accent()))
    return view


def picture(title: str, url: str, note: str | None = None) -> ui.LayoutView:
    gallery = ui.MediaGallery()
    gallery.add_item(media=url)
    view = ui.LayoutView()
    view.add_item(ui.Container(ui.TextDisplay(title), gallery, *([ui.TextDisplay(note)] if note else []), accent_color=accent()))
    return view


class Utility(commands.Cog):
    reminder_group = app_commands.Group(name="reminder", description="Get reminded about something later")

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.reminders = Store("reminders.json")
        self.afk = Store("afk.json")
        self.deleted: dict[int, dict] = {}   # channel id → the last deleted message (in memory only)
        self.edited: dict[int, dict] = {}    # channel id → the last edited message (in memory only)
        self.afk_told: dict[tuple, float] = {}

    async def cog_load(self):
        self.reminder_loop.start()

    async def cog_unload(self):
        self.reminder_loop.cancel()

    # ── info ──

    @app_commands.command(name="userinfo", description="See details about a member")
    @app_commands.describe(member="Who (you if you leave it out)")
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member | None = None):
        m = member or interaction.user
        guild = interaction.guild
        roles = sorted((r for r in getattr(m, "roles", []) if not r.is_default()), key=lambda r: -r.position)
        lines = [f"{m.mention}{'  ·  🤖 Bot' if m.bot else ''}{'  ·  👑 Server owner' if m.id == guild.owner_id else ''}",
                 f"**ID:** `{m.id}`"]
        if ts(getattr(m, "created_at", None)):
            lines.append(f"**Account made:** <t:{ts(m.created_at)}:D> (<t:{ts(m.created_at)}:R>)")
        if ts(getattr(m, "joined_at", None)):
            lines.append(f"**Joined:** <t:{ts(m.joined_at)}:D> (<t:{ts(m.joined_at)}:R>)")
        if ts(getattr(m, "premium_since", None)):
            lines.append(f"**Boosting since:** <t:{ts(m.premium_since)}:D>")
        until = getattr(m, "timed_out_until", None)
        if until and ts(until) > now():
            lines.append(f"**Timed out until:** <t:{ts(until)}:f>")
        perms = [name for key, name in KEY_PERMS if getattr(m.guild_permissions, key, False)]
        extra = [ui.Separator(), ui.TextDisplay(
            f"**Roles ({len(roles)}):** " + (" ".join(r.mention for r in roles[:25]) or "None")
            + (f" and {len(roles) - 25} more" if len(roles) > 25 else "")
            + ("\n**Key permissions:** " + ", ".join(perms) if perms else ""))]
        await interaction.response.send_message(view=card(f"## {m.display_name}", lines, m.display_avatar.url, extra),
                                                ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="serverinfo", description="See details about this server")
    async def serverinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        members = list(getattr(g, "members", []))
        bots = sum(1 for m in members if m.bot)
        voice = len(getattr(g, "voice_channels", []))
        lines = [
            f"**Owner:** <@{g.owner_id}>",
            f"**ID:** `{g.id}`",
            f"**Made:** <t:{ts(g.created_at)}:D> (<t:{ts(g.created_at)}:R>)" if ts(getattr(g, "created_at", None)) else "",
            f"**Members:** {g.member_count:,}" + (f" ({len(members) - bots:,} people, {bots:,} bots)" if members else ""),
            f"**Channels:** {len(g.text_channels)} text, {voice} voice, {len(getattr(g, 'categories', []))} categories",
            f"**Roles:** {len(g.roles) - 1}  ·  **Emojis:** {len(getattr(g, 'emojis', []))}",
            f"**Boosts:** {getattr(g, 'premium_subscription_count', 0) or 0} (level {getattr(g, 'premium_tier', 0) or 0})",
            f"**Verification:** {str(getattr(g, 'verification_level', 'none')).replace('_', ' ').title()}",
        ]
        icon = g.icon.url if getattr(g, "icon", None) else None
        await interaction.response.send_message(view=card(f"## {g.name}", [l for l in lines if l], icon),
                                                ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="avatar", description="See someone's profile picture, full size")
    @app_commands.describe(user="Whose (yours if you leave it out)", server="Their picture for this server, if they set one")
    async def avatar(self, interaction: discord.Interaction, user: discord.User | None = None, server: bool = False):
        u = user or interaction.user
        guild_avatar = getattr(u, "guild_avatar", None)
        asset = guild_avatar if (server and guild_avatar) else (getattr(u, "avatar", None) or u.display_avatar)
        url = asset.url
        note = "-# They haven't set a separate picture for this server." if server and not guild_avatar else None
        await interaction.response.send_message(view=picture(f"## {getattr(u, 'display_name', u.name)}'s picture  ·  [Open]({url})", url, note),
                                                ephemeral=True)

    @app_commands.command(name="banner", description="See someone's profile banner")
    @app_commands.describe(user="Whose (yours if you leave it out)")
    async def banner(self, interaction: discord.Interaction, user: discord.User | None = None):
        u = user or interaction.user
        try:
            full = await self.bot.fetch_user(u.id)  # banners only come with a full lookup
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't look them up", "Discord didn't answer. Try again in a moment.")
        if full.banner is None:
            color = getattr(full, "accent_color", None)
            return await reply(interaction, f"## {full.name} has no banner",
                               f"Their profile color is {color}." if color else "They haven't set one.")
        await interaction.response.send_message(view=picture(f"## {full.name}'s banner  ·  [Open]({full.banner.url})", full.banner.url),
                                                ephemeral=True)

    @app_commands.command(name="membercount", description="How many members this server has")
    async def membercount(self, interaction: discord.Interaction):
        g = interaction.guild
        members = list(getattr(g, "members", []))
        bots = sum(1 for m in members if m.bot)
        await reply(interaction, f"## 👥 {g.member_count:,} members",
                    f"{len(members) - bots:,} people and {bots:,} bots" if members else "", ephemeral=False)

    @app_commands.command(name="ping", description="Check how fast the bot is answering")
    async def ping(self, interaction: discord.Interaction):
        ms = round((self.bot.latency or 0) * 1000)
        await reply(interaction, "## 🏓 Pong", f"Discord connection: **{ms} ms**")

    @app_commands.command(name="botinfo", description="See details about this bot")
    async def botinfo(self, interaction: discord.Interaction):
        bot = self.bot
        up = int(time.time() - getattr(bot, "start_time", time.time()))
        n_cmds = sum(len(getattr(c, "commands", [])) or 1 for c in bot.tree.get_commands())
        site = os.getenv("DASHBOARD_URL", "").strip()
        lines = [
            f"**Servers:** {len(bot.guilds):,}  ·  **Members:** {sum((g.member_count or 0) for g in bot.guilds):,}",
            f"**Commands:** {n_cmds}",
            f"**Online for:** {duration_text(up)}",
            f"**Ping:** {round((bot.latency or 0) * 1000)} ms",
            f"**Running on:** Python {platform.python_version()}, discord.py {discord.__version__}",
        ]
        if site.startswith("https://"):
            lines.append(f"**Dashboard:** {site}")
        me = bot.user
        await interaction.response.send_message(view=card(f"## {me.name if me else 'Bot'}", lines,
                                                          me.display_avatar.url if me else None), ephemeral=True)

    # ── /say ──

    @app_commands.command(name="say", description="Post a message as the bot")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.describe(message="What to say (type \\n for a new line)", channel="Where (this channel if you leave it out)",
                           plain="Post plain text instead of a panel")
    async def say(self, interaction: discord.Interaction, message: app_commands.Range[str, 1, 2000],
                  channel: discord.TextChannel | None = None, plain: bool = False):
        channel = channel or interaction.channel
        mine = channel.permissions_for(interaction.user)
        if not (mine.view_channel and mine.send_messages):
            return await reply(interaction, "## You can't post there", f"You don't have permission to send messages in {channel.mention}.")
        text = message.replace("\\n", "\n")
        pings = discord.AllowedMentions(everyone=mine.mention_everyone, roles=mine.mention_everyone, users=True)
        try:
            if plain:
                sent = await channel.send(text, allowed_mentions=pings)
            else:
                sent = await channel.send(view=simple_view(text), allowed_mentions=pings)
        except discord.HTTPException:
            return await reply(interaction, "## Couldn't post it", f"I can't send messages in {channel.mention}.")
        await send_log(interaction.guild, "mod_log_channel_id", "## 🗣️ /say",
                       f"{interaction.user.mention} posted in {channel.mention}", text[:1000])
        await reply(interaction, "## Posted", getattr(sent, "jump_url", None) or channel.mention)

    # ── reminders ──

    def book(self, guild) -> dict:
        return self.reminders.guild(guild, lambda: {"next": 1, "items": []})

    @reminder_group.command(name="set", description="Get reminded about something later")
    @app_commands.describe(when="In how long, like 10m, 2h, 1d or 1w", message="What to remind you about",
                           dm="Send it in your DMs instead of this channel")
    async def reminder_set(self, interaction: discord.Interaction, when: str, message: app_commands.Range[str, 1, 1000],
                           dm: bool = False):
        seconds = parse_duration(when)
        if not seconds or seconds < 60 or seconds > MAX_REMIND:
            return await reply(interaction, "## That isn't a time I can use", "Use something like `10m`, `2h`, `1d` or `1w` (1 minute to 1 year).")
        book = self.book(interaction.guild)
        mine = [r for r in book["items"] if r["user_id"] == interaction.user.id]
        if len(mine) >= MAX_REMINDERS:
            return await reply(interaction, "## That's a lot of reminders", f"You can have {MAX_REMINDERS} at once. Cancel one with `/reminder cancel`.")
        at = now() + seconds
        item = {"id": book["next"], "user_id": interaction.user.id, "channel_id": interaction.channel.id,
                "at": at, "text": message, "dm": dm, "set": now()}
        book["next"] += 1
        book["items"].append(item)
        self.reminders.save()
        await reply(interaction, f"## ⏰ Reminder #{item['id']} set",
                    f"<t:{at}:f> (<t:{at}:R>){' in your DMs' if dm else ''}: {message}")

    @reminder_group.command(name="list", description="See your reminders")
    async def reminder_list(self, interaction: discord.Interaction):
        mine = sorted((r for r in self.book(interaction.guild)["items"] if r["user_id"] == interaction.user.id), key=lambda r: r["at"])
        if not mine:
            return await reply(interaction, "## No reminders", "Set one with `/reminder set`.")
        lines = "\n".join(f"**#{r['id']}** <t:{r['at']}:R>: {r['text'][:120]}" for r in mine)
        await reply(interaction, f"## Your reminders ({len(mine)})", lines[:3900], "-# Cancel one with `/reminder cancel`.")

    @reminder_group.command(name="cancel", description="Cancel one of your reminders")
    @app_commands.describe(number="Its number, from /reminder list")
    async def reminder_cancel(self, interaction: discord.Interaction, number: int):
        book = self.book(interaction.guild)
        item = next((r for r in book["items"] if r["id"] == number and r["user_id"] == interaction.user.id), None)
        if item is None:
            return await reply(interaction, "## No such reminder", f"You don't have a reminder #{number}. See yours with `/reminder list`.")
        book["items"].remove(item)
        self.reminders.save()
        await reply(interaction, "## Reminder cancelled", item["text"][:500])

    @tasks.loop(seconds=30)
    async def reminder_loop(self):
        await self.send_reminders()

    @reminder_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def send_reminders(self, at: int | None = None) -> int:
        at, sent = at or now(), 0
        for gid, book in list(self.reminders.data.items()):
            guild = self.bot.get_guild(int(gid))
            if guild is None:
                continue
            due = [r for r in book["items"] if r["at"] <= at]
            for r in due:
                book["items"].remove(r)
                use_guild(guild)
                view = simple_view(f"## ⏰ Reminder for <@{r['user_id']}>", r["text"], f"-# You set this <t:{r['set']}:R>")
                ping = discord.AllowedMentions(everyone=False, roles=False, users=[discord.Object(id=r["user_id"])])
                channel = guild.get_channel(r["channel_id"])
                delivered = False
                if not r.get("dm") and channel is not None:
                    try:
                        await channel.send(view=view, allowed_mentions=ping)
                        delivered = True
                    except discord.HTTPException:
                        pass  # can't post there anymore: try their DMs
                if not delivered:
                    user = guild.get_member(r["user_id"]) or self.bot.get_user(r["user_id"])
                    try:
                        if user is not None:
                            await user.send(view=view)
                            delivered = True
                    except discord.HTTPException:
                        pass  # their DMs are closed and the channel is gone: nothing more to do
                sent += delivered
            if due:
                self.reminders.save()
        return sent

    # ── AFK ──

    @app_commands.command(name="afk", description="Let people know you're away when they mention you")
    @app_commands.describe(reason="What you're up to (shown when someone mentions you)")
    async def afk_cmd(self, interaction: discord.Interaction, reason: app_commands.Range[str, 1, 200] = "AFK"):
        if not config.get("util_afk", True):
            return await reply(interaction, "## AFK is turned off here", "The server turned it off on the dashboard.")
        member = interaction.user
        # Already AFK (a new reason): keep the nickname they had before going AFK the first time
        before = (self.afk.data.get(str(interaction.guild.id)) or {}).get(str(member.id))
        nicked = bool(before and before.get("nick"))
        old_nick = before.get("old_nick") if before else getattr(member, "nick", None)
        if not nicked and config.get("util_afk_nick", True) and not member.display_name.startswith(AFK_TAG):
            try:
                await member.edit(nick=(AFK_TAG + member.display_name)[:32], reason="AFK")
                nicked = True
            except (discord.HTTPException, AttributeError):
                pass  # the owner, or someone above the bot: their name stays
        self.afk.guild(interaction.guild)[str(member.id)] = {"reason": reason, "t": now(), "nick": nicked, "old_nick": old_nick}
        self.afk.save()
        await reply(interaction, f"## 💤 {member.display_name.removeprefix(AFK_TAG)} is AFK", reason, ephemeral=False)

    async def end_afk(self, message):
        book = self.afk.data.get(str(message.guild.id)) or {}
        entry = book.pop(str(message.author.id), None)
        if entry is None:
            return
        self.afk.save()
        if entry.get("nick") and message.author.display_name.startswith(AFK_TAG):
            try:  # the nickname they had before (none at all if they had none)
                await message.author.edit(nick=entry.get("old_nick"), reason="Back from AFK")
            except (discord.HTTPException, AttributeError):
                pass
        try:
            await message.channel.send(view=simple_view(f"Welcome back {message.author.display_name.removeprefix(AFK_TAG)}, I removed your AFK.",
                                                        f"-# You were away for {duration_text(now() - entry['t'])}"),
                                       delete_after=10, allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or message.author.bot:
            return
        book = self.afk.data.get(str(message.guild.id))
        if not book:
            return
        use_guild(message.guild)
        if not feature_on(config, "utility") or not config.get("util_afk", True):
            return
        entry = book.get(str(message.author.id))
        if entry and now() - entry["t"] > 5:
            await self.end_afk(message)
        told = []
        for user in message.mentions[:5]:
            away = book.get(str(user.id))
            if not away or user.id == message.author.id:
                continue
            key = (message.channel.id, user.id)
            if time.monotonic() - self.afk_told.get(key, 0) < 30:
                continue  # said it here a moment ago
            self.afk_told[key] = time.monotonic()
            name = getattr(user, "display_name", user.name).removeprefix(AFK_TAG)
            told.append(f"💤 **{name}** is AFK: {away['reason']}  ·  <t:{away['t']}:R>")
        if told:
            try:
                await message.channel.send(view=simple_view("\n".join(told)), delete_after=20,
                                           allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                pass

    # ── snipe ──

    def _snipe_on(self, message) -> bool:
        if message.guild is None or message.author.bot:
            return False
        use_guild(message.guild)
        return feature_on(config, "utility") and config.get("util_snipe", True)

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if not self._snipe_on(message) or not (message.content or message.attachments):
            return
        self.deleted[message.channel.id] = {
            "author_id": message.author.id, "author": message.author.display_name, "avatar": message.author.display_avatar.url,
            "content": (message.content or "")[:1500], "files": [a.filename for a in message.attachments][:5], "t": now()}

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if not self._snipe_on(after) or before.content == after.content or not before.content:
            return
        self.edited[after.channel.id] = {
            "author_id": after.author.id, "author": after.author.display_name, "avatar": after.author.display_avatar.url,
            "before": before.content[:1500], "after": (after.content or "")[:1500], "t": now(), "url": after.jump_url}

    @app_commands.command(name="snipe", description="See the last deleted (or edited) message in this channel")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.describe(edited="Show the last edited message instead")
    async def snipe(self, interaction: discord.Interaction, edited: bool = False):
        if not config.get("util_snipe", True):
            return await reply(interaction, "## Snipe is turned off here", "The server turned it off on the dashboard.")
        found = (self.edited if edited else self.deleted).get(interaction.channel.id)
        if not found or now() - found["t"] > SNIPE_SECONDS:
            return await reply(interaction, "## Nothing to snipe",
                               f"No message was {'edited' if edited else 'deleted'} here in the last {SNIPE_SECONDS // 60} minutes.")
        if edited:
            lines = [f"<@{found['author_id']}>  ·  <t:{found['t']}:R>  ·  [Jump]({found['url']})",
                     f"**Before:** {found['before']}", f"**After:** {found['after'] or '(empty)'}"]
        else:
            lines = [f"<@{found['author_id']}>  ·  <t:{found['t']}:R>", found["content"] or "(no text)"]
            if found["files"]:
                lines.append("-# Files: " + ", ".join(found["files"]))
        await interaction.response.send_message(
            view=card(f"## {'✏️ Edited' if edited else '🗑️ Deleted'} by {found['author']}", lines, found["avatar"]),
            ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    # ── /steal ──

    @app_commands.command(name="steal", description="Add an emoji from another server to this one")
    @app_commands.default_permissions(manage_emojis=True)
    @app_commands.describe(emoji="Paste the custom emoji (needs Nitro to paste emojis from other servers)",
                           name="A name for it here (keeps its name if you leave it out)")
    async def steal(self, interaction: discord.Interaction, emoji: str, name: str | None = None):
        m = CUSTOM_EMOJI.match(emoji.strip())
        if not m:
            return await reply(interaction, "## That isn't a custom emoji",
                               "Paste a server emoji, like `<:name:123456789012345678>`. Normal emojis already work everywhere.")
        animated, old_name, eid = m.group(1) == "a", m.group(2), m.group(3)
        name = (name or old_name).strip().replace(" ", "_")
        if not EMOJI_NAME.match(name):
            return await reply(interaction, "## That name won't work", "Use 2-32 letters, numbers or underscores.")
        await interaction.response.defer(ephemeral=True, thinking=True)
        url = f"https://cdn.discordapp.com/emojis/{eid}.{'gif' if animated else 'png'}?size=128&quality=lossless"
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as http:
                async with http.get(url) as r:
                    if r.status != 200:
                        return await reply(interaction, "## Couldn't get that emoji", "Discord didn't have it. It may have been deleted.")
                    image = await r.read()
        except (aiohttp.ClientError, asyncio.TimeoutError):
            return await reply(interaction, "## Couldn't get that emoji", "Discord didn't answer. Try again in a moment.")
        if len(image) > 256 * 1024:
            return await reply(interaction, "## That emoji is too big", "Discord takes emojis up to 256 KB.")
        try:
            made = await interaction.guild.create_custom_emoji(name=name, image=image, reason=f"/steal by {interaction.user}")
        except discord.Forbidden:
            return await reply(interaction, "## I can't add emojis", "I need the **Manage Expressions** permission (Create Expressions).")
        except discord.HTTPException as e:
            full = getattr(e, "code", 0) == 30008 or "maximum" in str(e).lower()
            return await reply(interaction, "## Couldn't add it",
                               "This server has no free emoji slots left." if full else f"Discord said: {getattr(e, 'text', '') or e}")
        await reply(interaction, f"## Added {made}", f"`:{made.name}:` is ready to use here.")

    # ── dashboard ──

    def dashboard_info(self, guild) -> dict:
        return {
            "afk": len(self.afk.data.get(str(guild.id)) or {}),
            "reminders": len((self.reminders.data.get(str(guild.id)) or {}).get("items", [])),
        }


async def setup(bot: commands.Bot):
    await bot.add_cog(Utility(bot))
