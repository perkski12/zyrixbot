import discord
from discord.ext import commands
from discord import ui

from .wl_embed import config, accent, fill, use_guild, simple_view
from .figs import feature_on


def build_welcome_view(member: discord.Member) -> ui.LayoutView:
    """The welcome message (edited on the dashboard, Welcome page)."""
    guild = member.guild
    thumbnail_url = config.get("thumbnail_url", "")
    banner_url = config.get("banner_url", "")

    title = fill(config.get("welcome_title") or "Welcome To {server}", guild, member)
    body = fill(config.get("welcome_message") or "", guild, member)
    header = [ui.TextDisplay(f"## {title}")]
    if body:
        header.append(ui.TextDisplay(body))

    children = []

    # Header: title + thumbnail side by side
    if thumbnail_url and str(thumbnail_url).startswith("http"):
        children.append(ui.Section(
            *header,
            accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=thumbnail_url), description="Server thumbnail")
        ))
    else:
        children.extend(header)

    children.append(ui.Separator())

    # Banner image
    if banner_url and str(banner_url).startswith("http"):
        gallery = ui.MediaGallery()
        gallery.add_item(media=banner_url, description="Server banner")
        children.append(gallery)
        children.append(ui.Separator())

    # Channel links
    links = [f"- <#{cid}>" for cid in config.get("welcome_links", []) if cid]
    if links:
        children.append(ui.TextDisplay("\n".join(links)))

    footer = config.get("welcome_footer", "")
    if footer:
        children.append(ui.Separator(visible=False))
        children.append(ui.TextDisplay(f"-# {fill(footer, guild, member)}"))

    view = ui.LayoutView()
    view.add_item(ui.Container(*children, accent_color=accent()))
    return view


async def send_welcome(member: discord.Member, channel: discord.abc.Messageable | None = None) -> discord.Message | None:
    """Post the welcome message for `member` (in the welcome channel unless another channel is given)."""
    use_guild(member.guild)
    if channel is None:
        channel = member.guild.get_channel(config.get("welcome_channel_id") or 0)
    if channel is None:
        return None
    return await channel.send(view=build_welcome_view(member))


class Welcome(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        use_guild(member.guild)
        if not feature_on(config, "welcome"):
            return
        await self.give_join_roles(member)
        if config.get("welcome_dm") and not member.bot:
            try:
                await member.send(view=simple_view(fill(config["welcome_dm"], member.guild, member)))
            except (discord.HTTPException, AttributeError):
                pass  # their DMs are closed
        if not config.get("welcome_enabled", True) or not config.get("welcome_channel_id"):
            return
        try:
            await send_welcome(member)
        except Exception as e:
            print(f"[Welcome] Couldn't send welcome for {member}: {e}")

    async def give_join_roles(self, member: discord.Member):
        ids = config.get("join_bot_role_ids" if member.bot else "join_role_ids", [])
        roles = [r for r in (member.guild.get_role(i) for i in ids) if r is not None and r.is_assignable()]
        if roles:
            try:
                await member.add_roles(*roles, reason="Join roles")
            except discord.HTTPException as e:
                print(f"[Welcome] Couldn't give join roles to {member}: {e}")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        use_guild(member.guild)
        if not feature_on(config, "welcome") or not config.get("goodbye_enabled"):
            return
        channel = member.guild.get_channel(config.get("goodbye_channel_id") or 0)
        text = fill(config.get("goodbye_message") or "", member.guild, member)
        if channel is None or not text:
            return
        try:
            await channel.send(view=simple_view(text), allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(Welcome(bot))
