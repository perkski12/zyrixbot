import datetime

import discord
from discord import app_commands, ui
from discord.ext import commands

from .wl_embed import config, save_config, simple_view, city_emoji, accent, use_guild
from .figs import feature_on

DEFAULT_MESSAGE = (
    "You were caught by the honeypot in **{server}**. "
    "That channel is a trap for spam bots and hacked accounts."
)

# action key → (label, description shown in the menu)
ACTIONS = {
    "softban": ("Softban", "Ban + unban: wipes their last 24h of messages, they can rejoin"),
    "kick": ("Kick", "Removes them from the server, they can rejoin"),
    "ban": ("Ban", "Permanent ban, wipes their last 24h of messages"),
    "timeout_60": ("Timeout (1 hour)", "Mutes them for 1 hour, they stay in the server"),
    "timeout_1440": ("Timeout (1 day)", "Mutes them for 1 day, they stay in the server"),
    "timeout_10080": ("Timeout (1 week)", "Mutes them for 1 week, they stay in the server"),
}

# permission the bot needs for each kind of action
NEEDED_PERM = {"softban": "ban_members", "ban": "ban_members", "kick": "kick_members", "timeout": "moderate_members"}


def _action() -> str:
    action = str(config.get("honeypot_action", "softban")).lower()
    return action if action in ACTIONS else "softban"


def _catches() -> int:
    return int(config.get("honeypot_catches", 0))


# ──────────────────────────── settings menu ─────────────────────────────────

class BanMessageModal(ui.Modal, title="Ban Message"):
    def __init__(self, menu: "HoneypotMenu"):
        super().__init__()
        self.menu = menu
        self.text = ui.TextInput(
            label="Message sent to them before they're removed",
            style=discord.TextStyle.paragraph,
            default=config.get("honeypot_message", DEFAULT_MESSAGE),
            placeholder="Leave empty to send no message. {server} = your server name",
            required=False,
            max_length=1000
        )
        self.add_item(self.text)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)  # this server's settings for the form
        return True

    async def on_submit(self, interaction: discord.Interaction):
        config["honeypot_message"] = self.text.value.strip()
        save_config()
        self.menu.build()
        await interaction.response.edit_message(view=self.menu)


class HoneypotMenu(ui.LayoutView):
    def __init__(self, cog: "Honeypot", guild: discord.Guild):
        super().__init__(timeout=600)
        self.cog = cog
        self.guild = guild
        self.build()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        use_guild(interaction.guild)  # this server's settings for every button and menu
        return True

    def build(self):
        self.clear_items()
        guild = self.guild

        trap = guild.get_channel(config.get("honeypot_channel_id") or 0)
        log = guild.get_channel(config.get("honeypot_log_channel_id") or 0)
        main_log = guild.get_channel(config.get("log_channel_id") or 0)
        action = _action()
        message = config.get("honeypot_message", DEFAULT_MESSAGE)

        if log:
            log_text = log.mention
        elif main_log:
            log_text = f"{main_log.mention} (main log channel)"
        else:
            log_text = "Not set"

        details = (
            f"**Status:** {'On' if trap else 'Off, pick a trap channel to turn it on'}\n"
            f"**Trap Channel:** {trap.mention if trap else 'Not set'}\n"
            f"**Log Channel:** {log_text}\n"
            f"**Action:** {ACTIONS[action][0]}\n"
            f"**Total Caught:** **{_catches()}**"
        )

        perm = NEEDED_PERM["timeout" if action.startswith("timeout") else action]
        if not getattr(guild.me.guild_permissions, perm):
            details += f"\n\n**Heads up:** I need the **{perm.replace('_', ' ').title()}** permission for this action."

        ban_text = f"**Ban Message:**\n-# Sent to them before they're removed\n>>> {message}" if message \
            else "**Ban Message:** Off, no message is sent"

        # Dropdowns
        trap_select = ui.ChannelSelect(
            channel_types=[discord.ChannelType.text],
            placeholder="Pick the trap channel",
            default_values=[trap] if trap else []
        )
        log_select = ui.ChannelSelect(
            channel_types=[discord.ChannelType.text],
            placeholder="Pick the log channel",
            default_values=[log] if log else []
        )
        action_select = ui.Select(
            placeholder="Pick what happens to them",
            options=[
                discord.SelectOption(label=label, value=key, description=desc, default=(key == action))
                for key, (label, desc) in ACTIONS.items()
            ]
        )

        async def on_trap(interaction: discord.Interaction):
            channel_id = trap_select.values[0].id
            config["honeypot_channel_id"] = channel_id
            save_config()
            channel = guild.get_channel(channel_id)
            if channel:
                await self.cog.post_warning(channel)
            self.build()
            await interaction.response.edit_message(view=self)

        async def on_log(interaction: discord.Interaction):
            config["honeypot_log_channel_id"] = log_select.values[0].id
            save_config()
            self.build()
            await interaction.response.edit_message(view=self)

        async def on_action(interaction: discord.Interaction):
            config["honeypot_action"] = action_select.values[0]
            save_config()
            await self.cog.update_warning(guild)
            self.build()
            await interaction.response.edit_message(view=self)

        trap_select.callback = on_trap
        log_select.callback = on_log
        action_select.callback = on_action

        # Buttons
        edit_btn = ui.Button(label="Edit Ban Message", style=discord.ButtonStyle.primary)
        repost_btn = ui.Button(label="Repost Warning", style=discord.ButtonStyle.secondary, disabled=not trap)
        off_btn = ui.Button(label="Turn Off", style=discord.ButtonStyle.danger, disabled=not trap)

        async def on_edit(interaction: discord.Interaction):
            await interaction.response.send_modal(BanMessageModal(self))

        async def on_repost(interaction: discord.Interaction):
            if trap:
                await self.cog.post_warning(trap)
            self.build()
            await interaction.response.edit_message(view=self)

        async def on_off(interaction: discord.Interaction):
            config["honeypot_channel_id"] = None
            save_config()
            self.build()
            await interaction.response.edit_message(view=self)

        edit_btn.callback = on_edit
        repost_btn.callback = on_repost
        off_btn.callback = on_off

        thumb = config.get("thumbnail_url", "")
        header_lines = (
            ui.TextDisplay(f"## {city_emoji()} Honeypot Settings"),
            ui.TextDisplay("Anyone (except staff) who types in the trap channel gets caught."),
        )
        header = (
            ui.Section(*header_lines, accessory=ui.Thumbnail(
                media=discord.UnfurledMediaItem(url=thumb), description="Server thumbnail"))
            if thumb and str(thumb).startswith("http") else None
        )

        children = [header] if header else list(header_lines)
        children += [
            ui.Separator(),
            ui.TextDisplay(details),
            ui.TextDisplay(ban_text),
            ui.Separator(),
            ui.TextDisplay("-# Trap channel"),
            ui.ActionRow(trap_select),
            ui.TextDisplay("-# Log channel"),
            ui.ActionRow(log_select),
            ui.TextDisplay("-# Action"),
            ui.ActionRow(action_select),
            ui.ActionRow(edit_btn, repost_btn, off_btn),
        ]
        self.add_item(ui.Container(*children, accent_color=accent()))


# ──────────────────────────── cog ───────────────────────────────────────────

class Honeypot(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── warning message in the trap channel (shows the catch count) ──

    def _warning_view(self) -> ui.LayoutView:
        result = "timed out" if _action().startswith("timeout") else "removed from the server"
        return simple_view(
            f"## {city_emoji()} Do Not Type Here",
            "This channel is a trap for spam bots and hacked accounts.\n"
            f"Anyone who sends a message here is **automatically {result}**.",
            f"-# {_catches()} caught so far"
        )

    async def post_warning(self, channel: discord.TextChannel) -> bool:
        try:
            msg = await channel.send(view=self._warning_view())
            config["honeypot_warning_message_id"] = msg.id
            save_config()
            return True
        except discord.HTTPException:
            return False

    async def update_warning(self, guild: discord.Guild):
        channel = guild.get_channel(config.get("honeypot_channel_id") or 0)
        msg_id = config.get("honeypot_warning_message_id")
        if channel and msg_id:
            try:
                await channel.get_partial_message(msg_id).edit(view=self._warning_view())
            except discord.HTTPException:
                pass

    # ── /honeypot ──

    @app_commands.command(name="honeypot", description="Open the honeypot settings")
    @app_commands.default_permissions(administrator=True)
    async def honeypot(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=HoneypotMenu(self, interaction.guild), ephemeral=True)

    # ── catching ──

    def _log_view(self, member: discord.Member, message: discord.Message,
                  action: str, success: bool) -> ui.LayoutView:
        ts = int(discord.utils.utcnow().timestamp())

        typed = (message.content or "(no text)").replace("```", "'''")
        if len(typed) > 500:
            typed = typed[:500] + "…"
        if message.attachments:
            typed += f"\n+ {len(message.attachments)} attachment(s)"

        joined = discord.utils.format_dt(member.joined_at, "R") if member.joined_at else "Unknown"
        label = ACTIONS[action][0]
        result = label if success else f"Failed ({label}), check my role and permissions"
        title = f"## Honeypot Catch #{_catches()}" if success else "## Honeypot Failed"

        view = ui.LayoutView()
        view.add_item(ui.Container(
            ui.Section(
                ui.TextDisplay(title),
                ui.TextDisplay(f"{member.mention} typed in {message.channel.mention}"),
                accessory=ui.Thumbnail(
                    media=discord.UnfurledMediaItem(url=member.display_avatar.url),
                    description="User avatar"
                )
            ),
            ui.Separator(),
            ui.TextDisplay(
                f"**User:** {member.mention} (`{member}`)\n"
                f"**User ID:** `{member.id}`\n"
                f"**Action:** {result}\n"
                f"**Account Created:** {discord.utils.format_dt(member.created_at, 'R')}\n"
                f"**Joined Server:** {joined}\n"
                f"**Time:** <t:{ts}:F>"
            ),
            ui.TextDisplay(f"**What They Typed:**\n```\n{typed}\n```"),
            ui.Separator(visible=False),
            ui.TextDisplay(f"-# {message.guild.name}"),
            accent_color=accent()
        ))
        return view

    async def _catch(self, message: discord.Message):
        member = message.author
        if not isinstance(member, discord.Member) or member.guild_permissions.manage_messages:
            return  # never touch staff

        guild = message.guild
        action = _action()
        reason = "Honeypot: typed in the trap channel"

        # DM them first (can't message them once they're gone)
        text = config.get("honeypot_message", DEFAULT_MESSAGE)
        if text:
            try:
                await member.send(text.replace("{server}", guild.name))
            except discord.HTTPException:
                pass

        success = True
        try:
            if action == "ban":
                await member.ban(reason=reason, delete_message_seconds=86400)
            elif action == "softban":
                await member.ban(reason=reason, delete_message_seconds=86400)
                await guild.unban(member, reason="Honeypot softban")
            else:
                try:
                    await message.delete()
                except discord.HTTPException:
                    pass
                if action == "kick":
                    await member.kick(reason=reason)
                else:  # timeout_<minutes>
                    minutes = int(action.split("_")[1])
                    await member.timeout(datetime.timedelta(minutes=minutes), reason=reason)
        except discord.HTTPException:
            success = False

        if success:
            config["honeypot_catches"] = _catches() + 1
            save_config()
            await self.update_warning(guild)

        log_id = config.get("honeypot_log_channel_id") or config.get("log_channel_id") or 0
        log_channel = guild.get_channel(log_id)
        if log_channel:
            try:
                await log_channel.send(
                    view=self._log_view(member, message, action, success),
                    allowed_mentions=discord.AllowedMentions.none()
                )
            except discord.HTTPException:
                pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        use_guild(message.guild)
        if feature_on(config, "honeypot") and message.channel.id == config.get("honeypot_channel_id"):
            await self._catch(message)


async def setup(bot: commands.Bot):
    await bot.add_cog(Honeypot(bot))
