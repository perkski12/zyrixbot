@echo off
setlocal
title Bot Dashboard

rem ==========================================================================
rem  Opens the bot's dashboard on this PC while the bot runs on your VPS.
rem
rem  1. It tries the direct link first (http://YOUR-VPS-IP:8080). That works when the
rem     bot's .env has DASHBOARD_HOST=auto (the default) and port 8080 is open.
rem  2. If that doesn't answer, it makes a private, encrypted SSH connection instead
rem     and opens the dashboard at http://localhost:8080 on this PC (Linux VPS only).
rem     If a program on this PC already uses 8080 (Steam does), it uses 8081 or the next free one.
rem
rem  Copy this file to your PC (your Desktop is fine) and double-click it.
rem ==========================================================================

rem Change this only if you changed DASHBOARD_PORT in the bot's .env file
set "PORT=8080"

set "SAVED=%~dp0dashboard-vps.txt"
if exist "%SAVED%" set /p VPS=<"%SAVED%"
if defined VPS goto parse

echo.
echo   What's your VPS's IP address? Type it like:  123.45.67.89
echo   (Your host's control panel shows it. If you log in with SSH, you can type the
echo   login instead, like root@123.45.67.89.)
echo   It's remembered, so you only type it once. Delete dashboard-vps.txt to change it.
echo.
set /p "VPS=  VPS IP: "
if not defined VPS goto end
>"%SAVED%" echo %VPS%

:parse
rem The IP is the part after the @, if there is one
set "HOST=%VPS%"
for /f "tokens=2 delims=@" %%a in ("%VPS%") do set "HOST=%%a"

echo.
echo   Checking http://%HOST%:%PORT% ...
powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try { $ok=$c.ConnectAsync('%HOST%',%PORT%).Wait(4000) } catch { $ok=$false }; if ($ok -and $c.Connected) { exit 0 } else { exit 1 }"
if errorlevel 1 goto tunnel

echo   The dashboard answered. Opening it in your browser.
start "" "http://%HOST%:%PORT%"
timeout /t 3 >nul
goto end

:tunnel
echo   No answer on the direct link. That means the VPS firewall blocks port %PORT%,
echo   the bot isn't running, or its .env has DASHBOARD_HOST=127.0.0.1.
echo   Trying an SSH connection instead (needs a Linux VPS)...

where ssh >nul 2>nul
if not errorlevel 1 goto have_ssh
echo.
echo   This PC doesn't have SSH yet. Open Settings, go to Apps, Optional features,
echo   click "View features", add "OpenSSH Client", then run this file again.
echo   Or open port %PORT% in the VPS firewall so the direct link works (see README.md).
echo.
pause
goto end

:have_ssh
echo %VPS%| find "@" >nul
if not errorlevel 1 goto have_login
set "VUSER=root"
set /p "VUSER=  Your VPS username (press Enter for root): "
set "VPS=%VUSER%@%HOST%"
>"%SAVED%" echo %VPS%

:have_login
rem Port on this PC for the connection: %PORT% unless something here already uses it
rem (Steam's web debugger sits on 8080, and the browser would open Steam instead)
set "LPORT=%PORT%"
for /f %%p in ('powershell -NoProfile -Command "$p=%PORT%; while($p -lt %PORT%+20){$c=New-Object Net.Sockets.TcpClient; try{$c.Connect([Net.IPAddress]::Loopback,$p); $c.Close(); $p++}catch{break}}; $p"') do set "LPORT=%%p"
if not "%LPORT%"=="%PORT%" echo   Port %PORT% is busy on this PC (Steam often uses it), so the dashboard opens at http://localhost:%LPORT%
if not "%LPORT%"=="%PORT%" echo   For Login with Discord, add http://localhost:%LPORT%/callback under OAuth2, Redirects.

echo.
echo   Connecting to %VPS% ...
echo   - The first time, it may ask "Are you sure you want to continue connecting?" Type yes.
echo   - If it asks for a password, type your VPS password. Nothing shows while you type. Press Enter.
echo   - The dashboard opens in your browser once the connection is up.
echo   - Keep this window open while you use the dashboard. Close it when you're done.
echo.

rem Open the browser as soon as the connection works (waits up to 2 minutes)
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 120;$i++){try{$c=New-Object Net.Sockets.TcpClient('127.0.0.1',%LPORT%);$c.Close();Start-Sleep 1;Start-Process 'http://localhost:%LPORT%';break}catch{Start-Sleep 1}}"

ssh -N -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 -L %LPORT%:127.0.0.1:%PORT% %VPS%

echo.
echo   The connection closed.
echo   If that wasn't you: check the VPS login, check that the bot is running on the VPS,
echo   and make sure nothing else on this PC is using port %LPORT%.
echo   Windows VPS? SSH usually isn't set up there. Open port %PORT% in Windows Firewall
echo   on the VPS instead (the bot's console shows the command), then run this file again.
echo.
pause

:end
endlocal
